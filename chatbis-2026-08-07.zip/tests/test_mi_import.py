"""Exception-MI import over real HTTP: upload the extract, confirm the
column mapping (including the message-language column), and see the
numbers AND the message land on the dashboard and the code's page."""
import tempfile
import threading
import unittest
import urllib.parse
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from chatbis import db
from chatbis.server import Handler

CSV = (
    "Application,Exception Code,Period,Number of Occurrences,Message Language\n"
    "CLAIMS,E7701,2026-06,14,CLAIM REJECTED - DOB AFTER EFFECTIVE DATE\n"
    "CLAIMS,E7701,2026-07,9,CLAIM REJECTED - DOB AFTER EFFECTIVE DATE\n"
    "ENROLL,E8802,2026-07,3,ENROLLMENT INCOMPLETE - PLAN CODE BLANK\n"
)


class MiImportFlow(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.db_path = str(Path(cls.tmp.name) / "t.db")
        db.connect(cls.db_path).close()          # create schema
        Handler.db_path = cls.db_path
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.httpd.server_address[1]
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.tmp.cleanup()

    def get(self, path):
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}{path}") as r:
            return r.read().decode()

    def post(self, path, fields: dict):
        body = urllib.parse.urlencode(fields).encode()
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}{path}", body) as r:
            return r.read().decode()

    def upload(self, filename, text):
        boundary = "XBOUNDX"
        body = (f"--{boundary}\r\n"
                f'Content-Disposition: form-data; name="file"; '
                f'filename="{filename}"\r\n'
                f"Content-Type: text/csv\r\n\r\n{text}\r\n"
                f"--{boundary}--\r\n").encode()
        req = urllib.request.Request(
            f"http://127.0.0.1:{self.port}/mi/upload", body,
            headers={"Content-Type":
                     f"multipart/form-data; boundary={boundary}"})
        with urllib.request.urlopen(req) as r:
            return r.read().decode()

    def test_full_import_carries_the_message_language(self):
        # 1 · upload — the mapping screen proposes the message column
        html = self.upload("mi-june.csv", CSV)
        self.assertIn("Message column", html)
        self.assertIn("Message Language", html)

        # 2 · confirm the mapping, message column included
        html = self.post("/mi/import", {
            "file": "mi-june.csv", "code_col": 1, "period_col": 2,
            "count_col": 3, "application_col": 0, "message_col": 4})
        self.assertIn("Imported 3 rows", html)

        # 3 · dashboard: the MI table grows a Message column with the text
        dash = self.get("/dash")
        self.assertIn("<th>Message</th>", dash)
        self.assertIn("CLAIM REJECTED - DOB AFTER EFFECTIVE DATE", dash)

        # 4 · the message is filterable like every other MI column
        #     (assert on message text — the code itself also legitimately
        #     appears in the dashboard's Hottest-codes card)
        hit = self.get("/dash?mq=REJECTED")
        self.assertIn("CLAIM REJECTED - DOB AFTER EFFECTIVE DATE", hit)
        self.assertNotIn("ENROLLMENT INCOMPLETE", hit)

        # 5 · the code page shows the message language as production
        #     prints it
        page = self.get("/x/E7701")
        self.assertIn("CLAIM REJECTED - DOB AFTER EFFECTIVE DATE", page)
        self.assertIn("from the MI extract", page)
        self.assertIn("Occurrences by period", page)

    def test_import_without_message_column_stays_four_wide(self):
        self.upload("mi-plain.csv",
                    "Code,Period,Count\nE9903,2026-07,5\n")
        self.post("/mi/import", {"file": "mi-plain.csv", "code_col": 0,
                                 "period_col": 1, "count_col": 2,
                                 "application_col": -1, "message_col": -1})
        dash = self.get("/dash?mq=E9903")
        self.assertIn("E9903", dash)
        # no message anywhere in this filtered view → no empty column
        page = self.get("/x/E9903")
        self.assertIn("Occurrences by period", page)
        self.assertNotIn("from the MI extract", page)


if __name__ == "__main__":
    unittest.main()
