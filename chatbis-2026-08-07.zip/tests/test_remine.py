"""Force re-mine: unchanged files re-derive after a miner upgrade.

The unchanged-file skip is right for everyday ingest and wrong after a
ChatBIS upgrade — the same bytes now yield better facets. force=True
(CLI --force, web ↻ Re-mine) bypasses the skip and rides the existing
delete+re-derive path, so nothing duplicates."""
import tempfile
import unittest
from pathlib import Path

from chatbis import db
from chatbis.ingest import ingest_paths

COBOL = """\
       IDENTIFICATION DIVISION.
       PROGRAM-ID. REMINE1.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01 WS-AMT PIC S9(5)V99.
       PROCEDURE DIVISION.
       MAIN-PARA.
           IF WS-AMT = ZERO
              DISPLAY 'E1234 AMT MISSING'
           END-IF.
           STOP RUN.
"""


class ForceRemine(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.conn = db.connect(str(Path(self.tmp.name) / "t.db"))
        self.src = Path(self.tmp.name) / "REMINE1.cbl"
        self.src.write_text(COBOL)

    def tearDown(self):
        self.conn.close()
        self.tmp.cleanup()

    def counts(self):
        facets = self.conn.execute(
            "SELECT COUNT(*) FROM program_facet").fetchone()[0]
        items = self.conn.execute(
            "SELECT COUNT(*) FROM data_item").fetchone()[0]
        progs = self.conn.execute(
            "SELECT COUNT(*) FROM program").fetchone()[0]
        return facets, items, progs

    def test_unchanged_skips_without_force_and_remines_with(self):
        first = ingest_paths(self.conn, [self.src])
        self.assertNotIn("skipped", first[0])
        base = self.counts()
        self.assertGreater(base[1], 0)          # data items landed

        again = ingest_paths(self.conn, [self.src])
        self.assertEqual(again[0].get("skipped"), "unchanged")
        self.assertEqual(self.counts(), base)   # untouched

        forced = ingest_paths(self.conn, [self.src], force=True)
        self.assertNotIn("skipped", forced[0])  # reprocessed
        self.assertEqual(self.counts(), base)   # re-derived, no dupes

    def test_remine_route_reprocesses_stored_artifacts(self):
        # The web path: files the upload handler stored under
        # artifacts/<app>/ re-mine without re-uploading.
        aid = db.get_or_create_app(self.conn, "APP1")
        art = Path(self.tmp.name) / "artifacts" / "APP1"
        art.mkdir(parents=True)
        stored = art / "REMINE1.cbl"
        stored.write_text(COBOL)
        ingest_paths(self.conn, [stored], aid)
        base = self.counts()
        forced = ingest_paths(self.conn, [stored], aid, force=True)
        self.assertNotIn("skipped", forced[0])
        self.assertEqual(self.counts(), base)


if __name__ == "__main__":
    unittest.main()
