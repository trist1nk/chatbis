"""Nested-IF composition: outer scaffolding folds into leaf rules;
nothing real is lost, nothing actionless-but-meaningful is dropped."""
import unittest

from chatbis.mine import (compose_rules, detect_format, mine,
                          normalize_lines)


def mine_src(src: str):
    lines = src.strip("\n").split("\n")
    return mine(normalize_lines(lines, detect_format(lines)))


def rule(english, paragraph="EDIT-A", actions=None, code=None,
         context=None):
    return {"condition": f"IF {english}", "english": english,
            "paragraph": paragraph, "actions": actions or [],
            "code": code, "context": context or []}


class Compose(unittest.TestCase):
    def test_context_folds_into_when(self):
        rules = [
            rule("RFD CD is blank"),                       # container
            rule("BANK RTN is blank", actions=["raises E7001"],
                 code="E7001", context=["RFD CD is blank"]),
        ]
        out = compose_rules(rules)
        self.assertEqual(len(out), 1)
        self.assertEqual(out[0]["when"],
                         "RFD CD is blank AND BANK RTN is blank")
        self.assertEqual(out[0]["code"], "E7001")

    def test_three_levels_deep(self):
        rules = [
            rule("A is blank"),
            rule("B is blank", context=["A is blank"]),
            rule("C is blank", actions=["raises E1"], code="E1",
                 context=["A is blank", "B is blank"]),
        ]
        out = compose_rules(rules)
        self.assertEqual(len(out), 1)
        self.assertEqual(out[0]["when"],
                         "A is blank AND B is blank AND C is blank")

    def test_actionless_non_container_survives(self):
        # an EVALUATE pass-through documents the normal path — keep it
        rules = [rule("SQLCODE is 0")]
        out = compose_rules(rules)
        self.assertEqual(len(out), 1)
        self.assertEqual(out[0]["when"], "SQLCODE is 0")

    def test_outer_with_own_action_survives(self):
        rules = [
            rule("A is blank", actions=["performs LOG-IT"]),
            rule("B is blank", actions=["raises E1"], code="E1",
                 context=["A is blank"]),
        ]
        out = compose_rules(rules)
        self.assertEqual(len(out), 2)   # the outer DOES something — keep

    def test_container_match_is_paragraph_scoped(self):
        rules = [
            rule("A is blank", paragraph="EDIT-B"),        # other para
            rule("B is blank", actions=["raises E1"], code="E1",
                 paragraph="EDIT-A", context=["A is blank"]),
        ]
        out = compose_rules(rules)
        # EDIT-B's actionless gate is NOT the container of EDIT-A's rule
        self.assertEqual(len(out), 2)

    def test_seven_levels_end_to_end_through_the_real_miner(self):
        """Not a synthetic-dict test: real fixed-format COBOL, seven
        IFs deep, through the actual miner, then composed."""
        res = mine_src("""
       PROCEDURE DIVISION.
       DEEP-EDIT.
           IF WS-L1 = SPACES
              IF WS-L2 = SPACES
                 IF WS-L3 = SPACES
                    IF WS-L4 = SPACES
                       IF WS-L5 = SPACES
                          IF WS-L6 = SPACES
                             IF WS-L7 = SPACES
                                MOVE 'E7777' TO WS-ERR-CD
                                PERFORM WRITE-REJECT
                             END-IF
                          END-IF
                       END-IF
                    END-IF
                 END-IF
              END-IF
           END-IF.
""")
        self.assertEqual(len(res.rules), 7)      # one rule per gate
        leaf = res.rules[-1]
        self.assertEqual(leaf.code, "E7777")
        self.assertEqual(leaf.context,
                         [f"L{i} is blank" for i in range(1, 7)])

        details = [{"english": r.english, "paragraph": r.paragraph,
                    "actions": r.actions, "code": r.code,
                    "context": r.context} for r in res.rules]
        out = compose_rules(details)
        self.assertEqual(len(out), 1)            # six containers folded
        self.assertEqual(
            out[0]["when"],
            " AND ".join(f"L{i} is blank" for i in range(1, 8)))
        self.assertIn("raises E7777", out[0]["actions"])
        self.assertIn("performs WRITE-REJECT", out[0]["actions"])

    def test_inputs_never_mutated(self):
        r = rule("X is blank", actions=["raises E1"], code="E1",
                 context=["Y is blank"])
        compose_rules([r])
        self.assertNotIn("when", r)


if __name__ == "__main__":
    unittest.main()
