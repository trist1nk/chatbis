"""Triage-recipe invariants: dot-path navigation (case-insensitive, list
indexes), operator semantics (numeric vs string vs date-as-ISO), field-to-
field compares via $.path, and the all-matches contract."""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from chatbis.recipe import get_path, run_recipe, _MISSING

CASE = {
    "caseId": "CASE-889021",
    "status": "SUSPENDED",
    "beneficiary": {"dob": "2027-03-15", "effectiveDate": "2026-01-01", "planCode": ""},
    "premium": {"amount": "0"},
    "history": [{"code": "E3350"}],
}


class TestGetPath(unittest.TestCase):
    def test_nested_and_list(self):
        self.assertEqual(get_path(CASE, "beneficiary.dob"), "2027-03-15")
        self.assertEqual(get_path(CASE, "history.0.code"), "E3350")

    def test_case_insensitive_fallback(self):
        self.assertEqual(get_path(CASE, "Beneficiary.DOB"), "2027-03-15")

    def test_missing(self):
        self.assertIs(get_path(CASE, "beneficiary.nope"), _MISSING)
        self.assertIs(get_path(CASE, "history.9.code"), _MISSING)


class TestRunRecipe(unittest.TestCase):
    def test_field_to_field_date_compare_matches(self):
        out = run_recipe([{"path": "beneficiary.dob", "op": "gt",
                           "value": "$.beneficiary.effectiveDate",
                           "cause": "DOB after effective date",
                           "steps": "Verify DOB\nCorrect on PS220"}], CASE)
        self.assertEqual(len(out["matches"]), 1)
        m = out["matches"][0]
        self.assertEqual(m["cause"], "DOB after effective date")
        self.assertIn("2026-01-01", m["expected"])

    def test_blank_and_numeric(self):
        out = run_recipe([
            {"path": "beneficiary.planCode", "op": "blank", "cause": "Plan missing"},
            {"path": "premium.amount", "op": "le", "value": "0", "cause": "Zero premium"},
            {"path": "status", "op": "eq", "value": "suspended", "cause": "Suspended"},
        ], CASE)
        self.assertEqual([m["cause"] for m in out["matches"]],
                         ["Plan missing", "Zero premium", "Suspended"])

    def test_non_matching_and_missing_are_quiet(self):
        out = run_recipe([
            {"path": "premium.amount", "op": "gt", "value": "100", "cause": "High"},
            {"path": "no.such.field", "op": "eq", "value": "x", "cause": "Ghost"},
            {"path": "no.such.field", "op": "missing", "cause": "Field absent"},
        ], CASE)
        self.assertEqual([m["cause"] for m in out["matches"]], ["Field absent"])
        self.assertEqual(out["evaluated"], 3)

    def test_broken_field_ref_reports_error_not_crash(self):
        out = run_recipe([{"path": "status", "op": "eq",
                           "value": "$.does.not.exist", "cause": "X"}], CASE)
        self.assertEqual(out["matches"], [])
        self.assertTrue(out["errors"])




# ── repeating groups: occurrences, scope, and the "latest" trap ────────────

PERIODS = {
    "claimant": {"ssn": "123456789", "bic": "A"},
    "entitlementPeriods": [
        {"startDate": "2020-01-01", "endDate": "2022-06-30", "resumptionDate": ""},
        {"startDate": "2023-01-01", "endDate": "2022-12-31", "resumptionDate": ""},
        {"startDate": "2024-05-01", "endDate": "", "resumptionDate": "2024-08-01"},
    ],
}


class TestOccurrences(unittest.TestCase):
    def test_lists_and_single_values(self):
        from chatbis.recipe import occurrences
        self.assertEqual(len(occurrences(PERIODS, "entitlementPeriods")), 3)
        # a group holding one dict still evaluates as one occurrence
        self.assertEqual(len(occurrences({"g": {"a": 1}}, "g")), 1)
        self.assertEqual(occurrences(PERIODS, "nope"), [])


class TestPickLatest(unittest.TestCase):
    """The four readings of 'latest' disagree on purpose — that's the trap."""

    def setUp(self):
        self.rows = PERIODS["entitlementPeriods"]

    def test_max_start(self):
        from chatbis.recipe import pick_latest
        i, row = pick_latest(self.rows, "startDate", "max_start")
        self.assertEqual(i, 2)
        self.assertEqual(row["startDate"], "2024-05-01")

    def test_array_order_can_disagree(self):
        from chatbis.recipe import pick_latest
        shuffled = [self.rows[2], self.rows[0], self.rows[1]]
        by_array, _ = pick_latest(shuffled, "startDate", "array_order")
        by_start, _ = pick_latest(shuffled, "startDate", "max_start")
        self.assertEqual(by_array, 2)   # last element
        self.assertEqual(by_start, 0)   # actually the newest
        self.assertNotEqual(by_array, by_start)  # ← the silent-wrong-answer case

    def test_open_period(self):
        from chatbis.recipe import pick_latest
        i, row = pick_latest(self.rows, "endDate", "open_period")
        self.assertEqual(i, 2)
        self.assertEqual(row["endDate"], "")

    def test_open_period_falls_back_when_all_closed(self):
        from chatbis.recipe import pick_latest
        closed = [{"startDate": "2020-01-01", "endDate": "2021-01-01"},
                  {"startDate": "2022-01-01", "endDate": "2023-01-01"}]
        i, _ = pick_latest(closed, "startDate", "max_start")
        self.assertEqual(i, 1)

    def test_empty(self):
        from chatbis.recipe import pick_latest
        self.assertEqual(pick_latest([], "startDate"), (None, None))


class TestScopedChecks(unittest.TestCase):
    def test_latest_is_the_default_scope(self):
        # end blank on the LATEST period → fires
        out = run_recipe([{
            "group": "entitlementPeriods", "path": "endDate", "op": "blank",
            "cause": "Current period left open",
        }], PERIODS, {"entitlementPeriods": {"order_by": "startDate",
                                             "latest_is": "max_start"}})
        self.assertEqual(len(out["matches"]), 1)
        m = out["matches"][0]
        self.assertEqual(m["occurrence"], 2)
        self.assertEqual(m["scope"], "latest")
        self.assertEqual(m["occurrences_total"], 3)

    def test_any_finds_the_bad_row_wherever_it_sits(self):
        # row 1 has end BEFORE start — a scalar check would never see it
        out = run_recipe([{
            "group": "entitlementPeriods", "scope": "any",
            "path": "endDate", "op": "lt", "value": "$.startDate",
            "cause": "Period end precedes its start",
        }], PERIODS)
        self.assertEqual(len(out["matches"]), 1)
        self.assertEqual(out["matches"][0]["occurrence"], 1)

    def test_same_occurrence_vs_case_level_refs(self):
        # $. = this occurrence, $$. = case level
        same = run_recipe([{"group": "entitlementPeriods", "scope": "any",
                            "path": "endDate", "op": "lt", "value": "$.startDate",
                            "cause": "x"}], PERIODS)
        self.assertEqual(len(same["matches"]), 1)
        case_level = run_recipe([{"group": "entitlementPeriods", "scope": "any",
                                  "path": "startDate", "op": "eq",
                                  "value": "$$.claimant.bic", "cause": "y"}], PERIODS)
        self.assertEqual(case_level["matches"], [])   # no start date equals "A"

    def test_all_and_none(self):
        every = run_recipe([{"group": "entitlementPeriods", "scope": "all",
                             "path": "startDate", "op": "not_blank",
                             "cause": "all have starts"}], PERIODS)
        self.assertEqual(len(every["matches"]), 1)
        nope = run_recipe([{"group": "entitlementPeriods", "scope": "none",
                            "path": "startDate", "op": "eq", "value": "1999-01-01",
                            "cause": "none from 1999"}], PERIODS)
        self.assertEqual(len(nope["matches"]), 1)

    def test_missing_group_is_an_error_not_a_crash(self):
        out = run_recipe([{"group": "nope", "path": "x", "op": "blank",
                           "cause": "c"}], PERIODS)
        self.assertEqual(out["matches"], [])
        self.assertTrue(out["errors"])

    def test_manual_checks_are_never_auto_evaluated(self):
        out = run_recipe([{"kind": "manual", "path": "n/a", "op": "eq",
                           "cause": "Compare against the application image"}], PERIODS)
        self.assertEqual(out["matches"], [])
        self.assertEqual(out["evaluated"], 0)

    def test_scalar_checks_still_work_unchanged(self):
        out = run_recipe([{"path": "claimant.bic", "op": "eq", "value": "A",
                           "cause": "BIC is A"}], PERIODS)
        self.assertEqual(len(out["matches"]), 1)
        self.assertNotIn("group", out["matches"][0])


class TestCheckFires(unittest.TestCase):
    """The Lab's live feedback must use the SAME engine as production."""

    def test_states(self):
        from chatbis.recipe import check_fires
        fires = check_fires({"group": "entitlementPeriods", "scope": "any",
                             "path": "endDate", "op": "lt", "value": "$.startDate",
                             "cause": "c"}, PERIODS)
        self.assertEqual(fires["state"], "fires")
        self.assertIn("endDate", fires["detail"])

        quiet = check_fires({"path": "claimant.bic", "op": "eq", "value": "Z",
                             "cause": "c"}, PERIODS)
        self.assertEqual(quiet["state"], "quiet")

        err = check_fires({"path": "x", "op": "eq", "value": "$.nope.nope",
                           "cause": "c"}, PERIODS)
        self.assertEqual(err["state"], "error")

        man = check_fires({"kind": "manual", "path": "n/a", "op": "eq",
                           "cause": "c"}, PERIODS)
        self.assertEqual(man["state"], "manual")




class TestBlankOrdering(unittest.TestCase):
    """Regression: an OPEN period (blank end date) must NOT read as
    'ends before it starts'. Found via the synthetic sandbox — "" sorts
    before any date in a string compare, so this fired on every healthy
    claim. Blank means NOT SET; use blank/missing to test for absence."""

    OPEN = {"entitlementPeriods": [{"startDate": "2025-04-01", "endDate": ""}]}
    BAD = {"entitlementPeriods": [{"startDate": "2023-01-01",
                                   "endDate": "2022-12-31"}]}

    CHECK = {"group": "entitlementPeriods", "scope": "any", "path": "endDate",
             "op": "lt", "value": "$.startDate", "cause": "end before start"}

    def test_open_period_does_not_fire(self):
        self.assertEqual(run_recipe([self.CHECK], self.OPEN)["matches"], [])

    def test_genuinely_inverted_period_still_fires(self):
        self.assertEqual(len(run_recipe([self.CHECK], self.BAD)["matches"]), 1)

    def test_all_ordering_ops_ignore_blanks(self):
        for op in ("gt", "lt", "ge", "le"):
            out = run_recipe([{"path": "a", "op": op, "value": "2020-01-01",
                               "cause": "c"}], {"a": ""})
            self.assertEqual(out["matches"], [], f"{op} fired on a blank value")

    def test_blank_op_still_detects_absence(self):
        out = run_recipe([{"group": "entitlementPeriods", "scope": "any",
                           "path": "endDate", "op": "blank",
                           "cause": "open period"}], self.OPEN)
        self.assertEqual(len(out["matches"]), 1)


if __name__ == "__main__":
    unittest.main()


class TestDateAwareOrdering(unittest.TestCase):
    """Ordering ops compare DATES as dates. Text ordering said
    '01/05/2027' < '12/31/2026' (month chars sort first), so a
    greater-than-a-date check never fired across a year boundary, and
    mixed formats (ISO case data vs US-typed value) never matched."""

    def fires(self, actual, op, value):
        out = run_recipe([{"path": "d", "op": op, "value": value,
                           "cause": "c"}], {"d": actual})
        return bool(out["matches"])

    def test_us_dates_across_a_year_boundary(self):
        self.assertTrue(self.fires("01/05/2027", "gt", "12/31/2026"))
        self.assertFalse(self.fires("12/31/2026", "gt", "01/05/2027"))

    def test_mixed_iso_and_us_formats(self):
        self.assertTrue(self.fires("2026-08-06", "gt", "08/01/2026"))
        self.assertTrue(self.fires("08/06/2026", "ge", "2026-08-06"))
        self.assertTrue(self.fires("2026-08-06", "eq", "08/06/2026"))

    def test_ccyymmdd_numeric_dates(self):
        self.assertTrue(self.fires("20270105", "gt", "12/31/2026"))
        self.assertTrue(self.fires(20270105, "gt", "2026-12-31"))

    def test_plain_numbers_still_compare_numerically(self):
        self.assertTrue(self.fires("100", "gt", "99"))     # text says less
        self.assertFalse(self.fires("99", "gt", "100"))

    def test_eight_digit_non_date_falls_back_to_number(self):
        # 20481395 would be year 2048 month 13 — invalid, so numeric.
        self.assertTrue(self.fires("20481395", "gt", "20481394"))

    def test_blank_guard_still_holds(self):
        self.assertFalse(self.fires("", "gt", "01/01/2020"))

    def test_latest_occurrence_picked_by_date_not_text(self):
        data = {"periods": [{"start": "12/31/2026", "flag": "OLD"},
                            {"start": "01/05/2027", "flag": "NEW"}]}
        out = run_recipe(
            [{"path": "flag", "op": "eq", "value": "NEW", "cause": "c",
              "group": "periods", "scope": "latest"}],
            data, {"periods": {"order_by": "start",
                               "latest_is": "max_start"}})
        self.assertEqual(len(out["matches"]), 1)   # NEW row is the latest


class TestBracketPaths(unittest.TestCase):
    """'beneficiaries[0].laf' — the JSON spelling every analyst tries
    first — resolves the same as 'beneficiaries.0.laf'."""

    DATA = {"beneficiaries": [{"laf": "C"}, {"laf": "D"}]}

    def test_bracket_index_resolves(self):
        out = run_recipe([{"path": "beneficiaries[0].laf", "op": "eq",
                           "value": "C", "cause": "laf is C"}], self.DATA)
        self.assertEqual(len(out["matches"]), 1)
        self.assertEqual(out["matches"][0]["actual"], "C")

    def test_dot_index_still_resolves(self):
        out = run_recipe([{"path": "beneficiaries.1.laf", "op": "eq",
                           "value": "D", "cause": "c"}], self.DATA)
        self.assertEqual(len(out["matches"]), 1)


class TestResultsRundown(unittest.TestCase):
    """run_recipe reports EVERY check's outcome, not just the hits — a
    quiet check with its found value is how a cause is ruled out."""

    DATA = {"status": "SUSPENDED", "amount": "0",
            "beneficiaries": [{"laf": "C"}, {"laf": "D"}]}

    def test_one_record_per_check_in_authored_order(self):
        out = run_recipe([
            {"path": "status", "op": "eq", "value": "SUSPENDED", "cause": "Susp"},
            {"path": "status", "op": "eq", "value": "ACTIVE", "cause": "Act"},
            {"path": "amount", "op": "eq", "value": "$.no.such", "cause": "Ref"},
            {"kind": "manual", "path": "n/a", "cause": "Check the image"},
        ], self.DATA)
        self.assertEqual([r["state"] for r in out["results"]],
                         ["fired", "quiet", "error", "manual"])
        # the quiet record still carries what the case holds
        self.assertEqual(out["results"][1]["actual"], "SUSPENDED")
        self.assertIn("not found in case data", out["results"][2]["note"])

    def test_group_rundown_counts_occurrences(self):
        out = run_recipe([{"group": "beneficiaries", "scope": "any",
                           "path": "laf", "op": "eq", "value": "Z",
                           "cause": "laf Z"}], self.DATA)
        self.assertEqual(out["matches"], [])
        rec = out["results"][0]
        self.assertEqual(rec["state"], "quiet")
        self.assertEqual(rec["occurrences_total"], 2)
        self.assertEqual(rec["matched_count"], 0)
        self.assertEqual(rec["actual"], "C, D")   # what WAS found

    def test_unnamed_cause_becomes_the_rule_sentence(self):
        out = run_recipe([{"path": "beneficiaries[0].laf", "op": "eq",
                           "value": "C"}], self.DATA)
        m = out["matches"][0]
        self.assertTrue(m["unnamed"])
        self.assertEqual(m["cause"], "beneficiaries[0].laf is C")
        self.assertNotIn("(unnamed cause)", m["cause"])

    def test_named_cause_is_not_flagged(self):
        out = run_recipe([{"path": "status", "op": "eq", "value": "SUSPENDED",
                           "cause": "Suspended"}], self.DATA)
        self.assertFalse(out["matches"][0]["unnamed"])

    def test_blank_and_missing_are_spelled_out(self):
        out = run_recipe([
            {"path": "empty", "op": "blank", "cause": "b"},
            {"path": "gone", "op": "missing", "cause": "m"},
        ], {"empty": ""})
        self.assertEqual([m["actual"] for m in out["matches"]],
                         ["«blank»", "«missing»"])

    def test_evidence_text_reads_rule_first(self):
        from chatbis.recipe import evidence_text
        out = run_recipe([{"path": "beneficiaries[0].laf", "op": "eq",
                           "value": "C", "cause": "c"}], self.DATA)
        self.assertEqual(evidence_text(out["matches"][0]),
                         "beneficiaries[0].laf is C — found C")

    def test_evidence_text_names_the_occurrence(self):
        from chatbis.recipe import evidence_text
        out = run_recipe([{"group": "beneficiaries", "scope": "any",
                           "path": "laf", "op": "eq", "value": "D",
                           "cause": "c"}], self.DATA)
        self.assertEqual(evidence_text(out["matches"][0]),
                         "beneficiaries[1].laf is D — found D "
                         "(occurrence 2 of 2)")
