"""The Investigate chat: bounded model over deterministic tools,
activity trail as the citation record, transcripts in memory only.

The model here is a SCRIPTED fake — the tests prove ChatBIS's side of
the contract (tool execution, trail, refusal, storage doctrine), not
any particular model's cleverness."""
import json
import threading
import time
import unittest
import urllib.parse
import urllib.request
import http.server

from chatbis import db
from chatbis import investigate
from chatbis.investigate import exec_describe_program, exec_evaluate_case, \
    exec_lookup_code, exec_pull_case, exec_read_document, \
    exec_search_source, tool_schemas


class _FakeLLM(http.server.BaseHTTPRequestHandler):
    """First round: call lookup_code(E4417). Second: answer from it."""
    def do_POST(self):
        body = json.loads(self.rfile.read(
            int(self.headers["Content-Length"])))
        has_tool_result = any(m.get("role") == "tool"
                              for m in body["messages"])
        if not has_tool_result:
            msg = {"role": "assistant", "content": None, "tool_calls": [
                {"id": "t1", "type": "function", "function": {
                    "name": "lookup_code",
                    "arguments": '{"code": "E4417"}'}}]}
        else:
            catalog = json.loads(
                [m for m in body["messages"]
                 if m.get("role") == "tool"][0]["content"])
            msg = {"role": "assistant",
                   "content": f"E4417 means: {catalog['meaning']} "
                              f"[lookup_code]"}
        out = json.dumps({"choices": [{"message": msg}]}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(out)

    def log_message(self, *a):
        pass


class InvestigateChat(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import socket
        import tempfile
        from chatbis.server import serve
        cls.llm = http.server.HTTPServer(("127.0.0.1", 0), _FakeLLM)
        llm_port = cls.llm.server_address[1]
        threading.Thread(target=cls.llm.serve_forever, daemon=True).start()

        cls.tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        conn = db.connect(cls.tmp.name)
        db.upsert_exception(
            conn, "E4417", category="exception",
            meaning="Beneficiary DOB is after the policy effective date")
        conn.execute(
            "INSERT INTO source_file (id, application_id, path, name,"
            " kind, encoding, fmt, line_count, content_hash,"
            " ingested_at) VALUES (9, NULL, '/x/BF.cbl', 'BF.cbl',"
            " 'cobol', 'utf-8', 'fixed', 10, 'h', 'now')")
        conn.execute("INSERT INTO program (id, source_file_id, name)"
                     " VALUES (9, 9, 'BFDISAB')")
        conn.execute(
            "INSERT INTO llm_config (id, provider, base_url, model,"
            " enabled) VALUES (1, 'in-network',"
            f" 'http://127.0.0.1:{llm_port}', 'fake', 1)")
        conn.commit()
        conn.close()
        with socket.socket() as s:
            s.bind(("127.0.0.1", 0))
            cls.port = s.getsockname()[1]
        threading.Thread(target=serve, args=(cls.tmp.name, cls.port),
                         daemon=True).start()
        time.sleep(0.6)

    @classmethod
    def tearDownClass(cls):
        cls.llm.shutdown()

    def get(self, path):
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}{path}") as r:
            return r.read().decode()

    def post(self, path, data):
        req = urllib.request.Request(
            f"http://127.0.0.1:{self.port}{path}",
            data=urllib.parse.urlencode(data).encode(), method="POST")
        with urllib.request.urlopen(req) as r:
            return json.loads(r.read().decode())

    def test_full_loop_trail_and_grounded_answer(self):
        d = self.post("/chat/ask", {"q": "what is E4417?"})
        chat = d["chat"]
        for _ in range(40):
            st = json.loads(self.get(f"/chat/status?chat={chat}"))
            if st["done"]:
                break
            time.sleep(0.25)
        self.assertTrue(st["done"], "chat never finished")
        self.assertIsNone(st["error"])
        labels = [e["label"] for e in st["events"]]
        self.assertIn("Reading the catalog · E4417", labels)
        self.assertIn("Beneficiary DOB is after", st["answer_html"])

    def test_transcripts_never_touch_the_database(self):
        import sqlite3
        conn = sqlite3.connect(self.tmp.name)
        tables = [r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")]
        conn.close()
        self.assertFalse([t for t in tables if "chat" in t.lower()],
                         "chat state must stay in server memory")

    def test_unknown_chat_refuses_by_name(self):
        st = json.loads(self.get("/chat/status?chat=nope"))
        self.assertEqual(st["error"], "unknown chat")

    def test_chat_end_clears_the_transcript(self):
        d = self.post("/chat/ask", {"q": "what is E4417?"})
        chat = d["chat"]
        for _ in range(40):
            if json.loads(self.get(f"/chat/status?chat={chat}"))["done"]:
                break
            time.sleep(0.25)
        self.post("/chat/end", {"chat": chat})
        st = json.loads(self.get(f"/chat/status?chat={chat}"))
        self.assertEqual(st["error"], "unknown chat")

    def test_prefill_and_autosend_ride_the_query_string(self):
        h = self.get("/chat?q=hello%20there&send=1")
        self.assertIn('"hello there"', h)
        self.assertIn("requestSubmit", h)

    def test_program_hero_carries_the_draft_dfr_button(self):
        h = self.get("/prog/9")
        self.assertIn("Draft DFR", h)
        self.assertIn("/prog/9/dfr", h)        # the assembler waiting room

    def test_dfr_download_route_serves_markdown(self):
        raw = self.get("/prog/9/dfr.md?prose=0")
        self.assertIn("# DFR — BFDISAB (DRAFT)", raw)
        self.assertIn("## 3. Input data", raw)
        self.assertIn("## 4. Output data and format", raw)
        self.assertIn("## 5. Business rules", raw)

    def test_dfr_waiting_room_serves_instantly_with_skip_link(self):
        h = self.get("/prog/9/dfr")
        self.assertIn("Drafting the DFR", h)
        self.assertIn("/prog/9/dfr.md?prose=0", h)  # the no-model escape

    def test_dfr_job_survives_navigation_start_poll_download(self):
        # The job runs server-side: start it, "navigate away" (no page
        # holds a request open), poll status, download the file.
        d = self.post("/prog/9/dfr/start", {})
        self.assertIn(d["status"], ("working", "done"))
        for _ in range(80):
            s = json.loads(self.get("/prog/9/dfr/status"))
            if s["status"] in ("done", "error"):
                break
            time.sleep(0.25)
        self.assertEqual(s["status"], "done")
        raw = self.get("/prog/9/dfr/file")
        self.assertIn("# DFR — BFDISAB (DRAFT)", raw)
        self.assertIn("## 5. Business rules", raw)
        # a second start joins the finished job instead of re-running
        again = self.post("/prog/9/dfr/start", {})
        self.assertEqual(again["status"], "done")

    def test_dfr_cancel_discards_the_job(self):
        import chatbis.server as srv
        with srv.DFR_JOBS_LOCK:
            srv.DFR_JOBS[777] = {"status": "working", "md": None,
                                 "error": None, "started": 0,
                                 "finished": None, "name": "X",
                                 "cancel": False}
        self.post("/prog/777/dfr/cancel", {})
        s = json.loads(self.get("/prog/777/dfr/status"))
        self.assertEqual(s["status"], "none")

    def test_stop_flag_halts_the_loop_before_any_model_call(self):
        from chatbis.investigate import (InvestigationStopped,
                                         run_investigation)
        conn = db.connect(":memory:")
        cfg = {"base_url": "http://127.0.0.1:1", "model": "x",
               "api_key": ""}
        msgs = [{"role": "system", "content": "s"},
                {"role": "user", "content": "q"}]
        with self.assertRaises(InvestigationStopped):
            run_investigation(conn, None, cfg, msgs, lambda k, l: None,
                              should_stop=lambda: True)
        conn.close()

    def test_chat_stop_route_sets_the_flag(self):
        import chatbis.server as srv
        with srv.CHATS_LOCK:
            srv.CHATS["stoptest"] = {"stop": False, "done": False}
        self.post("/chat/stop", {"chat": "stoptest"})
        with srv.CHATS_LOCK:
            flag = srv.CHATS.pop("stoptest")["stop"]
        self.assertTrue(flag)

    def test_dock_rides_every_page_but_not_the_chat_page(self):
        self.assertIn("cdockbtn", self.get("/catalog"))
        self.assertIn("cdockbtn", self.get("/prog/9"))
        self.assertNotIn("cdockbtn", self.get("/chat"))

    def test_history_returns_display_pairs_for_the_dock(self):
        d = self.post("/chat/ask", {"q": "what is E4417?"})
        chat = d["chat"]
        for _ in range(40):
            if json.loads(self.get(f"/chat/status?chat={chat}"))["done"]:
                break
            time.sleep(0.25)
        h = json.loads(self.get(f"/chat/history?chat={chat}"))
        whos = [m["who"] for m in h["messages"]]
        self.assertEqual(whos[0], "user")
        self.assertEqual(whos[-1], "bot")
        self.assertIn("Beneficiary DOB", h["messages"][-1]["html"])
        # unknown ids refuse
        miss = json.loads(self.get("/chat/history?chat=zzz"))
        self.assertEqual(miss["error"], "unknown chat")

    def test_file_viewer_carries_in_member_search(self):
        h = self.get("/file/9")
        for piece in ("srcbar", "id=srcq", "srccnt", "srcprev",
                      "srcnext", "fmatch", "split('\\n')"):
            self.assertIn(piece, h)

    def test_chat_page_carries_the_dark_shell(self):
        h = self.get("/chat")
        for piece in ("cwb", "chatlog", "ctrail", "cdots",
                      "/chat/status", "session memory only"):
            self.assertIn(piece, h)


class AnswerRendering(unittest.TestCase):
    """Answers render the markdown models actually emit — nothing more,
    and raw HTML never survives."""

    def test_bold_code_headings_and_rules(self):
        from chatbis.server import md_lite
        h = md_lite("# Draft DFR\n**Scope**: all claims\n`E4417` "
                    "raised\n---")
        self.assertIn("<b>Scope</b>", h)
        self.assertIn("<code>E4417</code>", h)
        self.assertIn("Draft DFR</b>", h)
        self.assertIn("class=chr", h)
        self.assertNotIn("**", h)

    def test_html_is_escaped_before_rendering(self):
        from chatbis.server import md_lite
        h = md_lite("**<script>alert(1)</script>**")
        self.assertNotIn("<script>", h)
        self.assertIn("<b>&lt;script&gt;", h)

    def test_system_prompt_permits_drafting(self):
        self.assertIn("DRAFTING IS PART OF YOUR JOB",
                      investigate.SYSTEM_PROMPT)

    def test_system_prompt_locks_the_scope(self):
        sp = investigate.SYSTEM_PROMPT
        self.assertIn("SCOPE: you exist ONLY for this workbench", sp)
        for piece in ("personal questions", "opinions",
                      "general knowledge", "No exceptions"):
            self.assertIn(piece, sp)


class Compaction(unittest.TestCase):
    """Near the context window, old turns fold into a summary; the tail
    stays verbatim; a failed summary never destroys history."""

    def transcript(self, turns=6, fat=5200):
        msgs = [{"role": "system", "content": "sys"}]
        for i in range(turns):
            msgs += [
                {"role": "user", "content": f"question {i}"},
                {"role": "assistant", "content": None, "tool_calls": [
                    {"id": f"t{i}", "type": "function", "function": {
                        "name": "lookup_code",
                        "arguments": '{"code": "E1"}'}}]},
                {"role": "tool", "tool_call_id": f"t{i}",
                 "content": json.dumps({"blob": "x" * fat})},
                {"role": "assistant", "content": f"answer {i}"},
            ]
        msgs.append({"role": "user", "content": "the current question"})
        return msgs

    def test_under_budget_is_untouched(self):
        msgs = self.transcript(turns=1, fat=100)
        before = list(msgs)
        investigate.compact_messages(
            {"base_url": "http://x", "model": "m", "api_key": ""},
            msgs, lambda *a: None)
        self.assertEqual(msgs, before)

    def test_over_budget_summarizes_and_keeps_the_tail(self):
        msgs = self.transcript()
        events = []
        real = investigate.llm_chat
        investigate.llm_chat = lambda cfg, m, t: {
            "content": "SUMMARY-OF-THE-PAST"}
        try:
            investigate.compact_messages(
                {"base_url": "http://x", "model": "m", "api_key": ""},
                msgs, lambda k, l: events.append(l))
        finally:
            investigate.llm_chat = real
        self.assertIn("Compacting the conversation", events)
        self.assertIn("SUMMARY-OF-THE-PAST", msgs[1]["content"])
        self.assertEqual(msgs[-1]["content"], "the current question")
        self.assertLess(investigate.est_tokens(msgs),
                        investigate.CONTEXT_TOKENS)
        # the cut lands on a turn boundary: every tool message still
        # follows an assistant message that carries tool_calls
        for i, m in enumerate(msgs):
            if m.get("role") == "tool":
                self.assertTrue(msgs[i - 1].get("tool_calls"),
                                "orphaned tool result")

    def test_failed_summary_falls_back_to_stubs_not_data_loss(self):
        msgs = self.transcript()
        n_before = len(msgs)
        real = investigate.llm_chat
        def boom(cfg, m, t):
            raise urllib.error.URLError("down")
        investigate.llm_chat = boom
        try:
            investigate.compact_messages(
                {"base_url": "http://x", "model": "m", "api_key": ""},
                msgs, lambda *a: None)
        finally:
            investigate.llm_chat = real
        self.assertEqual(len(msgs), n_before)      # nothing deleted
        self.assertIn("dropped during compaction", msgs[3]["content"])
        self.assertEqual(msgs[4]["content"], "answer 0")  # dialogue kept


class ToolExecutors(unittest.TestCase):
    def setUp(self):
        self.conn = db.connect(":memory:")
        self.cid = db.upsert_exception(
            self.conn, "E9001", category="exception", meaning="Test code")
        db.add_link(self.conn, self.cid, "program", "PGMONE", "emitted_by",
                    confidence=0.9)

    def tearDown(self):
        self.conn.close()

    def test_lookup_returns_catalog_facts(self):
        out = exec_lookup_code(self.conn, "e-9001")   # separator-blind
        self.assertEqual(out["meaning"], "Test code")
        self.assertEqual(out["programs"][0]["program"], "PGMONE")

    def test_lookup_refuses_unknown_codes(self):
        self.assertIn("error", exec_lookup_code(self.conn, "NOPE99"))

    def test_search_source_empty_on_no_tokens(self):
        self.assertEqual(exec_search_source(self.conn, "  "), [])

    def _seed_program(self):
        self.conn.execute(
            "INSERT INTO source_file (id, application_id, path, name,"
            " kind, encoding, fmt, line_count, content_hash,"
            " ingested_at) VALUES (1, NULL, '/x/PREM.cbl', 'PREM.cbl',"
            " 'cobol', 'utf-8', 'fixed', 10, 'abc', 'now')")
        self.conn.execute("INSERT INTO program (id, source_file_id, name)"
                          " VALUES (1, 1, 'PREMCALC')")
        self.conn.execute(
            "INSERT INTO program_facet (program_id, kind, ref, detail)"
            " VALUES (1, 'rule', 'E9001', ?)",
            (json.dumps({"english": "AMOUNT is negative",
                         "paragraph": "EDIT-AMT",
                         "actions": ["raises E9001"]}),))
        self.conn.execute(
            "INSERT INTO program_facet (program_id, kind, ref, detail)"
            " VALUES (1, 'copy', 'ERRCODES', '{}')")
        self.conn.commit()

    def test_describe_program_profiles_from_mined_facts(self):
        self._seed_program()
        prof = exec_describe_program(self.conn, "premcalc")  # case-blind
        self.assertEqual(prof["program"], "PREMCALC")
        self.assertEqual(prof["copies"], ["ERRCODES"])
        self.assertEqual(prof["business_rules"][0]["when"],
                         "AMOUNT is negative")
        self.assertIn("1 rules mined", prof["mined_note"])

    def test_describe_program_refuses_with_close_matches(self):
        self._seed_program()
        out = exec_describe_program(self.conn, "PREMCAL")
        self.assertIn("error", out)
        self.assertIn("PREMCALC", out["error"])   # named, not guessed

    def test_read_document_sections_and_query_filter(self):
        self.conn.execute(
            "INSERT INTO document (id, title, path, doc_type, kind,"
            " ingested_at) VALUES (7, 'Posting DFR', '/x/dfr.md', 'md',"
            " 'dfr', 'now')")
        for i, (h, t) in enumerate([("Scope", "covers claim posting"),
                                    ("Duplicates", "reject duplicate keys"),
                                    ("Appendix", "misc")]):
            self.conn.execute(
                "INSERT INTO doc_section (document_id, heading, ord,"
                " text) VALUES (7, ?, ?, ?)", (h, i, t))
        self.conn.commit()
        out = exec_read_document(self.conn, "Posting DFR")
        self.assertEqual(len(out["sections"]), 3)
        out = exec_read_document(self.conn, "Posting DFR",
                                 query="duplicate")
        self.assertEqual([x["heading"] for x in out["sections"]],
                         ["Duplicates"])
        self.assertIn("1 of 3", out["sections_note"])

    def test_read_document_names_what_exists_on_miss(self):
        out = exec_read_document(self.conn, "Nonexistent")
        self.assertIn("error", out)
        self.assertIn("available", out)

    def test_seven_tools_declared(self):
        names = [t["function"]["name"] for t in tool_schemas(self.conn)]
        self.assertEqual(sorted(names),
                         ["cobol_ref", "describe_program", "evaluate_case",
                          "lookup_code", "pull_case", "read_document",
                          "search_source"])

    def test_schemas_name_available_endpoints(self):
        self.conn.execute(
            "INSERT INTO api_endpoint (name, method, path, created_at)"
            " VALUES ('Claim core', 'GET', '/v1/claims?ssn={ssn}',"
            " '2026-01-01')")
        self.conn.commit()
        pull = [t for t in tool_schemas(self.conn)
                if t["function"]["name"] == "pull_case"][0]
        self.assertIn("Claim core", pull["function"]["description"])
        self.assertIn("ssn", pull["function"]["description"])


class ChatCaseEvaluation(unittest.TestCase):
    """evaluate_case: deterministic chat triage — the endpoint comes from
    configuration (the recipe's, or the sole one), the engine is shared
    with the Evaluate screen, and every call lands in the call log."""

    CASE = {"claimant": {"bic": "A", "dob": "2001-02-03"},
            "beneficiaries": [{"laf": "C"}]}

    def setUp(self):
        self.conn = db.connect(":memory:")
        self.cid = db.upsert_exception(self.conn, "E1245",
                                       category="exception",
                                       meaning="LAF mismatch")
        self.conn.execute(
            "INSERT INTO api_env (name, base_url, token, insecure_tls,"
            " created_at) VALUES ('TEST', 'http://x', 'jwt', 0, 'now')")
        self.conn.execute(
            "INSERT INTO api_endpoint (name, method, path, body, created_at)"
            " VALUES ('Claim by SSN+BIC', 'POST', '/v1/claims',"
            " ?, 'now')", ('{"ssn": "{ssn}", "bic": "{bic}"}',))
        self.ep_id = self.conn.execute(
            "SELECT id FROM api_endpoint").fetchone()["id"]
        checks = [{"path": "beneficiaries[0].laf", "op": "eq", "value": "C",
                   "cause": "LAF is C"}]
        self.conn.execute(
            "INSERT INTO playbook (exception_id, endpoint_id, checks,"
            " general_steps) VALUES (?, ?, ?, 'Check the award')",
            (self.cid, self.ep_id, json.dumps(checks)))
        self.conn.commit()
        self.calls = []

    def tearDown(self):
        self.conn.close()

    def ok_api(self, env, ep, params):
        self.calls.append((ep["name"], dict(params)))
        return 200, json.dumps(self.CASE), 5, None

    def bad_api(self, env, ep, params):
        return 400, '{"message": "bic is required"}', 5, None

    def test_evaluate_runs_the_recipe_end_to_end(self):
        out = exec_evaluate_case(self.conn, self.ok_api, "e1245",
                                 {"ssn": "123556789", "bic": "A"})
        self.assertEqual(out["verdict"], "1 of 1 checks matched")
        self.assertEqual(out["matches"][0]["cause"], "LAF is C")
        self.assertIn("found C", out["matches"][0]["evidence"])
        # The endpoint came from the recipe — the model never named it.
        self.assertEqual(self.calls[0][0], "Claim by SSN+BIC")

    def test_http_error_surfaces_body_and_masked_params(self):
        out = exec_evaluate_case(self.conn, self.bad_api, "E1245",
                                 {"ssn": "123556789", "bic": "A"})
        self.assertEqual(out["error"], "HTTP 400")
        self.assertIn("bic is required", out["response"])
        self.assertEqual(out["sent_params"]["ssn"], "•••6789")
        self.assertEqual(out["sent_params"]["bic"], "A")

    def test_chat_calls_land_in_the_call_log(self):
        exec_evaluate_case(self.conn, self.ok_api, "E1245",
                           {"ssn": "123556789", "bic": "A"})
        row = self.conn.execute("SELECT * FROM api_call_log").fetchone()
        self.assertEqual(row["endpoint"], "Claim by SSN+BIC (chat)")
        self.assertEqual(row["ok"], 1)
        self.assertNotIn("123556789", row["params"])   # masked in the log

    def test_pull_case_defaults_to_the_sole_endpoint(self):
        out = exec_pull_case(self.conn, self.ok_api, "",
                             {"ssn": "1", "bic": "A"})
        self.assertIn("case", out)

    def test_pull_case_ambiguity_names_the_options(self):
        self.conn.execute(
            "INSERT INTO api_endpoint (name, method, path, created_at)"
            " VALUES ('Second', 'GET', '/x', 'now')")
        self.conn.commit()
        out = exec_pull_case(self.conn, self.ok_api, "", {})
        self.assertIn("error", out)
        self.assertEqual(out["available"], ["Claim by SSN+BIC", "Second"])

    def test_no_recipe_is_an_honest_error(self):
        db.upsert_exception(self.conn, "E9999", meaning="No recipe")
        out = exec_evaluate_case(self.conn, self.ok_api, "E9999", {})
        self.assertIn("no diagnostic recipe", out["error"])

    def test_unknown_code_refuses(self):
        out = exec_evaluate_case(self.conn, self.ok_api, "ZZ1", {})
        self.assertIn("not in the catalog", out["error"])

    def test_redact_keeps_case_values_out_of_evidence(self):
        checks = [{"path": "claimant.dob", "op": "not_blank",
                   "cause": "DOB present"}]
        self.conn.execute("UPDATE playbook SET checks = ?",
                          (json.dumps(checks),))
        self.conn.commit()
        out = exec_evaluate_case(self.conn, self.ok_api, "E1245",
                                 {"ssn": "1"}, redact=True)
        self.assertNotIn("2001-02-03", json.dumps(out))
        self.assertIn("«redacted»", out["matches"][0]["evidence"])

    def test_triage_event_recorded_with_masked_params(self):
        exec_evaluate_case(self.conn, self.ok_api, "E1245",
                           {"ssn": "123556789", "bic": "A"})
        ev = self.conn.execute(
            "SELECT * FROM exception_event WHERE kind = 'triage'").fetchone()
        self.assertEqual(ev["actor"], "chat")
        self.assertNotIn("123556789", ev["payload"])
        self.assertIn("LAF is C", ev["payload"])

    def test_tool_schema_lists_evaluate_case(self):
        names = [t["function"]["name"] for t in tool_schemas(self.conn)]
        self.assertIn("evaluate_case", names)
        pull = [t for t in tool_schemas(self.conn)
                if t["function"]["name"] == "pull_case"][0]
        self.assertEqual(pull["function"]["parameters"]["required"],
                         ["params"])


if __name__ == "__main__":
    unittest.main()
