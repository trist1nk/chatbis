"""Field Scan + mined-pair acceptance over real HTTP.

Ingests a miniature two-stage pipeline (builder moves IN-X into the shared
record; writer moves it to a host variable and INSERTs it) and asserts the
scan classifies each touch, orders stages, draws the flow chain to the DB2
column, and that a mined COBOL↔DB2 pair can be accepted into field_map.
"""
import sqlite3
import sys
import tempfile
import threading
import unittest
import urllib.parse
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from chatbis import db
from chatbis.ingest import ingest_paths
from chatbis.server import Handler

BUILDER = """       IDENTIFICATION DIVISION.
       PROGRAM-ID. XBUILD.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  REC-AREA.
           05  REC-CASE-REF        PIC X(10).
       PROCEDURE DIVISION.
       MAIN.
           MOVE IN-CASE-REF TO REC-CASE-REF
           IF REC-CASE-REF = SPACES
               DISPLAY 'XBUILD ERROR E9901'
           END-IF
           GOBACK.
"""

WRITER = """       IDENTIFICATION DIVISION.
       PROGRAM-ID. XPUT.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-CASE-REF             PIC X(10).
       01  WS-UTIL-PGM             PIC X(08).
           COPY CASECOPY.
       PROCEDURE DIVISION.
       MAIN.
           MOVE REC-CASE-REF TO WS-CASE-REF
           CALL 'CASEUTIL' USING WS-CASE-REF
           MOVE 'CASEUTIL' TO WS-UTIL-PGM
           CALL WS-UTIL-PGM USING REC-AREA
           EXEC SQL
               INSERT INTO APP.CASE_TBL (CASE_REF)
               VALUES (:WS-CASE-REF)
           END-EXEC
           GOBACK.
"""

UTIL = """       IDENTIFICATION DIVISION.
       PROGRAM-ID. CASEUTIL.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
           COPY CASECOPY.
       PROCEDURE DIVISION.
       MAIN.
           GOBACK.
"""

ROOT = """       IDENTIFICATION DIVISION.
       PROGRAM-ID. XROOT.
       PROCEDURE DIVISION.
       MAIN.
           CALL 'XPUT' USING DUMMY-AREA
           GOBACK.
"""


class ScanFlow(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.db_path = str(Path(cls.tmp.name) / "t.db")
        src = Path(cls.tmp.name)
        (src / "XBUILD.cbl").write_text(BUILDER)
        (src / "XPUT.cbl").write_text(WRITER)
        (src / "CASEUTIL.cbl").write_text(UTIL)
        (src / "XROOT.cbl").write_text(ROOT)
        conn = db.connect(cls.db_path)
        b_id = db.get_or_create_app(conn, "BUILDER")
        w_id = db.get_or_create_app(conn, "WRITER")
        c_id = db.get_or_create_app(conn, "COMMON")
        ingest_paths(conn, [src / "XBUILD.cbl", src / "XROOT.cbl"], app_id=b_id)
        ingest_paths(conn, [src / "XPUT.cbl"], app_id=w_id)
        ingest_paths(conn, [src / "CASEUTIL.cbl"], app_id=c_id)
        for name, seq in (("BUILDER", 10), ("WRITER", 20)):
            conn.execute("UPDATE application SET pipeline='TESTFLOW',"
                         " stage_seq=? WHERE name=?", (seq, name))
        conn.commit()
        conn.close()
        Handler.db_path = cls.db_path
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.httpd.server_address[1]
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.tmp.cleanup()

    def get(self, path):
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}{path}") as r:
            return r.read().decode()

    def test_chain_reaches_the_database_column(self):
        html = self.get("/scan?q=CASE-REF")
        self.assertIn("Flow — mined from MOVE statements", html)
        # Every hop, ending at the DB2 column.
        for hop in ("IN-CASE-REF", "REC-CASE-REF", "WS-CASE-REF",
                    "APP.CASE_TBL.CASE_REF"):
            self.assertIn(hop, html)
        self.assertIn("SQL INSERT", html)

    def test_touches_are_classified_and_stage_ordered(self):
        html = self.get("/scan?q=CASE-REF")
        self.assertIn(">definition</span>", html)
        self.assertIn(">write</span>", html)
        self.assertIn(">read</span>", html)
        self.assertIn(">condition</span>", html)
        self.assertLess(html.index("BUILDER"), html.index("WRITER"))

    def test_underscore_and_hyphen_are_one_name(self):
        # Scanning the DB2 spelling finds the COBOL family and vice versa.
        html = self.get("/scan?q=CASE_REF")
        self.assertIn("REC-CASE-REF", html)

    def test_unknown_field_is_honest(self):
        html = self.get("/scan?q=NO-SUCH-FIELD")
        self.assertIn("No source line contains", html)

    def test_called_from_panel_static_and_dynamic(self):
        html = self.get("/scan?q=CASEUTIL")
        self.assertIn("Called from", html)
        self.assertIn("XPUT", html)
        self.assertIn("WS-CASE-REF", html)             # the USING contract
        # The dynamic site is found through MOVE 'CASEUTIL' TO WS-UTIL-PGM.
        self.assertIn("dynamic · via WS-UTIL-PGM", html)
        self.assertIn("REC-AREA", html)

    def test_no_callers_no_panel(self):
        html = self.get("/scan?q=CASE-REF")
        self.assertNotIn("Called from", html)

    def test_called_from_groups_by_application(self):
        html = self.get("/scan?q=CASEUTIL")
        self.assertIn("across <b>1</b> application", html)
        # Blast-radius badges: how each caller reaches the program.
        self.assertIn("1 static", html)
        self.assertIn("1 dynamic", html)
        # The callers sit under their application's group header, with the
        # pipeline stage on the header, not repeated per row.
        self.assertIn("WRITER <span", html)
        self.assertIn("stage in TESTFLOW", html)

    def test_shared_copybooks_are_the_layout_contract(self):
        # CASEUTIL and its caller XPUT both COPY CASECOPY — the scan names
        # the shared member so a layout change reads as wider impact.
        html = self.get("/scan?q=CASEUTIL")
        self.assertIn("Shared copybooks", html)
        self.assertIn("<code>CASECOPY</code>", html)

    def test_indirect_callers_walk_the_call_graph(self):
        # XROOT never names CASEUTIL; it reaches it through XPUT.
        html = self.get("/scan?q=CASEUTIL")
        self.assertIn("1 indirect caller", html)
        self.assertIn("Reaches it indirectly", html)
        self.assertIn("XROOT", html)
        self.assertIn("calls <code>XPUT</code>", html)

    def test_downstream_panel_lists_what_the_program_touches(self):
        html = self.get("/scan?q=XPUT")
        self.assertIn("What XPUT itself touches", html)
        self.assertIn("Calls out to", html)
        self.assertIn(">CASEUTIL</a>", html)
        self.assertIn("DB2 tables", html)
        self.assertIn(">APP.CASE_TBL</a>", html)
        self.assertIn("Copybooks", html)
        self.assertIn(">CASECOPY</a>", html)

    def test_downstream_panel_only_for_programs(self):
        html = self.get("/scan?q=CASE-REF")
        self.assertNotIn("itself touches", html)

    def test_mined_pair_offered_then_accepted(self):
        html = self.get("/settings?tab=fields")
        self.assertIn("Mined from embedded SQL", html)
        self.assertIn("WS-CASE-REF", html)
        self.assertIn("APP.CASE_TBL.CASE_REF", html)

        body = urllib.parse.urlencode({
            "host": "WS-CASE-REF", "column": "APP.CASE_TBL.CASE_REF",
            "label": "Case ref"}).encode()
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}/settings/fieldmap/mined",
                body) as r:
            r.read()
        c = sqlite3.connect(self.db_path)
        row = c.execute("SELECT label, cobol_field, db2_column, updated_by"
                        " FROM field_map WHERE cobol_field='WS-CASE-REF'"
                        ).fetchone()
        c.close()
        self.assertEqual(row, ("Case ref", "WS-CASE-REF",
                               "APP.CASE_TBL.CASE_REF", "mined"))
        # Accepted pair leaves the queue.
        html = self.get("/settings?tab=fields")
        self.assertNotIn("Mined from embedded SQL", html)


if __name__ == "__main__":
    unittest.main()
