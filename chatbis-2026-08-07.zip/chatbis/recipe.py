"""ChatBIS — triage recipes: automated diagnosis of a live case.

A recipe belongs to an exception code: which Case Lookup endpoint pulls the
case, and an ordered list of diagnostic checks evaluated against the fetched
JSON. Each check maps to a cause and its resolution steps, so the output is
"THIS case fails because X — do Y", with the evidence shown.

Read-only by design: no approval workflow, no mutation. The recipe answers;
the analyst acts in the system of record.

All pure functions — the diagnosis logic is testable without a server.
"""
from __future__ import annotations

import datetime as _dt

_MISSING = object()

OPS = {
    "eq": "is", "ne": "is not", "gt": "is greater than / after",
    "lt": "is less than / before", "ge": "is at least", "le": "is at most",
    "blank": "is blank", "not_blank": "is not blank",
    "missing": "is missing", "contains": "contains",
}
_UNARY = {"blank", "not_blank", "missing"}


def _show(v) -> str:
    """A value as the analyst should read it: absence is spelled out, never
    rendered as empty space that looks like a display bug."""
    if v is _MISSING:
        return "«missing»"
    s = str(v)
    return s if s.strip() else "«blank»"


def describe_check(c: dict) -> str:
    """The rule as a sentence — the headline when no cause is written.
    'beneficiaries · latest · laf is C' beats '(unnamed cause)'."""
    path = (c.get("path") or "").strip()
    op = (c.get("op") or "eq").strip()
    bits = []
    if (c.get("group") or "").strip():
        bits.append(f"{c['group'].strip()} · "
                    f"{(c.get('scope') or 'latest').strip()} ·")
    bits.append(path)
    bits.append(OPS.get(op, op))
    if op not in _UNARY:
        bits.append(str(c.get("value") or "").strip())
    return " ".join(b for b in bits if b)


def evidence_text(m: dict) -> str:
    """One line of evidence, rule first, observation second:
    'beneficiaries[0].laf is C — found C'. The old 'path = C · is · C'
    buried the rule inside the reading."""
    txt = f"{m['path']} {m['op']}"
    if m.get("expected"):
        txt += f" {m['expected']}"
    txt += f" — found {m['actual']}"
    if m.get("group") and m.get("occurrence") is not None:
        txt += (f" (occurrence {m['occurrence'] + 1} of "
                f"{m['occurrences_total']})")
    return txt


def get_path(data, path: str):
    """Dot-path into parsed JSON: 'beneficiary.dob', 'history.0.code'.
    JSON-style brackets are accepted too — 'beneficiaries[0].laf' is
    the spelling every analyst tries first, and silently matching
    nothing made a correct check look broken. Case-insensitive key
    fallback (Java APIs camelCase freely)."""
    cur = data
    normalized = (path or "").replace("[", ".").replace("]", "")
    for part in normalized.split("."):
        if not part:
            continue
        if isinstance(cur, list):
            try:
                cur = cur[int(part)]
                continue
            except (ValueError, IndexError):
                return _MISSING
        if not isinstance(cur, dict):
            return _MISSING
        if part in cur:
            cur = cur[part]
            continue
        lowered = {k.lower(): k for k in cur}
        if part.lower() in lowered:
            cur = cur[lowered[part.lower()]]
            continue
        return _MISSING
    return cur


_DATE_FMTS = ("%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y", "%Y/%m/%d", "%m-%d-%Y")


def _as_date(v) -> _dt.date | None:
    """The date a value spells, or None. Handles the formats case data
    actually carries: ISO, US slash/dash (2- or 4-digit year), and
    8-digit CCYYMMDD / MMDDCCYY. strptime validates ranges, so an
    8-digit account number that doesn't parse as a real date falls
    through to the numeric path unharmed."""
    t = str(v).strip().split("T")[0].split(" ")[0]
    if not t:
        return None
    if t.isdigit() and len(t) == 8:
        fmt = ("%Y%m%d" if t[:2] in ("19", "20")
               else "%m%d%Y" if t[4:6] in ("19", "20") else None)
        if not fmt:
            return None
        try:
            return _dt.datetime.strptime(t, fmt).date()
        except ValueError:
            return None
    for fmt in _DATE_FMTS:
        try:
            return _dt.datetime.strptime(t, fmt).date()
        except ValueError:
            continue
    return None


def _date_key(v) -> str:
    """A sortable key: dates normalize to ISO (which orders correctly as
    text), everything else stays the raw string. Fixes lexical ordering
    of MM/DD/YYYY across year boundaries."""
    d = _as_date(v)
    return d.isoformat() if d else str(v)


def _compare(actual, op: str, expected) -> bool:
    if op == "missing":
        return actual is _MISSING
    if actual is _MISSING:
        return False
    s = str(actual).strip()
    if op == "blank":
        return s == ""
    if op == "not_blank":
        return s != ""
    if op == "contains":
        return str(expected).lower() in s.lower()
    # ORDERING ops treat blank as NOT SET, never as "smaller than everything".
    # Found via the synthetic sandbox: an OPEN period (endDate = "") made
    # `endDate < startDate` fire on every healthy claim, because "" sorts
    # before any date. Use blank/not_blank/missing to test for absence.
    if op in ("gt", "lt", "ge", "le") and (s == "" or str(expected).strip() == ""):
        return False
    # DATE-AWARE ordering: '01/05/2027' compared to '12/31/2026' as text
    # says LESS (month chars sort before the year is ever read), so a
    # 'greater than a date' check never fired across a year boundary —
    # and mixed formats (ISO case data vs US-typed recipe value) never
    # matched at all. When BOTH sides spell a date, compare the dates;
    # otherwise numeric, then case-folded text, exactly as before.
    da, db = _as_date(s), _as_date(expected)
    if da is not None and db is not None:
        a, b = da, db
    else:
        try:
            a, b = float(s), float(str(expected).strip())
        except (TypeError, ValueError):
            a, b = s.lower(), str(expected).strip().lower()
    return {"eq": a == b, "ne": a != b, "gt": a > b,
            "lt": a < b, "ge": a >= b, "le": a <= b}[op]


# ── repeating groups ────────────────────────────────────────────────────────
# Case data carries groups that repeat (COBOL OCCURS): entitlement periods
# with start / end / resumption dates. "Usually the latest occurrence matters
# most", so `latest` is the DEFAULT scope — but see pick_latest(): "latest"
# is ambiguous, and picking the wrong row yields a confident WRONG diagnosis.
SCOPES = ("latest", "any", "all", "none", "count")


def occurrences(data, group: str) -> list:
    """The rows of a repeating group. A non-list value is treated as a single
    occurrence so a group that happens to hold one row still evaluates."""
    if not group:
        return []
    val = get_path(data, group)
    if val is _MISSING or val is None:
        return []
    return val if isinstance(val, list) else [val]


def pick_latest(rows: list, order_by: str = "", latest_is: str = "max_start",
                today: str = "") -> tuple:
    """(index, row) of the 'latest' occurrence, or (None, None).

    ⚠️ Deliberately explicit: last-array-element / max-start / open-period /
    covers-today disagree exactly in the messy cases that generate exceptions
    (resumed periods, overlaps, future-dated entitlements). The caller's
    choice is echoed back to the analyst so a wrong pick is visible, not
    silent.
    """
    if not rows:
        return (None, None)
    if latest_is == "array_order" or not order_by:
        return (len(rows) - 1, rows[-1])
    if latest_is == "open_period":
        for i, r in enumerate(rows):          # first row with no end date
            end = get_path(r, order_by)
            if end is _MISSING or not str(end or "").strip():
                return (i, r)
        # fall through to max_start when every period is closed
    if latest_is == "covers_today" and today:
        for i, r in enumerate(rows):
            start = str(get_path(r, order_by) or "")
            if start and _date_key(start) <= _date_key(today):
                return (i, r)
    best_i, best_key = None, None
    for i, r in enumerate(rows):
        key = get_path(r, order_by)
        if key is _MISSING or key is None:
            continue
        # date-aware: MM/DD/YYYY keys ordered as text pick the wrong
        # "latest" across a year boundary — normalize dates to ISO.
        k = _date_key(key)
        if best_key is None or k > best_key:
            best_i, best_key = i, k
    return (best_i, rows[best_i]) if best_i is not None else (len(rows) - 1, rows[-1])


def _resolve_value(raw: str, row, data):
    """`$.x` = this occurrence, `$$.x` = case level, anything else a literal.
    Returns (value, label, is_ref)."""
    raw = (raw or "").strip()
    if raw.startswith("$$."):
        v = get_path(data, raw[3:])
        return v, f"{raw[3:]} = " + ("«missing»" if v is _MISSING else str(v)), True
    if raw.startswith("$."):
        base = row if row is not None else data
        v = get_path(base, raw[2:])
        return v, f"{raw[2:]} = " + ("«missing»" if v is _MISSING else str(v)), True
    return raw, raw, False


def _eval_one(c: dict, row, data) -> tuple:
    """Evaluate a single check against one occurrence (or the case root).
    Returns (hit, actual, expected_label, error)."""
    path = (c.get("path") or "").strip()
    op = (c.get("op") or "eq").strip()
    base = row if row is not None else data
    actual = get_path(base, path)
    expected, label, is_ref = _resolve_value(c.get("value"), row, data)
    if is_ref and expected is _MISSING and op not in _UNARY:
        return (False, actual, label, f"{c.get('value')}: not found in case data")
    try:
        return (_compare(actual, op, expected), actual, label, None)
    except Exception as e:
        return (False, actual, label, f"{path} {op}: {e}")


def run_recipe(checks: list[dict], data, group_config: dict | None = None,
               today: str = "") -> dict:
    """Evaluate every check against the case data. Returns
    {matches: [...], evaluated: n, errors: [...], results: [...]} — ALL
    matching causes are reported, in authored order; the analyst judges
    between them. `results` holds one record per check — fired, quiet,
    error, or manual — so the reading shows what was RULED OUT, not just
    what hit: a quiet check with its found value is evidence too.

    Scalar checks omit `group`/`scope` and behave exactly as before —
    repeating-group support is purely additive.
    `group_config`: {group: {order_by, latest_is}} — how to pick "latest".
    """
    matches, errors, results = [], [], []
    evaluated = 0
    group_config = group_config or {}
    for c in checks:
        cause = (c.get("cause") or "").strip()
        if c.get("kind") == "manual":         # human step; never auto-evaluated
            results.append({"cause": cause or "manual step", "state": "manual",
                            "path": "", "op": "", "expected": "", "actual": "",
                            "note": "human step — not auto-evaluated"})
            continue
        path, op = (c.get("path") or "").strip(), (c.get("op") or "eq").strip()
        if not path or op not in OPS:
            continue
        evaluated += 1
        desc = cause or describe_check(c)

        def record(state, disp_path, expected="", actual="", note="", **extra):
            results.append({"cause": desc, "state": state, "path": disp_path,
                            "op": OPS[op], "expected": expected,
                            "actual": actual, "note": note, **extra})

        group = (c.get("group") or "").strip()
        if group:
            scope = (c.get("scope") or "latest").strip()
            gpath = f"{group}[{scope}].{path}"
            if scope not in SCOPES:
                errors.append(f"{group}: unknown scope '{scope}'")
                record("error", gpath, note=f"unknown scope '{scope}'")
                continue
            rows = occurrences(data, group)
            if not rows:
                errors.append(f"{group}: no occurrences in case data")
                record("error", gpath, note="no occurrences in case data")
                continue
            cfg = group_config.get(group, {})
            hits, first, err_seen = [], None, None
            found: list = []                  # distinct values, row order
            label = ""
            if scope == "latest":
                idx, row = pick_latest(rows, cfg.get("order_by", ""),
                                       cfg.get("latest_is", "max_start"), today)
                gpath = f"{group}[{idx}].{path}"
                hit, actual, label, err = _eval_one(c, row, data)
                if err:
                    errors.append(err)
                    record("error", gpath, note=err)
                    continue
                found.append(_show(actual))
                if hit:
                    hits.append(idx)
                    first = (idx, actual, label)
            else:
                for i, row in enumerate(rows):
                    hit, actual, label, err = _eval_one(c, row, data)
                    if err:
                        err_seen = err
                        continue
                    if _show(actual) not in found:
                        found.append(_show(actual))
                    if hit:
                        hits.append(i)
                        if first is None:
                            first = (i, actual, label)
                if err_seen and not hits:
                    errors.append(err_seen)
                    record("error", gpath, note=err_seen)
                    continue
            fired = {"any": bool(hits), "all": len(hits) == len(rows),
                     "none": not hits, "count": bool(hits),
                     "latest": bool(hits)}[scope]
            record("fired" if fired else "quiet", gpath,
                   expected=label if op not in _UNARY else "",
                   actual=", ".join(found[:4]) + ("…" if len(found) > 4 else ""),
                   matched_count=len(hits), occurrences_total=len(rows))
            if not fired:
                continue
            idx, actual, label = first if first else (None, _MISSING, "")
            # A fired `none` scope has no matching row — the evidence is
            # every value that was ruled out, not a blank.
            shown = (_show(actual) if first else
                     ", ".join(found[:4]) + ("…" if len(found) > 4 else ""))
            matches.append({
                "cause": desc,
                "unnamed": not cause,
                "steps": c.get("steps") or "",
                "path": f"{group}[{idx}].{path}" if idx is not None else f"{group}.{path}",
                "actual": shown,
                "op": OPS[op],
                "expected": label if op not in _UNARY else "",
                "scope": scope,
                "group": group,
                "occurrence": idx,
                "occurrences_total": len(rows),
                "matched_count": len(hits),
                "confidence": c.get("confidence") or "definitive",
                "screen": c.get("screen") or "",
                "fix_field": c.get("fix_field") or "",
            })
            continue

        # ── scalar check (unchanged behaviour) ──
        actual = get_path(data, path)
        raw_expected = (c.get("value") or "").strip()
        if raw_expected.startswith("$."):          # field-to-field compare
            expected = get_path(data, raw_expected[2:])
            expected_label = f"{raw_expected[2:]} = " + (
                "«missing»" if expected is _MISSING else str(expected))
            if expected is _MISSING and op not in _UNARY:
                errors.append(f"{raw_expected}: not found in case data")
                record("error", path, actual=_show(actual),
                       note=f"{raw_expected}: not found in case data")
                continue
        else:
            expected = raw_expected
            expected_label = raw_expected
        try:
            hit = _compare(actual, op, expected)
        except Exception as e:  # defensive: a bad check must not kill triage
            errors.append(f"{path} {op}: {e}")
            record("error", path, actual=_show(actual), note=str(e))
            continue
        record("fired" if hit else "quiet", path,
               expected=expected_label if op not in _UNARY else "",
               actual=_show(actual))
        if hit:
            matches.append({
                "cause": desc,
                "unnamed": not cause,
                "steps": c.get("steps") or "",
                "path": path,
                "actual": _show(actual),
                "op": OPS[op],
                "expected": expected_label if op not in _UNARY else "",
                "confidence": c.get("confidence") or "definitive",
                "screen": c.get("screen") or "",
                "fix_field": c.get("fix_field") or "",
            })
    return {"matches": matches, "evaluated": evaluated, "errors": errors,
            "results": results}


def check_fires(check: dict, data, group_config: dict | None = None,
                today: str = "") -> dict:
    """Single-check evaluation for the Lab's live FIRES / does-not-fire
    feedback. Same engine as run_recipe so the workbench can never disagree
    with production triage."""
    out = run_recipe([check], data, group_config, today)
    if out["errors"]:
        return {"state": "error", "detail": out["errors"][0]}
    if out["matches"]:
        m = out["matches"][0]
        return {"state": "fires", "detail": evidence_text(m), "match": m}
    if check.get("kind") == "manual":
        return {"state": "manual", "detail": "human step — not auto-evaluated"}
    rec = out["results"][0] if out["results"] else None
    if rec and rec["state"] == "quiet" and rec["actual"]:
        return {"state": "quiet",
                "detail": f"does not fire — found {rec['actual']}"}
    return {"state": "quiet", "detail": "does not fire on this case"}
