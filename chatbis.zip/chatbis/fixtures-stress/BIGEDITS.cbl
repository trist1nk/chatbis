       IDENTIFICATION DIVISION.
       PROGRAM-ID. BIGEDITS.
      * MASS BENEFIT EDIT MODULE - LARGE FIXTURE (GENERATED, SYNTHETIC)
       DATA DIVISION.
       WORKING-STORAGE SECTION.
           COPY ERRCODES.
       01  WS-CASE.
           05 WS-BENE-DOB        PIC 9(8).
           05 WS-ENT-DT          PIC 9(8).
           05 WS-TERM-DT         PIC 9(8).
           05 WS-PAY-AMT         PIC S9(7)V99 COMP-3.
           05 WS-PIA-AMT         PIC S9(7)V99 COMP-3.
           05 WS-MBA-AMT         PIC S9(7)V99 COMP-3.
           05 WS-STATE           PIC X(2).
           05 WS-CTZN-CD         PIC X(1).
           05 WS-CLM-TYPE        PIC X(3).
           05 WS-BIC             PIC X(2).
           05 WS-RFD-CD          PIC X(2).
           05 WS-ADDR-ZIP        PIC X(5).
           05 WS-BANK-RTN        PIC 9(9).
           05 WS-DED-AMT         PIC S9(5)V99 COMP-3.
           05 WS-OFFSET-AMT      PIC S9(5)V99 COMP-3.
           05 WS-WC-AMT          PIC S9(5)V99 COMP-3.
       PROCEDURE DIVISION.
       MAIN-CTL.
           PERFORM EDIT-GROUP-00
           PERFORM EDIT-GROUP-01
           PERFORM EDIT-GROUP-02
           PERFORM EDIT-GROUP-03
           PERFORM EDIT-GROUP-04
           PERFORM EDIT-GROUP-05
           PERFORM EDIT-GROUP-06
           PERFORM EDIT-GROUP-07
           PERFORM EDIT-GROUP-08
           PERFORM EDIT-GROUP-09
           PERFORM EDIT-GROUP-10
           PERFORM EDIT-GROUP-11
           GOBACK.
       EDIT-GROUP-00.
           IF WS-RFD-CD = SPACES
              IF WS-BANK-RTN = SPACES
                 MOVE 'E7001' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-ENT-DT < ZERO
              MOVE 'E7002' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-ADDR-ZIP = LOW-VALUES
              AND WS-ENT-DT NOT = SPACES
              MOVE 'E7003' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-STATE < ZERO
              IF WS-TERM-DT = SPACES
                 MOVE 'E7004' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-DED-AMT IS NEGATIVE
              MOVE 'E7005' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-CTZN-CD < ZERO
              AND WS-DED-AMT NOT = SPACES
              MOVE 'E7006' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-ENT-DT < WS-DED-AMT
              IF WS-PAY-AMT = SPACES
                 MOVE 'E7007' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-CTZN-CD > WS-PIA-AMT
              MOVE 'E7008' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-BANK-RTN < ZERO
              AND WS-CTZN-CD NOT = SPACES
              MOVE 'E7009' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-ENT-DT = LOW-VALUES
              IF WS-PIA-AMT = SPACES
                 MOVE 'E7010' TO WS-ERR-CD
              END-IF
           END-IF

       EDIT-GROUP-01.
           IF WS-BIC IS NEGATIVE
              MOVE 'E7011' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-PAY-AMT = LOW-VALUES
              AND WS-BIC NOT = SPACES
              MOVE 'E7012' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-MBA-AMT < ZERO
              IF WS-STATE = SPACES
                 MOVE 'E7013' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-ADDR-ZIP < ZERO
              MOVE 'E7014' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-ENT-DT = LOW-VALUES
              AND WS-STATE NOT = SPACES
              MOVE 'E7015' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-WC-AMT > WS-PIA-AMT
              IF WS-DED-AMT = SPACES
                 MOVE 'E7016' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-RFD-CD IS NEGATIVE
              MOVE 'E7017' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-ADDR-ZIP > 99999999
              AND WS-CTZN-CD NOT = SPACES
              MOVE 'E7018' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-MBA-AMT > WS-PIA-AMT
              IF WS-CTZN-CD = SPACES
                 MOVE 'E7019' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-TERM-DT = LOW-VALUES
              MOVE 'E7020' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF

       EDIT-GROUP-02.
           IF WS-WC-AMT > 99999999
              AND WS-OFFSET-AMT NOT = SPACES
              MOVE 'E7021' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-BIC = LOW-VALUES
              IF WS-TERM-DT = SPACES
                 MOVE 'E7022' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-PAY-AMT = LOW-VALUES
              MOVE 'E7023' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-MBA-AMT < WS-DED-AMT
              AND WS-RFD-CD NOT = SPACES
              MOVE 'E7024' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-PIA-AMT IS NEGATIVE
              IF WS-DED-AMT = SPACES
                 MOVE 'E7025' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-ENT-DT > WS-PIA-AMT
              MOVE 'E7026' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-RFD-CD > 99999999
              AND WS-ADDR-ZIP NOT = SPACES
              MOVE 'E7027' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-WC-AMT = LOW-VALUES
              IF WS-OFFSET-AMT = SPACES
                 MOVE 'E7028' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-TERM-DT < WS-DED-AMT
              MOVE 'E7029' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-CLM-TYPE IS NEGATIVE
              AND WS-TERM-DT NOT = SPACES
              MOVE 'E7030' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF

       EDIT-GROUP-03.
           IF WS-ENT-DT > WS-PIA-AMT
              IF WS-BIC = SPACES
                 MOVE 'E7031' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-OFFSET-AMT > 99999999
              MOVE 'E7032' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-ADDR-ZIP < ZERO
              AND WS-OFFSET-AMT NOT = SPACES
              MOVE 'E7033' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-ADDR-ZIP = SPACES
              IF WS-PAY-AMT = SPACES
                 MOVE 'E7034' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-WC-AMT < ZERO
              MOVE 'E7035' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-BIC = SPACES
              AND WS-CTZN-CD NOT = SPACES
              MOVE 'E7036' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-BANK-RTN IS NEGATIVE
              IF WS-WC-AMT = SPACES
                 MOVE 'E7037' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-TERM-DT = SPACES
              MOVE 'E7038' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-BANK-RTN = LOW-VALUES
              AND WS-CLM-TYPE NOT = SPACES
              MOVE 'E7039' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-PIA-AMT < WS-DED-AMT
              IF WS-DED-AMT = SPACES
                 MOVE 'E7040' TO WS-ERR-CD
              END-IF
           END-IF

       EDIT-GROUP-04.
           IF WS-CLM-TYPE > WS-PIA-AMT
              MOVE 'E7041' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-ADDR-ZIP > WS-PIA-AMT
              AND WS-BANK-RTN NOT = SPACES
              MOVE 'E7042' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-CTZN-CD = SPACES
              IF WS-TERM-DT = SPACES
                 MOVE 'E7043' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-MBA-AMT = SPACES
              MOVE 'E7044' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-CTZN-CD < ZERO
              AND WS-WC-AMT NOT = SPACES
              MOVE 'E7045' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-MBA-AMT > 99999999
              IF WS-BIC = SPACES
                 MOVE 'E7046' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-BENE-DOB = SPACES
              MOVE 'E7047' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-ADDR-ZIP = LOW-VALUES
              AND WS-RFD-CD NOT = SPACES
              MOVE 'E7048' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-PIA-AMT > WS-PIA-AMT
              IF WS-ENT-DT = SPACES
                 MOVE 'E7049' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-OFFSET-AMT < WS-DED-AMT
              MOVE 'E7050' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF

       EDIT-GROUP-05.
           IF WS-BANK-RTN IS NEGATIVE
              AND WS-BANK-RTN NOT = SPACES
              MOVE 'E7051' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-PAY-AMT IS NEGATIVE
              IF WS-BANK-RTN = SPACES
                 MOVE 'E7052' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-ENT-DT = SPACES
              MOVE 'E7053' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-STATE IS NEGATIVE
              AND WS-MBA-AMT NOT = SPACES
              MOVE 'E7054' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-PAY-AMT > 99999999
              IF WS-ENT-DT = SPACES
                 MOVE 'E7055' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-PAY-AMT < ZERO
              MOVE 'E7056' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-PAY-AMT > 99999999
              AND WS-BENE-DOB NOT = SPACES
              MOVE 'E7057' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-TERM-DT < WS-DED-AMT
              IF WS-STATE = SPACES
                 MOVE 'E7058' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-BANK-RTN = SPACES
              MOVE 'E7059' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-ADDR-ZIP = LOW-VALUES
              AND WS-ADDR-ZIP NOT = SPACES
              MOVE 'E7060' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF

       EDIT-GROUP-06.
           IF WS-WC-AMT < ZERO
              IF WS-PAY-AMT = SPACES
                 MOVE 'E7061' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-WC-AMT IS NEGATIVE
              MOVE 'E7062' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-WC-AMT > 99999999
              AND WS-TERM-DT NOT = SPACES
              MOVE 'E7063' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-PIA-AMT < ZERO
              IF WS-RFD-CD = SPACES
                 MOVE 'E7064' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-CLM-TYPE IS NEGATIVE
              MOVE 'E7065' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-BENE-DOB = SPACES
              AND WS-ADDR-ZIP NOT = SPACES
              MOVE 'E7066' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-PIA-AMT > WS-PIA-AMT
              IF WS-BENE-DOB = SPACES
                 MOVE 'E7067' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-BIC > WS-PIA-AMT
              MOVE 'E7068' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-CLM-TYPE = LOW-VALUES
              AND WS-ADDR-ZIP NOT = SPACES
              MOVE 'E7069' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-MBA-AMT > 99999999
              IF WS-CTZN-CD = SPACES
                 MOVE 'E7070' TO WS-ERR-CD
              END-IF
           END-IF

       EDIT-GROUP-07.
           IF WS-RFD-CD > WS-PIA-AMT
              MOVE 'E7071' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-STATE < WS-DED-AMT
              AND WS-CTZN-CD NOT = SPACES
              MOVE 'E7072' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-BANK-RTN > WS-PIA-AMT
              IF WS-CTZN-CD = SPACES
                 MOVE 'E7073' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-STATE = LOW-VALUES
              MOVE 'E7074' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-ADDR-ZIP > WS-PIA-AMT
              AND WS-BENE-DOB NOT = SPACES
              MOVE 'E7075' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-BENE-DOB < WS-DED-AMT
              IF WS-CLM-TYPE = SPACES
                 MOVE 'E7076' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-WC-AMT > 99999999
              MOVE 'E7077' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-ADDR-ZIP IS NEGATIVE
              AND WS-ADDR-ZIP NOT = SPACES
              MOVE 'E7078' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-ADDR-ZIP < ZERO
              IF WS-CTZN-CD = SPACES
                 MOVE 'E7079' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-PAY-AMT = SPACES
              MOVE 'E7080' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF

       EDIT-GROUP-08.
           IF WS-STATE > 99999999
              AND WS-STATE NOT = SPACES
              MOVE 'E7081' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-WC-AMT = LOW-VALUES
              IF WS-BENE-DOB = SPACES
                 MOVE 'E7082' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-WC-AMT > WS-PIA-AMT
              MOVE 'E7083' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-TERM-DT < WS-DED-AMT
              AND WS-PAY-AMT NOT = SPACES
              MOVE 'E7084' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-BANK-RTN < WS-DED-AMT
              IF WS-STATE = SPACES
                 MOVE 'E7085' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-WC-AMT = SPACES
              MOVE 'E7086' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-RFD-CD < ZERO
              AND WS-BANK-RTN NOT = SPACES
              MOVE 'E7087' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-OFFSET-AMT IS NEGATIVE
              IF WS-TERM-DT = SPACES
                 MOVE 'E7088' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-MBA-AMT = SPACES
              MOVE 'E7089' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-BENE-DOB = SPACES
              AND WS-OFFSET-AMT NOT = SPACES
              MOVE 'E7090' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF

       EDIT-GROUP-09.
           IF WS-PIA-AMT = LOW-VALUES
              IF WS-WC-AMT = SPACES
                 MOVE 'E7091' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-ADDR-ZIP = SPACES
              MOVE 'E7092' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-BENE-DOB < ZERO
              AND WS-PAY-AMT NOT = SPACES
              MOVE 'E7093' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-PIA-AMT IS NEGATIVE
              IF WS-STATE = SPACES
                 MOVE 'E7094' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-STATE < ZERO
              MOVE 'E7095' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-STATE > 99999999
              AND WS-CTZN-CD NOT = SPACES
              MOVE 'E7096' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-RFD-CD > 99999999
              IF WS-DED-AMT = SPACES
                 MOVE 'E7097' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-PIA-AMT < ZERO
              MOVE 'E7098' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-OFFSET-AMT > WS-PIA-AMT
              AND WS-DED-AMT NOT = SPACES
              MOVE 'E7099' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-PIA-AMT = LOW-VALUES
              IF WS-PIA-AMT = SPACES
                 MOVE 'E7100' TO WS-ERR-CD
              END-IF
           END-IF

       EDIT-GROUP-10.
           IF WS-BENE-DOB < WS-DED-AMT
              MOVE 'E7101' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-MBA-AMT = LOW-VALUES
              AND WS-BENE-DOB NOT = SPACES
              MOVE 'E7102' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-PIA-AMT = SPACES
              IF WS-PIA-AMT = SPACES
                 MOVE 'E7103' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-WC-AMT = LOW-VALUES
              MOVE 'E7104' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-ENT-DT > 99999999
              AND WS-WC-AMT NOT = SPACES
              MOVE 'E7105' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-PAY-AMT = LOW-VALUES
              IF WS-ENT-DT = SPACES
                 MOVE 'E7106' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-CTZN-CD = SPACES
              MOVE 'E7107' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-ENT-DT < WS-DED-AMT
              AND WS-PAY-AMT NOT = SPACES
              MOVE 'E7108' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-OFFSET-AMT = LOW-VALUES
              IF WS-BENE-DOB = SPACES
                 MOVE 'E7109' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-TERM-DT IS NEGATIVE
              MOVE 'E7110' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF

       EDIT-GROUP-11.
           IF WS-STATE > WS-PIA-AMT
              AND WS-CLM-TYPE NOT = SPACES
              MOVE 'E7111' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-OFFSET-AMT = LOW-VALUES
              IF WS-WC-AMT = SPACES
                 MOVE 'E7112' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-CTZN-CD > WS-PIA-AMT
              MOVE 'E7113' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-STATE < WS-DED-AMT
              AND WS-OFFSET-AMT NOT = SPACES
              MOVE 'E7114' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-PIA-AMT IS NEGATIVE
              IF WS-PAY-AMT = SPACES
                 MOVE 'E7115' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-BANK-RTN IS NEGATIVE
              MOVE 'E7116' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-TERM-DT > WS-PIA-AMT
              AND WS-CTZN-CD NOT = SPACES
              MOVE 'E7117' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-DED-AMT < ZERO
              IF WS-STATE = SPACES
                 MOVE 'E7118' TO WS-ERR-CD
              END-IF
           END-IF
           IF WS-BIC < WS-DED-AMT
              MOVE 'E7119' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-PIA-AMT > WS-PIA-AMT
              AND WS-ADDR-ZIP NOT = SPACES
              MOVE 'E7120' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF

       WRITE-REJECT.
           DISPLAY 'BIGEDITS REJECT ' WS-ERR-CD
           GOBACK.
