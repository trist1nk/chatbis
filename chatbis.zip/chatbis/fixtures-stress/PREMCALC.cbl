       IDENTIFICATION DIVISION.
       PROGRAM-ID. PREMCALC.
      * PREMIUM CALC + UNDERWRITING EDITS - COMPLEX STRESS FIXTURE
       DATA DIVISION.
       WORKING-STORAGE SECTION.
           COPY ERRCODES.
       01  WS-POLICY.
           05 WS-ISSUE-DATE      PIC 9(8).
           05 WS-BIRTH-DATE      PIC 9(8).
           05 WS-ISSUE-AGE       PIC S9(3) COMP-3.
           05 WS-STATE           PIC X(2).
           05 WS-PLAN-TYPE       PIC X(1).
              88 PLAN-TERM          VALUE 'T'.
              88 PLAN-WHOLE         VALUE 'W'.
           05 WS-FACE-AMT        PIC S9(9)V99 COMP-3.
           05 WS-ANNUAL-PREM     PIC S9(7)V99 COMP-3.
           05 WS-MODE-CD         PIC X(1).
           05 WS-SMOKER-FLAG     PIC X(1).
              88 IS-SMOKER          VALUE 'Y'.
           05 WS-RATE-CLASS      PIC X(2).
           05 WS-SURCHARGE       PIC S9(3)V99 COMP-3.
       PROCEDURE DIVISION.
       MAIN-CTL.
           PERFORM EDIT-POLICY
           PERFORM RATE-POLICY
           GOBACK.
       EDIT-POLICY.
           IF WS-ISSUE-DATE < WS-BIRTH-DATE
              MOVE 'E5001' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-ISSUE-AGE > 85 OR WS-ISSUE-AGE < 0
              MOVE 'E5002' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-STATE = 'VA' OR 'MD' OR 'DC'
              CONTINUE
           ELSE
              MOVE 'E5003' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-FACE-AMT IS NEGATIVE
              MOVE 'E5004' TO WS-ERR-CD
           END-IF
           IF PLAN-TERM AND WS-ISSUE-AGE > 70
              MOVE 'E5005' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-FACE-AMT > 5000000.00
              AND WS-RATE-CLASS NOT = 'PF'
              MOVE 'E5006' TO WS-ERR-CD
           END-IF
           IF PLAN-WHOLE
              IF WS-ISSUE-AGE > 75
                 IF WS-FACE-AMT > 100000
                    MOVE 'E5011' TO WS-ERR-CD
                    PERFORM WRITE-REJECT
                 END-IF
              END-IF
           END-IF.
       RATE-POLICY.
           EVALUATE TRUE
              WHEN WS-ISSUE-AGE < 18
                 MOVE 'JUV' TO WS-RATE-CLASS
              WHEN IS-SMOKER AND WS-ISSUE-AGE > 60
                 MOVE 'SS' TO WS-RATE-CLASS
                 PERFORM LOAD-SURCHARGE
              WHEN OTHER
                 MOVE 'ST' TO WS-RATE-CLASS
           END-EVALUATE
           EVALUATE WS-MODE-CD
              WHEN 'M'
                 COMPUTE WS-ANNUAL-PREM = WS-ANNUAL-PREM * 0.0875
              WHEN 'Q'
                 COMPUTE WS-ANNUAL-PREM = WS-ANNUAL-PREM * 0.26
              WHEN OTHER
                 MOVE 'E5007' TO WS-ERR-CD
           END-EVALUATE
           IF WS-ANNUAL-PREM / 12 < 10.00
              DISPLAY 'WARNING - PREMIUM BELOW MINIMUM MODAL AMOUNT'
              MOVE 'E5008' TO WS-ERR-CD
           END-IF.
       WRITE-REJECT.
           CALL 'REJWRT01' USING WS-POLICY WS-ERR-CD.
       LOAD-SURCHARGE.
           EXEC SQL
              SELECT SURCHARGE_PCT INTO :WS-SURCHARGE
              FROM RATE_SURCHARGE
              WHERE RATE_CLASS = :WS-RATE-CLASS
           END-EXEC
           EVALUATE SQLCODE
              WHEN 0
                 CONTINUE
              WHEN +100
                 MOVE 'E5009' TO WS-ERR-CD
              WHEN -811
                 MOVE 'E5010' TO WS-ERR-CD
              WHEN OTHER
                 MOVE 'E9001' TO WS-ERR-CD
           END-EVALUATE.
