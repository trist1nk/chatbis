"""ChatBIS — the case, presented as the MBR.

Analysts triage against the MBR — the master record the shop's DB2
carries, spread across tables and occurrences. The rails that fetch a
case (REST endpoints, bundles, the SQL rail) are transport; what the
analyst should SEE is the MBR itself. field_map's db2_column
(SCHEMA.TABLE.COLUMN) already declares where each JSON fact lives in
that record; this module projects a fetched case through those
declarations into table-shaped sections — master rows for scalar
columns, occurrence rows for array-backed tables.

Copybook areas (area_map: TDA/PDA/EE seeding) are internal plumbing for
the runner and the carry analysis. They deliberately do NOT appear here.

Doctrine: declared mappings only. A JSON leaf no mapping covers is
listed by raw path with no invented label — that list is the mapping
backlog, not an error. A field_map row whose db2_column isn't
SCHEMA.TABLE.COLUMN (or whose json_path nests [] twice) lands in
`refused`, by name, with the reason. Case data is session-memory only —
nothing in this module writes anywhere.

All pure functions over a connection and a parsed case dict, testable
without a server.
"""
from __future__ import annotations

import datetime

from .recipe import get_path, _MISSING

# Display-direction spelling of a declared format: how the MBR carries
# the value. Dates only — text/decimal/integer/flag read the same in
# both worlds, so they contribute nothing and return None.
_DATE_SPELL = {
    "yyyymmdd": "%Y%m%d",
    "yymmdd": "%y%m%d",
    "julian-ccyyddd": "%Y%j",
    "julian-yyddd": "%y%j",
}


def to_mainframe(value, fmt: str | None) -> str | None:
    """The value as the MBR spells it, or None when the spelling is the
    same (or not derivable — never guess a date)."""
    strf = _DATE_SPELL.get(fmt or "")
    if not strf:
        return None
    try:
        d = datetime.date.fromisoformat(str(value).strip()[:10])
    except (ValueError, TypeError):
        return None
    return d.strftime(strf)


def split_db2(db2: str | None) -> tuple[str, str, str] | None:
    """SCHEMA.TABLE.COLUMN → parts; TABLE.COLUMN gets an empty schema.
    Anything else is not an MBR address — None, and the caller refuses
    by name rather than mis-filing the fact."""
    parts = [p.strip() for p in (db2 or "").strip().split(".")]
    if len(parts) == 3 and all(parts):
        return parts[0], parts[1], parts[2]
    if len(parts) == 2 and all(parts):
        return "", parts[0], parts[1]
    return None


def _leaves(data, prefix: str = "", in_list: bool = False):
    """Every scalar leaf as (generalized_path, value). List indices
    generalize to [] so leaves compare against declared json_paths:
    entitlementPeriods[].startDate, not entitlementPeriods.2.startDate."""
    if isinstance(data, dict):
        for k, v in data.items():
            yield from _leaves(v, f"{prefix}.{k}" if prefix else k)
    elif isinstance(data, list):
        for item in data:
            yield from _leaves(item, prefix + "[]", in_list=True)
    else:
        yield prefix, data


def project_case(conn, data) -> dict:
    """The case as the MBR. Returns:
      sections: [{schema, table, root, columns:[{column,label,json_path,
                 format}], rows: [[{v, mf} ...] ...]}]
                root None = master row (one row); root set = occurrence
                table fed by that JSON array.
      no_home:  field_map rows mapped in JSON but with no db2_column —
                known facts with no declared MBR address yet.
      refused:  (label, reason) declarations this projection cannot use.
      unmapped: [(path, value)] JSON leaves no declaration covers.
      covered/total: leaf counts for the coverage line.
    """
    maps = conn.execute(
        "SELECT * FROM field_map ORDER BY id").fetchall()
    sections: dict[tuple, dict] = {}
    mbr_paths: set[str] = set()
    known_paths: set[str] = set()
    no_home: list[dict] = []
    refused: list[tuple[str, str]] = []
    for m in maps:
        jp = (m["json_path"] or "").strip()
        label = m["label"] or m["cobol_field"] or jp
        if not jp:
            continue                      # DB2/COBOL-only row: nothing to place
        known_paths.add(jp.lower())
        if not (m["db2_column"] or "").strip():
            no_home.append({"label": label, "json_path": jp})
            continue
        addr = split_db2(m["db2_column"])
        if not addr:
            refused.append((label, f"'{m['db2_column']}' is not "
                                   f"SCHEMA.TABLE.COLUMN"))
            continue
        if jp.count("[]") > 1:
            refused.append((label, f"'{jp}' nests [] twice — one "
                                   f"occurrence level is supported"))
            continue
        schema, table, column = addr
        root, sub = None, jp
        if "[]" in jp:
            root, _, sub = jp.partition("[]")
            root = root.rstrip(".")
            sub = sub.lstrip(".")
        key = (schema, table, root)
        sec = sections.setdefault(key, {"schema": schema, "table": table,
                                        "root": root, "columns": []})
        sec["columns"].append({"column": column, "label": label,
                               "json_path": jp, "sub": sub,
                               "format": m["format"] or ""})
        mbr_paths.add(jp.lower())

    out = []
    for sec in sections.values():
        cols = sec["columns"]
        if sec["root"] is None:
            row = []
            hit = False
            for c in cols:
                v = get_path(data, c["sub"])
                if v is _MISSING:
                    row.append({"v": None, "mf": None})
                else:
                    hit = True
                    row.append({"v": v, "mf": to_mainframe(v, c["format"])})
            sec["rows"] = [row] if hit else []
        else:
            arr = get_path(data, sec["root"])
            rows = []
            if isinstance(arr, list):
                for item in arr:
                    row = []
                    for c in cols:
                        v = get_path(item, c["sub"]) if c["sub"] else item
                        row.append({"v": None if v is _MISSING else v,
                                    "mf": None if v is _MISSING
                                    else to_mainframe(v, c["format"])})
                    rows.append(row)
            sec["rows"] = rows
        out.append(sec)
    # Tables with data first, in declaration order; empty ones trail so
    # "not in this pull" doesn't push real facts below the fold.
    out.sort(key=lambda s: 0 if s["rows"] else 1)

    unmapped, covered, total = [], 0, 0
    for path, value in _leaves(data if isinstance(data, (dict, list))
                               else {}):
        total += 1
        lp = path.lower()
        if lp in mbr_paths:
            covered += 1
        elif lp not in known_paths:
            unmapped.append((path, value))
    return {"sections": out, "no_home": no_home, "refused": refused,
            "unmapped": unmapped, "covered": covered, "total": total}
