"""ChatBIS — the DFR assembler: deterministic skeleton, model prose.

For a document that must be COMPLETE, the model is the wrong author —
the miner already extracted every rule, and a 300-rule module must not
be truncated to fit a context window. So the requirements body is
assembled deterministically from the full mined profile (every rule,
any size, milliseconds), and the model contributes only the connective
prose: one bounded module-description paragraph. If the model is
offline, the draft still assembles whole — the description slot says
so instead.

The output is a markdown DRAFT, clearly marked, for SME review. It is
never written into the document library; ingestion stays the only door
and it is human-operated.
"""
from __future__ import annotations

from .investigate import exec_describe_program, llm_chat

PROSE_PROMPT = (
    "Write ONE paragraph (90 words max) describing what the {name} "
    "module does, for the opening of a requirements document. Use only "
    "these mined facts, invent nothing:\n{facts}\nOutput only the "
    "paragraph."
)

SUMMARY_PROMPT = (
    "Write the 'Requirements summary' for a requirements document about "
    "the {name} module: one or two paragraphs, 130 words max, no "
    "heading. Below is the COMPLETE digest of its mined rules "
    "(condition -> code, grouped by paragraph). Summarize what the "
    "module enforces — the major groups of checks, the fields they "
    "guard, the most consequential rejections. Invent nothing:\n"
    "{digest}\nOutput only the text."
)


def rules_digest(prof: dict, budget_chars: int = 9000) -> str:
    """Every mined rule, compressed to 'condition -> code' lines grouped
    by paragraph — small enough for the model to see the WHOLE module
    while writing the summary. Over budget, groups keep their honest
    counts and drop tail entries with '+N more'."""
    groups: dict[str, list] = {}
    for r in prof.get("business_rules", []):
        groups.setdefault(r.get("paragraph") or "(main)", []).append(r)

    def render(per_group: int | None) -> str:
        lines = [f"{len(prof.get('business_rules', []))} rules across "
                 f"{len(groups)} paragraphs"]
        for para, rs in groups.items():
            shown = rs if per_group is None else rs[:per_group]
            entries = []
            for r in shown:
                e = r.get("when") or "(untranslated)"
                if r.get("code"):
                    e += f" -> {r['code']}"
                entries.append(e)
            more = ("" if len(shown) == len(rs)
                    else f" (+{len(rs) - len(shown)} more)")
            lines.append(f"{para} ({len(rs)}): "
                         + "; ".join(entries) + more)
        return "\n".join(lines)

    text = render(None)
    if len(text) > budget_chars:
        text = render(4)
    if len(text) > budget_chars:
        text = text[:budget_chars] + "\n[digest truncated]"
    return text


def _ask(cfg: dict, prompt: str) -> str | None:
    try:
        msg = llm_chat(cfg, [{"role": "user", "content": prompt}], [])
        return (msg.get("content") or "").strip() or None
    except Exception:
        return None


def build_prose(cfg: dict | None, prof: dict) -> str | None:
    """The one model-written paragraph. Bounded, fail-soft: any error
    returns None and the assembled draft says the description is
    pending — a missing paragraph must never block a complete draft."""
    if not cfg:
        return None
    facts = {
        "application": prof.get("application"),
        "copies": prof.get("copies"), "calls": prof.get("calls"),
        "sql_tables": prof.get("sql_tables"),
        "batch_jobs": prof.get("batch_jobs"),
        "codes": [c["code"] for c in prof.get("codes_raised_or_set", [])][:10],
        "sample_rules": [r["when"] for r in prof.get("business_rules", [])[:6]],
    }
    return _ask(cfg, PROSE_PROMPT.format(name=prof["program"],
                                         facts=facts))


def build_summary(cfg: dict | None, prof: dict) -> str | None:
    """The requirements-summary section — model-written from the full
    compressed rule digest. Bounded and fail-soft like the
    description."""
    if not cfg or not prof.get("business_rules"):
        return None
    return _ask(cfg, SUMMARY_PROMPT.format(
        name=prof["program"], digest=rules_digest(prof)))


def assemble_dfr(conn, name: str, cfg: dict | None = None,
                 with_prose: bool = True) -> tuple[str | None, str | None]:
    """(markdown, error). Every mined rule becomes a numbered
    requirement — no cap, no window, no model in the loop for the
    parts that must be complete."""
    prof = exec_describe_program(conn, name, rule_limit=None)
    if "error" in prof:
        return None, prof["error"]
    prose = build_prose(cfg, prof) if with_prose else None
    summary = build_summary(cfg, prof) if with_prose else None

    L: list[str] = []
    w = L.append
    w(f"# DFR — {prof['program']} (DRAFT)")
    w("")
    w("> **Draft derived from mined source by ChatBIS — for SME "
      "review.** Every requirement below traces to a mined decision "
      "gate in the program; only §1–§2 are model-written.")
    w("")
    meta = [f"**Program:** {prof['program']}"]
    if prof.get("application"):
        meta.append(f"**Application:** {prof['application']}")
    if prof.get("file"):
        meta.append(f"**Source member:** {prof['file']}")
    w(" · ".join(meta))
    w("")
    w("## 1. Module description")
    w("")
    w(prose if prose else
      "_(description pending — model offline at assembly; an SME or a "
      "later run fills this paragraph)_")
    w("")
    w("## 2. Requirements summary")
    w("")
    w(summary if summary else
      "_(summary pending — model offline at assembly, or no rules "
      "mined; an SME or a later run fills this section)_")
    w("")
    w("## 3. Interfaces and dependencies")
    w("")

    def inv(label, items):
        w(f"- **{label}:** " + (", ".join(
            f"`{x}`" for x in items) if items else "none mined"))
    inv("Copybooks", prof.get("copies"))
    inv("Called programs", prof.get("calls"))
    inv("SQL tables", prof.get("sql_tables"))
    inv("CICS", prof.get("cics"))
    jobs = [f"`{j['job']}` step `{j['step']}`"
            for j in prof.get("batch_jobs", [])]
    w("- **Batch schedule:** " + (", ".join(jobs) if jobs else
                                  "none mined"))
    w("")
    w("## 4. Functional requirements")
    w("")
    rules = prof.get("business_rules", [])
    if not rules:
        w("_No decision gates were mined from this program._")
    meanings = {c["code"]: c["meaning"]
                for c in prof.get("codes_raised_or_set", [])}
    for i, r in enumerate(rules, 1):
        w(f"### R-{i:03d}")
        w(f"- **When:** {r.get('when') or '(condition not translated)'}")
        acts = r.get("actions") or []
        if acts:
            w(f"- **Then:** {'; '.join(acts)}")
        if r.get("code"):
            mean = meanings.get(r["code"])
            w(f"- **Raises:** `{r['code']}`"
              + (f" — {mean}" if mean else ""))
        if r.get("paragraph"):
            w(f"- **Where:** paragraph `{r['paragraph']}`")
        w("")
    w("## 5. Exception code appendix")
    w("")
    codes = prof.get("codes_raised_or_set", [])
    if codes:
        w("| Code | Meaning |")
        w("|------|---------|")
        for c in codes:
            w(f"| `{c['code']}` | {c['meaning'] or '(not yet curated)'} |")
    else:
        w("_No codes raised or set by this module._")
    w("")
    w(f"---\n_{prof['mined_note']} · assembled by ChatBIS from the "
      f"mined profile; §1–§2 are the only model-written text._")
    return "\n".join(L), None
