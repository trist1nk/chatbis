"""ChatBIS prototype — COBOL text handling and exception mining.

Pattern-based on purpose (per spec §9): PROGRAM-ID, paragraphs, COPY, CALL,
EXEC SQL, 88-levels, and MOVE-literal-to-error-field. No grammar. The
emitting-condition heuristic is the spec's §5.2 walk-back: from the emitting
statement, climb to the nearest preceding IF / EVALUATE / WHEN and quote it
verbatim with a confidence flag.

All functions are pure text-in/data-out so the mining is unit-testable
without a database.
"""
from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field


# ── decoding & format ───────────────────────────────────────────────────────

def decode_bytes(raw: bytes) -> tuple[str, str]:
    """Return (text, encoding). EBCDIC first-class: stock Python ships
    cp037/cp1047 codecs, so mainframe extracts need no extra tooling."""
    if not raw:
        return "", "utf-8"
    try:
        text = raw.decode("utf-8")
        return text, "utf-8"
    except UnicodeDecodeError:
        pass
    # EBCDIC heuristic: NL (0x15 / 0x25) present or high-bit density where
    # utf-8 failed. cp037 covers US shops; cp1047 differs only in a few glyphs.
    text = raw.decode("cp037")
    return text, "cp037"


def split_records(text: str) -> list[str]:
    """Handle both newline-delimited files and fixed 80-byte records with
    no line terminators (a raw PDS member dump)."""
    if "\n" in text or "\r" in text:
        return text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    if len(text) > 80 and len(text) % 80 == 0:
        return [text[i:i + 80] for i in range(0, len(text), 80)]
    return [text]


def detect_format(lines: list[str]) -> str:
    """fixed vs free: fixed-format COBOL carries sequence numbers or blanks
    in cols 1-6 and code starting at col 8."""
    votes = 0
    considered = 0
    for ln in lines:
        if not ln.strip():
            continue
        considered += 1
        head = ln[:6]
        if len(ln) >= 7 and (head.strip() == "" or head.strip().isdigit()):
            if ln[6:7] in (" ", "*", "-", "/", "D"):
                votes += 1
    return "fixed" if considered and votes / considered >= 0.8 else "free"


@dataclass
class CodeLine:
    lineno: int          # 1-based, in the ORIGINAL file
    text: str            # normalized source text (area A onward for fixed)
    comment: bool


def normalize_lines(lines: list[str], fmt: str) -> list[CodeLine]:
    """Strip cols 1-6 and 73-80 for fixed format; classify comments.
    Original text stays in the file store — this feeds mining and search."""
    out: list[CodeLine] = []
    for i, ln in enumerate(lines, start=1):
        if fmt == "fixed":
            indicator = ln[6:7]
            body = ln[7:72].rstrip()
            comment = indicator in ("*", "/")
        else:
            body = ln.rstrip()
            comment = body.lstrip().startswith("*")
        out.append(CodeLine(i, body, comment))
    return out


# ── search tokenization (FR-4.2) ────────────────────────────────────────────

_IDENT = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]*")


def search_tokens(text: str) -> str:
    """Emit each identifier verbatim AND split, so WS-CUST-NAME matches
    'ws-cust-name', 'cust', and 'cust name'. Hyphens become an inert joiner
    (x7f-free: use '·'? no — keep ASCII) so FTS treats the verbatim form as
    one token: WS-CUST-NAME -> wsxcustxname + ws cust name."""
    parts: list[str] = []
    for m in _IDENT.finditer(text):
        tok = m.group(0).lower()
        joined = tok.replace("-", "x").replace("_", "x")
        parts.append(joined)
        if "-" in tok or "_" in tok:
            parts.extend(p for p in re.split(r"[-_]", tok) if p)
    return " ".join(parts)


def query_tokens(query: str) -> str:
    """Apply the same transform to a user query so both sides agree."""
    return search_tokens(query)


# ── mining ──────────────────────────────────────────────────────────────────

RE_PROGRAM_ID = re.compile(r"PROGRAM-ID\s*\.\s*([A-Z0-9-]+)", re.I)
RE_COPY = re.compile(r"\bCOPY\s+([A-Z0-9-]+)", re.I)
RE_CALL = re.compile(r"\bCALL\s+'([A-Z0-9-]+)'", re.I)
RE_CALL_DYN = re.compile(r"\bCALL\s+([A-Z][A-Z0-9-]*)(?:\s|$)", re.I)
RE_USING = re.compile(r"\bUSING\s+(.*)", re.I | re.S)
_USING_NOISE = {"BY", "REFERENCE", "CONTENT", "VALUE", "END-CALL", "RETURNING"}
# MOVE 'E4417' TO WS-ERR-CD — the field must smell like an error/code field.
# Any MOVE of a short literal to a field — consulted only for fields the
# shop DECLARED as code vocabularies (a WIC-IND field has no ERR-ish token
# for the pattern above to catch).
RE_MOVE_ANY = re.compile(
    r"\bMOVE\s+'([A-Z0-9][A-Z0-9-]{0,9})'\s+TO\s+([A-Z0-9-]+)", re.I)

RE_MOVE_ERR = re.compile(
    r"\bMOVE\s+'([A-Z0-9][A-Z0-9-]{1,9})'\s+TO\s+"
    r"([A-Z0-9-]*(?:ERR|ERROR|EXC|EXCP|MSG|CODE|CD|STAT)[A-Z0-9-]*)",
    re.I,
)
RE_88_LEVEL = re.compile(
    r"^\s*88\s+([A-Z0-9-]+)\s+VALUE(?:\s+IS)?\s+'([^']+)'", re.I
)
RE_PARAGRAPH = re.compile(r"^([A-Z0-9][A-Z0-9-]*)\s*\.\s*$", re.I)
# Data-division items: level number + name + the rest of the clause.
# 88s are handled separately; FILLER is skipped at collection time.
RE_DATA_ITEM = re.compile(r"^\s*(0[1-9]|[1-4][0-9]|66|77)\s+([A-Z][A-Z0-9-]*)\s*(.*)$", re.I)
RE_PIC = re.compile(r"\bPIC(?:TURE)?\s+(?:IS\s+)?([A-Z0-9()VSZ*+.,$-]+)", re.I)
RE_USAGE = re.compile(r"\b(COMP-[123456]|COMP|BINARY|PACKED-DECIMAL|DISPLAY)\b", re.I)
RE_OCCURS = re.compile(r"\bOCCURS\s+(\d+)", re.I)
RE_CONDITION = re.compile(r"^\s*(IF|EVALUATE|WHEN)\b", re.I)
RE_IF_LINE = re.compile(r"^\s*IF\s+(.+)$", re.I)
RE_EVALUATE_LINE = re.compile(r"^\s*EVALUATE\s+(.+)$", re.I)
RE_WHEN_LINE = re.compile(r"^\s*WHEN\s+(.+)$", re.I)
RE_PERFORM = re.compile(r"\bPERFORM\s+([A-Z0-9-]+)", re.I)
RE_GOTO = re.compile(r"\bGO\s+TO\s+([A-Z0-9-]+)", re.I)
RE_SQL_TABLE = re.compile(r"\b(?:FROM|INTO|UPDATE|JOIN|DELETE\s+FROM)\s+([A-Z0-9_.]+)", re.I)

# Data movement. MOVE 'literal' TO X is an assignment, not a flow between
# fields — the flow graph only wants identifier→identifier edges.
RE_MOVE_FLOW = re.compile(
    r"\bMOVE\s+(?:CORR(?:ESPONDING)?\s+)?([A-Z][A-Z0-9-]*)"
    r"(?:\s*\([^)]*\))?\s+TO\s+([A-Z][A-Z0-9-]*(?:\s*,?\s+[A-Z][A-Z0-9-]*)*)",
    re.I)
RE_ARITH = re.compile(
    r"\b(COMPUTE|ADD|SUBTRACT)\s+(.+?)(?:\s+GIVING\s+([A-Z][A-Z0-9-]*)"
    r"|\s*=\s*(.+))?\s*\.?\s*$", re.I)
_MOVE_NOISE = {"SPACES", "SPACE", "ZEROS", "ZEROES", "ZERO", "LOW-VALUES",
               "HIGH-VALUES", "LOW-VALUE", "HIGH-VALUE", "NULL", "NULLS",
               "FUNCTION", "LENGTH", "ALL", "QUOTES", "QUOTE", "TRUE", "FALSE"}

# Host-variable pairing inside embedded SQL.
RE_SQL_SELECT_INTO = re.compile(
    r"\bSELECT\s+(.+?)\s+INTO\s+(.+?)\s+FROM\s+([A-Z0-9_.]+)", re.I | re.S)
RE_SQL_INSERT = re.compile(
    r"\bINSERT\s+INTO\s+([A-Z0-9_.]+)\s*\(([^)]+)\)\s*VALUES\s*\(([^)]+)\)",
    re.I | re.S)
RE_SQL_UPDATE_SET = re.compile(r"\bUPDATE\s+([A-Z0-9_.]+)\s+SET\s+(.+?)(?:\s+WHERE|$)",
                               re.I | re.S)
RE_HOSTVAR = re.compile(r":([A-Z][A-Z0-9-]*)", re.I)

# Cursors: the dominant batch pattern. The column list lives in DECLARE,
# the host variables in FETCH — different EXEC SQL blocks, one contract.
RE_SQL_DECLARE = re.compile(
    r"\bDECLARE\s+([A-Z][A-Z0-9-]*)\s+CURSOR\s+FOR\s+SELECT\s+(.+?)\s+FROM\s+"
    r"([A-Z0-9_.]+)", re.I | re.S)
RE_SQL_FETCH = re.compile(r"\bFETCH\s+([A-Z][A-Z0-9-]*)\s+INTO\s+(.+)", re.I | re.S)

# CICS: the online half of the shop. LINK/XCTL are the online CALLs, maps
# are the screens, ABEND codes are exceptions with a transaction dump.
RE_CICS_PGM = re.compile(r"\b(LINK|XCTL)\s+PROGRAM\('([A-Z0-9$#@]+)'\)", re.I)
RE_CICS_MAP = re.compile(
    r"\b(SEND|RECEIVE)\s+MAP\('([A-Z0-9$#@]+)'\)"
    r"(?:\s+MAPSET\('([A-Z0-9$#@]+)'\))?", re.I)
RE_CICS_ABEND = re.compile(r"\bABEND\b(?:\s+ABCODE\('([A-Z0-9-]+)'\))?", re.I)
RE_CICS_TRAN = re.compile(r"\bRETURN\s+TRANSID\('([A-Z0-9$#@]+)'\)", re.I)

# IDMS DML: a network database speaks verbs and records, not SQL. The verb
# names the record it touches; WITHIN names the set being walked.
RE_IDMS = re.compile(
    r"\b(OBTAIN|FIND|STORE|MODIFY|ERASE)\s+"
    r"(?:(CALC|CURRENT|FIRST|NEXT|LAST|PRIOR|OWNER|DUPLICATE)\s+)?"
    r"([A-Z][A-Z0-9]*-[A-Z0-9-]+)"
    r"(?:\s+WITHIN\s+([A-Z][A-Z0-9-]+))?", re.I)

# File I-O: the analyst's window into what a business function produced.
RE_SELECT_ASSIGN = re.compile(
    r"\bSELECT\s+([A-Z][A-Z0-9-]*)\s+ASSIGN\s+TO\s+([A-Z][A-Z0-9-]*)", re.I)
RE_FILE_ORG = re.compile(r"\bORGANIZATION\s+(?:IS\s+)?(INDEXED|SEQUENTIAL|RELATIVE)", re.I)
RE_OPEN = re.compile(r"\bOPEN\s+(INPUT|OUTPUT|I-O|EXTEND)\s+([A-Z][A-Z0-9-]*)", re.I)
RE_READ_INTO = re.compile(r"\bREAD\s+([A-Z][A-Z0-9-]*)(?:\s+INTO\s+([A-Z][A-Z0-9-]*))?", re.I)
RE_WRITE_FROM = re.compile(r"\b(WRITE|REWRITE)\s+([A-Z][A-Z0-9-]*)(?:\s+FROM\s+([A-Z][A-Z0-9-]*))?", re.I)

# Fields that smell like an error code target but are really flags/status
# noise; tune per shop.
CODE_BLOCKLIST = {"YES", "NO", "Y", "N", "OK", "TRUE", "FALSE"}


def looks_like_code(lit: str) -> bool:
    """A code is letter-led, contains a digit, and is at least three
    characters: E4417, S0C7, ALT-47F5. 'VA', 'AC', 'RET', '00' are domain
    values — states, statuses, claim types — and claiming them as
    exceptions is exactly the plausible-but-wrong finding this miner
    refuses. Real corpora are full of MOVE 'AC' TO WS-CLM-STAT."""
    t = lit.strip().upper()
    return (len(t) >= 3 and t[0].isalpha()
            and any(c.isdigit() for c in t)
            and all(c.isalnum() or c == "-" for c in t))

# Statements that sit alone on a line ending with a period and would
# otherwise masquerade as paragraph names.
NOT_PARAGRAPHS = {
    "GOBACK", "EXIT", "CONTINUE", "ELSE", "END-IF", "END-EVALUATE",
    "END-PERFORM", "END-READ", "END-SEARCH", "END-EXEC", "STOP",
}

# ── message classification: exception vs alert vs processing limitation ────
RE_DISPLAY = re.compile(r"\bDISPLAY\s+'([^']{4,120})'", re.I)
RE_CODE_IN_TEXT = re.compile(r"\b([A-Z]{1,4}-?\d{3,5})(?![A-Z0-9-])")
LIMIT_WORDS = ("LIMIT", "FULL", "OVERFLOW", "TRUNCAT", "EXCEED",
               "CAPACITY", "MAXIMUM", "TOO MANY", "TABLE FULL")
ALERT_WORDS = ("WARNING", "ALERT", "ATTENTION", "BYPASS", "SKIPPED")


def classify_message(text: str) -> str | None:
    """Bucket a DISPLAYed message. None = plain trace noise, don't catalog.
    Limitation wins over alert: 'WARNING - TABLE FULL' is a limitation."""
    u = text.upper()
    if any(w in u for w in LIMIT_WORDS):
        return "limitation"
    if any(w in u for w in ALERT_WORDS):
        return "alert"
    if RE_CODE_IN_TEXT.search(u):
        return "alert"  # a code surfaced via DISPLAY is at least an alert
    return None


def finding_code(program: str, category: str, text: str) -> str:
    """Stable synthetic code for a message-based finding (no literal code to
    key on). Hash of program + normalized message survives re-ingest and
    line drift."""
    norm = re.sub(r"\s+", " ", text.upper()).strip()
    h = hashlib.sha1(f"{program}|{norm}".encode()).hexdigest()[:4].upper()
    return ("LIM-" if category == "limitation" else "ALT-") + h


# ── business rule extraction: decision gates in analyst English ─────────────
_DATEISH = re.compile(r"DATE|DOB|-DT\b", re.I)
_IDENT_PREFIX = re.compile(r"^(WS|LS|WK|IN|OUT)-", re.I)


def _pretty_ident(tok: str) -> str:
    return _IDENT_PREFIX.sub("", tok).replace("-", " ")


def _pretty_literal(tok: str) -> str:
    t = tok.strip("'\"")
    if re.fullmatch(r"(19|20)\d{6}", t):
        return f"{t[:4]}-{t[4:6]}-{t[6:]}"  # 20160101 → 2016-01-01
    return t


def translate_condition(cond: str) -> str:
    """A COBOL condition in analyst English. The verbatim source stays the
    truth; this is the readable line above it. Date-ish comparisons phrase
    as before/after; figurative literals (SPACES, ZERO) become words."""
    c = re.sub(r"^\s*(IF|WHEN)\s+", "", cond.strip().rstrip("."), flags=re.I)
    dateish = bool(_DATEISH.search(c))
    toks = c.split()
    out: list[str] = []
    i = 0
    while i < len(toks):
        up = toks[i].upper()
        nxt = toks[i + 1].upper() if i + 1 < len(toks) else ""
        if up == "NOT" and nxt == "NUMERIC":
            out.append("is not numeric"); i += 2; continue
        if up == "NOT" and nxt in ("=", ">", "<"):
            out.append({"=": "is not", ">": "is not greater than",
                        "<": "is not less than"}[nxt]); i += 2; continue
        if up == "NUMERIC":
            out.append("is numeric"); i += 1; continue
        if up == ">=":
            out.append("is at least"); i += 1; continue
        if up == "<=":
            out.append("is at most"); i += 1; continue
        if up == ">":
            out.append("is after" if dateish else "is greater than"); i += 1; continue
        if up == "<":
            out.append("is before" if dateish else "is less than"); i += 1; continue
        if up == "=":
            out.append("is"); i += 1; continue
        if up in ("AND", "OR"):
            out.append(up.lower()); i += 1; continue
        if up in ("SPACES", "SPACE"):
            out.append("blank"); i += 1; continue
        if up in ("ZERO", "ZEROS", "ZEROES"):
            out.append("zero"); i += 1; continue
        if up == "IS":
            out.append("is"); i += 1; continue
        if up in ("NEGATIVE", "POSITIVE"):
            out.append(up.lower()); i += 1; continue
        if re.fullmatch(r"[A-Za-z][A-Za-z0-9-]*", toks[i]):
            out.append(_pretty_ident(toks[i])); i += 1; continue
        out.append(_pretty_literal(toks[i])); i += 1
    return " ".join(out)


@dataclass
class Rule:
    condition: str
    english: str
    lineno: int
    paragraph: str | None
    actions: list[str]       # "raises E7001", "warns: …", "performs EXIT-LOAD"
    code: str | None         # exception raised inside the branch, if any
    context: list[str] = field(default_factory=list)  # enclosing IF gates, in English


@dataclass
class Emission:
    code: str
    field: str
    lineno: int
    paragraph: str | None
    condition: str | None
    condition_lineno: int | None
    confidence: float


@dataclass
class SqlBlock:
    start_line: int
    end_line: int
    text: str
    tables: list[str] = field(default_factory=list)


@dataclass
class Message:
    text: str
    lineno: int
    paragraph: str | None
    category: str            # alert | limitation
    codes: list[str]         # code literals surfaced inside the message


@dataclass
class DataItem:
    level: int
    name: str
    pic: str | None
    usage: str
    item_type: str
    length: int | None       # bytes; None for groups
    occurs: int | None
    lineno: int


def _expand_pic(pic: str) -> str:
    """9(4)V99 → 9999V99 — expand repeat factors so symbols can be counted."""
    out: list[str] = []
    i = 0
    while i < len(pic):
        ch = pic[i]
        if i + 1 < len(pic) and pic[i + 1] == "(":
            j = pic.find(")", i)
            try:
                out.append(ch * int(pic[i + 2:j]))
                i = j + 1
                continue
            except (ValueError, IndexError):
                pass
        out.append(ch)
        i += 1
    return "".join(out)


def pic_info(pic: str | None, usage: str = "DISPLAY") -> tuple[str, int | None]:
    """(type, byte length) from a PIC clause + USAGE. The storage rules that
    matter in practice: DISPLAY = one byte per symbol position, COMP-3 packs
    two digits per byte plus a sign nibble, COMP/BINARY sizes by digit count
    (2/4/8 bytes)."""
    if not pic:
        return ("group", None)
    exp = _expand_pic(pic.upper()).replace("S", "")
    digits = exp.count("9")
    xs = exp.count("X") + exp.count("A")
    positions = len(exp.replace("V", ""))
    u = usage.upper()
    if digits and not xs:
        if "COMP-3" in u or "PACKED" in u:
            return ("packed", digits // 2 + 1)
        if u in ("COMP", "BINARY", "COMP-4", "COMP-5"):
            return ("binary", 2 if digits <= 4 else 4 if digits <= 9 else 8)
        if any(c in exp for c in "Z*,.$+-"):
            return ("numeric-edited", positions)
        return ("numeric", positions)
    if xs and not digits:
        return ("alphanumeric", xs)
    if xs or digits:
        return ("alphanumeric-edited", positions)
    return ("other", positions or None)


@dataclass
class CallSite:
    """One CALL statement. dynamic means the target is a variable — the
    program name is resolved at runtime, so `name` is the VARIABLE and the
    literal that fills it shows up as an ordinary scan touch."""
    name: str
    lineno: int
    using: list[str]
    dynamic: bool


@dataclass
class FlowEdge:
    """One data movement: MOVE source TO target (or an arithmetic result).
    group_move marks whole-record moves (both sides are group items or the
    statement had no PIC-level certainty) — recorded as-is, never expanded
    into per-field claims."""
    source: str
    target: str
    verb: str                # move | compute | add | subtract | string
    lineno: int


@dataclass
class CicsCmd:
    """One EXEC CICS command worth knowing about: op is link | xctl |
    send-map | receive-map | abend | return-transid; ref is the program,
    map, abend code, or transaction it names."""
    op: str
    ref: str
    mapset: str | None
    lineno: int


@dataclass
class IdmsOp:
    op: str                  # obtain | find | store | modify | erase
    record: str
    qualifier: str | None    # CALC | NEXT | ...
    set_name: str | None     # WITHIN <set>
    lineno: int


@dataclass
class FileUse:
    logical: str             # the SELECT name
    ddname: str              # ASSIGN TO — joins to the JCL DD
    org: str | None          # INDEXED = VSAM KSDS, etc.
    lineno: int
    ops: list = field(default_factory=list)   # [{op, target, line}]


@dataclass
class SqlMap:
    """One DB2 column ↔ host variable pairing, read positionally from an
    embedded statement. The last hop of every field's journey."""
    column: str              # TABLE.COLUMN when the table is known
    host: str                # WS-CLM-POLICY (colon stripped)
    stmt: str                # select | insert | update
    lineno: int


@dataclass
class MineResult:
    program_name: str | None = None
    paragraphs: list[tuple[str, int, int]] = field(default_factory=list)  # name, start, end
    copies: list[tuple[str, int]] = field(default_factory=list)
    calls: list[tuple[str, int]] = field(default_factory=list)
    emissions: list[Emission] = field(default_factory=list)
    level88: list[tuple[str, str, int]] = field(default_factory=list)      # name, value, line
    sql: list[SqlBlock] = field(default_factory=list)
    messages: list[Message] = field(default_factory=list)
    data_items: list[DataItem] = field(default_factory=list)
    rules: list[Rule] = field(default_factory=list)
    flows: list[FlowEdge] = field(default_factory=list)
    sqlmaps: list[SqlMap] = field(default_factory=list)
    cics: list[CicsCmd] = field(default_factory=list)
    idms: list[IdmsOp] = field(default_factory=list)
    files: list[FileUse] = field(default_factory=list)


def pair_sql(text: str, lineno: int) -> list[SqlMap]:
    """Column↔host-variable pairs from one embedded statement. Positional
    pairing only; a count mismatch yields NOTHING for that clause — a wrong
    mapping is worse than a missing one."""
    out: list[SqlMap] = []
    t = " ".join(text.split())

    m = RE_SQL_SELECT_INTO.search(t)
    if m:
        cols = [c.strip().upper() for c in m.group(1).split(",")]
        hosts = [h for chunk in m.group(2).split(",")
                 for h in RE_HOSTVAR.findall(chunk)]
        table = m.group(3).upper()
        if len(cols) == len(hosts):
            for c, h in zip(cols, hosts):
                if re.fullmatch(r"[A-Z0-9_.]+", c):
                    out.append(SqlMap(f"{table}.{c}", h.upper(), "select", lineno))

    m = RE_SQL_INSERT.search(t)
    if m:
        table = m.group(1).upper()
        cols = [c.strip().upper() for c in m.group(2).split(",")]
        hosts = [h for chunk in m.group(3).split(",")
                 for h in RE_HOSTVAR.findall(chunk)]
        if len(cols) == len(hosts):
            for c, h in zip(cols, hosts):
                out.append(SqlMap(f"{table}.{c}", h.upper(), "insert", lineno))

    m = RE_SQL_UPDATE_SET.search(t)
    if m:
        table = m.group(1).upper()
        for clause in m.group(2).split(","):
            if "=" not in clause:
                continue
            col, rhs = clause.split("=", 1)
            hosts = RE_HOSTVAR.findall(rhs)
            col = col.strip().upper()
            if len(hosts) == 1 and re.fullmatch(r"[A-Z0-9_]+", col):
                out.append(SqlMap(f"{table}.{col}", hosts[0].upper(),
                                  "update", lineno))
    return out


def _enclosing_paragraph(paragraphs: list[tuple[str, int, int]], lineno: int) -> str | None:
    for name, start, end in paragraphs:
        if start <= lineno <= end:
            return name
    return None


def _walk_back_condition(lines: list[CodeLine], idx: int, limit: int = 25
                         ) -> tuple[str | None, int | None]:
    """§5.2: nearest preceding IF/EVALUATE/WHEN, quoted verbatim. A heuristic,
    not data-flow — the UI must flag it as such."""
    for j in range(idx, max(-1, idx - limit), -1):
        cl = lines[j]
        if cl.comment:
            continue
        if RE_CONDITION.match(cl.text):
            cond = cl.text.strip()
            # Conditions often wrap; pull up to 2 continuation lines until a
            # period or the emitting statement.
            for k in (j + 1, j + 2):
                if k <= idx - 1 and k < len(lines) and not lines[k].comment:
                    nxt = lines[k].text.strip()
                    if not nxt or RE_CONDITION.match(nxt) or "MOVE" in nxt.upper():
                        break
                    cond += " " + nxt
                    if nxt.endswith("."):
                        break
            return cond, cl.lineno
    return None, None


def mine(lines: list[CodeLine],
         vocab_fields: list[str] | None = None) -> MineResult:
    res = MineResult()
    active = [cl for cl in lines if not cl.comment and cl.text.strip()]

    # Paragraphs: a name alone on a line, in procedure division territory.
    para_starts: list[tuple[str, int]] = []
    in_procedure = False
    for cl in active:
        if "PROCEDURE DIVISION" in cl.text.upper():
            in_procedure = True
        m = RE_PROGRAM_ID.search(cl.text)
        if m:
            res.program_name = m.group(1).upper()
        if in_procedure:
            pm = RE_PARAGRAPH.match(cl.text.strip())
            if (pm and pm.group(1).upper() not in NOT_PARAGRAPHS
                    and "DIVISION" not in cl.text.upper()
                    and "SECTION" not in cl.text.upper()):
                para_starts.append((pm.group(1).upper(), cl.lineno))
        else:
            dm = RE_DATA_ITEM.match(cl.text)
            if dm and dm.group(2).upper() != "FILLER":
                clause = dm.group(3)
                pm2 = RE_PIC.search(clause)
                um = RE_USAGE.search(clause)
                om = RE_OCCURS.search(clause)
                pic = pm2.group(1).rstrip(".") if pm2 else None
                usage = (um.group(1).upper() if um else "DISPLAY")
                item_type, length = pic_info(pic, usage)
                res.data_items.append(DataItem(
                    int(dm.group(1)), dm.group(2).upper(), pic, usage,
                    item_type, length,
                    int(om.group(1)) if om else None, cl.lineno))
    last_line = lines[-1].lineno if lines else 0
    for i, (name, start) in enumerate(para_starts):
        end = para_starts[i + 1][1] - 1 if i + 1 < len(para_starts) else last_line
        res.paragraphs.append((name, start, end))

    # CICS blocks: LINK/XCTL become call edges (the online CALL), maps and
    # ABEND codes become facts about the program's screens and failures.
    i = 0
    while i < len(active):
        if "EXEC CICS" in active[i].text.upper():
            start = active[i].lineno
            buf = [active[i].text.strip()]
            j = i
            while j < len(active) and "END-EXEC" not in active[j].text.upper():
                j += 1
                if j < len(active):
                    buf.append(active[j].text.strip())
            text = " ".join(buf)
            for m in RE_CICS_PGM.finditer(text):
                op = m.group(1).lower()
                res.cics.append(CicsCmd(op, m.group(2).upper(), None, start))
                res.calls.append(CallSite(m.group(2).upper(), start, [], False))
            for m in RE_CICS_MAP.finditer(text):
                res.cics.append(CicsCmd(
                    m.group(1).lower() + "-map", m.group(2).upper(),
                    m.group(3).upper() if m.group(3) else None, start))
            m = RE_CICS_ABEND.search(text)
            if m and m.group(1):
                res.cics.append(CicsCmd("abend", m.group(1).upper(), None, start))
                res.emissions.append(Emission(
                    m.group(1).upper(), "ABEND", start, None, None, None, 0.9))
            m = RE_CICS_TRAN.search(text)
            if m:
                res.cics.append(CicsCmd("return-transid", m.group(1).upper(),
                                        None, start))
            i = j + 1
        else:
            i += 1

    # SQL blocks.
    i = 0
    while i < len(active):
        if "EXEC SQL" in active[i].text.upper():
            start = active[i].lineno
            buf = [active[i].text.strip()]
            j = i
            while j < len(active) and "END-EXEC" not in active[j].text.upper():
                j += 1
                if j < len(active):
                    buf.append(active[j].text.strip())
            end = active[min(j, len(active) - 1)].lineno
            text = " ".join(buf)
            tables = sorted({t.upper() for t in RE_SQL_TABLE.findall(text)})
            res.sql.append(SqlBlock(start, end, text, tables))
            res.sqlmaps.extend(pair_sql(text, start))
            i = j + 1
        else:
            i += 1

    # Cursor pairing across blocks: positional, count-strict — a mismatch
    # pairs NOTHING (a shifted pairing is plausible and wrong), and a FETCH
    # against an undeclared cursor claims nothing.
    cursors: dict = {}
    for blk in res.sql:
        m = RE_SQL_DECLARE.search(" ".join(blk.text.split()))
        if m:
            cols = [c.strip().upper() for c in m.group(2).split(",")]
            cursors[m.group(1).upper()] = (cols, m.group(3).upper())
    for blk in res.sql:
        for m in RE_SQL_FETCH.finditer(" ".join(blk.text.split())):
            decl = cursors.get(m.group(1).upper())
            if not decl:
                continue
            cols, table = decl
            hosts = RE_HOSTVAR.findall(m.group(2))
            if len(cols) != len(hosts):
                continue
            for c, h in zip(cols, hosts):
                if re.fullmatch(r"[A-Z0-9_.]+", c):
                    res.sqlmaps.append(SqlMap(f"{table}.{c}", h.upper(),
                                              "fetch", blk.start_line))

    in_proc = False
    for idx, cl in enumerate(lines):
        if cl.comment:
            continue
        if "PROCEDURE DIVISION" in cl.text.upper():
            in_proc = True
        # Flow edges: identifier-to-identifier movement, procedure division
        # only (a MOVE in a comment or literal must not fabricate lineage).
        if in_proc:
            fm = RE_MOVE_FLOW.search(cl.text)
            if fm and "'" not in cl.text.split("TO")[0]:
                src = fm.group(1).upper()
                if src not in _MOVE_NOISE:
                    for tgt in re.split(r"[,\s]+", fm.group(2)):
                        tgt = tgt.strip().upper().rstrip(".")
                        if tgt and tgt not in _MOVE_NOISE:
                            res.flows.append(FlowEdge(src, tgt, "move", cl.lineno))
            am = RE_ARITH.search(cl.text)
            if am and am.group(3):          # ADD/COMPUTE ... GIVING target
                for tok in re.findall(r"[A-Z][A-Z0-9-]*", am.group(2).upper()):
                    if tok not in _MOVE_NOISE and tok not in ("TO", "FROM", "BY"):
                        res.flows.append(FlowEdge(
                            tok, am.group(3).upper(),
                            am.group(1).lower(), cl.lineno))
        u = cl.text.upper()
        if "EXEC " not in u:
            for m in RE_IDMS.finditer(cl.text):
                res.idms.append(IdmsOp(
                    m.group(1).lower(), m.group(3).upper(),
                    m.group(2).upper() if m.group(2) else None,
                    m.group(4).upper() if m.group(4) else None, cl.lineno))
        m = RE_SELECT_ASSIGN.search(cl.text)
        if m:
            res.files.append(FileUse(m.group(1).upper(), m.group(2).upper(),
                                     None, cl.lineno))
        m = RE_FILE_ORG.search(cl.text)
        if m and res.files and res.files[-1].org is None:
            res.files[-1].org = m.group(1).upper()
        if in_proc:
            m = RE_OPEN.search(cl.text)
            if m:
                for fu in res.files:
                    if fu.logical == m.group(2).upper():
                        fu.ops.append({"op": "open-" + m.group(1).lower(),
                                       "line": cl.lineno})
            m = RE_READ_INTO.search(cl.text)
            if m:
                for fu in res.files:
                    if fu.logical == m.group(1).upper():
                        fu.ops.append({"op": "read", "line": cl.lineno})
                        if m.group(2):
                            res.flows.append(FlowEdge(
                                fu.logical, m.group(2).upper(),
                                "read", cl.lineno))
            m = RE_WRITE_FROM.search(cl.text)
            if m and "MOVE" not in u:
                rec = m.group(2).upper()
                for fu in res.files:
                    fu_recs = [o for o in fu.ops if o["op"].startswith("open")]
                    # record-to-file association needs the FD hierarchy;
                    # the write is recorded on every open-output file honestly
                    # marked, rather than guessed onto one.
                if m.group(3):
                    res.flows.append(FlowEdge(
                        m.group(3).upper(), rec, "write", cl.lineno))
                if res.files:
                    res.files[-1].ops.append(
                        {"op": m.group(1).lower(), "target": rec,
                         "line": cl.lineno})
        for m in RE_COPY.finditer(cl.text):
            res.copies.append((m.group(1).upper(), cl.lineno))
        cm = RE_CALL.search(cl.text)
        cdyn = None if cm else RE_CALL_DYN.search(cl.text)
        if cm or cdyn:
            # Statement text may continue over the next lines (long USING
            # lists usually do): join forward until a period or END-CALL,
            # capped — honesty over completeness on pathological layouts.
            stmt = cl.text
            k = idx + 1
            while (k < len(lines) and "." not in stmt and "END-CALL"
                   not in stmt.upper() and k - idx <= 4):
                if not lines[k].comment:
                    stmt += " " + lines[k].text
                k += 1
            using = []
            um = RE_USING.search(stmt)
            if um:
                for tok in re.findall(r"[A-Z][A-Z0-9-]*", um.group(1).upper()):
                    if tok in _USING_NOISE:
                        continue
                    if tok.startswith("END-") or tok in (
                            "GOBACK", "MOVE", "PERFORM", "IF", "ELSE",
                            "DISPLAY", "COMPUTE", "SET", "CALL"):
                        break            # scope terminator or the next verb
                    using.append(tok)
            res.calls.append(CallSite(
                (cm or cdyn).group(1).upper(), cl.lineno,
                using, dynamic=cm is None))
        for m in RE_88_LEVEL.finditer(cl.text):
            res.level88.append((m.group(1).upper(), m.group(2), cl.lineno))
        dm = RE_DISPLAY.search(cl.text)
        if dm:
            msg = dm.group(1).strip()
            category = classify_message(msg)
            if category:
                res.messages.append(Message(
                    msg, cl.lineno,
                    _enclosing_paragraph(res.paragraphs, cl.lineno),
                    category,
                    [c.upper() for c in RE_CODE_IN_TEXT.findall(msg.upper())],
                ))
        m = RE_MOVE_ERR.search(cl.text)
        if m is None and vocab_fields:
            m2 = RE_MOVE_ANY.search(cl.text)
            if m2 and any(v in m2.group(2).upper() for v in vocab_fields):
                m = m2
        _vocab_hit = bool(m and vocab_fields and any(
            v in m.group(2).upper() for v in vocab_fields))
        # A declared vocabulary field holds codes BY DECLARATION, so the
        # code-shape gate relaxes there: 'S06' or 'T2' into WS-SUSP-CD is
        # a status code even though it would fail looks_like_code.
        if (m and m.group(1).upper() not in CODE_BLOCKLIST
                and (looks_like_code(m.group(1)) or _vocab_hit)):
            code, fld = m.group(1).upper(), m.group(2).upper()
            cond, cond_line = _walk_back_condition(lines, idx - 1)
            para = _enclosing_paragraph(res.paragraphs, cl.lineno)
            # Confidence: condition found in the same paragraph beats a distant one.
            conf = 0.4
            if cond is not None:
                conf = 0.7 if (para and cond_line and
                               _enclosing_paragraph(res.paragraphs, cond_line) == para) else 0.55
            res.emissions.append(Emission(code, fld, cl.lineno, para, cond, cond_line, conf))

    # Business rules: every IF / EVALUATE-WHEN decision gate, in analyst
    # English, paired with the first consequences inside its branch. An
    # IF-stack carries enclosing gates into nested rules, so the innermost
    # rule of IF A / IF B / IF C reads "When C — given A, B".
    eval_subject: str | None = None
    if_stack: list[str] = []
    for idx, cl in enumerate(lines):
        if cl.comment or not cl.text.strip():
            continue
        text = cl.text.strip()
        up_text = text.upper()
        if RE_PARAGRAPH.match(text) or text.endswith("."):
            terminal = True   # a period ends every open IF (old-style scope)
        else:
            terminal = False
        if up_text.startswith("END-IF"):
            if if_stack:
                if_stack.pop()
            if terminal:
                if_stack.clear()
            continue
        ev = RE_EVALUATE_LINE.match(text)
        if ev:
            eval_subject = ev.group(1).strip().rstrip(".")
            if eval_subject.upper() == "TRUE":
                eval_subject = None
            continue
        cond = None
        english_src = None
        im = RE_IF_LINE.match(text)
        wm = RE_WHEN_LINE.match(text)
        if not im and terminal:
            if_stack.clear()
        if im:
            cond = "IF " + im.group(1).strip()
            for k in (idx + 1, idx + 2):  # wrapped conditions
                if k < len(lines) and not lines[k].comment:
                    nxt = lines[k].text.strip()
                    if (not nxt or RE_CONDITION.match(nxt) or re.match(
                            r"^(MOVE|PERFORM|DISPLAY|GO|COMPUTE|ADD|SET|EXIT|"
                            r"CONTINUE|NEXT|END|CALL|OPEN|CLOSE|READ|WRITE)\b",
                            nxt, re.I)):
                        break
                    cond += " " + nxt
            english_src = cond
        elif wm:
            val = wm.group(1).strip().rstrip(".")
            if val.upper() == "OTHER":
                continue  # catch-all branch, not a business rule
            cond = f"WHEN {val}"
            english_src = f"{eval_subject} = {val}" if eval_subject else val
        if not cond:
            continue

        actions: list[str] = []
        code: str | None = None
        for k in range(idx, min(idx + 9, len(lines))):
            nl = lines[k]
            if nl.comment:
                continue
            t = nl.text.strip()
            up = t.upper()
            if k > idx and (up.startswith("END-IF") or up.startswith("ELSE")
                            or RE_WHEN_LINE.match(t) or up.startswith("END-EVALUATE")
                            or RE_IF_LINE.match(t)):
                # A nested IF starts its own rule — its consequences must not
                # be claimed by the enclosing gate.
                break
            mm = RE_MOVE_ERR.search(t)
            if mm and mm.group(1).upper() not in CODE_BLOCKLIST:
                code = mm.group(1).upper()
                actions.append(f"raises {code}")
            else:
                dm2 = RE_DISPLAY.search(t)
                pm3 = RE_PERFORM.search(t)
                gm = RE_GOTO.search(t)
                cm = re.search(r"\bCOMPUTE\s+([A-Z0-9-]+)", t, re.I)
                mv = re.search(r"\bMOVE\s+(\S+)\s+TO\s+([A-Z0-9-]+)", t, re.I)
                if dm2:
                    actions.append(f"shows “{dm2.group(1).strip()}”")
                elif pm3 and k > idx:
                    actions.append(f"performs {pm3.group(1).upper()}")
                elif gm:
                    actions.append(f"goes to {gm.group(1).upper()}")
                elif cm and k > idx:
                    actions.append(f"computes {_pretty_ident(cm.group(1).upper())}")
                elif mv and k > idx:
                    actions.append(f"sets {_pretty_ident(mv.group(2).upper())} to "
                                   f"{_pretty_literal(mv.group(1))}")
            if len(actions) >= 2:
                break
        res.rules.append(Rule(
            cond, translate_condition(english_src), cl.lineno,
            _enclosing_paragraph(res.paragraphs, cl.lineno), actions, code,
            context=list(if_stack)))
        if im:  # this IF now encloses whatever follows
            if_stack.append(translate_condition(english_src))
            if text.endswith("."):
                if_stack.clear()
    return res


def snippet(lines: list[CodeLine], center: int, radius: int = 3) -> str:
    """±radius original-order lines around a 1-based line number."""
    rows = [cl for cl in lines if center - radius <= cl.lineno <= center + radius]
    return "\n".join(f"{cl.lineno:>6}  {cl.text}" for cl in rows)
