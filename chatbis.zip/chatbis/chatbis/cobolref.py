"""ChatBIS — the COBOL reference: the language bible as a tool.

Analysts ask "what does COMP-3 mean?", "what is an S0C7?", "what does
OCCURS DEPENDING ON do?" — the model must answer from a curated entry,
not from its training-data memory of COBOL. Each entry is short,
correct, and carries the production-support gotcha ('watch') that a
textbook leaves out.

Curated by hand, shipped with the app, versioned in git. Lookup is
case-, space- and hyphen-blind with alias resolution; a miss refuses
with suggestions, never guesses.
"""
from __future__ import annotations

import re

_E = dict  # brevity below: what / example / watch / aliases

REFERENCE: dict[str, dict] = {
    # ── data description ─────────────────────────────────────────────
    "PIC": _E(
        aliases=["PICTURE", "PIC CLAUSE"],
        what="Declares a field's size and character class. 9=digit, "
             "X=any character, A=letter, V=implied decimal point, "
             "S=sign, Z=zero-suppressed digit. 9(5) means five digits.",
        example="05 WS-AMT PIC S9(7)V99.  *> signed, 7+2 digits",
        watch="V is IMPLIED — no byte holds the point. Moving 9(7)V99 "
              "to 9(7) silently drops the cents."),
    "COMP-3": _E(
        aliases=["PACKED-DECIMAL", "PACKED", "COMPUTATIONAL-3"],
        what="Packed decimal storage: two digits per byte, sign in the "
             "final half-byte. A PIC S9(7)V99 COMP-3 field takes 5 "
             "bytes ((digits+1)/2 rounded up). The mainframe's native "
             "money format.",
        example="05 WS-PAY-AMT PIC S9(7)V99 COMP-3.",
        watch="Displaying it raw shows gibberish; an invalid sign "
              "nibble or garbage byte in a COMP-3 field is the classic "
              "cause of an S0C7 abend."),
    "COMP": _E(
        aliases=["BINARY", "COMP-4", "COMPUTATIONAL"],
        what="Binary storage. PIC S9(4) COMP = halfword (2 bytes), "
             "S9(9) COMP = fullword (4), S9(18) COMP = doubleword (8). "
             "Used for counters, lengths and subscripts.",
        example="05 WS-COUNT PIC S9(4) COMP.",
        watch="Truncation follows the PICTURE, not the storage: S9(4) "
              "COMP holds ±9999 by rule even though 2 bytes could "
              "hold 32767 (unless TRUNC(BIN) changes the rules)."),
    "COMP-1": _E(
        aliases=["COMP-2", "FLOATING POINT"],
        what="Hexadecimal floating point — COMP-1 single, COMP-2 "
             "double precision. Rare in business code; scientific use.",
        example="05 WS-RATE COMP-2.",
        watch="Never use floats for money — decimal fractions don't "
              "round-trip. Amounts belong in COMP-3."),
    "REDEFINES": _E(
        what="Lets two data layouts share the same storage bytes — "
             "one area, several interpretations. Common for date "
             "formats, type-dependent record bodies, byte surgery.",
        example="05 WS-DATE PIC 9(8).\n"
                "05 WS-DATE-X REDEFINES WS-DATE.\n"
                "   10 WS-YYYY PIC 9(4).\n"
                "   10 WS-MM   PIC 9(2).\n"
                "   10 WS-DD   PIC 9(2).",
        watch="No conversion happens — it is the same bytes read "
              "differently. Redefining COMP-3 as DISPLAY reads packed "
              "bytes as characters: nonsense, or an S0C7 downstream."),
    "OCCURS": _E(
        aliases=["TABLE", "ARRAY"],
        what="Declares a repeating group — COBOL's array. Subscripts "
             "are 1-based, referenced as FIELD(I).",
        example="05 WS-BENE OCCURS 12 TIMES.\n   10 WS-BENE-ID PIC X(9).",
        watch="Subscripting past the declared count is not checked "
              "unless compiled with SSRANGE — it silently reads or "
              "corrupts the storage after the table (or S0C4s)."),
    "OCCURS DEPENDING ON": _E(
        aliases=["ODO", "VARIABLE TABLE"],
        what="A table whose active length is governed by another "
             "field: OCCURS 1 TO 50 TIMES DEPENDING ON WS-COUNT. The "
             "record's usable size flexes with WS-COUNT.",
        example="05 WS-ENT OCCURS 1 TO 50 DEPENDING ON WS-ENT-CNT.",
        watch="If the DEPENDING ON count is wrong (unset, stale, or "
              "beyond the max) reads walk off the record — a classic "
              "source of ghost data and S0C4/S0C7 abends."),
    "88": _E(
        aliases=["88 LEVEL", "88-LEVEL", "CONDITION NAME", "LEVEL 88"],
        what="A named condition bound to a parent field's values. "
             "IF PLAN-TERM is readable shorthand for IF WS-PLAN-TYPE "
             "= 'T'. SET PLAN-TERM TO TRUE stores the value.",
        example="05 WS-PLAN-TYPE PIC X.\n"
                "   88 PLAN-TERM  VALUE 'T'.\n"
                "   88 PLAN-WHOLE VALUE 'W'.",
        watch="An 88 can list several values (VALUE 'A' 'B' 'C') — "
              "the IF is true for any of them; the miner and the "
              "reader both need the full list, not the first."),
    "FILLER": _E(
        what="An unnamed area in a record — padding, reserved bytes, "
             "or fields this program doesn't care about.",
        example="05 FILLER PIC X(10).",
        watch="FILLER bytes still travel with the record. A layout "
              "mismatch often hides in miscounted FILLER."),
    "VALUE": _E(
        what="Initial contents of a WORKING-STORAGE field at program "
             "start (or the value list of an 88 level).",
        example="05 WS-MAX PIC 9(3) VALUE 120.",
        watch="VALUE initializes once at load — not on every CALL. A "
              "re-entered subprogram keeps prior contents unless "
              "INITIAL is declared or you INITIALIZE explicitly."),
    "LEVEL NUMBERS": _E(
        aliases=["01 LEVEL", "05 LEVEL", "77", "66", "01"],
        what="Hierarchy of a record: 01 is the record, 02–49 nest "
             "inside, 66 renames, 77 is a standalone item, 88 names a "
             "condition. Numbers only order the nesting — 05 under 01 "
             "is convention, not law.",
        example="01 WS-CASE.\n   05 WS-SSN PIC 9(9).",
        watch="A group item (no PIC) is always treated as character "
              "data when moved — moving a group over COMP-3 members "
              "does NOT convert anything."),
    "USAGE DISPLAY": _E(
        aliases=["DISPLAY FORMAT", "ZONED DECIMAL"],
        what="One character per byte — zoned decimal for numbers "
             "(digit in the low nibble, zone in the high, sign zoned "
             "into the last byte). The default USAGE.",
        example="05 WS-NUM PIC S9(5).  *> 5 bytes zoned",
        watch="A zoned field that ever held spaces or letters S0C7s "
              "the first time arithmetic touches it. IF NUMERIC "
              "guards against exactly this."),
    "JUSTIFIED": _E(
        aliases=["JUST RIGHT"],
        what="Right-aligns alphanumeric moves into the field instead "
             "of the default left-align-and-pad.",
        example="05 WS-REF PIC X(10) JUSTIFIED RIGHT.",
        watch=None),
    "SIGN SEPARATE": _E(
        aliases=["SIGN LEADING", "SIGN TRAILING"],
        what="Stores the sign as its own character (+/-) rather than "
             "overpunched into a digit — common on external files.",
        example="05 WS-AMT PIC S9(7) SIGN LEADING SEPARATE.",
        watch="Size grows by one byte; forgetting that shifts every "
              "field after it in the record."),

    # ── figurative constants ─────────────────────────────────────────
    "SPACES": _E(
        aliases=["SPACE"],
        what="All-blank figurative constant. MOVE SPACES TO X clears "
             "a character field; IF X = SPACES tests emptiness.",
        example="IF WS-BIC = SPACES ...",
        watch="A numeric field full of spaces is NOT zero — it is "
              "invalid zoned data waiting to S0C7."),
    "ZEROS": _E(
        aliases=["ZERO", "ZEROES"],
        what="All-zero figurative constant, valid in numeric or "
             "character contexts.",
        example="MOVE ZEROS TO WS-COUNT.",
        watch=None),
    "LOW-VALUES": _E(
        aliases=["HIGH-VALUES", "LOW-VALUE", "HIGH-VALUE"],
        what="The lowest (X'00') and highest (X'FF') byte values. "
             "Used as sentinels, key limits, and 'never touched' "
             "markers.",
        example="IF WS-KEY = LOW-VALUES ...",
        watch="LOW-VALUES in a DISPLAY numeric field is invalid data, "
              "and many file layouts use it to mean 'absent' — test "
              "for it BEFORE testing NUMERIC."),

    # ── procedure: moves and arithmetic ──────────────────────────────
    "MOVE": _E(
        what="Copies data with conversion/editing by category: "
             "numeric moves align on the decimal point and convert "
             "USAGE; alphanumeric moves copy left-to-right, padding "
             "or truncating on the right.",
        example="MOVE WS-IN-AMT TO WS-OUT-AMT.",
        watch="Truncation is SILENT: high-order digits drop on "
              "numeric overflow, right characters drop on X fields. "
              "Group moves are raw byte copies — no conversion at all."),
    "COMPUTE": _E(
        what="Arithmetic with an expression: COMPUTE X = A * B / C. "
             "ROUNDED rounds the result; ON SIZE ERROR traps overflow "
             "and division by zero.",
        example="COMPUTE WS-PREM ROUNDED = WS-BASE * WS-RATE\n"
                "    ON SIZE ERROR PERFORM RATE-FAIL.",
        watch="Without ON SIZE ERROR an overflowing result silently "
              "truncates. Intermediate results have their own rules — "
              "A/B*C and C*A/B can differ in pennies."),
    "ADD": _E(
        aliases=["SUBTRACT", "MULTIPLY", "DIVIDE"],
        what="Single-operation arithmetic verbs. ADD A TO B leaves "
             "the sum in B; GIVING targets a third field; REMAINDER "
             "captures a division remainder.",
        example="ADD WS-PAY TO WS-YTD.\nDIVIDE A BY B GIVING Q "
                "REMAINDER R.",
        watch="Same silent-truncation rule as COMPUTE — ON SIZE "
              "ERROR is the guard."),
    "INITIALIZE": _E(
        what="Resets a group: numerics to zero, alphanumerics to "
             "spaces, member by member (unlike a group MOVE).",
        example="INITIALIZE WS-CASE.",
        watch="FILLER and REDEFINES areas are left untouched."),
    "STRING": _E(
        aliases=["UNSTRING"],
        what="STRING concatenates fields (DELIMITED BY SIZE/SPACE/"
             "literal) into one; UNSTRING splits one field into many.",
        example="STRING WS-LAST ', ' WS-FIRST DELIMITED BY SIZE\n"
                "    INTO WS-NAME.",
        watch="Without WITH POINTER the target is NOT space-filled "
              "first — leftovers from the previous contents survive "
              "past the new text."),
    "INSPECT": _E(
        what="Counts or replaces characters: INSPECT X TALLYING for "
             "counts, INSPECT X REPLACING for substitutions.",
        example="INSPECT WS-AMT REPLACING ALL SPACES BY ZEROS.",
        watch=None),

    # ── procedure: control flow ──────────────────────────────────────
    "IF": _E(
        aliases=["END-IF", "NESTED IF"],
        what="Conditional. Modern code closes with END-IF; older "
             "code ends at the period — which is where nesting bugs "
             "live. ELSE binds to the nearest unclosed IF.",
        example="IF WS-AMT IS NEGATIVE\n   MOVE 'E5004' TO WS-ERR-CD\n"
                "END-IF",
        watch="In period-style code a misplaced period ends EVERY "
              "open IF at once — the classic maintenance bug when "
              "adding a line to old logic."),
    "EVALUATE": _E(
        aliases=["WHEN", "WHEN OTHER"],
        what="COBOL's switch/case. EVALUATE a subject, WHEN each "
             "value or condition, WHEN OTHER as the default. First "
             "matching WHEN wins; execution does not fall through.",
        example="EVALUATE SQLCODE\n   WHEN 0 CONTINUE\n"
                "   WHEN -803 PERFORM DUP-KEY\n"
                "   WHEN OTHER PERFORM SQL-FAIL\nEND-EVALUATE",
        watch="EVALUATE TRUE with condition WHENs is an if-else "
              "ladder in disguise — order matters."),
    "PERFORM": _E(
        aliases=["PERFORM UNTIL", "PERFORM VARYING", "PERFORM THRU"],
        what="Executes a paragraph/section and returns — COBOL's call "
             "to internal code. UNTIL loops, VARYING iterates a "
             "counter, TIMES repeats, inline PERFORM ... END-PERFORM "
             "loops a block in place.",
        example="PERFORM EDIT-POLICY\nPERFORM VARYING I FROM 1 BY 1\n"
                "    UNTIL I > WS-CNT ... END-PERFORM",
        watch="UNTIL tests BEFORE the body by default (WITH TEST "
              "AFTER changes it) — a true condition on entry means "
              "zero executions. PERFORM A THRU Z runs every paragraph "
              "physically between them: reordering paragraphs changes "
              "behaviour."),
    "GO TO": _E(
        aliases=["GOTO"],
        what="Unconditional jump to a paragraph. Legacy style; often "
             "paired with a DEPENDING ON list for computed branching.",
        example="GO TO REJECT-EXIT.",
        watch="GO TO out of a PERFORMed paragraph abandons the "
              "return path — the next PERFORM of anything in that "
              "range can behave unpredictably."),
    "CONTINUE": _E(
        aliases=["NEXT SENTENCE"],
        what="CONTINUE is an explicit no-op. NEXT SENTENCE jumps past "
             "the next PERIOD — not the next statement.",
        example="IF WS-STATE = 'VA' OR 'MD' OR 'DC'\n   CONTINUE\n"
                "ELSE\n   MOVE 'E5003' TO WS-ERR-CD\nEND-IF",
        watch="NEXT SENTENCE and CONTINUE are NOT interchangeable in "
              "END-IF code — NEXT SENTENCE can leap further than "
              "intended."),
    "PARAGRAPH": _E(
        aliases=["SECTION", "PROCEDURE DIVISION"],
        what="A named block of procedure code (the miner's 'Where'). "
             "A SECTION groups paragraphs; PERFORM of a section runs "
             "them all in order.",
        example="EDIT-POLICY.\n    IF ... END-IF.",
        watch=None),
    "GOBACK": _E(
        aliases=["STOP RUN", "EXIT PROGRAM"],
        what="GOBACK returns to whoever invoked the program (caller "
             "or the system) — the safe modern ending. STOP RUN ends "
             "the entire run unit; EXIT PROGRAM returns from a "
             "subprogram only.",
        example="GOBACK.",
        watch="STOP RUN in a CALLed subprogram kills the whole job "
              "step, not just the subprogram."),

    # ── programs talking to programs ─────────────────────────────────
    "CALL": _E(
        aliases=["BY REFERENCE", "BY CONTENT", "BY VALUE",
                 "STATIC CALL", "DYNAMIC CALL"],
        what="Invokes another program. BY REFERENCE (default) shares "
             "the caller's storage — the callee's writes land in the "
             "caller. BY CONTENT passes a copy. CALL 'LIT' is static "
             "(linked in); CALL WS-NAME is dynamic (loaded at run "
             "time).",
        example="CALL 'EEGET' USING PDA-RECORD EE-RECORD.",
        watch="BY REFERENCE aliasing means a callee can corrupt "
              "caller storage past the declared parameter length — "
              "layout mismatch between caller and callee is a prime "
              "storage-overlay suspect. Dynamic CALL failing to find "
              "the module abends S806."),
    "LINKAGE SECTION": _E(
        aliases=["USING", "PROCEDURE DIVISION USING"],
        what="Declares data the program receives from its caller "
             "(or CICS). No storage is allocated — the names overlay "
             "the caller's bytes, bound in order by PROCEDURE "
             "DIVISION USING.",
        example="LINKAGE SECTION.\n01 PDA-RECORD. ...\n"
                "PROCEDURE DIVISION USING PDA-RECORD.",
        watch="Caller and callee layouts must agree byte-for-byte; "
              "USING order, not names, does the binding."),
    "COPY": _E(
        aliases=["COPYBOOK", "COPY REPLACING"],
        what="Compile-time include of a shared layout or code member. "
             "COPY REPLACING rewrites text while including (prefix "
             "swaps like ==:TAG:== BY ==WS==).",
        example="COPY EEREC.\nCOPY STDREC REPLACING ==:PFX:== BY ==WS==.",
        watch="A copybook change recompiles into consumers only when "
              "they are recompiled — programs built before the change "
              "still run the OLD layout. Version skew between two "
              "programs sharing a copybook is a classic corruption "
              "source."),
    "COMMAREA": _E(
        aliases=["DFHCOMMAREA", "EIBCALEN"],
        what="CICS's data hand-off between programs/transactions — "
             "the caller's area arrives in LINKAGE as DFHCOMMAREA, "
             "with its length in EIBCALEN.",
        example="IF EIBCALEN > 0 MOVE DFHCOMMAREA TO WS-INPUT.",
        watch="Touching DFHCOMMAREA when EIBCALEN is 0 (first entry, "
              "no data passed) is an instant S0C4/ASRA."),

    # ── files and JCL edges ──────────────────────────────────────────
    "SELECT": _E(
        aliases=["ASSIGN", "FD", "FILE SECTION"],
        what="SELECT names a file and ASSIGNs it to a DDNAME; the FD "
             "in FILE SECTION declares its record layout. The JCL DD "
             "statement binds the DDNAME to a real dataset at run "
             "time.",
        example="SELECT CLAIM-FILE ASSIGN TO CLAIMIN.\n"
                "*> JCL: //CLAIMIN DD DSN=PROD.CLAIMS.DAILY,DISP=SHR",
        watch="File status '35' on OPEN = the DD is missing from the "
              "JCL or the dataset doesn't exist."),
    "FILE STATUS": _E(
        aliases=["STATUS CODE", "FILE-STATUS"],
        what="Two-character result of every file operation. '00' ok, "
             "'10' end of file, '22' duplicate key, '23' record not "
             "found, '35' file not there on OPEN, '39' attribute "
             "mismatch, '9x' serious/VSAM errors.",
        example="IF WS-STAT NOT = '00' AND '10' PERFORM FILE-FAIL.",
        watch="Code that only tests '10' treats every hard error as "
              "end-of-file — short files with no abend are the "
              "symptom."),
    "READ": _E(
        aliases=["WRITE", "REWRITE", "OPEN", "CLOSE", "AT END"],
        what="File verbs: OPEN INPUT/OUTPUT/I-O/EXTEND, READ (with "
             "AT END or INVALID KEY), WRITE record, REWRITE in place, "
             "CLOSE. Sequential READs advance; keyed READs position "
             "by key.",
        example="READ CLAIM-FILE AT END SET EOF-YES TO TRUE END-READ.",
        watch="WRITE uses the RECORD name, READ uses the FILE name — "
              "'WRITE CLAIM-REC' / 'READ CLAIM-FILE'."),
    "SEARCH": _E(
        aliases=["SEARCH ALL", "INDEXED BY", "SET"],
        what="Table lookup: SEARCH walks entries with WHEN "
             "conditions; SEARCH ALL binary-searches a table declared "
             "ASCENDING KEY. Tables use INDEXED BY indexes moved with "
             "SET.",
        example="SET BX TO 1\nSEARCH BENE-ENTRY\n"
                "   WHEN BENE-ID(BX) = WS-ID PERFORM FOUND\n"
                "END-SEARCH",
        watch="SEARCH ALL on a table that is not actually sorted "
              "returns wrong answers silently — no error, just the "
              "wrong entry."),

    # ── SQL and CICS in COBOL ────────────────────────────────────────
    "EXEC SQL": _E(
        aliases=["HOST VARIABLE", "DCLGEN", "CURSOR"],
        what="Embedded DB2: EXEC SQL ... END-EXEC blocks. Host "
             "variables (:WS-SSN) carry COBOL data in and out; "
             "DCLGEN generates the table's COBOL layout; cursors "
             "(DECLARE/OPEN/FETCH/CLOSE) walk multi-row results.",
        example="EXEC SQL SELECT BENE_DOB INTO :WS-DOB\n"
                "  FROM MBR.CLAIM WHERE CLM_NO = :WS-CLM END-EXEC.",
        watch="ALWAYS check SQLCODE after every statement — DB2 does "
              "not abend on most errors, it just sets the code and "
              "continues."),
    "SQLCODE": _E(
        aliases=["SQLSTATE", "SQLCA"],
        what="DB2's result code in the SQLCA. 0 = success, +100 = no "
             "row found / end of cursor. Common negatives: -803 "
             "duplicate key, -805 package not bound, -811 more than "
             "one row on a singleton SELECT, -818 timestamp mismatch, "
             "-904 resource unavailable, -911 deadlock victim (rolled "
             "back), -913 deadlock (no rollback), -180/-181 bad "
             "date/timestamp value.",
        example="EVALUATE SQLCODE WHEN 0 CONTINUE\n"
                "   WHEN 100 PERFORM NOT-FOUND ...",
        watch="+100 on a cursor FETCH is normal end-of-data; +100 on "
              "a singleton SELECT means the row genuinely isn't "
              "there — two different triage paths."),
    "EXEC CICS": _E(
        aliases=["SEND MAP", "RECEIVE MAP", "XCTL", "LINK", "RESP"],
        what="CICS commands in COBOL: SEND MAP/RECEIVE MAP for BMS "
             "screens, LINK (call-and-return) and XCTL (transfer, no "
             "return) between programs, READ/WRITE for VSAM through "
             "CICS. RESP(WS-RESP) captures the outcome.",
        example="EXEC CICS SEND MAP('PS220M') MAPSET('PS220S')\n"
                "     FROM(PS220MO) ERASE END-EXEC.",
        watch="Without RESP or a HANDLE, a failing command abends "
              "the transaction (AEI* codes). ASRA is the CICS name "
              "for a program check — usually an S0C4/S0C7 inside "
              "your code."),
    "EIB": _E(
        aliases=["EIBAID", "EIBTRNID", "EIBRESP"],
        what="The CICS Exec Interface Block — per-task facts the "
             "program can read: EIBAID (which key the user pressed), "
             "EIBTRNID (transaction id), EIBCALEN (commarea length), "
             "EIBRESP (last command's result).",
        example="IF EIBAID = DFHPF3 PERFORM EXIT-SCREEN.",
        watch=None),

    # ── abends: what the letters mean at 2am ─────────────────────────
    "S0C7": _E(
        aliases=["0C7", "DATA EXCEPTION", "SOC7"],
        what="Data exception: arithmetic or a numeric move touched a "
             "field whose bytes are not valid packed/zoned data — "
             "spaces in a numeric, corrupted COMP-3, layout "
             "misalignment.",
        example="*> ADD 1 TO WS-COUNT when WS-COUNT holds spaces",
        watch="Find WHICH field: the abend offset maps to a statement "
              "via the compile listing; the usual suspects are "
              "unvalidated input and REDEFINES/ODO misreads. IF "
              "NUMERIC before arithmetic is the cheap guard."),
    "S0C4": _E(
        aliases=["0C4", "PROTECTION EXCEPTION", "SOC4", "ASRA"],
        what="Protection exception: the program addressed storage it "
             "doesn't own — subscript past a table, bad ODO count, "
             "LINKAGE item used with no commarea, corrupted pointer.",
        example="*> WS-BENE(13) when the table OCCURS 12",
        watch="In CICS this surfaces as an ASRA abend. Check "
              "subscripts and EIBCALEN first."),
    "S0C1": _E(
        aliases=["0C1", "OPERATION EXCEPTION"],
        what="Operation exception: the CPU tried to execute something "
             "that isn't an instruction — usually a wild branch "
             "through a clobbered address or falling off the end of "
             "code.",
        example=None,
        watch="Almost always secondary damage; find what overwrote "
              "storage first."),
    "S806": _E(
        aliases=["806"],
        what="Module not found: a CALL or JCL EXEC named a program "
             "the loader can't find in the STEPLIB/JOBLIB/linklist "
             "concatenation.",
        example=None,
        watch="Wrong load library in JCL, or the module was never "
              "linked to that environment — deployment gap, not code "
              "bug."),
    "S222": _E(
        aliases=["S322", "222", "322"],
        what="S222: the job was CANCELLED by an operator or user. "
             "S322: killed for exceeding its CPU TIME limit.",
        example=None,
        watch="S322 on a normally-fast step usually means an infinite "
              "loop, not a busy day."),
    "SB37": _E(
        aliases=["SD37", "SE37", "B37", "D37", "E37"],
        what="Out of space on an output dataset: B37 ran out of "
             "allocated extents/volume, D37 no secondary allocation "
             "to grow into, E37 volume/extent limit.",
        example=None,
        watch="Fix is JCL SPACE (or dataset reorg), then rerun — the "
              "program logic is usually innocent."),
    "S878": _E(
        aliases=["S80A", "878", "80A"],
        what="Out of region memory — GETMAIN could not be satisfied "
             "within the step's REGION.",
        example=None,
        watch="Raise REGION= in JCL, or find the leak: growing "
              "tables and unbounded ODO counts eat region."),
    "U ABEND": _E(
        aliases=["USER ABEND", "U4038", "U0778"],
        what="A user abend — the application or a runtime CHOSE to "
             "abend with its own code (e.g., Language Environment "
             "U4038 wrapping an unhandled condition). The number's "
             "meaning belongs to whoever issued it — check the shop's "
             "abend table and the preceding messages.",
        example=None,
        watch="For LE U4038, the REAL error is in the CEEDUMP/SYSOUT "
              "messages just above it."),

    # ── source format ────────────────────────────────────────────────
    "COLUMNS": _E(
        aliases=["AREA A", "AREA B", "COLUMN 7", "FIXED FORMAT",
                 "CONTINUATION"],
        what="Fixed-format COBOL: columns 1–6 sequence numbers, "
             "column 7 indicator (* comment, - continuation, D debug "
             "line), Area A columns 8–11 (divisions, sections, "
             "paragraphs, 01/77 levels), Area B 12–72 (everything "
             "else). Columns 73–80 ignored.",
        example="*> a '-' in column 7 continues a literal",
        watch="Text past column 72 silently never reaches the "
              "compiler — the same rule that bites in BMS macros."),
}


def _norm(term: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", (term or "").upper())


_INDEX: dict[str, str] = {}
for key, entry in REFERENCE.items():
    _INDEX[_norm(key)] = key
    for alias in entry.get("aliases", []):
        _INDEX.setdefault(_norm(alias), key)


def lookup(term: str) -> dict:
    """One reference entry, alias- and punctuation-blind. A miss
    refuses with the closest topics — never a guess."""
    n = _norm(term)
    if not n:
        return {"error": "empty term",
                "topics": sorted(REFERENCE.keys())}
    key = _INDEX.get(n)
    if not key:
        close = sorted({k for nk, k in _INDEX.items()
                        if n in nk or nk in n})[:8]
        return {"error": f"'{term}' is not in the COBOL reference",
                "suggestions": close,
                "hint": "try the base keyword — e.g. OCCURS, COMP-3, "
                        "SQLCODE, S0C7"}
    e = REFERENCE[key]
    out = {"term": key, "meaning": e["what"]}
    if e.get("example"):
        out["example"] = e["example"]
    if e.get("watch"):
        out["production_gotcha"] = e["watch"]
    if e.get("aliases"):
        out["also_known_as"] = e["aliases"]
    return out
