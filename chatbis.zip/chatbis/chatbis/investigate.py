"""ChatBIS — the Investigate chat: a bounded model over deterministic tools.

Doctrine (docs/agent-architecture.md): the deterministic engine is the
product; the model is a fallback that gathers evidence THROUGH the same
tools the UI uses and answers only from what they return. Every tool call
is surfaced to the analyst as it happens — the activity trail IS the
citation trail.

Transcripts, tool results and case data live in SERVER MEMORY for the
session — never in chatbis.db. Case payloads pass through db.redact()
before reaching the model when redact_identifiers is on (the default).

Stdlib only. The model endpoint is any OpenAI-compatible
/chat/completions — in-network llama-server, vLLM, whatever the shop
approves. No endpoint configured = the chat refuses by name, it does
not degrade to guessing.
"""
from __future__ import annotations

import json
import urllib.error
import urllib.request

from . import db
from .cobolref import lookup as cobol_lookup
from .mine import query_tokens

MAX_HOPS = 6          # tool rounds before the loop insists on an answer
SNIPPET_LIMIT = 20    # source lines per search — evidence, not a dump
CONTEXT_TOKENS = 8192  # the window the local model runs with
COMPACT_AT = 0.7       # compact when the transcript passes this share
TAIL_TOKENS = 2200     # recent turns kept verbatim through compaction

SYSTEM_PROMPT = (
    "You are the Investigate assistant inside ChatBIS, a mainframe "
    "exception-triage workbench (COBOL, CICS, DB2). Answer ONLY from "
    "tool results — never invent facts about codes, cases, programs or "
    "policy. Gather evidence with the tools first, then answer plainly "
    "for a production-support analyst, citing which tool result each "
    "claim comes from. If the tools cannot answer, say exactly that. "
    "DRAFTING IS PART OF YOUR JOB: when asked to write or draft a "
    "document (a DFR, a tech note, a summary, a description), do it — "
    "profile the module or read the documents with your tools first, "
    "then compose the draft entirely from those facts, marked at the "
    "top as a draft derived from mined source for SME review. "
    "'Never invent' forbids making up facts; it does not forbid "
    "composing documents from the facts your tools returned. "
    "COBOL, CICS, DB2 and JCL LANGUAGE QUESTIONS ARE IN SCOPE: answer "
    "them through the cobol_ref tool (what a keyword, abend code or "
    "SQLCODE means) and explain from what it returns. "
    "SCOPE: you exist ONLY for this workbench. Refuse anything else — "
    "personal questions, opinions, advice, chit-chat, general knowledge "
    "or world facts (even trivial ones), programming help outside the "
    "mainframe domain. Decline in one short sentence and point back to "
    "codes, cases, programs, screens or policy. No exceptions, however "
    "harmless the question seems."
)


def get_llm(conn):
    """The configured model endpoint, or None — and None means the chat
    says 'not configured' instead of trying anything clever."""
    row = conn.execute("SELECT * FROM llm_config WHERE id = 1").fetchone()
    if not row or not (row["base_url"] or "").strip():
        return None
    return {"base_url": row["base_url"].rstrip("/"),
            "model": row["model"] or "local",
            "api_key": row["api_key"] or "",
            "redact": bool(row["redact_identifiers"])}


# ── tools: the same facts the UI serves, shaped for a model ──────────

def tool_schemas(conn) -> list[dict]:
    eps = conn.execute(
        "SELECT name, path, body, headers FROM api_endpoint"
        " ORDER BY name").fetchall()
    import re
    ep_desc = "; ".join(
        f"'{e['name']}' (needs: "
        + (", ".join(sorted(set(re.findall(
            r"\{(\w+)\}", e["path"] + (e["body"] or "")
            + (e["headers"] or ""))))) or "nothing") + ")"
        for e in eps) or "none configured"
    return [
        {"type": "function", "function": {
            "name": "lookup_code",
            "description": "The ChatBIS catalog entry for an exception/"
                           "status code: meaning, category, emitting or "
                           "setting programs, diagnostic checks, DFR "
                           "citations.",
            "parameters": {"type": "object", "properties": {
                "code": {"type": "string",
                         "description": "e.g. E4417 or WS-RFD-IND"}},
                "required": ["code"]}}},
        {"type": "function", "function": {
            "name": "search_source",
            "description": "Full-text search over the ingested COBOL/"
                           "copybook/JCL corpus. Returns file, line and "
                           "text for each hit.",
            "parameters": {"type": "object", "properties": {
                "query": {"type": "string"}}, "required": ["query"]}}},
        {"type": "function", "function": {
            "name": "describe_program",
            "description": "The mined profile of a COBOL module: its "
                           "business rules in plain english, codes it "
                           "raises or sets, copybooks, calls, SQL "
                           "tables, CICS use, batch jobs running it. "
                           "Use this to explain what a module does.",
            "parameters": {"type": "object", "properties": {
                "name": {"type": "string",
                         "description": "program name, e.g. BFDISAB"}},
                "required": ["name"]}}},
        {"type": "function", "function": {
            "name": "read_document",
            "description": "Sections of an ingested DFR or policy "
                           "document, by title. Optional query narrows "
                           "to matching sections. Use this to explain "
                           "what a DFR or policy says.",
            "parameters": {"type": "object", "properties": {
                "title": {"type": "string"},
                "query": {"type": "string",
                          "description": "optional — only sections "
                                         "mentioning this"}},
                "required": ["title"]}}},
        {"type": "function", "function": {
            "name": "cobol_ref",
            "description": "The curated COBOL/CICS/DB2/JCL language "
                           "reference: what a keyword, clause, abend "
                           "code or SQLCODE means, with an example and "
                           "the production gotcha. Use for language "
                           "questions — COMP-3, REDEFINES, S0C7, "
                           "SQLCODE -803, OCCURS DEPENDING ON.",
            "parameters": {"type": "object", "properties": {
                "term": {"type": "string",
                         "description": "e.g. COMP-3, S0C7, EVALUATE"}},
                "required": ["term"]}}},
        {"type": "function", "function": {
            "name": "pull_case",
            "description": f"Pull the live case (the MBR) through a "
                           f"saved endpoint. Available endpoints: "
                           f"{ep_desc}. params supplies the "
                           f"placeholders the endpoint needs.",
            "parameters": {"type": "object", "properties": {
                "endpoint": {"type": "string"},
                "params": {"type": "object",
                           "additionalProperties": {"type": "string"}}},
                "required": ["endpoint", "params"]}}},
    ]


def exec_lookup_code(conn, code: str) -> dict:
    norm = db.normalize_code(code or "")
    r = conn.execute("SELECT * FROM exception_code WHERE normalized = ?",
                     (norm,)).fetchone()
    if not r:
        return {"error": f"'{code}' is not in the catalog"}
    programs = [
        {"program": l["target_ref"], "relation": l["relation"]}
        for l in conn.execute(
            "SELECT target_ref, relation FROM exception_link"
            " WHERE exception_id = ? AND target_kind = 'program'"
            " AND relation IN ('emitted_by','raised_by','set_by')"
            " ORDER BY confidence DESC LIMIT 8", (r["id"],))]
    docs = [l["target_ref"] for l in conn.execute(
        "SELECT target_ref FROM exception_link WHERE exception_id = ?"
        " AND relation = 'governed_by' LIMIT 5", (r["id"],))]
    pb = conn.execute("SELECT checks, general_steps FROM playbook"
                      " WHERE exception_id = ?", (r["id"],)).fetchone()
    return {"code": r["code"], "category": r["category"],
            "meaning": r["meaning"], "screen": r["screen_id"],
            "programs": programs, "dfr_citations": docs,
            "checks": json.loads(pb["checks"]) if pb and pb["checks"]
            else [],
            "fallback_steps": pb["general_steps"] if pb else None}


def exec_search_source(conn, query: str) -> list[dict]:
    tokens = query_tokens(query or "")
    if not tokens:
        return []
    files = {f["id"]: f["name"] for f in
             conn.execute("SELECT id, name FROM source_file")}
    return [{"file": files.get(r["file_id"], "?"), "line": r["lineno"],
             "text": r["text"].strip()[:160]}
            for r in conn.execute(
                "SELECT file_id, lineno, text FROM line_fts"
                " WHERE tokens MATCH ? LIMIT ?",
                (tokens, SNIPPET_LIMIT))]


def exec_pull_case(conn, call_api, endpoint: str, params: dict) -> dict:
    ep = conn.execute("SELECT * FROM api_endpoint WHERE name = ?",
                      (endpoint or "",)).fetchone()
    env = conn.execute("SELECT * FROM api_env ORDER BY id LIMIT 1"
                       ).fetchone()
    if not ep:
        return {"error": f"no endpoint named '{endpoint}'"}
    if not env:
        return {"error": "no API environment configured"}
    clean = {str(k): str(v) for k, v in (params or {}).items()}
    status, text, ms, err = call_api(env, ep, clean)
    if err or not (status and 200 <= status < 300):
        return {"error": err or f"HTTP {status}", "environment": env["name"]}
    try:
        return {"environment": env["name"], "case": json.loads(text)}
    except ValueError:
        return {"environment": env["name"], "raw": text[:2000]}


RULE_LIMIT = 25       # business rules per program profile
SECTION_LIMIT = 12    # document sections per read
SECTION_CHARS = 700   # per-section text budget


def exec_describe_program(conn, name: str,
                          rule_limit: int | None = RULE_LIMIT) -> dict:
    """The deterministic profile of a program — everything the miner
    extracted, shaped for the model to DESCRIBE from. The tool never
    summarizes; prose is the model's job and every claim in it traces
    back to a field returned here."""
    r = conn.execute(
        """SELECT p.id, p.name, f.name AS file, a.name AS app
           FROM program p JOIN source_file f ON f.id = p.source_file_id
           LEFT JOIN application a ON a.id = f.application_id
           WHERE UPPER(p.name) = UPPER(?)""", (name or "",)).fetchone()
    if not r:
        like = [x["name"] for x in conn.execute(
            "SELECT name FROM program WHERE name LIKE ? LIMIT 6",
            (f"%{(name or '').upper()}%",))]
        return {"error": f"no program named '{name}' in the corpus"
                + (f" — close matches: {', '.join(like)}" if like else "")}
    facets: dict = {}
    for f in conn.execute(
            "SELECT kind, ref, detail FROM program_facet"
            " WHERE program_id = ? ORDER BY id", (r["id"],)):
        facets.setdefault(f["kind"], []).append(f)
    rules = []
    take = facets.get("rule", [])
    if rule_limit is not None:
        take = take[:rule_limit]
    for f in take:
        d = json.loads(f["detail"] or "{}")
        rules.append({"when": d.get("english") or d.get("condition"),
                      "paragraph": d.get("paragraph"),
                      "actions": d.get("actions"),
                      "code": f["ref"] or d.get("code")})
    codes = [{"code": row["code"], "meaning": row["meaning"]}
             for row in conn.execute(
                 """SELECT DISTINCT e.code, e.meaning
                    FROM exception_link l
                    JOIN exception_code e ON e.id = l.exception_id
                    WHERE l.target_kind = 'program'
                    AND UPPER(l.target_ref) = UPPER(?)
                    AND l.relation IN ('emitted_by','raised_by','set_by')
                    LIMIT ?""", (r["name"],
                                 15 if rule_limit is not None else 100000))]
    jobs = [{"job": j["job"], "step": j["step_name"]}
            for j in conn.execute(
                """SELECT s.step_name, jj.name AS job FROM jcl_step s
                   JOIN jcl_job jj ON jj.id = s.job_id
                   WHERE UPPER(s.pgm) = UPPER(?) LIMIT 8""",
                (r["name"],))]
    refs = lambda kind: sorted({f["ref"] for f in facets.get(kind, [])
                                if f["ref"]})[:15]
    total_rules = len(facets.get("rule", []))
    return {"program": r["name"], "file": r["file"],
            "application": r["app"],
            "copies": refs("copy"), "calls": refs("call"),
            "sql_tables": refs("sql") + refs("sqlmap"),
            "cics": refs("cics"), "messages": refs("message"),
            "codes_raised_or_set": codes,
            "batch_jobs": jobs,
            "business_rules": rules,
            "mined_note": (f"{total_rules} rules mined, first "
                           f"{len(rules)} shown"
                           if len(rules) < total_rules else
                           f"{total_rules} rules mined — full set shown")}


def exec_read_document(conn, title: str, query: str = "") -> dict:
    """Real sections of a DFR or policy document, capped. The model
    reads and describes; the section text IS the citation."""
    like = f"%{(title or '').strip()}%"
    docs = conn.execute(
        "SELECT * FROM document WHERE title LIKE ? ORDER BY title"
        " LIMIT 6", (like,)).fetchall()
    if not docs:
        names = [d["title"] for d in conn.execute(
            "SELECT title FROM document ORDER BY title LIMIT 12")]
        return {"error": f"no document matching '{title}'",
                "available": names}
    if len(docs) > 1 and not any(
            d["title"].lower() == (title or "").strip().lower()
            for d in docs):
        return {"error": f"'{title}' matches several documents — "
                         f"pick one by exact title",
                "matches": [d["title"] for d in docs]}
    doc = next((d for d in docs
                if d["title"].lower() == (title or "").strip().lower()),
               docs[0])
    if query:
        q = f"%{query.strip()}%"
        secs = conn.execute(
            "SELECT heading, text FROM doc_section WHERE document_id = ?"
            " AND (heading LIKE ? OR text LIKE ?) ORDER BY ord LIMIT ?",
            (doc["id"], q, q, SECTION_LIMIT)).fetchall()
    else:
        secs = conn.execute(
            "SELECT heading, text FROM doc_section WHERE document_id = ?"
            " ORDER BY ord LIMIT ?", (doc["id"], SECTION_LIMIT)).fetchall()
    total = conn.execute("SELECT COUNT(*) FROM doc_section"
                         " WHERE document_id = ?", (doc["id"],)).fetchone()[0]
    codes = [r["code"] for r in conn.execute(
        """SELECT DISTINCT e.code FROM exception_link l
           JOIN exception_code e ON e.id = l.exception_id
           WHERE l.relation = 'governed_by'
           AND json_extract(l.detail, '$.doc_id') = ? LIMIT 20""",
        (doc["id"],))]
    return {"title": doc["title"],
            "kind": doc["kind"] or "dfr",
            "sections": [{"heading": x["heading"],
                          "text": x["text"][:SECTION_CHARS]} for x in secs],
            "sections_note": (f"{len(secs)} of {total} sections shown"
                              + (f" matching '{query}'" if query else "")),
            "codes_governed": codes}


def llm_chat(cfg: dict, messages: list, tools: list) -> dict:
    req = urllib.request.Request(
        cfg["base_url"] + "/chat/completions",
        data=json.dumps({"model": cfg["model"], "temperature": 0,
                         "messages": messages, "tools": tools}).encode(),
        headers={"Content-Type": "application/json",
                 **({"Authorization": f"Bearer {cfg['api_key']}"}
                    if cfg["api_key"] else {})})
    with urllib.request.urlopen(req, timeout=300) as r:
        out = json.load(r)
    return out["choices"][0]["message"]


def _label(name: str, args: dict) -> str:
    if name == "lookup_code":
        return f"Reading the catalog · {args.get('code', '?')}"
    if name == "search_source":
        return f"Searching source · {args.get('query', '?')}"
    if name == "pull_case":
        return f"Calling the case API · {args.get('endpoint', '?')}"
    if name == "describe_program":
        return f"Reading program · {args.get('name', '?')}"
    if name == "read_document":
        return f"Reading document · {args.get('title', '?')}"
    if name == "cobol_ref":
        return f"Opening the COBOL reference · {args.get('term', '?')}"
    return name


def est_tokens(messages: list) -> int:
    """Chars/4 — coarse, deterministic, and errs high for JSON. Good
    enough to decide when to compact; never used for anything subtle."""
    return sum(len(json.dumps(m)) // 4 for m in messages)


def compact_messages(cfg: dict, messages: list, status) -> None:
    """When the transcript nears the model's window, fold the older
    turns into a model-written summary and keep the recent turns
    verbatim — the cut always lands on a turn boundary (a user message)
    so no tool result is ever orphaned from its call. If the summary
    call fails, fall back deterministically: old tool payloads become
    stubs, dialogue text survives. History is never destroyed on a
    failed summary."""
    if est_tokens(messages) <= int(CONTEXT_TOKENS * COMPACT_AT):
        return
    user_idx = [i for i, m in enumerate(messages)
                if m.get("role") == "user" and i > 0]
    if not user_idx:
        return
    cut = user_idx[-1]                 # at minimum keep the current turn
    for i in user_idx:
        if est_tokens(messages[i:]) <= TAIL_TOKENS:
            cut = i
            break
    head, tail = messages[1:cut], messages[cut:]
    if not head:
        return
    status("thinking", "Compacting the conversation")
    try:
        msg = llm_chat(cfg, list(messages[:1]) + head + [{
            "role": "user", "content":
            "Summarize this investigation so far for your own continued "
            "use: facts established (naming which tool result each came "
            "from), cases pulled, codes examined, open questions. "
            "Compact but complete; output only the summary."}], [])
        summary = (msg.get("content") or "").strip()
    except (urllib.error.URLError, OSError, KeyError, ValueError):
        summary = ""
    if summary:
        messages[:] = list(messages[:1]) + [
            {"role": "user", "content":
             "[Earlier turns were compacted. Summary of the "
             "investigation so far:]\n" + summary},
            {"role": "assistant",
             "content": "Noted — continuing from the summary."}] + tail
    else:
        # deterministic fallback: the dialogue survives, fat tool
        # payloads become named stubs the model can re-fetch
        for m in head:
            if m.get("role") == "tool":
                m["content"] = ('{"note": "result dropped during '
                                'compaction — call the tool again if '
                                'this evidence is needed"}')


def run_investigation(conn, call_api, cfg: dict, messages: list,
                      status) -> str:
    """The loop: think → call tools → feed results → answer. `messages`
    is mutated in place (the chat's memory); `status(kind, label)`
    narrates for the activity trail."""
    compact_messages(cfg, messages, status)
    tools = tool_schemas(conn)
    for _ in range(MAX_HOPS):
        status("thinking", "Thinking")
        msg = llm_chat(cfg, messages, tools)
        calls = msg.get("tool_calls") or []
        if not calls:
            answer = (msg.get("content") or "").strip() \
                or "The model returned nothing — try rephrasing."
            messages.append({"role": "assistant", "content": answer})
            return answer
        messages.append({"role": "assistant", "content": None,
                         "tool_calls": calls})
        for c in calls:
            fn = c["function"]["name"]
            try:
                args = json.loads(c["function"]["arguments"] or "{}")
            except ValueError:
                args = {}
            status("tool", _label(fn, args))
            if fn == "lookup_code":
                result = exec_lookup_code(conn, args.get("code", ""))
            elif fn == "search_source":
                result = exec_search_source(conn, args.get("query", ""))
            elif fn == "describe_program":
                result = exec_describe_program(conn, args.get("name", ""))
            elif fn == "read_document":
                result = exec_read_document(conn, args.get("title", ""),
                                            args.get("query", ""))
            elif fn == "cobol_ref":
                result = cobol_lookup(args.get("term", ""))
            elif fn == "pull_case":
                result = exec_pull_case(conn, call_api,
                                        args.get("endpoint", ""),
                                        args.get("params", {}))
                if cfg["redact"]:
                    result = db.redact(result)
            else:
                result = {"error": f"'{fn}' is not a ChatBIS tool"}
            messages.append({"role": "tool",
                             "tool_call_id": c.get("id", "0"),
                             "content": json.dumps(result)[:12000]})
    status("thinking", "Wrapping up")
    messages.append({"role": "user", "content":
                     "Answer now from the evidence you have gathered."})
    msg = llm_chat(cfg, messages, [])
    answer = (msg.get("content") or "").strip() \
        or "Ran out of tool budget without an answer."
    messages.append({"role": "assistant", "content": answer})
    return answer
