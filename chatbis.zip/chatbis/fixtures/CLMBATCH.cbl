       IDENTIFICATION DIVISION.
       PROGRAM-ID. CLMBATCH.
      * CLAIMS BATCH POSTING - SYNTHETIC FIXTURE
       DATA DIVISION.
       WORKING-STORAGE SECTION.
           COPY ERRCODES.
       01  WS-CLAIM-REC.
           05 WS-CLM-POLICY      PIC X(10).
           05 WS-CLM-AMT         PIC S9(9)V99 COMP-3.
       PROCEDURE DIVISION.
       MAIN-PARA.
           PERFORM POST-CLAIM
           GOBACK.
       POST-CLAIM.
           EXEC SQL
              INSERT INTO CLAIM_LEDGER (POLICY_NO, CLM_AMT)
              VALUES (:WS-CLM-POLICY, :WS-CLM-AMT)
           END-EXEC
           EVALUATE SQLCODE
              WHEN 0
                 CONTINUE
              WHEN -803
                 MOVE 'E2088' TO WS-ERR-CD
                 PERFORM WRITE-SUSPENSE
              WHEN OTHER
                 MOVE 'E9001' TO WS-ERR-CD
                 PERFORM WRITE-SUSPENSE
           END-EVALUATE.
       WRITE-SUSPENSE.
           CALL 'SUSWRT01' USING WS-CLAIM-REC WS-ERR-CD.
