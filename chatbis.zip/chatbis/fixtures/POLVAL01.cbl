000100 IDENTIFICATION DIVISION.                                         POLVAL01
000200 PROGRAM-ID. POLVAL01.                                            POLVAL01
000300* POLICY VALIDATION - SYNTHETIC FIXTURE, NOT REAL SOURCE          POLVAL01
000400 ENVIRONMENT DIVISION.                                            POLVAL01
000500 DATA DIVISION.                                                   POLVAL01
000600 WORKING-STORAGE SECTION.                                         POLVAL01
000700     COPY ERRCODES.                                               POLVAL01
000800 01  WS-POLICY-REC.                                               POLVAL01
000900     05 WS-POL-NUMBER      PIC X(10).                             POLVAL01
001000     05 WS-BENE-DOB        PIC 9(8).                              POLVAL01
001100     05 WS-EFF-DATE        PIC 9(8).                              POLVAL01
001200     05 WS-PREM-AMT        PIC S9(7)V99 COMP-3.                   POLVAL01
001300 PROCEDURE DIVISION.                                              POLVAL01
001400 MAIN-CONTROL.                                                    POLVAL01
001500     PERFORM VALIDATE-DATES                                       POLVAL01
001600     PERFORM VALIDATE-PREMIUM                                     POLVAL01
001700     GOBACK.                                                      POLVAL01
001800 VALIDATE-DATES.                                                  POLVAL01
001900     IF WS-BENE-DOB > WS-EFF-DATE                                 POLVAL01
002000        MOVE 'E4417' TO WS-ERR-CD                                 POLVAL01
002100        PERFORM WRITE-REJECT                                      POLVAL01
002200     END-IF.                                                      POLVAL01
002300 VALIDATE-PREMIUM.                                                POLVAL01
002400     IF WS-PREM-AMT NOT NUMERIC                                   POLVAL01
002500        MOVE 'E4102' TO WS-ERR-CD                                 POLVAL01
002600        PERFORM WRITE-REJECT                                      POLVAL01
002700     END-IF.                                                      POLVAL01
002800 WRITE-REJECT.                                                    POLVAL01
002900     CALL 'REJWRT01' USING WS-POLICY-REC WS-ERR-CD.               POLVAL01
