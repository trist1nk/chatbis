      * SYNTHETIC ERROR CODE COPYBOOK - FIXTURE
       01  WS-ERROR-FIELDS.
           05 WS-ERR-CD          PIC X(5).
              88 ERR-DOB-AFTER-EFF     VALUE 'E4417'.
              88 ERR-PREM-NOT-NUM      VALUE 'E4102'.
              88 ERR-DUP-POLICY        VALUE 'E2088'.
              88 ERR-BENE-MISSING      VALUE 'E3350'.
           05 WS-ERR-MSG         PIC X(60).
