# Policy Validation — Detailed Functional Requirements (synthetic fixture)

## 3.1 Beneficiary date of birth

The beneficiary date of birth must be on or before the policy effective
date. A case where WS-BENE-DOB is later than WS-EFF-DATE must be rejected
with exception E4417 and routed to the suspense file for analyst review.
The correction is applied on screen PS220 in the BENE-DOB field.

## 3.2 Premium amount

The premium amount must be numeric and greater than zero. Non-numeric
premium data raises exception E4102. Premiums are corrected on screen
PS310.

## 4.1 Beneficiary table capacity

The beneficiary load table holds a maximum of 500 entries per policy.
Records beyond capacity are skipped in the nightly load and reported on
the reject listing. This is a known processing limitation.
