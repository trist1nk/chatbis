       IDENTIFICATION DIVISION.
       PROGRAM-ID. BFDISAB.
      *----------------------------------------------------------------*
      * BUSINESS FUNCTION - DISABILITY. THE COMPUTATION PROGRAM IS    *
      * PICKED AT RUNTIME (DYNAMIC CALL) FROM THE CLAIM TYPE, AND     *
      * THE PDA IS REACHED ONLY THROUGH THE EE INTERFACE: EEGET,      *
      * LOCAL WORK, EEPUT. THE DATUM CHANGES NAMES AT EVERY HOP.      *
      *----------------------------------------------------------------*
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY PDAREC.
       COPY EEREC.
       01  WS-COMP-PGM                 PIC X(08).
       01  PIA-PARM-AREA.
           05  PIA-AIME                PIC 9(07)V99.
           05  PIA-ELIG-YEAR           PIC 9(04).
           05  PIA-RESULT              PIC 9(07)V99.
           05  PIA-RC                  PIC X(02).
       01  WS-LOCAL.
           05  WS-DOB                  PIC X(10).
           05  WS-MBA                  PIC 9(07)V99.
       PROCEDURE DIVISION.
       0000-MAIN.
           MOVE 'PIACOMP' TO WS-COMP-PGM
           CALL WS-COMP-PGM USING PIA-PARM-AREA
           MOVE PIA-RESULT TO PDA-PIA
           CALL 'EEGET' USING PDA-RECORD EE-RECORD
           IF EE-CLM-TYPE = 'DIS'
               PERFORM 1000-APPLY-DISABILITY
           END-IF
           GOBACK.
       1000-APPLY-DISABILITY.
           MOVE EE-DOB TO WS-DOB
           MOVE EE-MBA TO WS-MBA
           COMPUTE WS-MBA = WS-MBA * .85
           MOVE WS-DOB TO EE-DOB
           MOVE WS-MBA TO EE-MBA
           CALL 'EEPUT' USING EE-RECORD PDA-RECORD.
