       IDENTIFICATION DIVISION.
       PROGRAM-ID. BFRETIRE.
      *----------------------------------------------------------------*
      * BUSINESS FUNCTION - RETIREMENT. COMPUTES THE PIA AND MBA FOR   *
      * A RETIREMENT CLAIM ON THE PDA.                                 *
      *----------------------------------------------------------------*
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY PDAREC.
       01  PIA-PARM-AREA.
           05  PIA-AIME                PIC 9(07)V99.
           05  PIA-ELIG-YEAR           PIC 9(04).
           05  PIA-RESULT              PIC 9(07)V99.
           05  PIA-RC                  PIC X(02).
       01  WS-ERROR-CODE               PIC X(05).
       PROCEDURE DIVISION.
       0000-MAIN.
           PERFORM 1000-COMPUTE-PIA
           PERFORM 2000-SET-MBA
           GOBACK.
       1000-COMPUTE-PIA.
           CALL 'PIACOMP' USING PIA-PARM-AREA
           IF PIA-RC NOT = '00'
               MOVE 'E7201' TO WS-ERROR-CODE
               DISPLAY 'BFRETIRE PIA FAILED ' WS-ERROR-CODE
               CALL 'EXCEPTRN' USING WS-ERROR-CODE
           END-IF
           MOVE PIA-RESULT TO PDA-PIA.
       2000-SET-MBA.
           MOVE PDA-PIA TO PDA-MBA.
