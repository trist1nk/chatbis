       IDENTIFICATION DIVISION.
       PROGRAM-ID. BFSURV.
      *----------------------------------------------------------------*
      * BUSINESS FUNCTION - SURVIVOR. A SURVIVOR CLAIM NEEDS A DEATH   *
      * ON RECORD, DATES IN ORDER, AND BOTH COMPUTATIONS: PIA FROM     *
      * THE DECEASED WAGE EARNER, THEN THE SURVIVOR MBA FROM IT.       *
      *----------------------------------------------------------------*
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY PDAREC.
       01  PIA-PARM-AREA.
           05  PIA-AIME                PIC 9(07)V99.
           05  PIA-ELIG-YEAR           PIC 9(04).
           05  PIA-RESULT              PIC 9(07)V99.
           05  PIA-RC                  PIC X(02).
       01  MBA-PARM-AREA.
           05  MBA-PIA-IN              PIC 9(07)V99.
           05  MBA-REL-CD              PIC X(01).
           05  MBA-RESULT              PIC 9(07)V99.
           05  MBA-RC                  PIC X(02).
       01  WS-ERROR-CODE               PIC X(05).
       PROCEDURE DIVISION.
       0000-MAIN.
           PERFORM 1000-EDIT-SURVIVOR
           PERFORM 2000-COMPUTE-PIA
           PERFORM 3000-COMPUTE-MBA
           GOBACK.
       1000-EDIT-SURVIVOR.
           IF PDA-CLM-TYPE = 'SUR'
               IF PDA-BENE-DOD = SPACES
                   MOVE 'E7301' TO WS-ERROR-CODE
                   PERFORM 9000-EXCEPT
               END-IF
               IF PDA-BENE-DOD < PDA-BENE-DOB
                   MOVE 'E7302' TO WS-ERROR-CODE
                   PERFORM 9000-EXCEPT
               END-IF
           END-IF.
       2000-COMPUTE-PIA.
           CALL 'PIACOMP' USING PIA-PARM-AREA
           IF PIA-RC NOT = '00'
               MOVE 'E7201' TO WS-ERROR-CODE
               PERFORM 9000-EXCEPT
           END-IF.
       3000-COMPUTE-MBA.
           MOVE PIA-RESULT TO MBA-PIA-IN
           CALL 'MBACOMP' USING MBA-PARM-AREA
           IF MBA-RC = '04'
               MOVE 'E7401' TO WS-ERROR-CODE
               PERFORM 9000-EXCEPT
           END-IF
           MOVE MBA-RESULT TO PDA-MBA.
       9000-EXCEPT.
           DISPLAY 'BFSURV EXCEPTION ' WS-ERROR-CODE
           CALL 'EXCEPTRN' USING WS-ERROR-CODE.
