       IDENTIFICATION DIVISION.
       PROGRAM-ID. EEPUT.
      *----------------------------------------------------------------*
      * PUT MODULE - POSTS THE EE INTERFACE AREA BACK TO THE PDA.     *
      * THE ONLY PATH BY WHICH A BUSINESS FUNCTION'S WORK REACHES     *
      * THE PROCESSING DATA AREA.                                     *
      *----------------------------------------------------------------*
       DATA DIVISION.
       LINKAGE SECTION.
       COPY EEREC.
       COPY PDAREC.
       PROCEDURE DIVISION USING EE-RECORD PDA-RECORD.
       0000-MAIN.
           MOVE EE-DOB TO PDA-BENE-DOB
           MOVE EE-ENT-DT TO PDA-ENT-DT
           MOVE EE-MBA TO PDA-MBA
           MOVE '00' TO EE-RC
           GOBACK.
