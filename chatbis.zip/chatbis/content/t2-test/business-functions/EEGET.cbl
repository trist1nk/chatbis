       IDENTIFICATION DIVISION.
       PROGRAM-ID. EEGET.
      *----------------------------------------------------------------*
      * GET MODULE - PROJECTS THE CALLER'S PDA INTO THE EE INTERFACE  *
      * AREA. BOTH AREAS BELONG TO THE CALLER; THIS PROGRAM ONLY      *
      * MOVES BETWEEN THEM.                                           *
      *----------------------------------------------------------------*
       DATA DIVISION.
       LINKAGE SECTION.
       COPY PDAREC.
       COPY EEREC.
       PROCEDURE DIVISION USING PDA-RECORD EE-RECORD.
       0000-MAIN.
           MOVE PDA-SSN TO EE-SSN
           MOVE PDA-BENE-DOB TO EE-DOB
           MOVE PDA-CLM-TYPE TO EE-CLM-TYPE
           MOVE PDA-ENT-DT TO EE-ENT-DT
           MOVE PDA-MBA TO EE-MBA
           MOVE '00' TO EE-RC
           GOBACK.
