# Business Functions — Detailed Functional Requirements (synthetic fixture)

## 5.1 Computation sequence

The business functions process the PDA in sequence and each updates it in
place. The PIA computes before the MBA — the monthly benefit amount
derives from the primary insurance amount, never the reverse.

## 5.2 PIA computation

The PIA computation utility receives the AIME and eligibility year. A
zero AIME raises E7101; an eligibility year before 1979 raises E7102 and
routes the claim to the old-law computation. A nonzero return code from
the utility on a retirement claim raises E7201.

## 5.3 Survivor claims

A survivor claim requires a date of death on record: a survivor claim
without one raises E7301, and a date of death before the date of birth
raises E7302. Both are corrected on screen PS230 after the death data is
verified.

## 5.4 MBA by relationship

The MBA is the PIA scaled by relationship: one hundred percent for the
wage earner, seventy-five percent for a surviving child, seventy-one and
a half percent for a widow or widower at minimum age. A computed MBA
below the statutory minimum raises E7401 and the minimum is paid.
