# PUT — Detailed Functional Requirements (synthetic fixture)

## 6.1 Database posting

PUT writes the processed PDA to the claim table in a single unit of work.
An insert rejected by DB2 raises E6401 and the unit of work rolls back —
the claim posts entirely or not at all.

## 6.2 Control row

The claim control row carries the last run date and status for the
restart logic. A control update rejected by DB2 raises E6402; the nightly
run does not continue past a failed control update.

## 6.3 Restartability

The PUT step is restartable from the last committed transaction. Rerun
after an abend resumes from the control row — transactions already posted
are not reposted.
