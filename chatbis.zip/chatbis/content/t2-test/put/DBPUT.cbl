       IDENTIFICATION DIVISION.
       PROGRAM-ID. DBPUT.
      *----------------------------------------------------------------*
      * PUT - WRITES THE PROCESSED PDA TO THE DATABASE. LAST STAGE.    *
      *----------------------------------------------------------------*
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY PDAREC.
       01  WS-HOST-VARS.
           05  WS-SSN                  PIC 9(09).
           05  WS-BIC                  PIC X(02).
           05  WS-DOB                  PIC X(10).
           05  WS-CLM-TYPE             PIC X(03).
           05  WS-ENT-DT               PIC X(10).
           05  WS-MBA                  PIC 9(07)V99.
       01  WS-ERROR-CODE               PIC X(05).
       PROCEDURE DIVISION.
       0000-MAIN.
           PERFORM 1000-STAGE-HOST-VARS
           PERFORM 2000-WRITE-CLAIM
           PERFORM 3000-UPDATE-STATUS
           GOBACK.
       1000-STAGE-HOST-VARS.
           MOVE PDA-SSN TO WS-SSN
           MOVE PDA-BIC TO WS-BIC
           MOVE PDA-BENE-DOB TO WS-DOB
           MOVE PDA-CLM-TYPE TO WS-CLM-TYPE
           MOVE PDA-ENT-DT TO WS-ENT-DT
           MOVE PDA-MBA TO WS-MBA.
       2000-WRITE-CLAIM.
           EXEC SQL
               INSERT INTO MCS.CLAIM
                   (SSN, BIC, BENE_DOB, CLM_TYPE, ENT_DT, MBA)
               VALUES (:WS-SSN, :WS-BIC, :WS-DOB, :WS-CLM-TYPE,
                       :WS-ENT-DT, :WS-MBA)
           END-EXEC
           IF SQLCODE NOT = 0
               MOVE 'E6401' TO WS-ERROR-CODE
               DISPLAY 'DBPUT INSERT FAILED ' WS-ERROR-CODE
               CALL 'EXCEPTRN' USING WS-ERROR-CODE
           END-IF.
       3000-UPDATE-STATUS.
           EXEC SQL
               UPDATE MCS.CLAIM_CONTROL
                  SET LAST_RUN_DT = :WS-ENT-DT,
                      RUN_STAT = :WS-CLM-TYPE
                WHERE SSN = :WS-SSN
           END-EXEC.
