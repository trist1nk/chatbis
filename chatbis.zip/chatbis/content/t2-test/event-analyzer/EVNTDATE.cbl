       IDENTIFICATION DIVISION.
       PROGRAM-ID. EVNTDATE.
      *----------------------------------------------------------------*
      * EVENT ANALYZER - DATE DERIVATION. THE ENTITLEMENT DATE COMES   *
      * FROM THE FILING DATE, ADJUSTED BY CLAIM TYPE. EVERY DOWNSTREAM *
      * STAGE TRUSTS WHAT THIS PROGRAM WRITES.                         *
      *----------------------------------------------------------------*
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-WORK.
           05  WS-TODAY                PIC X(10).
           05  WS-WAIT-MONTHS          PIC 9(02).
           05  WS-ERROR-CODE           PIC X(05).
       LINKAGE SECTION.
       COPY TDAREC.
       01  LS-DERIVE-STAT              PIC X(01).
       PROCEDURE DIVISION USING TDA-RECORD LS-DERIVE-STAT.
       0000-MAIN.
           PERFORM 1000-EDIT-INPUT
           PERFORM 2000-DERIVE
           GOBACK.
       1000-EDIT-INPUT.
           IF TDA-BENE-DOB = SPACES
               MOVE 'E6101' TO WS-ERROR-CODE
               PERFORM 9000-FAIL
           END-IF
           IF TDA-FILING-DT < TDA-BENE-DOB
               MOVE 'E6102' TO WS-ERROR-CODE
               PERFORM 9000-FAIL
           END-IF
           IF TDA-FILING-DT > WS-TODAY
               MOVE 'E6103' TO WS-ERROR-CODE
               PERFORM 9000-FAIL
           END-IF.
       2000-DERIVE.
           EVALUATE TDA-CLM-TYPE
               WHEN 'RET'
                   MOVE 0 TO WS-WAIT-MONTHS
               WHEN 'DIB'
                   MOVE 5 TO WS-WAIT-MONTHS
               WHEN 'SUR'
                   MOVE 0 TO WS-WAIT-MONTHS
               WHEN OTHER
                   DISPLAY 'EVNTDATE WARNING - UNKNOWN CLAIM TYPE '
                       TDA-CLM-TYPE ' DEFAULTED TO RET'
                   MOVE 0 TO WS-WAIT-MONTHS
           END-EVALUATE
           MOVE TDA-FILING-DT TO TDA-ENT-DT.
       9000-FAIL.
           MOVE 'N' TO LS-DERIVE-STAT
           DISPLAY 'EVNTDATE EXCEPTION ' WS-ERROR-CODE
           CALL 'EXCEPTRN' USING WS-ERROR-CODE.
