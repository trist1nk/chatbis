       IDENTIFICATION DIVISION.
       PROGRAM-ID. EVNTDRVR.
      *----------------------------------------------------------------*
      * EVENT ANALYZER - DRIVER. GETS THE TDA, DERIVES THE DATES IN    *
      * SEQUENCE, WRITES THEM BACK. THE SEQUENCE IS THE CONTRACT:      *
      * ENTITLEMENT BEFORE PERIODS, PERIODS BEFORE RESUMPTIONS.        *
      *----------------------------------------------------------------*
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY TDAREC.
       01  WS-SWITCHES.
           05  WS-DERIVE-STAT          PIC X(01).
               88  DERIVE-OK           VALUE 'Y'.
               88  DERIVE-FAILED       VALUE 'N'.
       01  WS-ERROR-CODE               PIC X(05).
       PROCEDURE DIVISION.
       0000-MAIN.
           PERFORM 1000-GET-TDA
           PERFORM 2000-DERIVE-ENTITLEMENT
           IF DERIVE-OK
               PERFORM 3000-DERIVE-PERIODS
               PERFORM 4000-DERIVE-RESUMPTIONS
           END-IF
           PERFORM 5000-PUT-TDA
           GOBACK.
       1000-GET-TDA.
           CALL 'TDAIO' USING TDA-RECORD.
       2000-DERIVE-ENTITLEMENT.
           SET DERIVE-OK TO TRUE
           CALL 'EVNTDATE' USING TDA-RECORD WS-DERIVE-STAT.
       3000-DERIVE-PERIODS.
           IF TDA-ENT-DT > TDA-BENE-DOD AND TDA-BENE-DOD NOT = SPACES
               MOVE 'E6203' TO WS-ERROR-CODE
               PERFORM 9000-EXCEPT
           END-IF
           MOVE TDA-ENT-DT TO TDA-ENT-STRT-DT (1).
       4000-DERIVE-RESUMPTIONS.
           MOVE SPACES TO TDA-ENT-RSMP-DT (1).
       5000-PUT-TDA.
           CALL 'TDAIO' USING TDA-RECORD.
       9000-EXCEPT.
           SET DERIVE-FAILED TO TRUE
           DISPLAY 'EVNTDRVR EXCEPTION ' WS-ERROR-CODE
           CALL 'EXCEPTRN' USING WS-ERROR-CODE.
