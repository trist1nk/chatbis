       IDENTIFICATION DIVISION.
       PROGRAM-ID. EVNTANLZ.
      *----------------------------------------------------------------*
      * EVENT ANALYZER - DERIVES THE ENTITLEMENT DATE AND THE          *
      * ENTITLEMENT PERIOD TABLE FROM THE FILING AND BIRTH DATES.      *
      * THE DATES THIS PROGRAM SETS DRIVE EVERY DOWNSTREAM DECISION.   *
      *----------------------------------------------------------------*
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY TDAREC.
       01  WS-WORK-AREAS.
           05  WS-COMPUTED-ENT-DT      PIC X(10).
           05  WS-FRA-YEARS            PIC 9(02).
           05  WS-ELIG-AGE             PIC 9(03).
           05  WS-ERROR-CODE           PIC X(05).
       PROCEDURE DIVISION.
       0000-MAIN.
           PERFORM 1000-DERIVE-ENTITLEMENT
           PERFORM 2000-SET-PERIODS
           GOBACK.
       1000-DERIVE-ENTITLEMENT.
           IF TDA-BENE-DOB = SPACES
               MOVE 'E6101' TO WS-ERROR-CODE
               PERFORM 9000-EXCEPT
           END-IF
           IF TDA-FILING-DT < TDA-BENE-DOB
               MOVE 'E6102' TO WS-ERROR-CODE
               PERFORM 9000-EXCEPT
           END-IF
           MOVE TDA-FILING-DT TO WS-COMPUTED-ENT-DT
           MOVE WS-COMPUTED-ENT-DT TO TDA-ENT-DT.
       2000-SET-PERIODS.
           MOVE TDA-ENT-DT TO TDA-ENT-STRT-DT (1)
           MOVE SPACES TO TDA-ENT-END-DT (1).
       9000-EXCEPT.
           DISPLAY 'EVNTANLZ EXCEPTION ' WS-ERROR-CODE
           CALL 'EXCEPTRN' USING WS-ERROR-CODE.
