# Event Analyzer — Detailed Functional Requirements (synthetic fixture)

## 2.1 Date of birth required

Entitlement cannot derive without a beneficiary date of birth on the
transaction. A TDA arriving with a blank date of birth raises exception
E6101 and the transaction is excepted out of the nightly run. The date of
birth is corrected at the source system; there is no online correction
screen for this condition.

## 2.2 Filing date ordering

The filing date must be on or after the beneficiary date of birth and must
not be in the future. A filing date before the date of birth raises E6102;
a future filing date raises E6103. Both are batch rejects — the analyst
verifies the filing evidence and resubmits the transaction.

## 2.3 Waiting period by claim type

Disability claims carry a five-month waiting period before entitlement;
retirement and survivor claims have none. An unknown claim type is
processed as retirement and a warning is written to the run log — the
claim is not excepted for this condition alone.

## 2.4 Death before entitlement

When a date of death is present, a derived entitlement date after the date
of death raises E6203. The analyst verifies the death data against the
death master file before any correction on screen PS220.
