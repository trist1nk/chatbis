       IDENTIFICATION DIVISION.
       PROGRAM-ID. MBACOMP.
      *----------------------------------------------------------------*
      * MBA COMPUTATION UTILITY. THE MONTHLY BENEFIT AMOUNT DERIVES    *
      * FROM THE PIA BY RELATIONSHIP: 100% WAGE EARNER, 75% SURVIVOR   *
      * CHILD, 71.5% WIDOW(ER) AT MINIMUM AGE. FLOORS AT THE STATUTORY *
      * MINIMUM AND ROUNDS DOWN TO THE DIME.                           *
      *----------------------------------------------------------------*
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-CONSTANTS.
           05  WS-MIN-MBA              PIC 9(03)V99 VALUE 49.40.
           05  WS-PCT-SURV-CHILD       PIC V999 VALUE .750.
           05  WS-PCT-WIDOW            PIC V999 VALUE .715.
       01  WS-WORK-MBA                 PIC 9(07)V99.
       LINKAGE SECTION.
       01  MBA-PARM-AREA.
           05  MBA-PIA-IN              PIC 9(07)V99.
           05  MBA-REL-CD              PIC X(01).
               88  REL-WAGE-EARNER     VALUE 'A'.
               88  REL-SURV-CHILD      VALUE 'C'.
               88  REL-WIDOW           VALUE 'W'.
           05  MBA-RESULT              PIC 9(07)V99.
           05  MBA-RC                  PIC X(02).
       PROCEDURE DIVISION USING MBA-PARM-AREA.
       0000-MAIN.
           EVALUATE TRUE
               WHEN REL-WAGE-EARNER
                   MOVE MBA-PIA-IN TO WS-WORK-MBA
               WHEN REL-SURV-CHILD
                   COMPUTE WS-WORK-MBA = MBA-PIA-IN * WS-PCT-SURV-CHILD
               WHEN REL-WIDOW
                   COMPUTE WS-WORK-MBA = MBA-PIA-IN * WS-PCT-WIDOW
               WHEN OTHER
                   MOVE MBA-PIA-IN TO WS-WORK-MBA
           END-EVALUATE
           IF WS-WORK-MBA < WS-MIN-MBA
               MOVE '04' TO MBA-RC
               MOVE WS-MIN-MBA TO WS-WORK-MBA
           ELSE
               MOVE '00' TO MBA-RC
           END-IF
           MOVE WS-WORK-MBA TO MBA-RESULT
           GOBACK.
