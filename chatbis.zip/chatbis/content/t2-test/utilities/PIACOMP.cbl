       IDENTIFICATION DIVISION.
       PROGRAM-ID. PIACOMP.
      *----------------------------------------------------------------*
      * PIA COMPUTATION UTILITY - CALLED BY THE BUSINESS FUNCTIONS.    *
      * COMPUTES THE PRIMARY INSURANCE AMOUNT FROM THE EARNINGS AND    *
      * ENTITLEMENT PARAMETERS THE CALLER PASSES.                      *
      *----------------------------------------------------------------*
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-BEND-POINTS.
           05  WS-BEND-1               PIC 9(05).
           05  WS-BEND-2               PIC 9(05).
       01  WS-ERROR-CODE               PIC X(05).
       LINKAGE SECTION.
       01  PIA-PARM-AREA.
           05  PIA-AIME                PIC 9(07)V99.
           05  PIA-ELIG-YEAR           PIC 9(04).
           05  PIA-RESULT              PIC 9(07)V99.
           05  PIA-RC                  PIC X(02).
       PROCEDURE DIVISION USING PIA-PARM-AREA.
       0000-MAIN.
           IF PIA-AIME = ZEROS
               MOVE 'E7101' TO WS-ERROR-CODE
               MOVE '08' TO PIA-RC
               GOBACK
           END-IF
           IF PIA-ELIG-YEAR < 1979
               MOVE 'E7102' TO WS-ERROR-CODE
               MOVE '12' TO PIA-RC
               GOBACK
           END-IF
           PERFORM 1000-COMPUTE
           MOVE '00' TO PIA-RC
           GOBACK.
       1000-COMPUTE.
           COMPUTE PIA-RESULT = PIA-AIME * 0.9
           MOVE PIA-RESULT TO PIA-RESULT.
