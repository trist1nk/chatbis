       IDENTIFICATION DIVISION.
       PROGRAM-ID. PDABUILD.
      *----------------------------------------------------------------*
      * PDA-BUILD - PROJECTS THE VALIDATED TDA INTO THE PROCESSING     *
      * DATA AREA THE BUSINESS FUNCTIONS UPDATE IN SEQUENCE.           *
      *----------------------------------------------------------------*
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY TDAREC.
       COPY PDAREC.
       01  WS-IDX                      PIC 9(02).
       01  WS-ERROR-CODE               PIC X(05).
       PROCEDURE DIVISION.
       0000-MAIN.
           IF NOT TDA-EDIT-PASS
               MOVE 'E6301' TO WS-ERROR-CODE
               DISPLAY 'PDABUILD BLOCKED ' WS-ERROR-CODE
               CALL 'EXCEPTRN' USING WS-ERROR-CODE
           END-IF
           PERFORM 1000-PROJECT
           GOBACK.
       1000-PROJECT.
           MOVE TDA-SSN TO PDA-SSN
           MOVE TDA-BIC TO PDA-BIC
           MOVE TDA-BENE-DOB TO PDA-BENE-DOB
           MOVE TDA-BENE-DOD TO PDA-BENE-DOD
           MOVE TDA-CLM-TYPE TO PDA-CLM-TYPE
           MOVE TDA-ENT-DT TO PDA-ENT-DT
           PERFORM VARYING WS-IDX FROM 1 BY 1 UNTIL WS-IDX > 12
               MOVE TDA-ENT-STRT-DT (WS-IDX) TO PDA-ENT-STRT-DT (WS-IDX)
               MOVE TDA-ENT-END-DT (WS-IDX) TO PDA-ENT-END-DT (WS-IDX)
           END-PERFORM.
