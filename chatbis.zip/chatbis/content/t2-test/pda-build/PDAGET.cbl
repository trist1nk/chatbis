       IDENTIFICATION DIVISION.
       PROGRAM-ID. PDAGET.
      *----------------------------------------------------------------*
      * PDA-BUILD - GET-DATA MODULE. PULLS PRIOR-CLAIM HISTORY FROM    *
      * DB2 SO THE PDA CARRIES WHAT THE BUSINESS FUNCTIONS NEED        *
      * WITHOUT THEIR OWN SQL.                                         *
      *----------------------------------------------------------------*
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY PDAREC.
       01  WS-HOST-VARS.
           05  WS-SSN                  PIC 9(09).
           05  WS-PRIOR-MBA            PIC 9(07)V99.
           05  WS-PRIOR-ENT-DT         PIC X(10).
           05  WS-PRIOR-STAT           PIC X(01).
       01  WS-ERROR-CODE               PIC X(05).
       PROCEDURE DIVISION.
       0000-MAIN.
           MOVE PDA-SSN TO WS-SSN
           PERFORM 1000-GET-PRIOR
           GOBACK.
       1000-GET-PRIOR.
           EXEC SQL
               SELECT MBA, ENT_DT, CLM_STAT
                 INTO :WS-PRIOR-MBA, :WS-PRIOR-ENT-DT, :WS-PRIOR-STAT
                 FROM MCS.CLAIM_HISTORY
                WHERE SSN = :WS-SSN
           END-EXEC
           EVALUATE SQLCODE
               WHEN 0
                   MOVE WS-PRIOR-MBA TO PDA-PIA
               WHEN 100
                   MOVE ZEROS TO PDA-PIA
               WHEN OTHER
                   MOVE 'E6402' TO WS-ERROR-CODE
                   DISPLAY 'PDAGET DB2 ERROR ' WS-ERROR-CODE
                   CALL 'EXCEPTRN' USING WS-ERROR-CODE
           END-EVALUATE.
