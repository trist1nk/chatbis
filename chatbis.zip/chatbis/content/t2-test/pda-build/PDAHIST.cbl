       IDENTIFICATION DIVISION.
       PROGRAM-ID. PDAHIST.
      *----------------------------------------------------------------*
      * PDA-BUILD - ENTITLEMENT HISTORY. WALKS THE PERIOD ROWS WITH A  *
      * CURSOR AND LOADS THE PDA PERIOD TABLE IN START-DATE ORDER.     *
      * MORE THAN TWELVE PERIODS IS THE LIM-6310 LIMITATION.           *
      *----------------------------------------------------------------*
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY PDAREC.
       01  WS-HOST-VARS.
           05  WS-SSN                  PIC 9(09).
           05  WS-STRT-DT              PIC X(10).
           05  WS-END-DT               PIC X(10).
           05  WS-RSMP-DT              PIC X(10).
       01  WS-IDX                      PIC 9(02).
       01  WS-ERROR-CODE               PIC X(05).
           EXEC SQL
               DECLARE HIST-CUR CURSOR FOR
               SELECT ENT_STRT_DT, ENT_END_DT, RSMP_DT
                 FROM MCS.ENT_PERIODS
                WHERE SSN = :WS-SSN
                ORDER BY ENT_STRT_DT
           END-EXEC.
       PROCEDURE DIVISION.
       0000-MAIN.
           MOVE PDA-SSN TO WS-SSN
           EXEC SQL OPEN HIST-CUR END-EXEC
           MOVE 1 TO WS-IDX
           PERFORM 1000-FETCH-PERIOD UNTIL SQLCODE = 100 OR WS-IDX > 12
           IF SQLCODE NOT = 100 AND WS-IDX > 12
               DISPLAY 'PDAHIST LIMITATION LIM-6310 - PERIODS DROPPED'
           END-IF
           EXEC SQL CLOSE HIST-CUR END-EXEC
           GOBACK.
       1000-FETCH-PERIOD.
           EXEC SQL
               FETCH HIST-CUR
                INTO :WS-STRT-DT, :WS-END-DT, :WS-RSMP-DT
           END-EXEC
           IF SQLCODE = 0
               MOVE WS-STRT-DT TO PDA-ENT-STRT-DT (WS-IDX)
               MOVE WS-END-DT TO PDA-ENT-END-DT (WS-IDX)
               ADD 1 TO WS-IDX
           END-IF.
