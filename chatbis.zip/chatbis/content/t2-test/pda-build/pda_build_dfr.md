# PDA Build — Detailed Functional Requirements (synthetic fixture)

## 4.1 Gate on weeder status

The processing data area is built only from a TDA that passed every edit.
A TDA arriving with the edit-fail flag set raises E6301 and the PDA build
is blocked for that transaction.

## 4.2 Prior-claim history

The PDA carries prior-claim history pulled from the claim history table
so the business functions never issue their own SQL. A DB2 error other
than not-found during the pull raises E6402. A not-found is normal for a
first claim and initializes the history fields to zeros.

## 4.3 Period table capacity

The PDA period table holds twelve entitlement periods. Excess periods are
dropped and LIM-6310 is recorded — a known processing limitation, not an
exception. Claims with more than twelve periods are worked manually.
