      *================================================================*
      * TDAREC - TRANSACTION DATA AREA RECORD LAYOUT                   *
      * BUILT BY INFRASTRUCTURE, READ BY EVERY DOWNSTREAM STAGE.       *
      *================================================================*
       01  TDA-RECORD.
           05  TDA-KEY.
               10  TDA-SSN             PIC 9(09).
               10  TDA-BIC             PIC X(02).
           05  TDA-BENE.
               10  TDA-BENE-DOB        PIC X(10).
               10  TDA-BENE-DOD        PIC X(10).
               10  TDA-BENE-NAME       PIC X(30).
           05  TDA-CLAIM.
               10  TDA-CLM-TYPE        PIC X(03).
               10  TDA-ENT-DT          PIC X(10).
               10  TDA-FILING-DT       PIC X(10).
           05  TDA-ENT-TABLE.
               10  TDA-ENT-ENTRY       OCCURS 12 TIMES.
                   15  TDA-ENT-STRT-DT PIC X(10).
                   15  TDA-ENT-END-DT  PIC X(10).
                   15  TDA-ENT-RSMP-DT PIC X(10).
           05  TDA-STATUS.
               10  TDA-EDIT-STAT       PIC X(01).
                   88  TDA-EDIT-PASS   VALUE 'P'.
                   88  TDA-EDIT-FAIL   VALUE 'F'.
