      *================================================================*
      * EEREC - THE EE INTERFACE AREA. BUSINESS FUNCTIONS DO NOT      *
      * TOUCH THE PDA DIRECTLY: EEGET PROJECTS THE PDA INTO THIS      *
      * AREA, THE FUNCTION WORKS ON ITS OWN STORAGE, EEPUT POSTS THE  *
      * RESULT BACK. THE SAME DATUM WEARS FOUR NAMES ON THE TRIP:     *
      * PDA-BENE-DOB -> EE-DOB -> WS-DOB -> EE-DOB -> PDA-BENE-DOB.  *
      *================================================================*
       01  EE-RECORD.
           05  EE-SSN              PIC 9(09).
           05  EE-DOB              PIC X(10).
           05  EE-CLM-TYPE         PIC X(03).
           05  EE-ENT-DT           PIC X(10).
           05  EE-MBA              PIC 9(07)V99.
           05  EE-RC               PIC X(02).
