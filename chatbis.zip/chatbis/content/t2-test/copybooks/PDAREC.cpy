      *================================================================*
      * PDAREC - PROCESSING DATA AREA RECORD LAYOUT                    *
      * BUILT FROM THE TDA; BUSINESS FUNCTIONS UPDATE IT IN SEQUENCE;  *
      * PUT WRITES IT TO THE DATABASE.                                 *
      *================================================================*
       01  PDA-RECORD.
           05  PDA-KEY.
               10  PDA-SSN             PIC 9(09).
               10  PDA-BIC             PIC X(02).
           05  PDA-BENE.
               10  PDA-BENE-DOB        PIC X(10).
               10  PDA-BENE-DOD        PIC X(10).
           05  PDA-CLAIM.
               10  PDA-CLM-TYPE        PIC X(03).
               10  PDA-ENT-DT          PIC X(10).
               10  PDA-MBA             PIC 9(07)V99.
               10  PDA-PIA             PIC 9(07)V99.
           05  PDA-ENT-TABLE.
               10  PDA-ENT-ENTRY       OCCURS 12 TIMES.
                   15  PDA-ENT-STRT-DT PIC X(10).
                   15  PDA-ENT-END-DT  PIC X(10).
           05  PDA-PROC-STAT           PIC X(01).
               88  PDA-PROC-DONE       VALUE 'D'.
