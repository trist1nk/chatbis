      *================================================================*
      * IDMSCLM - CLAIM-REC AS CARRIED IN THE IDMS CLAIM AREA.         *
      * NETWORK DATABASE: THE RECORD IS REACHED BY CALC KEY (SSN) OR   *
      * BY WALKING THE CLAIM-SET FROM THE BENEFICIARY OWNER RECORD.    *
      *================================================================*
       01  CLAIM-REC.
           05  CLM-SSN                 PIC 9(09).
           05  CLM-BIC                 PIC X(02).
           05  CLM-STATUS              PIC X(02).
               88  CLM-ACTIVE          VALUE 'AC'.
               88  CLM-SUSPENDED       VALUE 'SU'.
               88  CLM-TERMINATED      VALUE 'TE'.
           05  CLM-SUSP-RSN            PIC X(05).
           05  CLM-STATUS-DT           PIC X(10).
           05  CLM-MBA                 PIC 9(07)V99.
