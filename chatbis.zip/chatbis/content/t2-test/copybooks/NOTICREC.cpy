      *================================================================*
      * NOTICREC - BENEFICIARY NOTICE RECORD                           *
      * BUILT BY NOTIFY FROM THE POSTED CLAIM; PRINTED DOWNSTREAM.     *
      *================================================================*
       01  NOTICE-RECORD.
           05  NOT-SSN                 PIC 9(09).
           05  NOT-BIC                 PIC X(02).
           05  NOT-TYPE                PIC X(03).
               88  NOT-AWARD           VALUE 'AWD'.
               88  NOT-DENIAL          VALUE 'DEN'.
               88  NOT-ADJUSTMENT      VALUE 'ADJ'.
           05  NOT-NAME                PIC X(30).
           05  NOT-ADDRESS.
               10  NOT-ADDR-LINE1      PIC X(30).
               10  NOT-ADDR-LINE2      PIC X(30).
               10  NOT-CITY            PIC X(20).
               10  NOT-STATE           PIC X(02).
               10  NOT-ZIP             PIC X(09).
           05  NOT-MBA                 PIC 9(07)V99.
           05  NOT-EFF-DT              PIC X(10).
           05  NOT-LANG-CD             PIC X(01).
               88  NOT-ENGLISH         VALUE 'E'.
               88  NOT-SPANISH         VALUE 'S'.
