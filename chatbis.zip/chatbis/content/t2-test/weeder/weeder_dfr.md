# Weeder — Detailed Functional Requirements (synthetic fixture)

## 3.1 Purpose of the weeder

The weeder is the last gate before the processing data area is built. A
transaction that fails any weeder edit never reaches the PDA and never
runs the business functions. Weeder rejects are worked from the reject
listing, not from an online queue.

## 3.2 Date sanity

A date of birth after the derived entitlement date raises E6201; the
correction is applied on screen PS220 in the BENE-DOB field. An
entitlement period whose end date precedes its start date raises E6202
and is corrected on screen PS225.

## 3.3 Death checks

An entitlement date after the date of death raises E6203. Death data is
verified before correction — see the Event Analyzer requirements.

## 3.4 Duplicate transactions

Two transactions in the same nightly input carrying the same SSN and BIC
raise E6204 on the second occurrence. The duplicate is investigated
before either transaction is released; releasing both double-posts the
claim.

## 3.5 Period overlaps

Entitlement periods must not overlap: a period that starts before the
prior period ends raises E6205. Overlaps are corrected on screen PS225 by
closing the earlier period.
