       IDENTIFICATION DIVISION.
       PROGRAM-ID. WEEDEDIT.
      *----------------------------------------------------------------*
      * WEEDER - STRUCTURAL EDITS. DUPLICATE KEYS AND PERIOD OVERLAPS. *
      * RUNS AFTER WEEDCHK; A RECORD THAT FAILS EITHER NEVER REACHES   *
      * THE PDA.                                                       *
      *----------------------------------------------------------------*
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY TDAREC.
       01  WS-PREV-KEY.
           05  WS-PREV-SSN             PIC 9(09).
           05  WS-PREV-BIC             PIC X(02).
       01  WS-IDX                      PIC 9(02).
       01  WS-JDX                      PIC 9(02).
       01  WS-ERROR-CODE               PIC X(05).
       PROCEDURE DIVISION.
       0000-MAIN.
           PERFORM 1000-CHECK-DUPLICATE
           PERFORM 2000-CHECK-OVERLAPS
           GOBACK.
       1000-CHECK-DUPLICATE.
           IF TDA-SSN = WS-PREV-SSN AND TDA-BIC = WS-PREV-BIC
               MOVE 'E6204' TO WS-ERROR-CODE
               PERFORM 9000-WEED-OUT
           END-IF
           MOVE TDA-SSN TO WS-PREV-SSN
           MOVE TDA-BIC TO WS-PREV-BIC.
       2000-CHECK-OVERLAPS.
           PERFORM VARYING WS-IDX FROM 1 BY 1 UNTIL WS-IDX > 11
               ADD 1 WS-IDX GIVING WS-JDX
               IF TDA-ENT-STRT-DT (WS-JDX) NOT = SPACES
                   IF TDA-ENT-STRT-DT (WS-JDX) < TDA-ENT-END-DT (WS-IDX)
                       MOVE 'E6205' TO WS-ERROR-CODE
                       PERFORM 9000-WEED-OUT
                   END-IF
               END-IF
           END-PERFORM.
       9000-WEED-OUT.
           SET TDA-EDIT-FAIL TO TRUE
           DISPLAY 'WEEDEDIT REJECT ' WS-ERROR-CODE
           CALL 'EXCEPTRN' USING WS-ERROR-CODE.
