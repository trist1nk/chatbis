       IDENTIFICATION DIVISION.
       PROGRAM-ID. WEEDCHK.
      *----------------------------------------------------------------*
      * WEEDER - DATA CHECKS ON THE COMPLETED TDA. A RECORD THAT       *
      * FAILS HERE NEVER REACHES THE PDA.                              *
      *----------------------------------------------------------------*
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT SUSP-FILE ASSIGN TO REJECTS
               ORGANIZATION IS INDEXED
               ACCESS IS SEQUENTIAL
               RECORD KEY IS SUSP-KEY.
       DATA DIVISION.
       FILE SECTION.
       FD  SUSP-FILE.
       01  SUSP-RECORD.
           05  SUSP-KEY.
               10  SUSP-SSN            PIC 9(09).
               10  SUSP-BIC            PIC X(02).
           05  SUSP-ERR-CD             PIC X(05).
           05  SUSP-DATA               PIC X(200).
       WORKING-STORAGE SECTION.
       COPY TDAREC.
       01  WS-ERROR-CODE               PIC X(05).
       PROCEDURE DIVISION.
       0000-MAIN.
           OPEN OUTPUT SUSP-FILE
           PERFORM 1000-CHECK-DATES
           PERFORM 2000-CHECK-DEATH
           IF NOT TDA-EDIT-FAIL
               SET TDA-EDIT-PASS TO TRUE
           END-IF
           GOBACK.
       1000-CHECK-DATES.
           IF TDA-BENE-DOB > TDA-ENT-DT
               MOVE 'E6201' TO WS-ERROR-CODE
               PERFORM 9000-WEED-OUT
           END-IF
           IF TDA-ENT-END-DT (1) > SPACES
               IF TDA-ENT-END-DT (1) < TDA-ENT-STRT-DT (1)
                   MOVE 'E6202' TO WS-ERROR-CODE
                   PERFORM 9000-WEED-OUT
               END-IF
           END-IF.
       2000-CHECK-DEATH.
           IF TDA-BENE-DOD NOT = SPACES
               IF TDA-ENT-DT > TDA-BENE-DOD
                   MOVE 'E6203' TO WS-ERROR-CODE
                   PERFORM 9000-WEED-OUT
               END-IF
           END-IF.
       9000-WEED-OUT.
           SET TDA-EDIT-FAIL TO TRUE
           MOVE TDA-SSN TO SUSP-SSN
           MOVE TDA-BIC TO SUSP-BIC
           MOVE WS-ERROR-CODE TO SUSP-ERR-CD
           WRITE SUSP-RECORD FROM TDA-RECORD
           DISPLAY 'WEEDCHK REJECT ' WS-ERROR-CODE
           CALL 'EXCEPTRN' USING WS-ERROR-CODE.
