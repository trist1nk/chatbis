       IDENTIFICATION DIVISION.
       PROGRAM-ID. OPS220.
      *----------------------------------------------------------------*
      * ONLINE - PS220 DATE CORRECTIONS. THE ANALYST FIXES THE DATES   *
      * THE NIGHTLY REJECTED. SAME EDITS AS THE BATCH PATH - THE RULE  *
      * LIVES ONCE, IN THE BUSINESS FUNCTION THIS SCREEN LINKS TO.     *
      *----------------------------------------------------------------*
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      * SYMBOLIC MAP (AS GENERATED FROM PS220S) - THE SCREEN JOINT.
       01  PS220M-FIELDS.
           05  SSNINI                  PIC 9(09).
           05  BENEDOBI                PIC 9(08).
           05  EFFDATEI                PIC 9(08).
           05  ERRMSGO                 PIC X(70).
       01  WS-SCREEN-FIELDS.
           05  WS-BENE-DOB             PIC 9(08).
           05  WS-EFF-DATE             PIC 9(08).
       01  WS-COMMAREA.
           05  WS-COMM-SSN             PIC 9(09).
           05  WS-COMM-RC              PIC X(02).
       01  WS-ERROR-CODE               PIC X(05).
       PROCEDURE DIVISION.
       0000-MAIN.
           EXEC CICS RECEIVE MAP('PS220M') MAPSET('PS220S') END-EXEC
           MOVE BENEDOBI TO WS-BENE-DOB
           MOVE EFFDATEI TO WS-EFF-DATE
           PERFORM 1000-EDIT-DATES
           PERFORM 2000-REAPPLY
           EXEC CICS SEND MAP('PS220M') MAPSET('PS220S') ERASE END-EXEC
           EXEC CICS RETURN TRANSID('P220') END-EXEC.
       1000-EDIT-DATES.
           IF WS-BENE-DOB > WS-EFF-DATE
               MOVE 'E4417' TO WS-ERROR-CODE
               MOVE 'DOB IS AFTER THE EFFECTIVE DATE' TO ERRMSGO
               PERFORM 9000-SEND-ERROR
           END-IF.
       2000-REAPPLY.
           EXEC CICS LINK PROGRAM('BFRETIRE')
                COMMAREA(WS-COMMAREA) END-EXEC
           IF WS-COMM-RC = '99'
               EXEC CICS ABEND ABCODE('AP22') END-EXEC
           END-IF.
       9000-SEND-ERROR.
           DISPLAY 'OPS220 EDIT FAILED ' WS-ERROR-CODE.
