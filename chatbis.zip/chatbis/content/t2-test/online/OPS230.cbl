       IDENTIFICATION DIVISION.
       PROGRAM-ID. OPS230.
      *----------------------------------------------------------------*
      * ONLINE - PS230 SUSPENSE RELEASE. THE ANALYST CLEARS A          *
      * SUSPENDED CLAIM AFTER VERIFYING THE DEATH DATA. THE CLAIM      *
      * LIVES IN IDMS - REACHED BY CALC KEY, UPDATED IN PLACE.         *
      *----------------------------------------------------------------*
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY IDMSCLM.
       01  WS-SCREEN.
           05  WS-NEW-STATUS           PIC X(02).
           05  WS-RELEASE-RSN          PIC X(05).
       01  WS-ERROR-CODE               PIC X(05).
       PROCEDURE DIVISION.
       0000-MAIN.
           EXEC CICS RECEIVE MAP('PS230M') MAPSET('PS230S') END-EXEC
           PERFORM 1000-GET-CLAIM
           PERFORM 2000-RELEASE
           EXEC CICS SEND MAP('PS230M') MAPSET('PS230S') END-EXEC
           EXEC CICS RETURN TRANSID('P230') END-EXEC.
       1000-GET-CLAIM.
           OBTAIN CALC CLAIM-REC
           IF CLM-STATUS NOT = 'SU'
               MOVE 'E7305' TO WS-ERROR-CODE
               DISPLAY 'NOT IN SUSPENSE - RELEASE REFUSED ' WS-ERROR-CODE
           END-IF.
       2000-RELEASE.
           MOVE WS-NEW-STATUS TO CLM-STATUS
           MOVE WS-RELEASE-RSN TO CLM-SUSP-RSN
           MODIFY CLAIM-REC
           FIND OWNER WITHIN BENE-CLAIM-SET.
