       IDENTIFICATION DIVISION.
       PROGRAM-ID. NOTIFFMT.
      *----------------------------------------------------------------*
      * NOTIFY - FORMATTER. LANGUAGE SELECTION AND PRINT-LINE LAYOUT.  *
      * AN UNKNOWN LANGUAGE CODE FALLS BACK TO ENGLISH WITH A WARNING, *
      * NEVER A HOLD.                                                  *
      *----------------------------------------------------------------*
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-PRINT-LINE               PIC X(132).
       LINKAGE SECTION.
       COPY NOTICREC.
       PROCEDURE DIVISION USING NOTICE-RECORD.
       0000-MAIN.
           EVALUATE TRUE
               WHEN NOT-ENGLISH
                   CONTINUE
               WHEN NOT-SPANISH
                   CONTINUE
               WHEN OTHER
                   DISPLAY 'NOTIFFMT WARNING - UNKNOWN LANGUAGE '
                       NOT-LANG-CD ' DEFAULTED TO ENGLISH'
                   SET NOT-ENGLISH TO TRUE
           END-EVALUATE
           MOVE NOT-NAME TO WS-PRINT-LINE
           GOBACK.
