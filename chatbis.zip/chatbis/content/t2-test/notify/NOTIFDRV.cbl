       IDENTIFICATION DIVISION.
       PROGRAM-ID. NOTIFDRV.
      *----------------------------------------------------------------*
      * NOTIFY - DRIVER. AFTER PUT POSTS THE CLAIM, BUILD THE AWARD    *
      * OR DENIAL NOTICE FROM THE DATABASE ROW AND RELEASE IT TO THE   *
      * PRINT FILE. AN INCOMPLETE ADDRESS HOLDS THE NOTICE, NEVER      *
      * THE CLAIM.                                                     *
      *----------------------------------------------------------------*
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY NOTICREC.
       01  WS-HOST-VARS.
           05  WS-SSN                  PIC 9(09).
           05  WS-NAME                 PIC X(30).
           05  WS-ADDR1                PIC X(30).
           05  WS-CITY                 PIC X(20).
           05  WS-STATE                PIC X(02).
           05  WS-ZIP                  PIC X(09).
           05  WS-MBA                  PIC 9(07)V99.
       01  WS-ERROR-CODE               PIC X(05).
       PROCEDURE DIVISION.
       0000-MAIN.
           PERFORM 1000-GET-CLAIMANT
           PERFORM 2000-BUILD-NOTICE
           PERFORM 3000-RELEASE
           GOBACK.
       1000-GET-CLAIMANT.
           EXEC SQL
               SELECT BENE_NAME, ADDR_LINE1, CITY, ST, ZIP, MBA
                 INTO :WS-NAME, :WS-ADDR1, :WS-CITY, :WS-STATE,
                      :WS-ZIP, :WS-MBA
                 FROM MCS.CLAIMANT
                WHERE SSN = :WS-SSN
           END-EXEC.
       2000-BUILD-NOTICE.
           MOVE WS-SSN TO NOT-SSN
           MOVE WS-NAME TO NOT-NAME
           MOVE WS-ADDR1 TO NOT-ADDR-LINE1
           MOVE WS-CITY TO NOT-CITY
           MOVE WS-STATE TO NOT-STATE
           MOVE WS-ZIP TO NOT-ZIP
           MOVE WS-MBA TO NOT-MBA
           IF NOT-ADDR-LINE1 = SPACES OR NOT-ZIP = SPACES
               MOVE 'E6501' TO WS-ERROR-CODE
               DISPLAY 'NOTIFDRV HELD ' WS-ERROR-CODE
               CALL 'EXCEPTRN' USING WS-ERROR-CODE
           END-IF.
       3000-RELEASE.
           CALL 'NOTIFFMT' USING NOTICE-RECORD.
