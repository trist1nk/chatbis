# Notify — Detailed Functional Requirements (synthetic fixture)

## 7.1 Notice on posting

Every posted award, denial, or adjustment releases a notice to the
beneficiary. The notice is built from the posted database row, never from
the PDA — what the notice says must be what the database says.

## 7.2 Address completeness

A notice with an incomplete address — blank first address line or blank
ZIP — raises E6501 and the notice is held, never the claim. The address
is corrected on screen PS410 and the notice re-releases on the next run.

## 7.3 Language

Notices issue in English or Spanish from the language code on the
claimant record. An unknown language code falls back to English with a
warning in the run log; language problems never hold a notice.
