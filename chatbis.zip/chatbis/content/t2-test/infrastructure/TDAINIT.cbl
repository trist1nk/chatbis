       IDENTIFICATION DIVISION.
       PROGRAM-ID. TDAINIT.
      *----------------------------------------------------------------*
      * INFRASTRUCTURE - CLEARS THE TDA BEFORE EACH TRANSACTION.       *
      *----------------------------------------------------------------*
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY TDAREC.
       PROCEDURE DIVISION.
       0000-MAIN.
           INITIALIZE TDA-RECORD
           MOVE SPACES TO TDA-EDIT-STAT
           GOBACK.
