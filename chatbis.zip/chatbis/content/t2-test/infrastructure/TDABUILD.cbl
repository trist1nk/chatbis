       IDENTIFICATION DIVISION.
       PROGRAM-ID. TDABUILD.
      *----------------------------------------------------------------*
      * INFRASTRUCTURE - BUILDS THE TRANSACTION DATA AREA FROM THE     *
      * INPUT TRANSACTION. FIRST STAGE OF THE NIGHTLY RUN.             *
      *----------------------------------------------------------------*
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY TDAREC.
       01  IN-TRANSACTION.
           05  IN-SSN                  PIC 9(09).
           05  IN-BIC                  PIC X(02).
           05  IN-DOB                  PIC X(10).
           05  IN-DOD                  PIC X(10).
           05  IN-NAME                 PIC X(30).
           05  IN-CLM-TYPE             PIC X(03).
           05  IN-FILING-DT            PIC X(10).
       01  WS-ERROR-CODE               PIC X(05).
       PROCEDURE DIVISION.
       0000-MAIN.
           PERFORM 1000-VALIDATE-INPUT
           PERFORM 2000-BUILD-TDA
           GOBACK.
       1000-VALIDATE-INPUT.
           IF IN-SSN = ZEROS
               MOVE 'E6001' TO WS-ERROR-CODE
               PERFORM 9000-ABORT
           END-IF
           IF IN-BIC = SPACES
               MOVE 'E6002' TO WS-ERROR-CODE
               PERFORM 9000-ABORT
           END-IF.
       2000-BUILD-TDA.
           MOVE IN-SSN TO TDA-SSN
           MOVE IN-BIC TO TDA-BIC
           MOVE IN-DOB TO TDA-BENE-DOB
           MOVE IN-DOD TO TDA-BENE-DOD
           MOVE IN-NAME TO TDA-BENE-NAME
           MOVE IN-CLM-TYPE TO TDA-CLM-TYPE
           MOVE IN-FILING-DT TO TDA-FILING-DT.
       9000-ABORT.
           DISPLAY 'TDABUILD ABEND ' WS-ERROR-CODE
           CALL 'ABENDRTN' USING WS-ERROR-CODE.
