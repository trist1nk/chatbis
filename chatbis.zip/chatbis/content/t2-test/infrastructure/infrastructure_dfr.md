# Infrastructure — Detailed Functional Requirements (synthetic fixture)

## 1.1 Transaction keying

Every nightly transaction keys on SSN and BIC. A transaction with a zero
SSN raises E6001 and cannot be keyed; a blank BIC raises E6002. Both abort
the TDA build for that transaction — there is nothing downstream to
correct, the input feed is repaired at the source.

## 1.2 TDA initialization

The transaction data area is cleared before each transaction. A TDA
carried over from the prior transaction is a data-integrity defect, not a
processing exception — report it to the infrastructure team.

## 1.3 Field carriage

The TDA carries the transaction fields unmodified: dates are not edited,
derived, or defaulted at this stage. Editing belongs to the event
analyzer and the weeder.
