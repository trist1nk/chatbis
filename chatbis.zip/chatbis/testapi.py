#!/usr/bin/env python3
"""ChatBIS — synthetic benefit-data API for building and testing recipes.

Stdlib only. Serves SSA-shaped claim records keyed by SSN + BIC, with
several repeating data groups (entitlement periods, addresses, payments)
and a citizenship group — the shape real recipes have to navigate.

    python3 testapi.py            # http://127.0.0.1:8799
    GET /v1/claims?ssn=900010001&bic=A
    GET /v1/cases                 # index of every seeded case + its defects

⚠️  ALL DATA IS SYNTHETIC. SSNs use the 900-xx-xxxx range, which is never
    issued (reserved/ITIN space), so nothing here can collide with a real
    person. Never point this at, or seed it from, production data.

Each case is seeded with SPECIFIC defects so a recipe has something to
catch. `GET /v1/cases` prints the catalogue; `defects` on each record names
them (the field is metadata for you, not something a recipe should read —
a real API won't have it).
"""
from __future__ import annotations

import json
import urllib.parse
from http.server import BaseHTTPRequestHandler, HTTPServer

PORT = 8799


def claim(ssn, bic, *, surname, first, dob, claim_type, entitlement,
          periods, addresses, citizenship, payments, exceptions,
          defects, dod=None, pia="1842.50", mba="1842.50", payee=None,
          medicare=None):
    return {
        "claimNumber": f"{ssn}{bic}",
        "claimant": {
            "ssn": ssn, "bic": bic, "surname": surname, "firstName": first,
            "dateOfBirth": dob, "dateOfDeath": dod,
        },
        "claim": {
            "claimType": claim_type,          # RETIREMENT | DISABILITY | SURVIVORS
            "entitlementDate": entitlement,
            "primaryInsuranceAmount": pia,
            "monthlyBenefitAmount": mba,
            "fullRetirementAge": "67",
        },
        "entitlementPeriods": periods,        # repeating
        "addresses": addresses,               # repeating
        "citizenship": citizenship,
        "payments": payments,                 # repeating
        "representativePayee": payee,
        "medicare": medicare or {"partA": "Y", "partB": "Y",
                                 "enrollmentDate": "2023-01-01"},
        "exceptions": exceptions,             # repeating
        "defects": defects,                   # TEST METADATA — not in a real API
    }


def period(start, end="", resume="", status="ACTIVE", reason=""):
    return {"startDate": start, "endDate": end, "resumptionDate": resume,
            "status": status, "reasonCode": reason}


def address(line1, city, state, zipc, eff, end="", kind="RESIDENCE",
            foreign="N", country="USA"):
    return {"type": kind, "line1": line1, "city": city, "state": state,
            "postalCode": zipc, "effectiveDate": eff, "endDate": end,
            "foreignIndicator": foreign, "country": country}


def payment(per, amount, status="PAID", method="EFT"):
    return {"period": per, "amount": amount, "status": status, "method": method}


def exc(code, raised, status="OPEN"):
    return {"code": code, "raisedDate": raised, "status": status}


# ── the seeded cases ───────────────────────────────────────────────────────
# Each demonstrates a different defect class so recipes have real material.
CASES = {}


def _add(c):
    CASES[(c["claimant"]["ssn"], c["claimant"]["bic"].upper())] = c


# 1 — CLEAN. Retirement, everything consistent. Use to catch over-broad
#     checks: a recipe that fires here is wrong.
_add(claim(
    "900010001", "A", surname="OKONKWO", first="ADAEZE", dob="1958-03-12",
    claim_type="RETIREMENT", entitlement="2025-04-01",
    periods=[period("2025-04-01")],
    addresses=[address("14 Larch Ave", "Baltimore", "MD", "21201", "2019-06-01")],
    citizenship={"status": "USC", "countryOfBirth": "USA", "evidenceCode": "BC",
                 "verifiedDate": "2025-02-11", "alienRegistrationNumber": None},
    payments=[payment("2026-06", "1842.50"), payment("2026-07", "1842.50")],
    exceptions=[],
    defects=[],
))

# 2 — DOB AFTER ENTITLEMENT (the E4417 shape) + period end before start.
_add(claim(
    "900010002", "A", surname="HALVORSEN", first="MARIT", dob="2027-03-15",
    claim_type="RETIREMENT", entitlement="2026-01-01",
    periods=[period("2020-01-01", "2022-06-30", status="TERMINATED",
                    reason="RET"),
             period("2023-01-01", "2022-12-31")],   # end precedes start
    addresses=[address("902 Kestrel Rd", "Towson", "MD", "21204", "2021-01-01")],
    citizenship={"status": "USC", "countryOfBirth": "USA", "evidenceCode": "BC",
                 "verifiedDate": "2024-09-02", "alienRegistrationNumber": None},
    payments=[payment("2026-07", "0.00", status="SUSPENDED")],
    exceptions=[exc("E4417", "2026-07-28")],
    defects=["dob_after_entitlement", "period_end_before_start"],
))

# 3 — DISABILITY with MULTIPLE OPEN PERIODS and a resumption that precedes
#     the suspension it resumes.
_add(claim(
    "900010003", "B", surname="ADEYEMI", first="TUNDE", dob="1972-11-04",
    claim_type="DISABILITY", entitlement="2018-09-01",
    periods=[period("2018-09-01", "2021-03-31", resume="2021-01-15",
                    status="SUSPENDED", reason="MED"),   # resume < end
             period("2021-06-01"),                       # open
             period("2024-02-01")],                      # ALSO open
    addresses=[address("77 Pinegrove Ct", "Silver Spring", "MD", "20901",
                       "2017-05-01")],
    citizenship={"status": "USC", "countryOfBirth": "USA", "evidenceCode": "BC",
                 "verifiedDate": "2018-07-19", "alienRegistrationNumber": None},
    payments=[payment("2026-06", "1204.00"), payment("2026-07", "1204.00")],
    exceptions=[exc("E5002", "2026-07-30")],
    defects=["multiple_open_periods", "resume_before_end"],
    pia="1204.00", mba="1204.00",
))

# 4 — NON-CITIZEN missing alien registration number and unverified.
_add(claim(
    "900010004", "C", surname="NGUYEN", first="LINH", dob="2009-06-22",
    claim_type="SURVIVORS", entitlement="2024-02-01",
    periods=[period("2024-02-01")],
    addresses=[address("3 Rue Lafayette", "Paris", "", "75009", "2023-11-01",
                       foreign="Y", country="FRA")],
    citizenship={"status": "NONCITIZEN", "countryOfBirth": "VNM",
                 "evidenceCode": "", "verifiedDate": None,
                 "alienRegistrationNumber": None},          # missing
    payments=[payment("2026-07", "0.00", status="WITHHELD")],
    exceptions=[exc("E3350", "2026-07-25")],
    defects=["noncitizen_missing_arn", "citizenship_unverified",
             "foreign_address"],
    pia="880.00", mba="880.00",
    payee={"name": "NGUYEN, MAI", "relationship": "PARENT",
           "appointedDate": "2024-02-01"},
))

# 5 — ENTITLEMENT GAP + overlapping addresses.
_add(claim(
    "900010005", "A", surname="PETROVA", first="YELENA", dob="1955-01-30",
    claim_type="RETIREMENT", entitlement="2020-02-01",
    periods=[period("2020-02-01", "2022-12-31", status="TERMINATED"),
             period("2024-06-01")],                  # 17-month unexplained gap
    addresses=[address("18 Halstead St", "Rockville", "MD", "20850",
                       "2019-01-01", "2023-01-01"),
               address("400 Beech Ln", "Bethesda", "MD", "20814",
                       "2022-06-01")],               # overlaps the above
    citizenship={"status": "LPR", "countryOfBirth": "BGR", "evidenceCode": "I551",
                 "verifiedDate": "2019-10-04",
                 "alienRegistrationNumber": "A012345678"},
    payments=[payment("2026-06", "1610.00"), payment("2026-07", "1610.00")],
    exceptions=[exc("E5001", "2026-07-29")],
    defects=["entitlement_gap", "overlapping_addresses"],
    pia="1610.00", mba="1610.00",
))

# 6 — DISABILITY entitled ABOVE full retirement age (claim-type mismatch),
#     and a deceased claimant still in ACTIVE status.
_add(claim(
    "900010006", "D", surname="MBEKI", first="THANDIWE", dob="1949-08-17",
    claim_type="DISABILITY", entitlement="2025-09-01",   # age 76 at entitlement
    dod="2026-05-14",
    periods=[period("2025-09-01", status="ACTIVE")],     # active after death
    addresses=[address("22 Cedar Loop", "Columbia", "MD", "21044", "2015-03-01")],
    citizenship={"status": "USC", "countryOfBirth": "ZAF", "evidenceCode": "N550",
                 "verifiedDate": "1998-04-22",
                 "alienRegistrationNumber": "A987654321"},
    payments=[payment("2026-06", "1390.00"), payment("2026-07", "1390.00")],
    exceptions=[exc("E5005", "2026-07-31"), exc("E9001", "2026-07-31")],
    defects=["disability_above_fra", "active_period_after_death",
             "payments_after_death"],
    pia="1390.00", mba="1390.00",
))

# 7 — MANY occurrences (24 periods) to exercise history rendering and prove
#     `latest` picks correctly when array order is deliberately shuffled.
_many = [period(f"20{y:02d}-{m:02d}-01", f"20{y:02d}-{m + 2:02d}-28",
                status="TERMINATED")
         for y in range(2, 14) for m in (1, 7)]
_many = _many[::-1]                      # array order != chronological order
_many.append(period("2025-11-01"))       # the real latest, buried mid-array
_many.insert(5, _many.pop())
_add(claim(
    "900010007", "A", surname="SZABO", first="ISTVAN", dob="1960-12-05",
    claim_type="RETIREMENT", entitlement="2002-01-01",
    periods=_many,
    addresses=[address("9 Kossuth Ter", "Annapolis", "MD", "21401", "2001-01-01")],
    citizenship={"status": "USC", "countryOfBirth": "HUN", "evidenceCode": "N550",
                 "verifiedDate": "1995-06-30",
                 "alienRegistrationNumber": "A222333444"},
    payments=[payment(f"2026-{m:02d}", "1725.00") for m in range(1, 8)],
    exceptions=[],
    defects=["array_order_not_chronological", "many_occurrences"],
    pia="1725.00", mba="1725.00",
))


class Handler(BaseHTTPRequestHandler):
    def _json(self, payload, status=200):
        body = json.dumps(payload, indent=2).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        url = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(url.query)

        # Bearer token accepted but not enforced — this is a sandbox. It
        # exists so the ChatBIS JWT path is exercised end to end.
        if url.path == "/v1/cases":
            self._json({"cases": [
                {"claimNumber": c["claimNumber"],
                 "ssn": c["claimant"]["ssn"], "bic": c["claimant"]["bic"],
                 "name": f'{c["claimant"]["surname"]}, {c["claimant"]["firstName"]}',
                 "claimType": c["claim"]["claimType"],
                 "periods": len(c["entitlementPeriods"]),
                 "exceptions": [e["code"] for e in c["exceptions"]],
                 "defects": c["defects"]}
                for c in CASES.values()]})
            return

        # Separate sources, so a complete case needs several calls — this is
        # what ChatBIS case BUNDLES compose back into one object.
        if url.path == "/v1/periods":
            cn = (qs.get("claim", [""])[0] or "").strip()
            rec = next((c for c in CASES.values()
                        if c["claimNumber"] == cn), None)
            if not rec:
                self._json({"error": "No claim"}, 404)
                return
            self._json(rec["entitlementPeriods"])
            return

        if url.path == "/v1/addresses":
            ssn = (qs.get("ssn", [""])[0] or "").replace("-", "").strip()
            rec = next((c for c in CASES.values()
                        if c["claimant"]["ssn"] == ssn), None)
            if not rec:
                self._json({"error": "No claim"}, 404)
                return
            self._json(rec["addresses"])
            return

        if url.path in ("/v1/claims", "/v1/cases/by-ssn"):
            ssn = (qs.get("ssn", [""])[0] or "").replace("-", "").strip()
            bic = (qs.get("bic", [""])[0] or "").strip().upper()
            if not ssn or not bic:
                self._json({"error": "ssn and bic are both required"}, 400)
                return
            rec = CASES.get((ssn, bic))
            if not rec:
                self._json({"error": "No claim found for that SSN and BIC"}, 404)
                return
            self._json(rec)
            return

        self._json({"error": "Not found",
                    "endpoints": ["/v1/cases", "/v1/claims?ssn=&bic="]}, 404)

    def log_message(self, *a):
        pass


if __name__ == "__main__":
    print(f"ChatBIS synthetic benefit API → http://127.0.0.1:{PORT}")
    print(f"  index : http://127.0.0.1:{PORT}/v1/cases")
    print(f"  claim : http://127.0.0.1:{PORT}/v1/claims?ssn=900010002&bic=A")
    print("  ⚠️  synthetic data only — 900-xx-xxxx SSNs are never issued\n")
    for (ssn, bic), c in CASES.items():
        print(f"  {ssn} {bic}  {c['claimant']['surname']:<10} "
              f"{c['claim']['claimType']:<11} {', '.join(c['defects']) or 'clean'}")
    print()
    HTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
