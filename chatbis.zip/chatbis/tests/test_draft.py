"""Auto-drafting invariants.

The rule that matters: a condition we cannot translate faithfully must be
BLOCKED with a reason, never silently guessed. A wrong drafted rule reads as
authored and fires on the wrong cases -- worse than no draft at all.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from chatbis.draft import (draft_checks, parse_condition, walk_paths,
                           _split_group)

FMAP = [
    {"cobol_field": "WS-BENE-DOB", "json_path": "claimant.dateOfBirth",
     "label": "Beneficiary date of birth"},
    {"cobol_field": "WS-EFF-DATE", "json_path": "claim.entitlementDate",
     "label": "Policy effective date"},
    {"cobol_field": "WS-ENT-STRT-DT", "json_path": "entitlementPeriods[].startDate",
     "label": "Entitlement period start"},
    {"cobol_field": "WS-ENT-END-DT", "json_path": "entitlementPeriods[].endDate",
     "label": "Entitlement period end"},
    {"cobol_field": "WS-ADDR-EFF-DT", "json_path": "addresses[].effectiveDate",
     "label": "Address effective date"},
    {"cobol_field": "WS-BENE-ID", "json_path": "beneficiaryId",
     "label": "Beneficiary id"},
    {"cobol_field": "WS-STATE", "json_path": "addresses[].state",
     "label": "State"},
]


def src(cond, **kw):
    d = {"condition": cond, "program": "POLVAL01", "file": "polval01.cbl",
         "line": 412}
    d.update(kw)
    return d


class TestParseCondition(unittest.TestCase):
    def test_simple_relation(self):
        p = parse_condition("IF WS-BENE-DOB > WS-EFF-DATE")
        self.assertIsNone(p["blocked"])
        self.assertEqual(p["clauses"], [{"lhs": "WS-BENE-DOB", "op": "gt",
                                         "rhs": "WS-EFF-DATE",
                                         "rhs_literal": False}])

    def test_wordy_operators(self):
        for text, op in (("IF A IS GREATER THAN B", "gt"),
                         ("IF A NOT GREATER THAN B", "le"),
                         ("IF A NOT LESS THAN B", "ge"),
                         ("IF A LESS THAN OR EQUAL TO B", "le"),
                         ("IF A EQUAL TO B", "eq"),
                         ("IF A NOT = B", "ne")):
            with self.subTest(text=text):
                self.assertEqual(parse_condition(text)["clauses"][0]["op"], op)

    def test_figurative_constants_become_blank_ops(self):
        p = parse_condition("IF WS-BENE-ID = SPACES")
        self.assertEqual(p["clauses"][0]["op"], "blank")
        p = parse_condition("IF WS-BENE-ID NOT = SPACES")
        self.assertEqual(p["clauses"][0]["op"], "not_blank")

    def test_sign_condition(self):
        p = parse_condition("IF WS-FACE-AMT IS NEGATIVE")
        self.assertEqual(p["clauses"][0], {"lhs": "WS-FACE-AMT", "op": "lt",
                                           "rhs": "0", "rhs_literal": True})

    def test_or_splits_into_clauses(self):
        p = parse_condition("IF WS-ISSUE-AGE > 85 OR WS-ISSUE-AGE < 0")
        self.assertIsNone(p["blocked"])
        self.assertEqual([(c["op"], c["rhs"]) for c in p["clauses"]],
                         [("gt", "85"), ("lt", "0")])

    def test_abbreviated_or_reuses_operator_and_field(self):
        p = parse_condition("IF WS-STATE = 'VA' OR 'MD' OR 'DC' CONTINUE")
        self.assertIsNone(p["blocked"])
        self.assertEqual([c["rhs"] for c in p["clauses"]], ["VA", "MD", "DC"])
        self.assertTrue(all(c["lhs"] == "WS-STATE" for c in p["clauses"]))

    # ── the refusals ──────────────────────────────────────────────────
    def test_and_is_declined_not_guessed(self):
        p = parse_condition("IF PLAN-TERM AND WS-ISSUE-AGE > 70")
        self.assertEqual(p["clauses"], [])
        self.assertIn("AND", p["blocked"])

    def test_flag_condition_declined(self):
        self.assertIn("no relational operator",
                      parse_condition("IF PLAN-TERM")["blocked"])

    def test_class_condition_declined(self):
        self.assertIn("NUMERIC",
                      parse_condition("IF WS-PREM-AMT NOT NUMERIC")["blocked"])

    def test_evaluate_branch_declined(self):
        self.assertIsNotNone(parse_condition("WHEN -803")["blocked"])
        self.assertIsNotNone(parse_condition("WHEN OTHER")["blocked"])

    def test_or_across_different_fields_declined(self):
        p = parse_condition("IF WS-A > 1 OR WS-B > 2")
        self.assertIn("different fields", p["blocked"])


class TestSplitGroup(unittest.TestCase):
    def test_shapes(self):
        self.assertEqual(_split_group("claimant.dateOfBirth"),
                         ("", "claimant.dateOfBirth"))
        self.assertEqual(_split_group("entitlementPeriods[].startDate"),
                         ("entitlementPeriods", "startDate"))


class TestDraftChecks(unittest.TestCase):
    def test_case_level_compare_carries_provenance_and_english(self):
        d = draft_checks([src("IF WS-BENE-DOB > WS-EFF-DATE")], FMAP)
        self.assertEqual(len(d), 1)
        self.assertIsNone(d[0]["blocked"])
        c = d[0]["check"]
        self.assertEqual(c["path"], "claimant.dateOfBirth")
        self.assertEqual(c["op"], "gt")
        self.assertEqual(c["value"], "$$.claim.entitlementDate")
        self.assertEqual(c["group"], "")
        self.assertEqual(d[0]["provenance"]["line"], 412)
        self.assertIn("Beneficiary date of birth", d[0]["why"])
        self.assertIn("Policy effective date", d[0]["why"])

    def test_same_group_compare_uses_same_row_reference(self):
        d = draft_checks([src("IF WS-ENT-STRT-DT > WS-ENT-END-DT")], FMAP)
        c = d[0]["check"]
        self.assertEqual(c["group"], "entitlementPeriods")
        self.assertEqual(c["scope"], "latest")
        self.assertEqual(c["path"], "startDate")
        self.assertEqual(c["value"], "$.endDate")        # $. not $$.
        self.assertTrue(d[0]["why"].startswith("In the latest entitlementPeriods,"))

    def test_cross_group_compare_declined(self):
        d = draft_checks([src("IF WS-ENT-STRT-DT > WS-ADDR-EFF-DT")], FMAP)
        self.assertIsNone(d[0]["check"])
        self.assertIn("two repeating groups", d[0]["blocked"])

    def test_unmapped_field_is_an_actionable_todo(self):
        d = draft_checks([src("IF WS-MYSTERY > WS-EFF-DATE")], FMAP)
        self.assertIsNone(d[0]["check"])
        self.assertEqual(d[0]["needs_mapping"], "WS-MYSTERY")

    def test_blank_check_needs_no_right_hand_mapping(self):
        d = draft_checks([src("IF WS-BENE-ID = SPACES")], FMAP)
        self.assertIsNone(d[0]["blocked"])
        self.assertEqual(d[0]["check"]["op"], "blank")
        self.assertEqual(d[0]["check"]["path"], "beneficiaryId")

    def test_drafts_are_likely_not_definitive(self):
        # A machine-drafted rule is a proposal; the analyst promotes it.
        d = draft_checks([src("IF WS-BENE-DOB > WS-EFF-DATE")], FMAP)
        self.assertEqual(d[0]["check"]["confidence"], "likely")

    def test_or_produces_one_draft_per_clause(self):
        d = draft_checks([src("IF WS-STATE = 'VA' OR 'MD'")], FMAP)
        self.assertEqual(len(d), 2)
        self.assertEqual([x["check"]["value"] for x in d], ["VA", "MD"])


class TestWalkPaths(unittest.TestCase):
    CASE = {
        "claimNumber": "A123",
        "claimant": {"dateOfBirth": "1958-04-02", "name": "REDACTED"},
        "entitlementPeriods": [
            {"startDate": "2019-01-01", "endDate": ""},
            {"startDate": "2021-06-01", "endDate": "2022-01-01"},
        ],
        "flags": ["X", "Y"],
    }

    def test_leaves_nested_and_groups(self):
        got = {e["path"]: e for e in walk_paths(self.CASE)}
        self.assertEqual(got["claimNumber"]["value"], "A123")
        self.assertEqual(got["claimant.dateOfBirth"]["value"], "1958-04-02")
        self.assertEqual(got["entitlementPeriods"]["kind"], "group")
        self.assertEqual(got["entitlementPeriods"]["count"], 2)

    def test_group_children_are_relative_to_the_occurrence(self):
        got = {e["path"]: e for e in walk_paths(self.CASE)}
        child = got["entitlementPeriods[].startDate"]
        self.assertEqual(child["group"], "entitlementPeriods")
        self.assertEqual(child["field"], "startDate")   # not the full path
        self.assertEqual(child["value"], "2019-01-01")  # sample from row 0

    def test_scalar_list_is_a_leaf(self):
        got = {e["path"]: e for e in walk_paths(self.CASE)}
        self.assertEqual(got["flags"]["kind"], "leaf")
        self.assertEqual(got["flags"]["value"], "X, Y")

    def test_empty_and_non_dict_input(self):
        self.assertEqual(walk_paths({}), [])
        self.assertEqual(walk_paths([1, 2]), [])


if __name__ == "__main__":
    unittest.main()
