"""First-real-corpus findings, pinned: domain values must not become
exceptions, paragraph names must not become alerts, dismissed codes stay
dismissed through re-ingest, and an application can be deleted."""
import tempfile
import threading
import unittest
import urllib.parse
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

from chatbis import db
from chatbis.ingest import ingest_paths
from chatbis.mine import classify_message, looks_like_code
from chatbis.server import Handler, corpus_generation

MEMBER = """\
       IDENTIFICATION DIVISION.
       PROGRAM-ID. HYG01.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-STATE-CD             PIC X(02).
       01  WS-CLM-STAT             PIC X(02).
       01  WS-ERROR-CODE           PIC X(05).
       PROCEDURE DIVISION.
       MAIN.
           MOVE 'VA' TO WS-STATE-CD
           MOVE 'AC' TO WS-CLM-STAT
           IF WS-STATE-CD = SPACES
               MOVE 'E9410' TO WS-ERROR-CODE
           END-IF
           DISPLAY 'B301-READ COMPLETE'
           DISPLAY 'WARNING - BLANK STATE BYPASSED'
           GOBACK.
"""


class MinerHygiene(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.db_path = str(Path(cls.tmp.name) / "t.db")
        conn = db.connect(cls.db_path)
        aid = db.get_or_create_app(conn, "HYGIENE")
        cls.src = Path(cls.tmp.name) / "HYG01.cbl"
        cls.src.write_text(MEMBER)
        ingest_paths(conn, [cls.src], app_id=aid)
        conn.commit()
        cls.conn = conn
        cls.aid = aid
        Handler.db_path = cls.db_path
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.httpd.server_address[1]
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.conn.close()
        cls.tmp.cleanup()

    def codes(self):
        return {r["code"] for r in self.conn.execute(
            "SELECT code FROM exception_code")}

    def get(self, path):
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}{path}") as r:
            return r.read().decode()

    def post(self, path, data=None):
        req = urllib.request.Request(
            f"http://127.0.0.1:{self.port}{path}",
            data=urllib.parse.urlencode(data or {}).encode())
        with urllib.request.urlopen(req) as r:
            return r.geturl()

    def test_01_domain_values_are_not_exceptions(self):
        got = self.codes()
        self.assertNotIn("VA", got, "a state landed in the catalog")
        self.assertNotIn("AC", got, "a status landed in the catalog")
        self.assertIn("E9410", got, "the real emission must survive")

    def test_02_paragraph_names_are_not_alert_codes(self):
        self.assertIsNone(classify_message("B301-READ COMPLETE"))
        self.assertEqual(classify_message("WARNING - BLANK STATE BYPASSED"),
                         "alert")
        self.assertFalse(looks_like_code("VA"))
        self.assertTrue(looks_like_code("E9410"))

    def test_03_dismiss_hides_and_reingest_does_not_resurrect(self):
        norm = db.normalize_code("E9410")
        self.post(f"/x/{urllib.parse.quote(norm)}/dismiss")
        self.assertNotIn("E9410", self.get("/catalog"))
        self.assertNotIn(">E9410<", self.get(f"/app/{self.aid}"))
        # re-ingest the same member: the dismissal must hold
        ingest_paths(self.conn, [self.src], app_id=self.aid)
        self.conn.commit()
        st = self.conn.execute(
            "SELECT status FROM exception_code WHERE normalized = ?",
            (norm,)).fetchone()["status"]
        self.assertEqual(st, "dismissed")
        # and restore brings it back
        self.post(f"/x/{urllib.parse.quote(norm)}/restore")
        self.assertIn("E9410", self.get("/catalog"))

    def test_04_delete_application_removes_the_mined_world(self):
        g1 = corpus_generation(self.conn)
        self.assertIn("Delete this application", self.get(f"/app/{self.aid}"))
        final = self.post(f"/app/{self.aid}/delete")
        self.assertTrue(final.endswith("/apps"))
        for table, col in (("source_file", "application_id"),
                           ("document", "application_id")):
            n = self.conn.execute(
                f"SELECT COUNT(*) FROM {table} WHERE {col} = ?",
                (self.aid,)).fetchone()[0]
            self.assertEqual(n, 0, table)
        self.assertEqual(self.conn.execute(
            "SELECT COUNT(*) FROM program").fetchone()[0], 0)
        self.assertEqual(self.conn.execute(
            "SELECT COUNT(*) FROM exception_link WHERE target_kind='program'"
            " AND target_ref='HYG01'").fetchone()[0], 0)
        # catalog rows survive deletion — they may be curated knowledge
        self.assertIn("E9410", self.codes())
        self.assertNotEqual(g1, corpus_generation(self.conn),
                            "the readiness cache must invalidate")


class UploadSummaryShapes(unittest.TestCase):
    """Every ingester returns its own result shape; the upload results
    page must render all of them. A BMS upload crashed it with
    KeyError: 'encoding' — after the ingest had already committed."""

    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.db_path = str(Path(cls.tmp.name) / "t.db")
        conn = db.connect(cls.db_path)
        cls.aid = db.get_or_create_app(conn, "SHAPES")
        conn.commit()
        conn.close()
        Handler.db_path = cls.db_path
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.httpd.server_address[1]
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.tmp.cleanup()

    def upload(self, fname, payload):
        boundary = "XxShapeBoundaryxX"
        body = (f"--{boundary}\r\nContent-Disposition: form-data; "
                f"name=\"files\"; filename=\"{fname}\"\r\n"
                f"Content-Type: application/octet-stream\r\n\r\n"
                ).encode() + payload + f"\r\n--{boundary}--\r\n".encode()
        req = urllib.request.Request(
            f"http://127.0.0.1:{self.port}/app/{self.aid}/upload",
            data=body,
            headers={"Content-Type":
                     f"multipart/form-data; boundary={boundary}"})
        with urllib.request.urlopen(req) as r:
            return r.status, r.read().decode()

    def test_bms_upload_renders_its_result(self):
        bms = (b"TSTSET   DFHMSD TYPE=&SYSPARM,MODE=INOUT,LANG=COBOL\n"
               b"TSTMAP   DFHMDI SIZE=(24,80),LINE=1,COLUMN=1\n"
               b"FLD1     DFHMDF POS=(3,9),LENGTH=9,ATTRB=(UNPROT)\n"
               b"         DFHMSD TYPE=FINAL\n         END\n")
        status, html = self.upload("TSTSET.bms", bms)
        self.assertEqual(status, 200)
        self.assertIn("mapset", html)

    def test_jcl_upload_renders_its_result(self):
        jcl = (b"//TSTJOB   JOB (ACCT),'T'\n"
               b"//STEP010  EXEC PGM=TSTPGM\n"
               b"//SYSOUT   DD SYSOUT=*\n")
        status, html = self.upload("TSTJOB.jcl", jcl)
        self.assertEqual(status, 200)
        self.assertIn("steps", html)


class WindowsRunnerDiscovery(unittest.TestCase):
    def test_exe_is_found_when_it_is_what_exists(self):
        # Windows cargo builds cobrun.exe; the bare-name lookup missed it
        # and Windows installs silently had no runner.
        with tempfile.TemporaryDirectory() as t:
            (Path(t) / "cobrun/target/release").mkdir(parents=True)
            (Path(t) / "cobrun/target/release/cobrun.exe").write_bytes(b"MZ")
            h = Handler.__new__(Handler)
            h.db_path = str(Path(t) / "chatbis.db")
            found = h._cobrun_binary()
            self.assertIsNotNone(found)
            self.assertTrue(found.endswith("cobrun.exe"))


if __name__ == "__main__":
    unittest.main()
