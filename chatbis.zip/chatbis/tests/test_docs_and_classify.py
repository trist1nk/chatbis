"""Classification and document invariants: DISPLAY messages bucket into
alert/limitation (limitation wins), synthetic finding codes are stable
across re-ingest, DFR sections split on md/numbered/ALL-CAPS headings,
explicit code mentions link, and .docx extracts via stdlib zipfile."""
import io
import sys
import unittest
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from chatbis.docs import extract_docx, find_code_mentions, split_sections
from chatbis.mine import classify_message, finding_code, mine, normalize_lines


def prep(src: str):
    lines = src.strip("\n").split("\n")
    return normalize_lines(lines, "free")


class TestClassify(unittest.TestCase):
    def test_limitation_beats_alert(self):
        self.assertEqual(classify_message("WARNING - BENE TABLE FULL"), "limitation")
        self.assertEqual(classify_message("RECORD COUNT EXCEEDS MAXIMUM"), "limitation")

    def test_alert(self):
        self.assertEqual(classify_message("WARNING - BLANK BENE ID BYPASSED"), "alert")

    def test_code_in_message_is_alert(self):
        self.assertEqual(classify_message("REJECTED WITH E4417"), "alert")

    def test_plain_trace_is_noise(self):
        self.assertIsNone(classify_message("ENTERING MAIN-PARA"))

    def test_finding_code_stable_and_distinct(self):
        a = finding_code("BENELOAD", "limitation", "BENE TABLE  FULL")
        b = finding_code("BENELOAD", "limitation", "bene table full")
        self.assertEqual(a, b)  # whitespace/case-insensitive → survives re-ingest
        self.assertTrue(a.startswith("LIM-"))
        self.assertNotEqual(a, finding_code("OTHERPRG", "limitation", "BENE TABLE FULL"))

    def test_mine_collects_classified_messages_only(self):
        res = mine(prep("""
       PROCEDURE DIVISION.
       P1.
           DISPLAY 'ENTERING P1'
           DISPLAY 'BENE TABLE FULL - RECORDS SKIPPED'
           DISPLAY 'WARNING - BLANK ID BYPASSED'.
"""))
        cats = sorted(m.category for m in res.messages)
        self.assertEqual(cats, ["alert", "limitation"])


class TestDocs(unittest.TestCase):
    MD = """# Title

intro text

## 3.1 Beneficiary date of birth
Rejected with exception E4417 on screen PS220.

VALIDATION RULES
The premium must be numeric (E4102).
"""

    def test_split_sections(self):
        secs = split_sections(self.MD)
        headings = [h for h, _ in secs]
        self.assertIn("3.1 Beneficiary date of birth", headings)
        self.assertIn("Validation Rules", headings)  # ALL-CAPS line titled

    def test_find_code_mentions(self):
        body = dict(split_sections(self.MD))["3.1 Beneficiary date of birth"]
        self.assertIn("4417", find_code_mentions(body, {}))

    def test_known_codes_match_without_pattern(self):
        found = find_code_mentions("see ABC failure note", {"ABC": "ABC"})
        self.assertIn("ABC", found)

    def test_docx_extraction(self):
        doc_xml = (
            '<?xml version="1.0"?>'
            '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
            "<w:body>"
            '<w:p><w:pPr><w:pStyle w:val="Heading1"/></w:pPr>'
            "<w:r><w:t>Rules</w:t></w:r></w:p>"
            "<w:p><w:r><w:t>Exception E4417 applies.</w:t></w:r></w:p>"
            "</w:body></w:document>"
        )
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as zf:
            zf.writestr("word/document.xml", doc_xml)
        text = extract_docx(buf.getvalue())
        self.assertIn("# Rules", text)
        self.assertIn("E4417", text)


if __name__ == "__main__":
    unittest.main()
