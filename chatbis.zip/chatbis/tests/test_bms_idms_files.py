"""BMS mapset parsing, IDMS DML mining, and file I-O mining.

Honesty invariants: unlabeled BMS fields are screen constants, not fields;
IDMS matching never fires inside EXEC blocks; a file's dataset name comes
only from a mined JCL DD binding, never from the DDNAME's looks.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from chatbis.bms import looks_like_bms, parse_bms
from chatbis.mine import mine, normalize_lines

BMS = (Path(__file__).resolve().parent.parent
       / "content/t2-test/online/PS220S.bms").read_text()

PROC = """       IDENTIFICATION DIVISION.
       PROGRAM-ID. T1.
       PROCEDURE DIVISION.
       MAIN.
"""


class TestBms(unittest.TestCase):
    def test_sniff(self):
        self.assertTrue(looks_like_bms(BMS))
        self.assertFalse(looks_like_bms("       IDENTIFICATION DIVISION."))

    def test_mapset_map_fields(self):
        ms = parse_bms(BMS)
        self.assertEqual(ms.name, "PS220S")
        self.assertEqual([m.name for m in ms.maps], ["PS220M"])
        named = {f.name: f for f in ms.maps[0].fields if f.name}
        self.assertEqual(set(named), {"SSNIN", "BENEDOB", "EFFDATE", "ERRMSG"})
        self.assertEqual((named["BENEDOB"].row, named["BENEDOB"].col,
                          named["BENEDOB"].length), (5, 14, 8))

    def test_constants_have_no_name(self):
        ms = parse_bms(BMS)
        consts = [f for f in ms.maps[0].fields if not f.name]
        self.assertTrue(any(f.initial == "BENE DOB:" for f in consts))

    def test_continuation_joins(self):
        # The DFHMSD card continues over two lines; it must not produce a
        # phantom map or field.
        ms = parse_bms(BMS)
        self.assertEqual(len(ms.maps), 1)


class TestGreenScreen(unittest.TestCase):
    """The 3270 preview must be emulator-accurate where it claims to be:
    text one column after the attribute byte, underscores only for
    unprotected input, bright only for BRT."""

    def fields(self):
        ms = parse_bms(BMS)
        return [{"pos_row": f.row, "pos_col": f.col, "length": f.length,
                 "initial": f.initial, "name": f.name, "attrb": f.attrb}
                for f in ms.maps[0].fields]

    def test_attrb_mined(self):
        named = {f["name"]: f["attrb"] for f in self.fields() if f["name"]}
        self.assertEqual(named["BENEDOB"], "UNPROT,NUM")
        self.assertEqual(named["ERRMSG"], "ASKIP,BRT")

    def test_render_positions_and_styles(self):
        from chatbis.server import render_bms_screen
        html = render_bms_screen(self.fields())
        # Title: POS=(1,30) = attribute byte at col 30, text at col 31 —
        # which is left:30ch zero-based. BRT renders bright.
        self.assertIn("left:30ch;top:0.0em;'>DATE CORRECTIONS", html)
        self.assertIn("class='g3f bright'", html)
        # BENEDOB: unprotected input, 8 underscores at (5,14)+1 = 14ch.
        self.assertIn("left:14ch;top:5.8em;'>________", html)
        self.assertIn("class='g3f inp'", html)
        # Protected output with no initial shows nothing visible.
        self.assertNotIn("ERRMSG", html)
        # SSNIN carries IC: the initial cursor block sits on its first byte.
        self.assertIn("class='g3f cursor' style='left:8ch;top:2.9em'>▌", html)


class TestCongestedMapset(unittest.TestCase):
    """PS310S exercises the full option set: composite maps, COLOR,
    HILIGHT, DRK, IC, OCCURS — and in-string column-72 continuation."""

    MS = parse_bms((Path(__file__).resolve().parent.parent
                    / "content/t2-test/online/PS310S.bms").read_text())

    def test_three_maps_with_placement(self):
        self.assertEqual([(m.name, m.line) for m in self.MS.maps],
                         [("HDR310", 1), ("BDY310", 3), ("FTR310", 22)])

    def test_instring_col72_continuation(self):
        # The separator's INITIAL spans a column-72 continuation INSIDE the
        # quoted string — the trailing-comma heuristic could never join it.
        sep = [f for f in self.MS.maps[0].fields if f.row == 2][0]
        self.assertEqual(len(sep.initial), 79)
        self.assertEqual(set(sep.initial), {"-"})

    def test_extended_attributes_mined(self):
        body = {f.name: f for f in self.MS.maps[1].fields if f.name}
        self.assertEqual(body["POLSTAT"].hilight, "REVERSE")
        self.assertEqual(body["POLSTAT"].color, "YELLOW")
        self.assertEqual(body["BENEDOB"].hilight, "UNDERLINE")
        self.assertIn("DRK", body["AUTHCD"].attrb)
        self.assertIn("IC", body["POLNO"].attrb)
        self.assertEqual(body["MOPREM"].occurs, 6)

    def test_render_honours_the_options(self):
        from chatbis.server import render_bms_screen
        flds = [{"pos_row": f.row, "pos_col": f.col, "length": f.length,
                 "initial": f.initial, "name": f.name, "attrb": f.attrb,
                 "color": f.color, "hilight": f.hilight, "occurs": f.occurs,
                 "map_line": m.line, "map_col": m.column}
                for m in self.MS.maps for f in m.fields]
        html = render_bms_screen(flds)
        self.assertIn("background:#ffd75e", html)          # REVERSE in yellow
        self.assertNotIn("AUTHCD", html)                   # DRK: non-display
        self.assertEqual(html.count(">_________<"), 6)     # OCCURS=6 inputs
        self.assertIn("g3f cursor", html)                  # IC cursor drawn
        # FTR310 at LINE=22: its PF line (map row 2) lands on screen row 23.
        self.assertIn(f"top:{22 * 1.45}em", html)


class TestIdms(unittest.TestCase):
    def test_verbs_records_and_sets(self):
        r = mine(normalize_lines((PROC + """           OBTAIN CALC CLAIM-REC
           MODIFY CLAIM-REC
           FIND OWNER WITHIN BENE-CLAIM-SET
           STORE PAYMENT-REC
           ERASE AUDIT-REC""").split("\n"), "free"))
        got = [(i.op, i.record, i.qualifier, i.set_name) for i in r.idms]
        self.assertIn(("obtain", "CLAIM-REC", "CALC", None), got)
        self.assertIn(("modify", "CLAIM-REC", None, None), got)
        self.assertIn(("store", "PAYMENT-REC", None, None), got)

    def test_exec_blocks_are_not_idms(self):
        r = mine(normalize_lines((PROC +
            "           EXEC SQL UPDATE T SET A = :B WHERE ID = :C END-EXEC"
            ).split("\n"), "free"))
        self.assertEqual(r.idms, [])

    def test_unhyphenated_word_is_not_a_record(self):
        # "FIND X" where X has no hyphen is far more likely English in a
        # DISPLAY or comment fragment than an IDMS record.
        r = mine(normalize_lines((PROC + "           STORE RESULT").split("\n"),
                                 "free"))
        self.assertEqual(r.idms, [])


class TestFiles(unittest.TestCase):
    SRC = """       IDENTIFICATION DIVISION.
       PROGRAM-ID. FWRITE.
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT SUSP-FILE ASSIGN TO REJECTS
               ORGANIZATION IS INDEXED.
       DATA DIVISION.
       FILE SECTION.
       FD  SUSP-FILE.
       01  SUSP-RECORD                 PIC X(200).
       PROCEDURE DIVISION.
       MAIN.
           OPEN OUTPUT SUSP-FILE
           WRITE SUSP-RECORD FROM WS-WORK-REC
           GOBACK.
"""

    def test_select_assign_org_and_ops(self):
        r = mine(normalize_lines(self.SRC.split("\n"), "free"))
        self.assertEqual(len(r.files), 1)
        f = r.files[0]
        self.assertEqual((f.logical, f.ddname, f.org),
                         ("SUSP-FILE", "REJECTS", "INDEXED"))
        ops = {o["op"] for o in f.ops}
        self.assertIn("open-output", ops)
        self.assertIn("write", ops)

    def test_write_from_is_a_flow_edge(self):
        r = mine(normalize_lines(self.SRC.split("\n"), "free"))
        self.assertIn(("WS-WORK-REC", "SUSP-RECORD", "write"),
                      [(e.source, e.target, e.verb) for e in r.flows])

    def test_read_into_is_a_flow_edge(self):
        src = self.SRC.replace("OPEN OUTPUT SUSP-FILE",
                               "OPEN INPUT SUSP-FILE") \
                      .replace("WRITE SUSP-RECORD FROM WS-WORK-REC",
                               "READ SUSP-FILE INTO WS-IN-REC")
        r = mine(normalize_lines(src.split("\n"), "free"))
        self.assertIn(("SUSP-FILE", "WS-IN-REC", "read"),
                      [(e.source, e.target, e.verb) for e in r.flows])


if __name__ == "__main__":
    unittest.main()
