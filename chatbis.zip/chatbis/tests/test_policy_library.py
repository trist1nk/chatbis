"""The policy library: global scope, semantic kinds, PDF ingestion — and
the boundary between policy (reference) and DFRs (application evidence)."""
import io
import tempfile
import threading
import unittest
import urllib.parse
import urllib.request
import zlib
from http.server import ThreadingHTTPServer
from pathlib import Path

from chatbis import db
from chatbis.ingest import ingest_paths, looks_like_policy
from chatbis.pdftext import extract_pdf_text
from chatbis.server import Handler


def make_pdf(text_ops: bytes) -> bytes:
    flate = zlib.compress(text_ops)
    return (b"%PDF-1.4\n1 0 obj\n<< /Length " + str(len(flate)).encode()
            + b" /Filter /FlateDecode >>\nstream\n" + flate
            + b"\nendstream\nendobj\ntrailer\n<<>>\n%%EOF")


POLICY_PDF = make_pdf(
    b"BT (RS 00605.362 Entitlement Date Rules) Tj "
    b"0 -14 Td (When code E5510 is raised, section 4.2.1 applies.) Tj "
    b"0 -14 Td (See RS 00605.370 and GN 00204.007 for exceptions.) Tj ET")


class PdfExtraction(unittest.TestCase):
    def test_flate_tj_hex_and_arrays(self):
        pdf = make_pdf(b"BT (Alpha ) Tj [(Be) -30 (ta)] TJ "
                       b"0 -14 Td <47616D6D61> Tj ET")
        t = extract_pdf_text(pdf)
        self.assertIn("Alpha Beta", t)
        self.assertIn("Gamma", t)

    def test_scan_refused_by_name(self):
        with self.assertRaises(ValueError) as cm:
            extract_pdf_text(b"%PDF-1.4\n%%EOF")
        self.assertIn("no text layer", str(cm.exception))

    def test_not_a_pdf_refused(self):
        with self.assertRaises(ValueError):
            extract_pdf_text(b"PK\x03\x04 zip bytes")


class PolicyLibrary(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.db_path = str(Path(cls.tmp.name) / "t.db")
        conn = db.connect(cls.db_path)
        cls.aid = db.get_or_create_app(conn, "REALAPP")
        # a known code so the policy PDF's mention links
        db.upsert_exception(conn, "E5510", meaning="Entitlement precedes DOB",
                            status="curated")
        conn.commit()
        cls.conn = conn
        Handler.db_path = cls.db_path
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.httpd.server_address[1]
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.conn.close()
        cls.tmp.cleanup()

    def get(self, path):
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}{path}") as r:
            return r.read().decode()

    def upload_policy(self, fname, payload):
        boundary = "XxPolicyBoundaryxX"
        body = (f"--{boundary}\r\nContent-Disposition: form-data; "
                f"name=\"files\"; filename=\"{fname}\"\r\n"
                f"Content-Type: application/octet-stream\r\n\r\n"
                ).encode() + payload + f"\r\n--{boundary}--\r\n".encode()
        req = urllib.request.Request(
            f"http://127.0.0.1:{self.port}/policy/upload", data=body,
            headers={"Content-Type":
                     f"multipart/form-data; boundary={boundary}"})
        with urllib.request.urlopen(req) as r:
            return r.read().decode()

    def test_01_pdf_policy_ingests_globally_and_links_codes(self):
        html = self.upload_policy("entitlement-policy.pdf", POLICY_PDF)
        self.assertIn("1 policy document ingested", html)
        d = self.conn.execute(
            "SELECT * FROM document WHERE title LIKE '%Entitlement Policy%'"
        ).fetchone()
        self.assertEqual(d["kind"], "policy")
        self.assertIsNone(d["application_id"])       # global, by definition
        # the section that names E5510 linked to the catalog
        n = self.conn.execute(
            """SELECT COUNT(*) FROM exception_link l
               JOIN exception_code e ON e.id = l.exception_id
               WHERE e.normalized = ? AND l.target_kind = 'document'""",
            (db.normalize_code("E5510"),)).fetchone()[0]
        self.assertGreater(n, 0)
        # and the code page labels it POLICY, not DFR
        page = self.get(f"/x/{db.normalize_code('E5510')}")
        self.assertIn("POLICY", page)
        self.assertIn("Read the policy", page)

    def test_02_policy_stays_out_of_the_app_dfr_list(self):
        html = self.get(f"/app/{self.aid}")
        self.assertNotIn("Entitlement Policy", html)

    def test_03_scan_pdf_refused_with_the_reason_shown(self):
        html = self.upload_policy("scanned.pdf", b"%PDF-1.4\n%%EOF")
        self.assertIn("no text layer", html)

    def test_04_suggestion_fires_on_policy_shaped_text(self):
        self.assertTrue(looks_like_policy(
            "quarterly update", "see RS 00605.362, GN 00204.007 and "
            "RS 00605.370 for details"))
        self.assertTrue(looks_like_policy("Retirement POLICY extract", ""))
        self.assertFalse(looks_like_policy(
            "DFR 2311", "the fix corrected the field and reran the job"))

    def test_05_reclassify_round_trip(self):
        d = self.conn.execute(
            "SELECT id FROM document WHERE COALESCE(kind,'dfr')='policy'"
        ).fetchone()
        data = urllib.parse.urlencode(
            {"id": d["id"], "kind": "dfr",
             "application_id": self.aid}).encode()
        urllib.request.urlopen(urllib.request.Request(
            f"http://127.0.0.1:{self.port}/doc/kind", data=data)).read()
        row = self.conn.execute("SELECT kind, application_id FROM document"
                                " WHERE id = ?", (d["id"],)).fetchone()
        self.assertEqual((row["kind"], row["application_id"]),
                         ("dfr", self.aid))
        data = urllib.parse.urlencode(
            {"id": d["id"], "kind": "policy"}).encode()
        urllib.request.urlopen(urllib.request.Request(
            f"http://127.0.0.1:{self.port}/doc/kind", data=data)).read()
        row = self.conn.execute("SELECT kind, application_id FROM document"
                                " WHERE id = ?", (d["id"],)).fetchone()
        self.assertEqual((row["kind"], row["application_id"]),
                         ("policy", None))

    def test_06_policy_search(self):
        html = self.get("/policy?q=" + urllib.parse.quote("Entitlement"))
        self.assertIn("match", html)


class ProseMentions(unittest.TestCase):
    """The letter-chip defect, pinned: one-character catalog codes must
    never be 'mentioned' by prose, and matches are whole-token only."""

    def test_short_codes_are_not_prose_detectable(self):
        from chatbis.docs import find_code_mentions
        known = {"I": "I", "A": "A", "804": "U804"}
        text = "A claimant Is entitled when U804 clears. I agree."
        got = find_code_mentions(text, known)
        self.assertIn("804", got)
        self.assertNotIn("I", got)
        self.assertNotIn("A", got)

    def test_no_substring_matches(self):
        from chatbis.docs import find_code_mentions
        known = {"REC": "REC", "804": "U804"}
        got = find_code_mentions("the RECORD holds XU804Y data", known)
        self.assertEqual(got, set())

    def test_startup_cleanup_removes_the_bogus_links(self):
        import tempfile
        from chatbis import db as _db
        with tempfile.TemporaryDirectory() as t:
            c = _db.connect(str(Path(t) / "x.db"))
            short_id = _db.upsert_exception(c, "I")
            long_id = _db.upsert_exception(c, "U804")
            for eid in (short_id, long_id):
                _db.add_link(c, eid, "document", "1", "governed_by",
                             detail={"doc_id": 1}, provenance="mined")
            _db.add_link(c, short_id, "document", "1", "governed_by",
                         detail={"doc_id": 1, "citation": "manual"},
                         provenance="sme")
            c.commit()
            c.close()
            c2 = _db.connect(str(Path(t) / "x.db"))
            _db.maintain(c2)                    # boot-time maintenance
            rows = c2.execute(
                """SELECT e.code, l.provenance FROM exception_link l
                   JOIN exception_code e ON e.id = l.exception_id
                   WHERE l.relation='governed_by' ORDER BY e.code"""
            ).fetchall()
            got = {(r["code"], r["provenance"]) for r in rows}
            self.assertIn(("U804", "mined"), got)     # real evidence stays
            self.assertIn(("I", "sme"), got)          # SME links untouched
            self.assertNotIn(("I", "mined"), got)     # the defect rows go


class DocumentFormats(unittest.TestCase):
    """Real DFRs arrive as whatever the shop's tooling emits — RTF, HTML
    exports, extensionless mainframe dumps, legacy .doc. Ingest what is
    honestly text; name what is refused."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.conn = db.connect(str(Path(self.tmp.name) / "t.db"))
        self.aid = db.get_or_create_app(self.conn, "FMT")

    def tearDown(self):
        self.conn.close()
        self.tmp.cleanup()

    def ingest(self, name, payload):
        p = Path(self.tmp.name) / name
        p.write_bytes(payload)
        out = ingest_paths(self.conn, [p], app_id=self.aid)
        self.conn.commit()
        return out[0]

    def test_rtf_ingests_as_document(self):
        r = self.ingest("dfr-2411.rtf",
                        rb"{\rtf1\ansi DFR 2411 \par fixed E4417\par}")
        self.assertEqual(r.get("type"), "rtf")
        self.assertGreater(r.get("sections", 0), 0)

    def test_html_ingests_as_document(self):
        r = self.ingest("dfr-2412.html",
                        b"<html><body><h1>DFR 2412</h1><p>rebuilt</p>"
                        b"</body></html>")
        self.assertEqual(r.get("type"), "html")

    def test_unknown_extension_text_is_salvaged_as_a_document(self):
        # extensionless files route to the COBOL miner by design (raw PDS
        # member dumps) — the salvage path is for unknown EXTENSIONS.
        payload = ("DFR 2413" + chr(10)
                   + "The weeder rejected the record." + chr(10)
                   + "Resolution: corrected the DOB and reran." + chr(10))
        r = self.ingest("DFR2413.dat", payload.encode())
        self.assertEqual(r.get("kind"), "document")
        self.assertGreater(r.get("sections", 0), 0)

    def test_legacy_doc_refused_with_the_fix_named(self):
        ole = bytes([0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1])
        r = self.ingest("dfr-2414.doc", ole + bytes(64))
        self.assertIn("Save As .docx", r.get("skipped", ""))

    def test_true_binary_still_skipped_naming_the_extension(self):
        r = self.ingest("mystery.bin", bytes(range(256)) * 8)
        self.assertIn(".bin", r.get("skipped", ""))


if __name__ == "__main__":
    unittest.main()
