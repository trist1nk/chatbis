"""A check must read back as a sentence the analyst can check at a glance.

The subtle one: `$.x` means "this occurrence" ONLY inside a repeating group.
At case level the engine resolves it against the case root, so the sentence
must not claim "the same row" when there is no row.
"""
import re
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from chatbis.server import readback


def plain(html: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", html)).strip()


class TestReadback(unittest.TestCase):
    def test_case_level_literal(self):
        self.assertEqual(
            plain(readback({"path": "claim.claimType", "op": "eq", "value": "RIB"})),
            "claim.claimType is RIB")

    def test_case_reference(self):
        s = plain(readback({"path": "claimant.dateOfBirth", "op": "gt",
                            "value": "$$.claim.entitlementDate"}))
        self.assertEqual(s, "claimant.dateOfBirth is greater than / after "
                            "the case's claim.entitlementDate")

    def test_same_row_reference_inside_a_group(self):
        s = plain(readback({"group": "entitlementPeriods", "scope": "latest",
                            "path": "endDate", "op": "lt", "value": "$.startDate"}))
        self.assertEqual(s, "In the latest entitlementPeriods, endDate is less "
                            "than / before the same row's startDate")

    def test_dollar_ref_outside_a_group_is_not_a_row(self):
        s = plain(readback({"path": "a", "op": "eq", "value": "$.b"}))
        self.assertIn("the case's b", s)
        self.assertNotIn("same row", s)

    def test_non_latest_scope_is_named(self):
        s = plain(readback({"group": "payments", "scope": "any", "path": "status",
                            "op": "eq", "value": "SUSPENDED"}))
        self.assertTrue(s.startswith("In any payments, status is SUSPENDED"), s)

    def test_unary_ops_drop_the_value(self):
        s = plain(readback({"path": "beneficiaryId", "op": "blank", "value": "x"}))
        self.assertEqual(s, "beneficiaryId is blank")

    def test_html_is_escaped(self):
        out = readback({"path": "<script>", "op": "eq", "value": "y"})
        self.assertNotIn("<script>", out)


if __name__ == "__main__":
    unittest.main()
