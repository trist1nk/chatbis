"""Pipelines are configuration, not code: applications carry pipeline /
stage_seq / role / reads / writes, and the screens render whatever flow the
rows describe.

Guards three behaviours:
  - creation places apps (standalone / existing pipeline / new pipeline),
    auto-appending stage_seq so analysts never hand-number stages;
  - the Applications screen orders stages by seq and draws the written data
    areas as the seams;
  - the Lab strip infers an exception's stage through its emitted_by program
    and shows NOTHING for apps outside a pipeline — the strip is earned by
    configuration, never faked.
"""
import sqlite3
import sys
import tempfile
import threading
import unittest
import urllib.parse
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from chatbis import db
from chatbis.server import Handler


class PipelineFlow(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.db_path = str(Path(cls.tmp.name) / "t.db")
        conn = db.connect(cls.db_path)
        # A mined program inside WEEDER so the Lab strip has an exception to
        # place: E7777 emitted_by WEEDCHK.
        aid = db.get_or_create_app(conn, "WEEDER")
        conn.execute(
            "INSERT INTO source_file (application_id, path, name, kind,"
            " encoding, fmt, line_count, content_hash, ingested_at)"
            " VALUES (?,?,?,?,?,?,?,?,?)",
            (aid, "/x/weedchk.cbl", "weedchk.cbl", "cobol",
             "utf-8", "fixed", 100, "x", db.now()))
        fid = conn.execute("SELECT id FROM source_file").fetchone()["id"]
        conn.execute("INSERT INTO program (source_file_id, name) VALUES (?,?)",
                     (fid, "WEEDCHK"))
        eid = db.upsert_exception(conn, "E7777", category="exception",
                                  meaning="Weeder rejects the record")
        db.add_link(conn, eid, "program", "WEEDCHK", "emitted_by",
                    detail={"condition": "IF WS-X = SPACES"})
        lone = db.upsert_exception(conn, "E8888", category="exception")
        conn.commit()
        conn.close()

        Handler.db_path = cls.db_path
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.httpd.server_address[1]
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.tmp.cleanup()

    def get(self, path):
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}{path}") as r:
            return r.read().decode()

    def post(self, path, data):
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}{path}",
                urllib.parse.urlencode(data).encode()) as r:
            return r.read().decode()

    def app(self, name):
        c = sqlite3.connect(self.db_path)
        c.row_factory = sqlite3.Row
        r = c.execute("SELECT * FROM application WHERE name = ?", (name,)).fetchone()
        c.close()
        return r

    def test_01_create_into_a_new_pipeline(self):
        self.post("/apps/create", {
            "name": "INFRASTRUCTURE", "description": "builds the TDA",
            "pipeline": "__new__", "new_pipeline": "T2 NIGHTLY",
            "stage_role": "builds", "stage_seq": "", "reads": "",
            "writes": "tda"})
        r = self.app("INFRASTRUCTURE")
        self.assertEqual(r["pipeline"], "T2 NIGHTLY")
        self.assertEqual(r["stage_seq"], 10)          # auto: first stage
        self.assertEqual(r["writes"], '["TDA"]')      # upcased, JSON array

    def test_02_add_to_existing_pipeline_appends(self):
        self.post("/apps/create", {
            "name": "EVENT-ANALYZER", "pipeline": "T2 NIGHTLY",
            "stage_role": "analyzes", "stage_seq": "",
            "reads": "TDA", "writes": "TDA"})
        self.assertEqual(self.app("EVENT-ANALYZER")["stage_seq"], 20)

    def test_03_standalone_create_is_untouched(self):
        self.post("/apps/create", {"name": "UTILS", "pipeline": ""})
        r = self.app("UTILS")
        self.assertIsNone(r["pipeline"])
        self.assertIsNone(r["stage_seq"])

    def test_04_existing_app_joins_via_placement(self):
        aid = self.app("WEEDER")["id"]
        self.post(f"/app/{aid}/pipeline", {
            "pipeline": "T2 NIGHTLY", "stage_role": "validates",
            "stage_seq": "", "reads": "TDA", "writes": ""})
        r = self.app("WEEDER")
        self.assertEqual(r["pipeline"], "T2 NIGHTLY")
        self.assertEqual(r["stage_seq"], 30)

    def test_05_apps_screen_draws_the_diagram_in_order(self):
        html = self.get("/apps")
        self.assertIn("T2 NIGHTLY", html)
        self.assertIn("<svg viewBox", html)           # a real diagram now
        i = html.index("INFRASTRUCTURE")
        j = html.index("EVENT-ANALYZER")
        k = html.index(">WEEDER<")
        self.assertTrue(i < j < k)                    # seq order, not name order
        self.assertIn(">TDA</text>", html)            # the data-area shape
        self.assertIn("marker-end='url(#arr)'", html) # real arrows
        self.assertIn("Standalone applications", html)
        self.assertIn("UTILS", html)

    def test_06_lab_strip_places_the_exception(self):
        html = self.get("/lab/edit?code=7777")
        self.assertIn("Raised at <b>WEEDER</b>", html)
        self.assertIn("stage 3 of 3", html)
        self.assertIn("upstream stages already ran", html)
        self.assertIn("pstage hit", html)             # the failing stage is marked

    def test_07_no_pipeline_no_strip(self):
        html = self.get("/lab/edit?code=8888")
        self.assertNotIn("Raised at", html)

    def test_08_app_detail_shows_stage_and_neighbours(self):
        aid = self.app("EVENT-ANALYZER")["id"]
        html = self.get(f"/app/{aid}")
        self.assertIn("stage 2 of 3", html)
        self.assertIn("INFRASTRUCTURE", html)         # ← neighbour link
        self.assertIn("WEEDER", html)                 # → neighbour link

    def test_09_leaving_the_pipeline_clears_placement(self):
        aid = self.app("UTILS")["id"]
        self.post(f"/app/{aid}/pipeline",
                  {"pipeline": "T2 NIGHTLY", "stage_seq": "", "stage_role": "",
                   "reads": "", "writes": ""})
        self.assertEqual(self.app("UTILS")["pipeline"], "T2 NIGHTLY")
        self.post(f"/app/{aid}/pipeline",
                  {"pipeline": "", "stage_seq": "99", "stage_role": "builds",
                   "reads": "TDA", "writes": "TDA"})
        r = self.app("UTILS")
        self.assertIsNone(r["pipeline"])
        self.assertIsNone(r["stage_seq"])             # no orphaned stage data


if __name__ == "__main__":
    unittest.main()
