"""The Screen lab: raw BMS in, the same render the miner produces out —
including honest parse errors."""
import tempfile
import threading
import unittest
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

from chatbis import db
from chatbis.ingest import ingest_paths
from chatbis.server import Handler

# NB: every line must stay within column 71 — a longer line puts a
# character in col 72, which the column-72 rule faithfully reads as
# "the next line is a continuation" and swallows the following field.
# The first draft of this fixture made exactly that mistake.
BMS = (b"LABSET   DFHMSD TYPE=&SYSPARM,MODE=INOUT,LANG=COBOL\n"
       b"LABMAP   DFHMDI SIZE=(24,80),LINE=1,COLUMN=1\n"
       b"         DFHMDF POS=(1,30),LENGTH=10,ATTRB=ASKIP,"
       b"INITIAL='LAB TITLE'\n"
       b"FLD1     DFHMDF POS=(3,9),LENGTH=9,ATTRB=(UNPROT,IC)\n"
       b"         DFHMSD TYPE=FINAL\n         END\n")


class ScreenLab(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.db_path = str(Path(cls.tmp.name) / "t.db")
        conn = db.connect(cls.db_path)
        aid = db.get_or_create_app(conn, "LAB")
        p = Path(cls.tmp.name) / "LABSET.bms"
        p.write_bytes(BMS)
        ingest_paths(conn, [p], app_id=aid)
        conn.commit()
        cls.fid = conn.execute(
            "SELECT id FROM source_file WHERE kind='bms'").fetchone()["id"]
        conn.close()
        Handler.db_path = cls.db_path
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.httpd.server_address[1]
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.tmp.cleanup()

    def preview(self, payload: bytes):
        req = urllib.request.Request(
            f"http://127.0.0.1:{self.port}/bms/preview", data=payload)
        with urllib.request.urlopen(req) as r:
            return r.read().decode()

    def test_lab_page_loads_with_the_source(self):
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}/bms/lab?file={self.fid}") as r:
            h = r.read().decode()
        self.assertIn("Screen lab", h)
        self.assertIn("LAB TITLE", h)          # source in the editor
        self.assertIn("/bms/preview", h)

    def test_preview_renders_an_edit(self):
        h = self.preview(BMS.replace(b"LAB TITLE", b"NEW TITLE"))
        self.assertIn("NEW TITLE", h)
        self.assertIn("24", h)                  # size line present

    def test_empty_source_says_so(self):
        h = self.preview(b"LABSET   DFHMSD TYPE=&SYSPARM\n"
                         b"         DFHMSD TYPE=FINAL\n")
        self.assertIn("no DFHMDF fields", h)

    # ── the lint checklist: the rules of the 24×80 board, named by line ──

    def test_clean_source_reports_no_issues(self):
        h = self.preview(BMS)
        self.assertIn("no layout issues", h)
        # marker splits lint from screen so the page can place them apart
        self.assertIn("<!--screen-->", h)

    def test_overlap_names_both_lines_and_the_attribute_byte(self):
        h = self.preview(
            b"LABMAP   DFHMSD TYPE=MAP,MODE=INOUT\n"
            b"LABMAPD  DFHMDI SIZE=(24,80)\n"
            b"         DFHMDF POS=(1,2),LENGTH=10,INITIAL='HELLO'\n"
            b"FLDA     DFHMDF POS=(1,8),LENGTH=6,ATTRB=UNPROT\n")
        self.assertIn("overlaps the field defined at line 3", h)
        self.assertIn("attribute byte", h)

    def test_off_screen_pos_is_an_error(self):
        h = self.preview(
            b"LABMAP   DFHMSD TYPE=MAP,MODE=INOUT\n"
            b"LABMAPD  DFHMDI SIZE=(24,80)\n"
            b"FLDB     DFHMDF POS=(30,5),LENGTH=4\n")
        self.assertIn("off the 24", h)

    def test_initial_longer_than_length_warns_truncation(self):
        h = self.preview(
            b"LABMAP   DFHMSD TYPE=MAP,MODE=INOUT\n"
            b"LABMAPD  DFHMDI SIZE=(24,80)\n"
            b"FLDC     DFHMDF POS=(2,2),LENGTH=4,INITIAL='TOOLONGTEXT'\n")
        self.assertIn("truncates", h)

    def test_lab_page_carries_the_editing_chrome(self):
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}/bms/lab?file={self.fid}") as r:
            h = r.read().decode()
        for piece in ("bmsbar", "data-snip", "gridtog", "lncol", "fsbtn",
                      "fsed", "bmsx", "requestFullscreen", "exitFullscreen",
                      # the workbench: gutter, col-72 ruler, problems
                      # panel, status bar, click-to-jump wiring
                      "id=gut", "rule72", "wbstatus", "probsum",
                      "data-ln"):
            self.assertIn(piece, h)
        # the page body is a Python f-string: a bare \n in its JS
        # compiles to a REAL newline and splits the string literal,
        # killing the whole script (BMS-LAB-002 regression). The served
        # page must carry the two-char escape sequence, verbatim.
        self.assertIn("split('\\n')", h)
        self.assertIn("X\\n", h)              # snippet continuation lines


if __name__ == "__main__":
    unittest.main()
