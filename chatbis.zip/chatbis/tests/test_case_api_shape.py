"""The rails that fetch a case: SSN in the POST body, regions in
headers, and the catalog surfaces that route analysts there.

Synthetic data only — 900-xx SSNs."""
import json
import threading
import unittest
import http.server

from chatbis import db
from chatbis.server import fill_headers, Handler


class HeaderTemplates(unittest.TestCase):
    def test_placeholders_fill_from_analyst_inputs(self):
        h = fill_headers("X-Region: {region}\nAccept-Language: en",
                         {"region": "NE", "ssn": "900041234"})
        self.assertEqual(h, {"X-Region": "NE", "Accept-Language": "en"})

    def test_junk_lines_are_skipped_not_guessed(self):
        h = fill_headers("no colon here\n\n: novalue\nX-Ok: yes", {})
        self.assertEqual(h, {"X-Ok": "yes"})

    def test_empty_spec_is_empty(self):
        self.assertEqual(fill_headers(None, {"a": "b"}), {})
        self.assertEqual(fill_headers("", {}), {})


class _Echo(http.server.BaseHTTPRequestHandler):
    """Echoes method, body, and selected headers back as JSON."""
    def _reply(self):
        length = int(self.headers.get("Content-Length", 0) or 0)
        body = self.rfile.read(length).decode() if length else ""
        out = json.dumps({"method": self.command, "body": body,
                          "region": self.headers.get("X-Region"),
                          "auth": self.headers.get("Authorization")})
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(out.encode())

    do_GET = _reply
    do_POST = _reply

    def log_message(self, *a):
        pass


class CallApi(unittest.TestCase):
    """_call_api against a live local echo server — the SSN travels in
    the POST body, the region travels in a header."""
    @classmethod
    def setUpClass(cls):
        cls.srv = http.server.HTTPServer(("127.0.0.1", 0), _Echo)
        cls.port = cls.srv.server_address[1]
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()

    def call(self, ep, params, body_override=None):
        env = {"base_url": f"http://127.0.0.1:{self.port}",
               "token": "tok-123", "insecure_tls": 0}
        status, text, _, err = Handler._call_api(
            object.__new__(Handler), env, ep, params, body_override)
        self.assertIsNone(err)
        self.assertEqual(status, 200)
        return json.loads(text)

    def test_ssn_fills_into_the_post_body(self):
        ep = {"method": "POST", "path": "/v1/case",
              "body": '{"ssn": "{ssn}", "bic": "{bic}"}', "headers": None}
        got = self.call(ep, {"ssn": "900041234", "bic": "A"})
        self.assertEqual(json.loads(got["body"]),
                         {"ssn": "900041234", "bic": "A"})
        self.assertEqual(got["method"], "POST")

    def test_region_header_fills_and_sends(self):
        ep = {"method": "POST", "path": "/v1/case",
              "body": '{"ssn": "{ssn}"}', "headers": "X-Region: {region}"}
        got = self.call(ep, {"ssn": "900041234", "region": "NE"})
        self.assertEqual(got["region"], "NE")
        self.assertEqual(got["auth"], "Bearer tok-123")

    def test_edited_body_wins_over_the_template(self):
        ep = {"method": "POST", "path": "/v1/case",
              "body": '{"ssn": "{ssn}"}', "headers": None}
        got = self.call(ep, {"ssn": "900041234"},
                        body_override='{"ssn": "{ssn}", "extra": true}')
        self.assertEqual(json.loads(got["body"]),
                         {"ssn": "900041234", "extra": True})


class CatalogSurfaces(unittest.TestCase):
    """The catalog offers every declared category, and 'where' counts
    every module — including set_by modules for indicator codes."""
    @classmethod
    def setUpClass(cls):
        import socket
        import tempfile
        from chatbis.server import serve
        cls.tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        conn = db.connect(cls.tmp.name)
        conn.execute(
            "INSERT INTO api_env (name, base_url, token, insecure_tls,"
            " created_at) VALUES ('SBX', 'http://127.0.0.1:1', 'tok-original',"
            " 0, '2026-01-01')")
        conn.execute(
            "INSERT INTO api_endpoint (name, method, path, body, headers,"
            " created_at) VALUES ('Case by SSN', 'POST', '/v1/case',"
            " '{\"ssn\": \"{ssn}\"}', 'X-Region: {region}', '2026-01-01')")
        cid = db.upsert_exception(conn, "WS-RFD-IND",
                                  category="indicator",
                                  meaning="Refugee indicator")
        for pgm in ("PGMALPHA", "PGMBETA", "PGMGAMMA"):
            db.add_link(conn, cid, "program", pgm, "set_by",
                        confidence=0.9)
        conn.commit()
        conn.close()
        with socket.socket() as s:
            s.bind(("127.0.0.1", 0))
            cls.port = s.getsockname()[1]
        threading.Thread(target=serve, args=(cls.tmp.name, cls.port),
                         daemon=True).start()
        import time
        time.sleep(0.6)

    def get(self, path):
        import urllib.request
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}{path}") as r:
            return r.read().decode()

    def test_every_declared_category_gets_a_tab(self):
        h = self.get("/catalog")
        for cat in ("exceptions", "alerts", "limitations", "suspensions",
                    "terminations", "indicators"):
            self.assertIn(f">{cat}</a>", h)

    def test_set_by_modules_show_with_a_count_not_a_dash(self):
        h = self.get("/catalog?cat=indicator")
        self.assertIn("set in", h)
        self.assertIn("PGM", h)          # a module, not the dash
        self.assertIn("+2 more", h)

    # ── environments and endpoints are editable, not add-once ──

    def post(self, path, data):
        import urllib.parse
        import urllib.request
        req = urllib.request.Request(
            f"http://127.0.0.1:{self.port}{path}",
            data=urllib.parse.urlencode(data).encode(), method="POST")
        with urllib.request.urlopen(req) as r:
            return r.read().decode()

    def test_env_edit_screen_prefills_and_updates(self):
        h = self.get("/settings/env/edit?id=1")
        self.assertIn("http://127.0.0.1:1", h)
        self.post("/settings/env/update",
                  {"id": 1, "name": "SBX", "base_url": "http://127.0.0.1:2",
                   "token": ""})
        h = self.get("/settings/env/edit?id=1")
        self.assertIn("http://127.0.0.1:2", h)
        # blank token KEPT the stored one, so the list still shows it set
        self.assertIn("unchanged — leave blank to keep", h)

    def test_endpoint_edit_screen_prefills_and_updates(self):
        h = self.get("/settings/endpoint/edit?id=1")
        self.assertIn("X-Region: {region}", h)
        self.assertIn("&quot;ssn&quot;", h)   # body template, esc()d
        self.post("/settings/endpoint/update",
                  {"id": 1, "name": "Case by SSN", "method": "POST",
                   "path": "/v2/case", "body": '{"ssn": "{ssn}"}',
                   "headers": "X-Region: {region}\nX-Env: TEST"})
        h = self.get("/settings/endpoint/edit?id=1")
        self.assertIn("/v2/case", h)
        self.assertIn("X-Env: TEST", h)

    def test_token_chip_and_inline_refresh(self):
        import base64 as b64
        import json as j
        import time as t
        # a JWT expiring in 20 minutes → chip shows the countdown
        payload = b64.urlsafe_b64encode(
            j.dumps({"exp": int(t.time()) + 1200}).encode()
        ).decode().rstrip("=")
        jwt = f"eyJhbGciOiJub25lIn0.{payload}.sig"
        self.post("/cases/token", {"env": 1, "ep": 1, "token": jwt})
        h = self.get("/cases?env=1&ep=1")
        self.assertIn("token to", h)
        # an EXPIRED one → the chip says so in red
        payload = b64.urlsafe_b64encode(
            j.dumps({"exp": int(t.time()) - 60}).encode()
        ).decode().rstrip("=")
        self.post("/cases/token",
                  {"env": 1, "ep": 1,
                   "token": f"eyJhbGciOiJub25lIn0.{payload}.sig"})
        h = self.get("/cases?env=1&ep=1")
        self.assertIn("token EXPIRED", h)
        # an opaque (non-JWT) token → no claim made about expiry
        self.post("/cases/token", {"env": 1, "ep": 1, "token": "opaque"})
        h = self.get("/cases?env=1&ep=1")
        self.assertIn("token set", h)

    def test_settings_rows_link_to_the_edit_screens(self):
        h = self.get("/settings?tab=api")
        self.assertIn("/settings/env/edit?id=1", h)
        self.assertIn("/settings/endpoint/edit?id=1", h)


if __name__ == "__main__":
    unittest.main()
