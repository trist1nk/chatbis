"""The DFR assembler: deterministic completeness at any module size,
model prose bounded to one fail-soft paragraph.

The 160-rule live proof runs against the dev corpus; these tests pin
the contract on synthetic seeds."""
import json
import re
import unittest

from chatbis import db
from chatbis import dfr_draft
from chatbis.dfr_draft import assemble_dfr, rules_digest


def seed_program(conn, n_rules):
    conn.execute(
        "INSERT INTO source_file (id, application_id, path, name, kind,"
        " encoding, fmt, line_count, content_hash, ingested_at)"
        " VALUES (1, NULL, '/x/BIG.cbl', 'BIG.cbl', 'cobol', 'utf-8',"
        " 'fixed', 1200, 'h', 'now')")
    conn.execute("INSERT INTO program (id, source_file_id, name)"
                 " VALUES (1, 1, 'BIGMOD')")
    for i in range(n_rules):
        code = f"E9{i:03d}"
        conn.execute(
            "INSERT INTO program_facet (program_id, kind, ref, detail)"
            " VALUES (1, 'rule', ?, ?)",
            (code, json.dumps({"english": f"FIELD-{i} is blank",
                               "paragraph": f"EDIT-{i // 10:02d}",
                               "actions": [f"raises {code}"]})))
        cid = db.upsert_exception(conn, code, category="exception",
                                  meaning=f"meaning {i}")
        db.add_link(conn, cid, "program", "BIGMOD", "emitted_by",
                    confidence=0.9)
    conn.commit()


class Assembly(unittest.TestCase):
    def setUp(self):
        self.conn = db.connect(":memory:")

    def tearDown(self):
        self.conn.close()

    def test_every_mined_rule_becomes_a_requirement_no_cap(self):
        seed_program(self.conn, 140)          # far past the chat cap
        md, err = assemble_dfr(self.conn, "BIGMOD", None,
                               with_prose=False)
        self.assertIsNone(err)
        self.assertEqual(
            len(re.findall(r"^### R-\d{3}$", md, re.M)), 140)
        self.assertEqual(
            len(re.findall(r"^\| `E9\d{3}` \|", md, re.M)), 140)
        self.assertIn("140 rules mined — full set shown", md)

    def test_requirement_carries_when_then_raises_where(self):
        seed_program(self.conn, 3)
        md, _ = assemble_dfr(self.conn, "BIGMOD", None,
                             with_prose=False)
        block = re.search(r"### R-002\n(.*?)\n\n", md, re.S).group(1)
        self.assertIn("**When:** FIELD-1 is blank", block)
        self.assertIn("**Then:** raises E9001", block)
        self.assertIn("**Raises:** `E9001` — meaning 1", block)
        self.assertIn("**Where:** paragraph `EDIT-00`", block)

    def test_model_offline_still_assembles_whole(self):
        seed_program(self.conn, 5)
        md, err = assemble_dfr(
            self.conn, "BIGMOD",
            {"base_url": "http://127.0.0.1:1", "model": "x",
             "api_key": ""}, with_prose=True)
        self.assertIsNone(err)
        self.assertIn("description pending — model offline", md)
        self.assertIn("summary pending — model offline", md)
        self.assertEqual(len(re.findall(r"^### R-\d{3}$", md, re.M)), 5)

    def test_prose_lands_when_the_model_answers(self):
        seed_program(self.conn, 2)
        real = dfr_draft.llm_chat
        dfr_draft.llm_chat = lambda cfg, m, t: {
            "content": "BIGMOD validates the case fields."}
        try:
            md, _ = assemble_dfr(self.conn, "BIGMOD",
                                 {"base_url": "http://x", "model": "m",
                                  "api_key": ""})
        finally:
            dfr_draft.llm_chat = real
        self.assertIn("BIGMOD validates the case fields.", md)
        self.assertNotIn("description pending", md)
        self.assertNotIn("summary pending", md)   # §2 landed too

    def test_digest_carries_every_rule_under_budget(self):
        seed_program(self.conn, 60)
        from chatbis.investigate import exec_describe_program
        prof = exec_describe_program(self.conn, "BIGMOD",
                                     rule_limit=None)
        d = rules_digest(prof)
        self.assertIn("60 rules across 6 paragraphs", d)
        self.assertEqual(d.count("->"), 60)        # every rule, coded
        self.assertNotIn("+", d.split("\n")[0])    # nothing dropped

    def test_digest_over_budget_keeps_honest_counts(self):
        seed_program(self.conn, 200)
        from chatbis.investigate import exec_describe_program
        prof = exec_describe_program(self.conn, "BIGMOD",
                                     rule_limit=None)
        d = rules_digest(prof, budget_chars=2000)
        self.assertLessEqual(len(d), 2100)
        self.assertIn("200 rules across", d)       # totals never lie
        self.assertIn("more)", d)                  # drops are named

    def test_unknown_program_refuses(self):
        md, err = assemble_dfr(self.conn, "NOPE", None)
        self.assertIsNone(md)
        self.assertIn("no program named", err)

    def test_marked_as_draft_never_an_official_document(self):
        seed_program(self.conn, 1)
        md, _ = assemble_dfr(self.conn, "BIGMOD", None,
                             with_prose=False)
        self.assertIn("(DRAFT)", md.splitlines()[0])
        self.assertIn("for SME review", md)


if __name__ == "__main__":
    unittest.main()
