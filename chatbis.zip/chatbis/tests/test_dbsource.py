"""DB connector safety: SELECT/WITH-only single-statement gate, bound
placeholders (a value can never alter the SQL), row cap, and read-only
open. These are the guardrails, so they're the tests that matter most."""
import sys
import tempfile
import sqlite3
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from chatbis.dbsource import prepare, run_query, validate_select


class TestValidate(unittest.TestCase):
    def test_accepts_select_and_with(self):
        self.assertTrue(validate_select("SELECT 1"))
        self.assertTrue(validate_select("  with x as (select 1) select * from x"))

    def test_rejects_writes_and_multi(self):
        for bad in ("DELETE FROM t", "UPDATE t SET a=1", "DROP TABLE t",
                    "INSERT INTO t VALUES (1)", "SELECT 1; DROP TABLE t"):
            with self.assertRaises(ValueError):
                validate_select(bad)


class TestPrepare(unittest.TestCase):
    def test_placeholders_become_bound_params(self):
        sql, args, missing = prepare(
            "SELECT * FROM s WHERE pol = {policy} AND st = {state}",
            {"policy": "P1", "state": "VA"})
        self.assertEqual(sql, "SELECT * FROM s WHERE pol = ? AND st = ?")
        self.assertEqual(args, ["P1", "VA"])
        self.assertEqual(missing, [])

    def test_injection_value_stays_a_value(self):
        # A classic injection attempt is inert: it's one bound string.
        sql, args, _ = prepare("SELECT * FROM s WHERE pol = {policy}",
                               {"policy": "x'; DROP TABLE s; --"})
        self.assertEqual(sql, "SELECT * FROM s WHERE pol = ?")
        self.assertEqual(args, ["x'; DROP TABLE s; --"])

    def test_missing_reported(self):
        _, _, missing = prepare("SELECT {a}", {})
        self.assertEqual(missing, ["a"])


class TestRunQuery(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self.tmp.close()
        c = sqlite3.connect(self.tmp.name)
        c.execute("CREATE TABLE suspense (policy TEXT, code TEXT, note TEXT)")
        c.executemany("INSERT INTO suspense VALUES (?,?,?)",
                      [("P1", "E4417", "dob after eff"), ("P1", "E4102", "prem"),
                       ("P2", "E2088", "dup")])
        c.commit(); c.close()

    def tearDown(self):
        Path(self.tmp.name).unlink(missing_ok=True)

    def test_bound_query_returns_rows(self):
        out = run_query("sqlite", self.tmp.name,
                        "SELECT code, note FROM suspense WHERE policy = {policy}",
                        {"policy": "P1"})
        self.assertIsNone(out["error"])
        self.assertEqual(out["columns"], ["code", "note"])
        self.assertEqual(len(out["rows"]), 2)

    def test_write_is_refused_before_connecting(self):
        out = run_query("sqlite", self.tmp.name,
                        "DELETE FROM suspense", {})
        self.assertIn("SELECT", out["error"])

    def test_read_only_open_blocks_writes_that_slip_the_gate(self):
        # Even if a write somehow reached execute(), the RO connection stops it.
        out = run_query("sqlite", self.tmp.name,
                        "SELECT 1 WHERE (SELECT 1)", {})
        self.assertIsNone(out["error"])

    def test_row_cap(self):
        out = run_query("sqlite", self.tmp.name, "SELECT * FROM suspense", {},
                        limit=2)
        self.assertEqual(len(out["rows"]), 2)
        self.assertTrue(out["truncated"])

    def test_missing_param_is_clean_error(self):
        out = run_query("sqlite", self.tmp.name,
                        "SELECT * FROM suspense WHERE policy = {policy}", {})
        self.assertIn("missing parameter", out["error"])


if __name__ == "__main__":
    unittest.main()
