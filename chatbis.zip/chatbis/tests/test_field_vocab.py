"""The shop's taxonomy: suspension/termination status codes and RFD/WIC
reason indicators are NOT exceptions. Field names decide, through a
declared vocabulary."""
import tempfile
import unittest
from pathlib import Path

from chatbis import db
from chatbis.ingest import ingest_paths

MEMBER = """\
       IDENTIFICATION DIVISION.
       PROGRAM-ID. VOC01.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-SUSP-CD              PIC X(03).
       01  WS-RFD-CD               PIC X(02).
       01  WS-WIC-IND              PIC X(02).
       01  WS-ERROR-CODE           PIC X(05).
       PROCEDURE DIVISION.
       MAIN.
           MOVE 'S06' TO WS-SUSP-CD
           MOVE 'R2' TO WS-RFD-CD
           MOVE 'W1' TO WS-WIC-IND
           IF WS-SUSP-CD = SPACES
               MOVE 'E9410' TO WS-ERROR-CODE
           END-IF
           GOBACK.
"""


class FieldVocab(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        conn = db.connect(str(Path(cls.tmp.name) / "t.db"))
        db.seed_field_vocab(conn)
        aid = db.get_or_create_app(conn, "VOCAB")
        src = Path(cls.tmp.name) / "VOC01.cbl"
        src.write_text(MEMBER)
        ingest_paths(conn, [src], app_id=aid)
        conn.commit()
        cls.conn = conn

    @classmethod
    def tearDownClass(cls):
        cls.conn.close()
        cls.tmp.cleanup()

    def cat(self, code):
        r = self.conn.execute(
            "SELECT category FROM exception_code WHERE code = ?",
            (code,)).fetchone()
        return r["category"] if r else None

    def test_status_and_reason_codes_are_not_exceptions(self):
        self.assertEqual(self.cat("S06"), "suspension")
        self.assertEqual(self.cat("R2"), "indicator")  # rescued: len 2
        self.assertEqual(self.cat("W1"), "indicator")
        self.assertEqual(self.cat("E9410"), "exception")

    def test_vocab_codes_link_as_set_by_not_emitted_by(self):
        rels = {r["relation"] for r in self.conn.execute(
            """SELECT l.relation FROM exception_link l
               JOIN exception_code e ON e.id = l.exception_id
               WHERE e.code = 'S06'""")}
        self.assertIn("set_by", rels)
        self.assertNotIn("emitted_by", rels)
        rels_e = {r["relation"] for r in self.conn.execute(
            """SELECT l.relation FROM exception_link l
               JOIN exception_code e ON e.id = l.exception_id
               WHERE e.code = 'E9410'""")}
        self.assertIn("emitted_by", rels_e)

    def test_undeclared_field_still_uses_the_shape_gate(self):
        # WS-SUSP-CD matched a vocab pattern; a random -CD field with a
        # short domain value must still be refused (no vocab, fails
        # looks_like_code)
        src = Path(self.tmp.name) / "VOC02.cbl"
        src.write_text(MEMBER.replace("VOC01", "VOC02")
                       .replace("WS-SUSP-CD", "WS-STATE-CD")
                       .replace("'S06'", "'VA'"))
        aid = db.get_or_create_app(self.conn, "VOCAB")
        ingest_paths(self.conn, [src], app_id=aid)
        self.conn.commit()
        self.assertIsNone(self.cat("VA"))


if __name__ == "__main__":
    unittest.main()
