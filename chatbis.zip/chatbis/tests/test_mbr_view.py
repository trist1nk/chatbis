"""The case, presented as the MBR — projection through field_map's
declared SCHEMA.TABLE.COLUMN homes. Analysts triage against the MBR;
the copybook areas (area_map) are internal and must never appear here.

Synthetic case data only — 900-xx SSNs, invented names."""
import unittest

from chatbis import db
from chatbis.mbr import project_case, split_db2, to_mainframe

CASE = {
    "claimNumber": "A2026-0117",
    "claimant": {"ssn": "900041234", "name": "TEST CASE",
                 "dateOfBirth": "1958-04-02"},
    "claim": {"claimType": "DIS", "entitlementDate": "2020-01-01",
              "mba": 1842.50},
    "entitlementPeriods": [
        {"startDate": "2020-01-01", "endDate": "2024-05-31"},
        {"startDate": "2024-08-01", "endDate": ""},
    ],
    "payments": [{"amount": 1842.50, "status": "PAID"}],
    "wageRecord": {"aime": 5210.00},
}


def seed(conn, rows):
    for label, db2, jp, fmt in rows:
        conn.execute(
            "INSERT INTO field_map (label, db2_column, json_path, format)"
            " VALUES (?, ?, ?, ?)", (label, db2, jp, fmt))
    conn.commit()


class Db2Address(unittest.TestCase):
    def test_three_and_two_part_addresses(self):
        self.assertEqual(split_db2("MBR.CLAIM.BENE_DOB"),
                         ("MBR", "CLAIM", "BENE_DOB"))
        self.assertEqual(split_db2("CLAIM.BENE_DOB"),
                         ("", "CLAIM", "BENE_DOB"))

    def test_anything_else_is_refused(self):
        for bad in ("BENE_DOB", "A.B.C.D", "", None, "MBR..DOB"):
            self.assertIsNone(split_db2(bad), bad)


class MainframeSpelling(unittest.TestCase):
    def test_date_formats_spell_as_the_mbr_carries_them(self):
        self.assertEqual(to_mainframe("1958-04-02", "yyyymmdd"), "19580402")
        self.assertEqual(to_mainframe("1958-04-02", "yymmdd"), "580402")
        self.assertEqual(to_mainframe("2026-02-01", "julian-ccyyddd"),
                         "2026032")

    def test_same_spelling_and_unparseable_contribute_nothing(self):
        self.assertIsNone(to_mainframe("DIS", "text"))
        self.assertIsNone(to_mainframe("1842.50", "decimal"))
        self.assertIsNone(to_mainframe("not-a-date", "yyyymmdd"))
        self.assertIsNone(to_mainframe("1958-04-02", None))


class Projection(unittest.TestCase):
    def setUp(self):
        self.conn = db.connect(":memory:")
        seed(self.conn, [
            ("Beneficiary date of birth", "MBR.CLAIM.BENE_DOB",
             "claimant.dateOfBirth", "yyyymmdd"),
            ("Claim type", "MBR.CLAIM.CLM_TYP", "claim.claimType", "text"),
            ("Period start", "MBR.ENT_PERIODS.ENT_STRT_DT",
             "entitlementPeriods[].startDate", "yyyymmdd"),
            ("Period end", "MBR.ENT_PERIODS.ENT_END_DT",
             "entitlementPeriods[].endDate", "yyyymmdd"),
            ("Payment amount", "", "payments[].amount", "decimal"),
        ])

    def tearDown(self):
        self.conn.close()

    def sec(self, proj, table):
        return next(s for s in proj["sections"] if s["table"] == table)

    def test_scalar_columns_form_the_master_row(self):
        proj = project_case(self.conn, CASE)
        claim = self.sec(proj, "CLAIM")
        self.assertIsNone(claim["root"])
        self.assertEqual(len(claim["rows"]), 1)
        dob, typ = claim["rows"][0]
        self.assertEqual(dob["v"], "1958-04-02")
        self.assertEqual(dob["mf"], "19580402")   # as the MBR carries it
        self.assertEqual(typ["v"], "DIS")

    def test_array_paths_become_occurrence_rows(self):
        proj = project_case(self.conn, CASE)
        per = self.sec(proj, "ENT_PERIODS")
        self.assertEqual(per["root"], "entitlementPeriods")
        self.assertEqual(len(per["rows"]), 2)     # two occurrences
        self.assertEqual(per["rows"][0][0]["mf"], "20200101")
        self.assertEqual(per["rows"][1][1]["v"], "")  # open period, blank

    def test_no_mbr_home_is_named_not_dropped(self):
        proj = project_case(self.conn, CASE)
        self.assertEqual([x["json_path"] for x in proj["no_home"]],
                         ["payments[].amount"])

    def test_unmapped_leaves_are_the_backlog(self):
        proj = project_case(self.conn, CASE)
        paths = [p for p, _ in proj["unmapped"]]
        self.assertIn("wageRecord.aime", paths)
        self.assertIn("claimant.ssn", paths)
        # mapped and no-home leaves are NOT in the backlog
        self.assertNotIn("claimant.dateOfBirth", paths)
        self.assertNotIn("payments[].amount", paths)

    def test_coverage_counts_mbr_homed_leaves_only(self):
        proj = project_case(self.conn, CASE)
        # dateOfBirth, claimType, 2x startDate, 2x endDate = 6 covered;
        # the case carries 14 scalar leaves in all
        self.assertEqual((proj["covered"], proj["total"]), (6, 14))

    def test_same_fact_in_two_tables_shows_in_both(self):
        seed(self.conn, [("DOB (claimant row)", "MBR.CLAIMANT.DOB",
                          "claimant.dateOfBirth", "yyyymmdd")])
        proj = project_case(self.conn, CASE)
        tables = [s["table"] for s in proj["sections"]]
        self.assertIn("CLAIM", tables)
        self.assertIn("CLAIMANT", tables)

    def test_bad_declarations_are_refused_by_name(self):
        seed(self.conn, [
            ("Broken home", "JUSTATABLE", "claim.mba", ""),
            ("Nested twice", "MBR.X.Y", "a[].b[].c", ""),
        ])
        proj = project_case(self.conn, CASE)
        reasons = dict(proj["refused"])
        self.assertIn("Broken home", reasons)
        self.assertIn("Nested twice", reasons)
        self.assertNotIn("X", [s["table"] for s in proj["sections"]
                               if s["columns"][0]["label"] == "Nested twice"])

    def test_table_absent_from_this_pull_trails_with_no_rows(self):
        seed(self.conn, [("Citizenship", "MBR.CTZN.STAT_CD",
                          "citizenship.status", "text")])
        proj = project_case(self.conn, CASE)
        ctzn = self.sec(proj, "CTZN")
        self.assertEqual(ctzn["rows"], [])
        self.assertEqual(proj["sections"][-1]["table"], "CTZN")

    def test_copybook_areas_never_leak_into_the_mbr_view(self):
        # area_map is internal plumbing; even fully seeded it must not
        # produce a section.
        self.conn.execute(
            "INSERT INTO area_map (area, cobol_field, json_path, format)"
            " VALUES ('EE-RECORD', 'EE-DOB', 'claimant.dateOfBirth',"
            " 'iso-date')")
        self.conn.commit()
        proj = project_case(self.conn, CASE)
        self.assertNotIn("EE-RECORD",
                         [s["table"] for s in proj["sections"]])


if __name__ == "__main__":
    unittest.main()
