"""The 'What happened' card: the run told in sentences. Every claim must be
derived from the run structure — these tests pin the derivations."""
import sqlite3
import tempfile
import unittest
from pathlib import Path

from chatbis import db
from chatbis.server import run_summary


def pipeline_run():
    return {
        "_ms": 7,
        "status": "completed",
        "steps": [
            {"step": "S1", "pgm": "BUILDER", "status": "completed", "rc": 8,
             "exceptions": 1},
            {"step": "S2", "pgm": "BFONE", "status": "skipped",
             "why": "COND=(8,LE,S1) (S1.RC = 8)"},
            {"step": "S3", "pgm": "BFTWO", "status": "skipped",
             "why": "COND=(8,LE,S1) (S1.RC = 8)"},
            {"step": "S4", "pgm": "PUTTER", "status": "completed", "rc": 0,
             "exceptions": 0},
        ],
        "exceptions": [{"code": "E9101", "pgm": "BUILDER", "line": 12,
                        "field": "WS-ERROR-CODE"}],
        "writes": [
            {"stmt": "insert", "column": "SCH.CLAIM.MBA", "value": "0.00"},
            {"stmt": "insert", "column": "SCH.CLAIM.DOB", "value": ""},
            {"stmt": "update", "column": "SCH.CTL.STAT", "value": "OK"},
        ],
        "trace": [
            {"kind": "sql", "op": "insert", "pgm": "PUTTER", "line": 30},
            {"kind": "file", "op": "write", "pgm": "BUILDER",
             "dsn": "P.AUDIT", "line": 9},
        ],
        "datasets": {"P.AUDIT": ["row-one"], "P.REJECTS": [],
                     "P.INPUT": ["seeded"]},
    }


class RunSummary(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.conn = db.connect(str(Path(cls.tmp.name) / "t.db"))
        cls.conn.execute(
            "INSERT INTO exception_code (code, normalized, meaning, status,"
            " updated_at) VALUES ('E9101', ?, "
            "'Date of birth missing from the build', 'curated', ?)",
            (db.normalize_code("E9101"), db.now()))
        cls.conn.commit()

    @classmethod
    def tearDownClass(cls):
        cls.conn.close()
        cls.tmp.cleanup()

    def test_completed_pipeline_reads_causally(self):
        h = run_summary(self.conn, pipeline_run())
        # headline: counts derived from the steps
        self.assertIn("All 4 steps", h)
        self.assertIn("2 were skipped by gates", h)
        # the exception carries its catalog meaning
        self.assertIn("Date of birth missing from the build", h)
        self.assertIn("return code 8", h)
        # the gate chain names the blocker AND the victims
        self.assertIn("S1 (BUILDER)", h)
        self.assertIn("BFONE", h)
        self.assertIn("never ran", h)
        # writes: grouped, verb conjugated, blanks counted with the reason
        self.assertIn("inserted <b>SCH.CLAIM</b> (2 columns)", h)
        self.assertIn("updated <b>SCH.CTL</b>", h)
        self.assertIn("2 of 3</b> posted values are blank or zero", h)
        self.assertIn("skipped business functions sit between", h)
        # datasets: written vs empty vs input are told apart
        self.assertIn("P.AUDIT</b> was written: 1 record", h)
        self.assertIn("P.REJECTS</b> ended the run empty", h)
        self.assertIn("P.INPUT</b>: 1 record (input)", h)

    def test_uncatalogued_code_says_so_instead_of_inventing(self):
        r = pipeline_run()
        r["exceptions"][0]["code"] = "E7777"
        h = run_summary(self.conn, r)
        self.assertIn("E7777", h)
        self.assertIn("not in the catalog yet", h)
        self.assertNotIn("Date of birth missing", h)

    def test_halted_pipeline_leads_with_where_and_why(self):
        r = pipeline_run()
        r["status"] = "halted"
        r["steps"][3] = {"step": "S4", "pgm": "PUTTER", "status": "halted",
                         "reason": "no field mapping for SCH.CTL.STAT"}
        r["writes"] = []
        h = run_summary(self.conn, r)
        self.assertIn("stopped at <b>S4 (PUTTER)</b>", h)
        self.assertIn("no field mapping for SCH.CTL.STAT", h)
        self.assertIn("1 step had already finished", h)

    def test_single_program_run_without_steps(self):
        h = run_summary(self.conn, {
            "_ms": 2, "status": "completed", "steps": [],
            "exceptions": [{"code": "E9101", "pgm": "SOLO", "line": 5,
                            "field": "WS-E"}],
            "writes": [], "trace": [], "datasets": {},
        })
        self.assertIn("ran to completion", h)
        self.assertIn("SOLO", h)
        self.assertIn("Date of birth missing from the build", h)


if __name__ == "__main__":
    unittest.main()
