"""JCL screens over real HTTP: ingest a job whose steps run programs across
two pipeline stages, then assert the job view renders the runbook, the
pipeline detail reconciles configured vs discovered order (both verdicts),
and the Scan called-from panel names the job step that runs a program.
"""
import sys
import tempfile
import threading
import unittest
import urllib.parse
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from chatbis import db
from chatbis.ingest import ingest_paths
from chatbis.server import Handler

STAGE_A = """       IDENTIFICATION DIVISION.
       PROGRAM-ID. AEXTRACT.
       PROCEDURE DIVISION.
       MAIN.
           GOBACK.
"""
STAGE_B = """       IDENTIFICATION DIVISION.
       PROGRAM-ID. BLOAD.
       PROCEDURE DIVISION.
       MAIN.
           GOBACK.
"""
JCL = """//NIGHTJOB JOB (X),'RUN'
//S1       EXEC PGM=AEXTRACT
//OUT      DD DSN=P.HANDOFF,DISP=(NEW,PASS)
//S2       EXEC PGM=BLOAD
//IN       DD DSN=P.HANDOFF,DISP=(OLD,DELETE)
//S3       EXEC PGM=GHOSTPGM
"""


class JclScreens(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.db_path = str(Path(cls.tmp.name) / "t.db")
        src = Path(cls.tmp.name)
        (src / "AEXTRACT.cbl").write_text(STAGE_A)
        (src / "BLOAD.cbl").write_text(STAGE_B)
        (src / "NIGHTJOB.jcl").write_text(JCL)
        conn = db.connect(cls.db_path)
        a = db.get_or_create_app(conn, "EXTRACT")
        b = db.get_or_create_app(conn, "LOAD")
        ingest_paths(conn, [src / "AEXTRACT.cbl"], app_id=a)
        ingest_paths(conn, [src / "BLOAD.cbl", src / "NIGHTJOB.jcl"], app_id=b)
        conn.execute("UPDATE application SET pipeline='NIGHT', stage_seq=10"
                     " WHERE name='EXTRACT'")
        conn.execute("UPDATE application SET pipeline='NIGHT', stage_seq=20"
                     " WHERE name='LOAD'")
        conn.commit()
        conn.close()
        Handler.db_path = cls.db_path
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.httpd.server_address[1]
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.tmp.cleanup()

    def get(self, path):
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}{path}") as r:
            return r.read().decode()

    def post(self, path, data):
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}{path}",
                urllib.parse.urlencode(data).encode()) as r:
            return r.read().decode()

    def test_job_view_renders_steps_seams_and_gaps(self):
        html = self.get("/job/1")
        self.assertIn("NIGHTJOB", html)
        self.assertLess(html.index("AEXTRACT"), html.index("BLOAD"))
        self.assertIn("P.HANDOFF", html)                 # the seam dataset
        self.assertIn("EXTRACT", html)                   # app chips resolved
        self.assertIn("not in the corpus", html)         # GHOSTPGM is honest

    def test_runbook_agrees_with_config(self):
        html = self.get("/pipeline?name=NIGHT")
        self.assertIn("Runbook — discovered from JCL", html)
        self.assertIn("matches the configured order", html)
        self.assertIn("GHOSTPGM", html)                  # unmapped step named

    def test_runbook_flags_disagreement(self):
        # Flip the configured order; the JCL now disagrees.
        import sqlite3
        c = sqlite3.connect(self.db_path)
        c.execute("UPDATE application SET stage_seq=5 WHERE name='LOAD'")
        c.commit(); c.close()
        try:
            html = self.get("/pipeline?name=NIGHT")
            self.assertIn("disagrees at position 1", html)
        finally:
            c = sqlite3.connect(self.db_path)
            c.execute("UPDATE application SET stage_seq=20 WHERE name='LOAD'")
            c.commit(); c.close()

    def test_scan_shows_run_by_job(self):
        html = self.get("/scan?q=AEXTRACT")
        self.assertIn("Called from", html)
        self.assertIn("NIGHTJOB", html)
        self.assertIn("job · S1", html)

    def test_jcl_reingest_is_clean(self):
        # Re-ingesting the same member must not duplicate the job.
        import sqlite3
        conn = db.connect(self.db_path)
        ingest_paths(conn, [Path(self.tmp.name) / "NIGHTJOB.jcl"])
        conn.commit(); conn.close()
        c = sqlite3.connect(self.db_path)
        self.assertEqual(
            c.execute("SELECT COUNT(*) FROM jcl_job").fetchone()[0], 1)
        self.assertEqual(
            c.execute("SELECT COUNT(*) FROM jcl_step").fetchone()[0], 3)
        c.close()


if __name__ == "__main__":
    unittest.main()
