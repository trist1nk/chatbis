"""Dry-run readiness over real HTTP.

The invariant: every BLOCKED verdict names concrete acquisition items —
the missing copybook, the uncalled-for program, the exact DB2 column —
and satisfying them (ingest, stub, map) flips the verdict. Nothing vague,
nothing optimistic.
"""
import sys
import tempfile
import threading
import unittest
import urllib.parse
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from chatbis import db
from chatbis.ingest import ingest_paths
from chatbis.server import Handler

DRIVER = """       IDENTIFICATION DIVISION.
       PROGRAM-ID. RDRIVER.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY MISSREC.
       01  WS-HOSTS.
           05  WS-AMT              PIC 9(07)V99.
       PROCEDURE DIVISION.
       MAIN.
           CALL 'RHELPER' USING WS-HOSTS
           CALL 'GONEPGM' USING WS-HOSTS
           EXEC SQL
               SELECT AMT INTO :WS-AMT FROM SCH.LEDGER WHERE K = :WS-K
           END-EXEC
           GOBACK.
"""
HELPER = """       IDENTIFICATION DIVISION.
       PROGRAM-ID. RHELPER.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-X                    PIC X.
       PROCEDURE DIVISION.
       MAIN.
           CALL 'DEEPPGM' USING WS-X
           GOBACK.
"""


class Readiness(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.db_path = str(Path(cls.tmp.name) / "t.db")
        src = Path(cls.tmp.name)
        (src / "RDRIVER.cbl").write_text(DRIVER)
        (src / "RHELPER.cbl").write_text(HELPER)
        conn = db.connect(cls.db_path)
        aid = db.get_or_create_app(conn, "RAPP")
        ingest_paths(conn, [src / "RDRIVER.cbl", src / "RHELPER.cbl"],
                     app_id=aid)
        conn.commit()
        cls.pid = conn.execute(
            "SELECT id FROM program WHERE name='RDRIVER'").fetchone()["id"]
        conn.close()
        Handler.db_path = cls.db_path
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.httpd.server_address[1]
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.tmp.cleanup()

    def page(self):
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}/prog/{self.pid}") as r:
            return r.read().decode()

    def post(self, path, data):
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}{path}",
                urllib.parse.urlencode(data).encode()) as r:
            return r.read().decode()

    def test_01_blocked_names_every_concrete_item(self):
        html = self.page()
        self.assertIn(">BLOCKED<", html)
        self.assertIn("ingest copybook MISSREC", html)
        self.assertIn("ingest GONEPGM (called by RDRIVER)", html)
        # Transitive: RHELPER resolves, and ITS missing callee surfaces too.
        self.assertIn("ingest DEEPPGM (called by RHELPER)", html)
        self.assertIn("map DB2 column SCH.LEDGER.AMT (read by RDRIVER)", html)

    def test_02_stubbing_satisfies_a_call(self):
        self.post("/stub", {"name": "GONEPGM", "back": "/"})
        self.post("/stub", {"name": "DEEPPGM", "back": "/"})
        html = self.page()
        self.assertNotIn("ingest GONEPGM", html)
        self.assertNotIn("ingest DEEPPGM", html)
        self.assertIn("unstub", html)
        self.assertIn(">BLOCKED<", html)     # copybook + column still block

    def test_03_mapping_and_copybook_flip_the_verdict(self):
        import sqlite3
        c = sqlite3.connect(self.db_path)
        # A mapping WITHOUT a declared format leaves an advisory, not a
        # blocker — the run would work but a date would not convert.
        c.execute("INSERT INTO field_map (label, db2_column, updated_by,"
                  " updated_at) VALUES ('Amt','SCH.LEDGER.AMT','t',?)",
                  (db.now(),))
        c.commit(); c.close()
        src = Path(self.tmp.name)
        (src / "MISSREC.cpy").write_text(
            "       01  MISS-REC.\n           05  MISS-A  PIC X(10).\n")
        conn = db.connect(self.db_path)
        ingest_paths(conn, [src / "MISSREC.cpy"])
        conn.commit(); conn.close()
        html = self.page()
        self.assertNotIn(">BLOCKED<", html)
        self.assertIn("declare the format for SCH.LEDGER.AMT", html)
        self.assertIn(">RUNNABLE<", html)
        # Declaring it clears the last advisory.
        c = sqlite3.connect(self.db_path)
        c.execute("UPDATE field_map SET format='decimal'"
                  " WHERE db2_column='SCH.LEDGER.AMT'")
        c.commit(); c.close()
        self.assertIn(">READY<", self.page())

    def test_04_unstub_reopens_the_blocker(self):
        self.post("/stub/delete", {"name": "GONEPGM", "back": "/"})
        html = self.page()
        self.assertIn(">BLOCKED<", html)
        self.assertIn("ingest GONEPGM", html)
        self.post("/stub", {"name": "GONEPGM", "back": "/"})   # restore


class CobrunWorkList(unittest.TestCase):
    """The aggregate view earns its place through DEDUPLICATION: many
    programs needing one thing is ONE errand, and satisfying it must move
    the whole fleet at once."""

    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.db_path = str(Path(cls.tmp.name) / "t.db")
        src = Path(cls.tmp.name)
        conn = db.connect(cls.db_path)
        aid = db.get_or_create_app(conn, "WAPP")
        # Three programs, all calling the same absent utility.
        for n in ("WONE", "WTWO", "WTHREE"):
            (src / f"{n}.cbl").write_text(
                "       IDENTIFICATION DIVISION.\n"
                f"       PROGRAM-ID. {n}.\n"
                "       DATA DIVISION.\n"
                "       WORKING-STORAGE SECTION.\n"
                "       01  WS-A                PIC X.\n"
                "       PROCEDURE DIVISION.\n"
                "       MAIN.\n"
                "           CALL 'SHAREDUT' USING WS-A\n"
                "           GOBACK.\n")
            ingest_paths(conn, [src / f"{n}.cbl"], app_id=aid)
        conn.commit()
        conn.close()
        Handler.db_path = cls.db_path
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.httpd.server_address[1]
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.tmp.cleanup()

    def get(self, path="/cobrun"):
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}{path}") as r:
            return r.read().decode()

    def post(self, path, data):
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}{path}",
                urllib.parse.urlencode(data).encode()) as r:
            return r.read().decode()

    def runnable(self, html):
        """(ok, total) from the scoped header."""
        import re
        m = re.search(r"(\d+) of (\d+) business functions runnable", html)
        return int(m.group(1)), int(m.group(2))

    def test_01_index_lists_flows_not_a_wall_of_programs(self):
        html = self.get()
        # The landing page is flows, with a roll-up — not every program.
        self.assertIn("WAPP", html)
        self.assertIn("0 of 3", html)
        self.assertNotIn("WTHREE", html)      # drill down to see those
        self.assertIn("What&#x27;s missing", html.replace("'", "&#x27;"))

    def test_02_drilling_in_shows_each_function_and_its_blocker(self):
        html = self.get("/cobrun?app=WAPP")
        self.assertEqual(self.runnable(html), (0, 3))
        for pgm in ("WONE", "WTWO", "WTHREE"):
            self.assertIn(pgm, html)
        # each one names the same missing utility, inline
        self.assertGreaterEqual(html.count("ingest SHAREDUT"), 3)
        # …and the deduplicated errand appears once in the work list
        self.assertEqual(html.count("<code>SHAREDUT</code>"), 1)
        self.assertIn("WONE, WTHREE, WTWO", html)

    def test_03_one_errand_turns_the_flow_green(self):
        self.post("/stub", {"name": "SHAREDUT", "back": "/cobrun"})
        html = self.get("/cobrun?app=WAPP")
        self.assertEqual(self.runnable(html), (3, 3))
        self.assertIn("all runnable", html)
        self.assertIn("closure complete", html)
        self.assertNotIn("Everything this flow needs", html)
        # the index says so too
        self.assertIn("all runnable", self.get())
        self.post("/stub/delete", {"name": "SHAREDUT", "back": "/cobrun"})

    def test_04_pipeline_scope(self):
        import sqlite3
        c = sqlite3.connect(self.db_path)
        c.execute("UPDATE application SET pipeline='WFLOW', stage_seq=10"
                  " WHERE name='WAPP'")
        c.commit(); c.close()
        html = self.get("/cobrun?pipeline=WFLOW")
        self.assertEqual(self.runnable(html)[1], 3)
        self.assertIn("WFLOW", html)

    def test_05_strip_links_into_the_scoped_view(self):
        html = self.get("/pipeline?name=WFLOW")
        self.assertIn("DRY RUN", html)
        self.assertIn("programs runnable", html)
        self.assertIn("/cobrun?pipeline=WFLOW", html)


if __name__ == "__main__":
    unittest.main()
