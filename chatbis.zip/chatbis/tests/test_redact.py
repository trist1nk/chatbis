"""db.redact() — strip identifying VALUES, preserve structure.

Used before anything is written to disk (Lab fixtures) or sent to a model
(Investigate path). Over-redaction is as much a bug as under-redaction:
destroying an addresses group also destroys its effective/end dates, which
recipe logic needs.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from chatbis.db import redact

CASE = {
    "claimant": {"ssn": "900010002", "bic": "A", "surname": "HALVORSEN",
                 "firstName": "MARIT", "dateOfBirth": "2027-03-15"},
    "claim": {"claimType": "RETIREMENT", "entitlementDate": "2026-01-01"},
    "entitlementPeriods": [{"startDate": "2023-01-01", "endDate": "2022-12-31",
                            "status": "ACTIVE"}],
    "addresses": [{"type": "RESIDENCE", "line1": "902 Kestrel Rd",
                   "city": "Towson", "postalCode": "21204",
                   "effectiveDate": "2021-01-01", "endDate": ""}],
    "citizenship": {"status": "USC", "countryOfBirth": "USA",
                    "verifiedDate": "2024-09-02"},
}
R = redact(CASE)
MASK = "«redacted»"


class TestRedact(unittest.TestCase):
    def test_identifiers_removed(self):
        for k in ("ssn", "surname", "firstName", "dateOfBirth"):
            self.assertEqual(R["claimant"][k], MASK, f"{k} leaked")
        a = R["addresses"][0]
        for k in ("line1", "city", "postalCode"):
            self.assertEqual(a[k], MASK, f"address {k} leaked")

    def test_structure_and_logic_fields_survive(self):
        # The whole point: check logic must still be testable on the shape.
        self.assertEqual(R["claim"]["claimType"], "RETIREMENT")
        self.assertEqual(R["claim"]["entitlementDate"], "2026-01-01")
        p = R["entitlementPeriods"][0]
        self.assertEqual(p["startDate"], "2023-01-01")
        self.assertEqual(p["endDate"], "2022-12-31")
        self.assertEqual(p["status"], "ACTIVE")
        self.assertEqual(R["claimant"]["bic"], "A")   # BIC alone identifies nobody

    def test_container_keys_are_recursed_not_flattened(self):
        # 'addresses' matches /addr/ but must NOT be blanket-redacted, or its
        # period dates vanish with it.
        self.assertIsInstance(R["addresses"], list)
        self.assertEqual(R["addresses"][0]["effectiveDate"], "2021-01-01")
        self.assertEqual(R["addresses"][0]["endDate"], "")

    def test_repeating_groups_keep_every_occurrence(self):
        many = redact({"addresses": [{"line1": f"{i} St", "effectiveDate": "2020-01-01"}
                                     for i in range(5)]})
        self.assertEqual(len(many["addresses"]), 5)
        self.assertTrue(all(a["line1"] == MASK for a in many["addresses"]))

    def test_blanks_and_nulls_pass_through(self):
        out = redact({"surname": "", "dateOfDeath": None})
        self.assertEqual(out["surname"], "")
        self.assertIsNone(out["dateOfDeath"])


if __name__ == "__main__":
    unittest.main()
