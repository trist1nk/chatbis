"""Exception-MI ingest invariants: the stdlib .xlsx reader resolves shared
and inline strings, Excel date serials become ISO dates, and the mapping
guesser reads roles from the file's own headers (dynamic by construction)."""
import io
import json
import sys
import unittest
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from chatbis.xlsx import (
    coerce_period, excel_serial_to_date, guess_mapping, read_table, read_xlsx,
)

NS = 'xmlns="http://www.openxmlformats.org/spreadsheetml/2006/main"'
NS = 'xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"'


def build_xlsx(shared: list[str], sheet_rows: str) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        sst = "".join(f"<si><t>{s}</t></si>" for s in shared)
        zf.writestr("xl/sharedStrings.xml",
                    f'<?xml version="1.0"?><sst {NS}>{sst}</sst>')
        zf.writestr("xl/worksheets/sheet1.xml",
                    f'<?xml version="1.0"?><worksheet {NS}>'
                    f"<sheetData>{sheet_rows}</sheetData></worksheet>")
    return buf.getvalue()


class TestXlsxReader(unittest.TestCase):
    def test_shared_inline_and_numeric_cells(self):
        raw = build_xlsx(
            ["Exception Code", "Count", "E4417"],
            '<row r="1"><c r="A1" t="s"><v>0</v></c><c r="B1" t="s"><v>1</v></c></row>'
            '<row r="2"><c r="A2" t="s"><v>2</v></c><c r="B2"><v>412</v></c></row>'
            '<row r="3"><c r="A3" t="inlineStr"><is><t>E9001</t></is></c>'
            '<c r="B3"><v>7</v></c></row>')
        rows = read_xlsx(raw)
        self.assertEqual(rows[0], ["Exception Code", "Count"])
        self.assertEqual(rows[1], ["E4417", "412"])
        self.assertEqual(rows[2], ["E9001", "7"])

    def test_sparse_cells_stay_rectangular(self):
        raw = build_xlsx([], '<row r="1"><c r="C1"><v>9</v></c></row>')
        self.assertEqual(read_xlsx(raw), [["", "", "9"]])

    def test_csv_dispatch(self):
        rows = read_table(b"code,count\nE1,5\n", "extract.csv")
        self.assertEqual(rows, [["code", "count"], ["E1", "5"]])


class TestPeriods(unittest.TestCase):
    def test_serial_to_date(self):
        self.assertEqual(excel_serial_to_date(46203), "2026-06-30")

    def test_coerce(self):
        self.assertEqual(coerce_period("46203"), "2026-06-30")
        self.assertEqual(coerce_period("2026-07"), "2026-07")   # opaque periods pass
        self.assertEqual(coerce_period("2026Q2"), "2026Q2")
        self.assertEqual(coerce_period("12"), "12")             # not a plausible serial


class TestGuessMapping(unittest.TestCase):
    def test_typical_mi_headers(self):
        g = guess_mapping(["Application", "Source Program", "Exception Code",
                           "Period", "Number of Occurrences", "Avg Mins"])
        self.assertEqual(g["code"], 2)
        self.assertEqual(g["period"], 3)
        self.assertEqual(g["count"], 4)
        self.assertEqual(g["application"], 0)

    def test_error_count_does_not_steal_the_code_role(self):
        g = guess_mapping(["Error Count", "Exception"])
        self.assertEqual(g["code"], 1)
        self.assertEqual(g["count"], 0)




class TestFieldMapImport(unittest.TestCase):
    """Field-map import stays dynamic: read the file's OWN headers, propose
    roles, let the analyst confirm. Nothing about the sheet is hardcoded."""

    def test_guesses_shop_style_headers(self):
        from chatbis.xlsx import guess_field_columns
        g = guess_field_columns(["Data Name", "DB2 Column", "API Attribute",
                                 "Business Description", "PIC / Usage"])
        self.assertEqual(g["cobol"], 0)
        self.assertEqual(g["db2"], 1)
        self.assertEqual(g["json"], 2)
        self.assertEqual(g["label"], 3)
        self.assertEqual(g["notes"], 4)

    def test_db2_column_does_not_steal_the_label_role(self):
        from chatbis.xlsx import guess_field_columns
        g = guess_field_columns(["Description", "Column"])
        self.assertEqual(g["label"], 0)
        self.assertEqual(g["db2"], 1)

    def test_json_array_of_objects(self):
        from chatbis.xlsx import read_field_map
        raw = json.dumps([{"label": "DOB", "cobol_field": "WS-DOB",
                           "json_path": "claimant.dateOfBirth"}]).encode()
        headers, rows = read_field_map(raw, "m.json")
        self.assertIn("cobol_field", headers)
        self.assertEqual(rows[0][headers.index("cobol_field")], "WS-DOB")

    def test_flat_crosswalk_dict(self):
        # The shape people paste when they already have COBOL -> JSON.
        from chatbis.xlsx import read_field_map
        raw = json.dumps({"WS-PAY-AMT": "payments[].amount"}).encode()
        headers, rows = read_field_map(raw, "x.json")
        self.assertEqual(headers, ["cobol_field", "json_path"])
        self.assertEqual(rows, [["WS-PAY-AMT", "payments[].amount"]])

    def test_ragged_json_objects_keep_every_key(self):
        from chatbis.xlsx import read_field_map
        raw = json.dumps([{"a": 1}, {"b": 2}]).encode()
        headers, rows = read_field_map(raw, "r.json")
        self.assertEqual(headers, ["a", "b"])
        self.assertEqual(rows, [["1", ""], ["", "2"]])

    def test_csv_and_empty(self):
        from chatbis.xlsx import read_field_map
        h, r = read_field_map(b"cobol,json\nWS-A,a.b\n", "m.csv")
        self.assertEqual(h, ["cobol", "json"])
        self.assertEqual(r, [["WS-A", "a.b"]])
        self.assertEqual(read_field_map(b"[]", "e.json"), ([], []))


if __name__ == "__main__":
    unittest.main()
