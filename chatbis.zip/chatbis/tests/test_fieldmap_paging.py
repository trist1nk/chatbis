"""The mapping component at production scale: ~1000 rows means search
and pages, and a row action must return the analyst to the exact
filtered view they were working in."""
import threading
import tempfile
import unittest
import urllib.parse
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

from chatbis import db
from chatbis.server import Handler


class FieldmapPaging(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.db_path = str(Path(cls.tmp.name) / "t.db")
        conn = db.connect(cls.db_path)
        for i in range(60):
            conn.execute(
                """INSERT INTO field_map (label, cobol_field, db2_column,
                   json_path, format, updated_by, updated_at)
                   VALUES (?,?,?,?,?,?,?)""",
                (f"Field {i:03}", f"WS-F-{i:03}", f"SCH.T.C{i:03}",
                 f"path.f{i:03}", "text", "t", db.now()))
        conn.commit()
        conn.close()
        Handler.db_path = cls.db_path
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.httpd.server_address[1]
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.tmp.cleanup()

    def get(self, path):
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}{path}") as r:
            return r.read().decode()

    def test_pages_of_25_with_a_pager(self):
        h = self.get("/settings?tab=fields")
        self.assertIn("Field mappings · 60", h)
        self.assertIn("1–25 of 60 · page 1 of 3", h)
        self.assertIn("WS-F-000", h)
        self.assertNotIn("WS-F-030", h)          # page 2's problem
        h3 = self.get("/settings?tab=fields&mp=3")
        self.assertIn("51–60 of 60 · page 3 of 3", h3)
        self.assertIn("WS-F-059", h3)

    def test_page_past_the_end_clamps(self):
        h = self.get("/settings?tab=fields&mp=99")
        self.assertIn("page 3 of 3", h)

    def test_search_filters_and_row_actions_return_there(self):
        h = self.get("/settings?tab=fields&q=F-04")
        self.assertIn("Field mappings · 10 matching", h)
        self.assertIn("WS-F-042", h)
        self.assertNotIn("WS-F-030", h)
        # the Set/Delete forms carry the filtered view as their return
        self.assertIn("name=back value='/settings?tab=fields&amp;q=F-04'", h)

    def test_pager_line_shows_even_on_a_single_page(self):
        # 23 rows looked pageless before — the count line must always
        # render so the paging is discoverable.
        h = self.get("/settings?tab=fields&q=F-04")
        self.assertIn("1–10 of 10 · page 1 of 1 · 25 per page", h)

    def test_add_form_is_its_own_card(self):
        h = self.get("/settings?tab=fields")
        self.assertIn("<div class=card><h2>Add a mapping</h2>", h)
        self.assertIn("<h2>Import &amp; export</h2>", h)

    def test_edit_roundtrip_returns_to_the_filtered_view(self):
        import re
        h = self.get("/settings?tab=fields&q=F-042")
        mid = re.search(r"fieldmap/edit\?id=(\d+)", h).group(1)
        # the edit form carries the row's values
        e = self.get(f"/settings/fieldmap/edit?id={mid}"
                     f"&back=%2Fsettings%3Ftab%3Dfields%26q%3DF-042")
        self.assertIn("value='WS-F-042'", e)
        self.assertIn("value='SCH.T.C042'", e)
        # update it
        data = urllib.parse.urlencode({
            "id": mid, "back": "/settings?tab=fields&q=F-042",
            "label": "Renamed 042", "cobol_field": "WS-F-042",
            "db2_column": "SCH.T.C042", "json_path": "path.renamed",
            "format": "decimal", "notes": "edited"}).encode()
        req = urllib.request.Request(
            f"http://127.0.0.1:{self.port}/settings/fieldmap/update",
            data=data)
        with urllib.request.urlopen(req) as r:
            final = r.geturl()
        self.assertIn("q=F-042", final)      # landed back on the filter
        h2 = self.get("/settings?tab=fields&q=F-042")
        self.assertIn("Renamed 042", h2)
        self.assertIn("path.renamed", h2)

    def test_delete_lives_on_the_edit_screen_not_the_row(self):
        h = self.get("/settings?tab=fields")
        self.assertNotIn("Delete</button></form></td>", h)   # rows: Edit only
        # a disposable row of our own, so the fixture's 60 stay intact
        conn = db.connect(self.db_path)
        conn.execute(
            """INSERT INTO field_map (label, cobol_field, json_path,
               updated_by, updated_at) VALUES (?,?,?,?,?)""",
            ("Disposable", "WS-DISPOSABLE", "x.y", "t", db.now()))
        conn.commit()
        mid = conn.execute("SELECT id FROM field_map WHERE"
                           " cobol_field='WS-DISPOSABLE'").fetchone()[0]
        conn.close()
        e = self.get(f"/settings/fieldmap/edit?id={mid}")
        self.assertIn("Delete this mapping", e)
        data = urllib.parse.urlencode({
            "kind": "fieldmap", "id": mid,
            "back": "/settings?tab=fields"}).encode()
        req = urllib.request.Request(
            f"http://127.0.0.1:{self.port}/settings/delete", data=data)
        with urllib.request.urlopen(req) as r:
            self.assertIn("tab=fields", r.geturl())
        h2 = self.get("/settings?tab=fields&q=DISPOSABLE")
        self.assertIn("Nothing matches", h2)

    def test_no_match_says_so(self):
        h = self.get("/settings?tab=fields&q=zzz-nope")
        self.assertIn("Nothing matches", h)


if __name__ == "__main__":
    unittest.main()
