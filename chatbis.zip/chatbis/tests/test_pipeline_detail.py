"""Pipeline detail screen lifecycle over real HTTP.

The editing invariants: move renumbers 10/20/30 (never fractional drift),
remove and dissolve clear ALL stage fields but never touch the application
itself or its source, rename carries every stage, and add refuses to steal
an app that already belongs to a pipeline.
"""
import sqlite3
import sys
import tempfile
import threading
import unittest
import urllib.parse
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from chatbis import db
from chatbis.server import Handler


class PipelineDetail(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.db_path = str(Path(cls.tmp.name) / "t.db")
        conn = db.connect(cls.db_path)
        for i, name in enumerate(("ALPHA", "BETA", "GAMMA"), start=1):
            aid = db.get_or_create_app(conn, name)
            conn.execute("UPDATE application SET pipeline='FLOW', stage_seq=?,"
                         " stage_role='builds' WHERE id=?", (i * 10, aid))
        db.get_or_create_app(conn, "LOOSE")          # standalone
        other = db.get_or_create_app(conn, "TAKEN")  # in another pipeline
        conn.execute("UPDATE application SET pipeline='OTHER', stage_seq=10"
                     " WHERE id=?", (other,))
        conn.commit()
        conn.close()
        Handler.db_path = cls.db_path
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.httpd.server_address[1]
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.tmp.cleanup()

    def get(self, path):
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}{path}") as r:
            return r.read().decode()

    def post(self, path, data):
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}{path}",
                urllib.parse.urlencode(data).encode()) as r:
            return r.read().decode()

    def rows(self, pipeline="FLOW"):
        c = sqlite3.connect(self.db_path)
        c.row_factory = sqlite3.Row
        out = [dict(r) for r in c.execute(
            "SELECT name, stage_seq, stage_role, pipeline FROM application"
            " WHERE pipeline = ? AND COALESCE(lane,'') != 'online'"
            " ORDER BY stage_seq", (pipeline,))]
        c.close()
        return out

    def app(self, name):
        c = sqlite3.connect(self.db_path)
        c.row_factory = sqlite3.Row
        r = c.execute("SELECT * FROM application WHERE name = ?",
                      (name,)).fetchone()
        c.close()
        return dict(r)

    def aid(self, name):
        return self.app(name)["id"]

    def test_01_detail_renders_in_order(self):
        html = self.get("/pipeline?name=FLOW")
        self.assertLess(html.index("ALPHA"), html.index("BETA"))
        self.assertLess(html.index("BETA"), html.index("GAMMA"))
        self.assertIn("Add a stage", html)
        # Only truly standalone apps are offered — TAKEN belongs elsewhere.
        self.assertIn("LOOSE", html)
        self.assertNotIn("TAKEN", html)

    def test_02_move_swaps_and_renumbers(self):
        self.post("/pipeline/move", {"name": "FLOW", "app_id": self.aid("GAMMA"),
                                     "dir": "up"})
        self.assertEqual([r["name"] for r in self.rows()],
                         ["ALPHA", "GAMMA", "BETA"])
        self.assertEqual([r["stage_seq"] for r in self.rows()], [10, 20, 30])
        self.post("/pipeline/move", {"name": "FLOW", "app_id": self.aid("GAMMA"),
                                     "dir": "down"})
        self.assertEqual([r["name"] for r in self.rows()],
                         ["ALPHA", "BETA", "GAMMA"])

    def test_03_move_past_the_edge_is_a_noop(self):
        self.post("/pipeline/move", {"name": "FLOW", "app_id": self.aid("ALPHA"),
                                     "dir": "up"})
        self.assertEqual([r["name"] for r in self.rows()],
                         ["ALPHA", "BETA", "GAMMA"])

    def test_04_stage_edit_updates_role_and_areas(self):
        self.post("/pipeline/stage", {"name": "FLOW", "app_id": self.aid("BETA"),
                                      "stage_role": "validates",
                                      "reads": "tda", "writes": "pda, log"})
        b = self.app("BETA")
        self.assertEqual(b["stage_role"], "validates")
        self.assertEqual(b["reads"], '["TDA"]')
        self.assertEqual(b["writes"], '["PDA", "LOG"]')

    def test_05_add_appends_and_respects_ownership(self):
        self.post("/pipeline/add", {"name": "FLOW", "app_id": self.aid("LOOSE"),
                                    "stage_role": "writes", "reads": "PDA",
                                    "writes": ""})
        self.assertEqual([r["name"] for r in self.rows()],
                         ["ALPHA", "BETA", "GAMMA", "LOOSE"])
        self.assertEqual(self.app("LOOSE")["stage_seq"], 40)
        # An app already in another pipeline cannot be stolen.
        self.post("/pipeline/add", {"name": "FLOW", "app_id": self.aid("TAKEN")})
        self.assertEqual(self.app("TAKEN")["pipeline"], "OTHER")

    def test_06_remove_clears_stage_fields_keeps_the_app(self):
        self.post("/pipeline/stage", {"name": "FLOW", "app_id": self.aid("LOOSE"),
                                      "remove": "1"})
        l = self.app("LOOSE")
        self.assertIsNone(l["pipeline"])
        self.assertIsNone(l["stage_seq"])
        self.assertIsNone(l["stage_role"])
        self.assertIsNone(l["reads"])
        self.assertEqual(len(self.rows()), 3)

    def test_07_rename_carries_every_stage(self):
        self.post("/pipeline/rename", {"name": "FLOW", "new_name": "FLOW V2"})
        self.assertEqual(len(self.rows("FLOW")), 0)
        self.assertEqual([r["name"] for r in self.rows("FLOW V2")],
                         ["ALPHA", "BETA", "GAMMA"])

    def test_08_dissolve_frees_the_apps_deletes_nothing(self):
        self.post("/pipeline/dissolve", {"name": "FLOW V2"})
        self.assertEqual(self.rows("FLOW V2"), [])
        for name in ("ALPHA", "BETA", "GAMMA"):
            a = self.app(name)
            self.assertIsNone(a["pipeline"])     # freed
            self.assertIsNotNone(a["id"])        # not deleted
        # The other pipeline is untouched.
        self.assertEqual(self.app("TAKEN")["pipeline"], "OTHER")

    def test_08b_online_lane_joins_without_a_seq(self):
        aid = self.aid("LOOSE")
        # LOOSE is standalone again after test_06; add it to OTHER's lane.
        self.post("/pipeline/add", {"name": "OTHER", "app_id": aid,
                                    "lane": "online", "stage_role": ""})
        l = self.app("LOOSE")
        self.assertEqual((l["pipeline"], l["lane"]), ("OTHER", "online"))
        self.assertIsNone(l["stage_seq"])          # not a step
        # The batch stage sequence is untouched by the lane.
        self.assertEqual([r["name"] for r in self.rows("OTHER")], ["TAKEN"])
        html = self.get("/pipeline?name=OTHER")
        self.assertIn("Online lane", html)
        self.assertIn("1 batch stages", html)
        self.assertIn("online lane (1)", html)
        # Remove clears the lane marker with everything else.
        self.post("/pipeline/stage", {"name": "OTHER", "app_id": aid,
                                      "remove": "1"})
        l = self.app("LOOSE")
        self.assertIsNone(l["pipeline"])
        self.assertIsNone(l["lane"])

    def test_09_unknown_pipeline_returns_to_apps(self):
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, *a, **kw):
                return None
        op = urllib.request.build_opener(NoRedirect)
        try:
            r = op.open(f"http://127.0.0.1:{self.port}/pipeline?name=NOPE")
            status, loc = r.status, r.headers.get("Location")
        except urllib.error.HTTPError as e:
            status, loc = e.code, e.headers.get("Location")
        self.assertEqual(status, 303)
        self.assertEqual(loc, "/apps")


if __name__ == "__main__":
    unittest.main()
