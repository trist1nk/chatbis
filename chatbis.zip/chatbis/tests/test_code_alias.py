"""The A2U804 quirk: MI reports codes wearing a business-function prefix.
Aliases and prefixes are DECLARED equivalences — a merge or a registered
prefix — never guessed from shape."""
import tempfile
import threading
import unittest
import urllib.parse
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

from chatbis import db
from chatbis.server import Handler


class CodeAlias(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.db_path = str(Path(cls.tmp.name) / "t.db")
        conn = db.connect(cls.db_path)
        cls.mined_id = db.upsert_exception(
            conn, "U804", meaning="Update rejected - prior period open",
            status="curated")
        # the MI duplicate, as an import would have created it
        cls.dup_id = db.upsert_exception(conn, "A2U804")
        conn.execute(
            """INSERT INTO exception_event (exception_id, kind, outcome,
               payload, actor, ts) VALUES (?, 'mi', NULL,
               '{"src":"mi.xlsx","count":57}', 'import', ?)""",
            (cls.dup_id, db.now()))
        conn.commit()
        cls.conn = conn
        Handler.db_path = cls.db_path
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.httpd.server_address[1]
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.conn.close()
        cls.tmp.cleanup()

    def get(self, path):
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}{path}") as r:
            return r.read().decode()

    def post(self, path, data):
        req = urllib.request.Request(
            f"http://127.0.0.1:{self.port}{path}",
            data=urllib.parse.urlencode(data).encode())
        with urllib.request.urlopen(req) as r:
            return r.geturl()

    def test_01_undeclared_prefix_does_not_resolve(self):
        # Before any declaration, B9U804 must NOT silently collapse into
        # U804 — an undeclared prefix is a guess, and guesses are refused.
        self.assertIsNone(db.resolve_exception(self.conn, "B9U804"))

    def test_02_duplicate_page_suggests_the_merge(self):
        norm = db.normalize_code("A2U804")
        h = self.get(f"/x/{urllib.parse.quote(norm)}")
        self.assertIn("looks like", h)
        self.assertIn("U804", h)
        self.assertIn("declare A2", h)
        self.assertIn("whose prefix?", h)

    def test_03_merge_moves_evidence_and_future_imports_resolve(self):
        norm = db.normalize_code("A2U804")
        final = self.post(f"/x/{urllib.parse.quote(norm)}/merge",
                          {"into": "U804", "declare_prefix": "A2"})
        self.assertIn(db.normalize_code("U804"), final)
        # the duplicate entry is gone; its MI event moved to the survivor
        self.assertIsNone(self.conn.execute(
            "SELECT id FROM exception_code WHERE normalized = ?",
            (norm,)).fetchone())
        n = self.conn.execute(
            "SELECT COUNT(*) FROM exception_event WHERE exception_id = ?"
            " AND kind = 'mi'", (self.mined_id,)).fetchone()[0]
        self.assertEqual(n, 1)
        # future MI code A2U804 resolves straight to the survivor…
        self.assertEqual(db.resolve_exception(self.conn, "A2U804"),
                         self.mined_id)
        # …and so does ANY code wearing the now-declared prefix
        db.upsert_exception(self.conn, "U901", status="curated")
        self.conn.commit()
        self.assertEqual(
            db.resolve_exception(self.conn, "A2U901"),
            self.conn.execute(
                "SELECT id FROM exception_code WHERE normalized = ?",
                (db.normalize_code("U901"),)).fetchone()["id"])
        # resolve_exception RECORDS the learned alias — commit it, or this
        # connection holds a write lock that blocks the server's requests
        self.conn.commit()

    def test_04_survivor_page_lists_the_alias(self):
        h = self.get(f"/x/{db.normalize_code('U804')}")
        self.assertIn("Also reported as", h)
        self.assertIn("A2U804", h)


class CategoryCuration(unittest.TestCase):
    """The code page's category selector: the shop's six-value taxonomy,
    changed by the analyst, logged as curation."""

    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.db_path = str(Path(cls.tmp.name) / "t.db")
        conn = db.connect(cls.db_path)
        cls.eid = db.upsert_exception(conn, "S06", category="suspension")
        conn.commit()
        cls.conn = conn
        Handler.db_path = cls.db_path
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.httpd.server_address[1]
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.conn.close()
        cls.tmp.cleanup()

    def test_selector_offers_the_full_taxonomy_and_change_is_logged(self):
        norm = db.normalize_code("S06")
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}/x/{norm}") as r:
            h = r.read().decode()
        for label in ("Exception", "Processing limitation (Proclim)",
                      "Alert", "Suspension", "Termination", "Indicator"):
            self.assertIn(label, h)
        urllib.request.urlopen(urllib.request.Request(
            f"http://127.0.0.1:{self.port}/x/{norm}/category",
            data=urllib.parse.urlencode(
                {"category": "termination"}).encode())).read()
        row = self.conn.execute(
            "SELECT category FROM exception_code WHERE id=?",
            (self.eid,)).fetchone()
        self.assertEqual(row["category"], "termination")
        ev = self.conn.execute(
            """SELECT outcome FROM exception_event WHERE exception_id=?
               AND kind='curated' ORDER BY id DESC LIMIT 1""",
            (self.eid,)).fetchone()
        self.assertEqual(ev["outcome"], "category-changed")

    def test_garbage_category_is_refused(self):
        norm = db.normalize_code("S06")
        urllib.request.urlopen(urllib.request.Request(
            f"http://127.0.0.1:{self.port}/x/{norm}/category",
            data=urllib.parse.urlencode(
                {"category": "made-up"}).encode())).read()
        row = self.conn.execute(
            "SELECT category FROM exception_code WHERE id=?",
            (self.eid,)).fetchone()
        self.assertIn(row["category"],
                      {"suspension", "termination"})   # unchanged by junk


class ApplicationPrefix(unittest.TestCase):
    """The prefix lives on the application that owns it — resolution and
    MI attribution flow from the same declared fact."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.conn = db.connect(str(Path(self.tmp.name) / "t.db"))
        self.aid = db.get_or_create_app(self.conn, "RETIRE-BF")
        self.conn.execute("UPDATE application SET mi_prefix='A2'"
                          " WHERE id=?", (self.aid,))
        self.uid = db.upsert_exception(self.conn, "U804", status="curated")
        self.conn.commit()

    def tearDown(self):
        self.conn.close()
        self.tmp.cleanup()

    def test_app_prefix_resolves_mi_codes(self):
        self.assertEqual(db.resolve_exception(self.conn, "A2U804"),
                         self.uid)
        self.conn.commit()
        # and the alias was learned for the survivor's page
        a = self.conn.execute(
            "SELECT exception_id FROM code_alias WHERE alias=?",
            (db.normalize_code("A2U804"),)).fetchone()
        self.assertEqual(a["exception_id"], self.uid)

    def test_prefix_names_the_owning_application(self):
        self.assertEqual(db.app_for_code_prefix(self.conn, "A2U804"),
                         "RETIRE-BF")
        self.assertIsNone(db.app_for_code_prefix(self.conn, "B9U804"))


class SmeCitations(unittest.TestCase):
    """SMEs curate the code↔policy links: add citations by reference,
    annotate mined hits, remove only what SMEs added."""

    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.db_path = str(Path(cls.tmp.name) / "t.db")
        conn = db.connect(cls.db_path)
        cls.exc_id = db.upsert_exception(conn, "E5510", status="curated",
                                         meaning="Ent precedes DOB")
        cur = conn.execute(
            """INSERT INTO document (title, path, doc_type, kind,
               ingested_at) VALUES ('Entitlement Policy', '/p1', 'txt',
               'policy', ?)""", (db.now(),))
        cls.doc_id = cur.lastrowid
        conn.execute(
            """INSERT INTO doc_section (document_id, heading, ord, text)
               VALUES (?, 'RS 00605.362 C.1 Entitlement date', 0,
               'The entitlement date may not precede the DOB.')""",
            (cls.doc_id,))
        conn.commit()
        cls.conn = conn
        Handler.db_path = cls.db_path
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.httpd.server_address[1]
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.conn.close()
        cls.tmp.cleanup()

    def get(self, path):
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}{path}") as r:
            return r.read().decode()

    def post(self, path, data):
        urllib.request.urlopen(urllib.request.Request(
            f"http://127.0.0.1:{self.port}{path}",
            data=urllib.parse.urlencode(data).encode())).read()

    def test_01_add_citation_binds_the_matching_section(self):
        norm = db.normalize_code("E5510")
        self.post(f"/x/{norm}/cite",
                  {"doc_id": self.doc_id, "citation": "RS 00605.362",
                   "sme_note": "governs the DOB check", "sme_by": "TK"})
        l = self.conn.execute(
            "SELECT * FROM exception_link WHERE provenance='sme'").fetchone()
        import json as j
        d = j.loads(l["detail"])
        self.assertEqual(d["citation"], "RS 00605.362")
        self.assertIn("section_id", d)              # heading matched
        h = self.get(f"/x/{norm}")
        self.assertIn("CITATION", h)
        self.assertIn("RS 00605.362", h)
        self.assertIn("governs the DOB check", h)
        self.assertIn("— TK", h)

    def test_02_annotate_updates_in_place(self):
        norm = db.normalize_code("E5510")
        l = self.conn.execute(
            "SELECT id FROM exception_link WHERE provenance='sme'").fetchone()
        self.post(f"/x/{norm}/link/{l['id']}/annotate",
                  {"citation": "RS 00605.362 C.1",
                   "sme_note": "updated wording"})
        import json as j
        d = j.loads(self.conn.execute(
            "SELECT detail FROM exception_link WHERE id=?",
            (l["id"],)).fetchone()["detail"])
        self.assertEqual(d["citation"], "RS 00605.362 C.1")
        self.assertEqual(d["sme_note"], "updated wording")

    def test_03_only_sme_links_are_removable(self):
        norm = db.normalize_code("E5510")
        db.add_link(self.conn, self.exc_id, "document", "1", "governed_by",
                    detail={"doc_id": self.doc_id, "heading": "mined"},
                    provenance="mined")
        self.conn.commit()
        mined = self.conn.execute(
            "SELECT id FROM exception_link WHERE provenance='mined'"
            " AND relation='governed_by'").fetchone()
        self.post(f"/x/{norm}/link/{mined['id']}/remove", {})
        self.assertIsNotNone(self.conn.execute(
            "SELECT id FROM exception_link WHERE id=?",
            (mined["id"],)).fetchone(), "mined evidence must survive")
        sme = self.conn.execute(
            "SELECT id FROM exception_link WHERE provenance='sme'").fetchone()
        self.post(f"/x/{norm}/link/{sme['id']}/remove", {})
        self.assertIsNone(self.conn.execute(
            "SELECT id FROM exception_link WHERE id=?",
            (sme["id"],)).fetchone())


if __name__ == "__main__":
    unittest.main()
