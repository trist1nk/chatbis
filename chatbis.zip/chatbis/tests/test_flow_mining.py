"""Flow-edge and SQL-pair mining invariants.

The flow graph must never fabricate lineage: literals and figurative
constants are not sources, comments and data division are not flows, and a
column/host count mismatch in SQL yields nothing rather than a shifted —
plausible but wrong — pairing.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from chatbis.mine import mine, normalize_lines, pair_sql


def run(src: str):
    return mine(normalize_lines(src.split("\n"), "free"))


PROC = """       IDENTIFICATION DIVISION.
       PROGRAM-ID. T1.
       PROCEDURE DIVISION.
       MAIN.
"""


class TestFlowEdges(unittest.TestCase):
    def test_simple_move(self):
        r = run(PROC + "           MOVE IN-DOB TO TDA-BENE-DOB.")
        self.assertEqual([(f.source, f.target, f.verb) for f in r.flows],
                         [("IN-DOB", "TDA-BENE-DOB", "move")])

    def test_multi_target_move_fans_out(self):
        r = run(PROC + "           MOVE WS-RATE TO TDA-RATE PDA-RATE.")
        self.assertEqual({f.target for f in r.flows}, {"TDA-RATE", "PDA-RATE"})
        self.assertTrue(all(f.source == "WS-RATE" for f in r.flows))

    def test_giving_arithmetic(self):
        r = run(PROC + "           ADD WS-A WS-B GIVING TDA-TOTAL.")
        self.assertEqual({(f.source, f.target) for f in r.flows},
                         {("WS-A", "TDA-TOTAL"), ("WS-B", "TDA-TOTAL")})

    def test_literal_and_figurative_are_not_sources(self):
        r = run(PROC + """           MOVE 'E1234' TO WS-ERR-CD.
           MOVE SPACES TO TDA-NAME.
           MOVE ZEROS TO TDA-AMT.""")
        self.assertEqual(r.flows, [])

    def test_data_division_move_in_comment_is_not_a_flow(self):
        r = run("""       IDENTIFICATION DIVISION.
       PROGRAM-ID. T2.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      * MOVE IN-X TO OUT-Y happens later
       01  WS-A PIC X.
       PROCEDURE DIVISION.
       MAIN.
           GOBACK.""")
        self.assertEqual(r.flows, [])

    def test_subscripted_source(self):
        r = run(PROC + "           MOVE WS-ENT (WS-IDX) TO PDA-ENT.")
        self.assertEqual([(f.source, f.target) for f in r.flows],
                         [("WS-ENT", "PDA-ENT")])


class TestSqlPairs(unittest.TestCase):
    def test_select_into(self):
        maps = pair_sql("SELECT BENE_DOB, CLM_TYPE INTO :WS-DOB, :WS-TYPE"
                        " FROM MCS.CLAIM WHERE SSN = :WS-SSN", 10)
        self.assertEqual([(m.column, m.host, m.stmt) for m in maps],
                         [("MCS.CLAIM.BENE_DOB", "WS-DOB", "select"),
                          ("MCS.CLAIM.CLM_TYPE", "WS-TYPE", "select")])

    def test_insert_values(self):
        maps = pair_sql("INSERT INTO CLAIM_LEDGER (POLICY_NO, CLM_AMT)"
                        " VALUES (:WS-POL, :WS-AMT)", 20)
        self.assertEqual([(m.column, m.host) for m in maps],
                         [("CLAIM_LEDGER.POLICY_NO", "WS-POL"),
                          ("CLAIM_LEDGER.CLM_AMT", "WS-AMT")])

    def test_update_set(self):
        maps = pair_sql("UPDATE MCS.CLAIM SET CLM_STAT = :WS-STAT,"
                        " PAID_DT = :WS-PAID-DT WHERE CLM_NO = :WS-CLM", 30)
        self.assertEqual([(m.column, m.host) for m in maps],
                         [("MCS.CLAIM.CLM_STAT", "WS-STAT"),
                          ("MCS.CLAIM.PAID_DT", "WS-PAID-DT")])

    def test_count_mismatch_yields_nothing(self):
        # Three columns, two hosts: positional pairing would silently shift.
        maps = pair_sql("SELECT A, B, C INTO :WS-A, :WS-B FROM T", 1)
        self.assertEqual(maps, [])

    def test_expression_columns_are_skipped(self):
        maps = pair_sql("SELECT COUNT(*) INTO :WS-N FROM T", 1)
        self.assertEqual(maps, [])          # COUNT(*) is not a column

    def test_where_hosts_are_not_pairs(self):
        maps = pair_sql("SELECT A INTO :WS-A FROM T WHERE B = :WS-B AND C > :WS-C", 1)
        self.assertEqual([(m.column, m.host) for m in maps], [("T.A", "WS-A")])


class TestCursors(unittest.TestCase):
    """DECLARE holds the columns, FETCH holds the hosts — different blocks,
    one contract, and the pairing must survive the separation."""

    BASE = """       IDENTIFICATION DIVISION.
       PROGRAM-ID. CURSTEST.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
           EXEC SQL
               DECLARE C1 CURSOR FOR
               SELECT COL_A, COL_B FROM SCH.TBL WHERE K = :WS-K
           END-EXEC.
       PROCEDURE DIVISION.
       MAIN.
           EXEC SQL OPEN C1 END-EXEC
           EXEC SQL FETCH C1 INTO :WS-A, :WS-B END-EXEC
           EXEC SQL CLOSE C1 END-EXEC
           GOBACK.
"""

    def test_fetch_pairs_against_the_declare(self):
        r = run(self.BASE)
        got = [(m.column, m.host, m.stmt) for m in r.sqlmaps]
        self.assertIn(("SCH.TBL.COL_A", "WS-A", "fetch"), got)
        self.assertIn(("SCH.TBL.COL_B", "WS-B", "fetch"), got)

    def test_count_mismatch_pairs_nothing(self):
        r = run(self.BASE.replace(":WS-A, :WS-B", ":WS-A"))
        self.assertEqual([m for m in r.sqlmaps if m.stmt == "fetch"], [])

    def test_undeclared_cursor_claims_nothing(self):
        r = run(self.BASE.replace("FETCH C1", "FETCH C9"))
        self.assertEqual([m for m in r.sqlmaps if m.stmt == "fetch"], [])

    def test_for_update_clause_does_not_break_columns(self):
        r = run(self.BASE.replace("WHERE K = :WS-K",
                                  "WHERE K = :WS-K FOR UPDATE OF COL_B"))
        self.assertIn(("SCH.TBL.COL_A", "WS-A"),
                      [(m.column, m.host) for m in r.sqlmaps])


class TestEndToEnd(unittest.TestCase):
    def test_full_program_flows_and_pairs(self):
        r = run("""       IDENTIFICATION DIVISION.
       PROGRAM-ID. DBPUT.
       PROCEDURE DIVISION.
       WRITE-CLAIM.
           MOVE PDA-BENE-DOB TO WS-DOB
           EXEC SQL
               INSERT INTO MCS.CLAIM (BENE_DOB) VALUES (:WS-DOB)
           END-EXEC
           GOBACK.""")
        self.assertEqual([(f.source, f.target) for f in r.flows],
                         [("PDA-BENE-DOB", "WS-DOB")])
        self.assertEqual([(m.column, m.host) for m in r.sqlmaps],
                         [("MCS.CLAIM.BENE_DOB", "WS-DOB")])
        # The two together are the last hop: PDA-BENE-DOB → WS-DOB → BENE_DOB.


if __name__ == "__main__":
    unittest.main()
