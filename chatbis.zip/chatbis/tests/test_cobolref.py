"""The COBOL reference: curated entries, blind-forgiving lookup,
refusal-with-suggestions on a miss."""
import unittest

from chatbis.cobolref import REFERENCE, lookup


class Lookup(unittest.TestCase):
    def test_case_space_hyphen_blind(self):
        for spelling in ("COMP-3", "comp3", "Comp 3", "COMPUTATIONAL-3"):
            self.assertEqual(lookup(spelling)["term"], "COMP-3", spelling)

    def test_aliases_resolve(self):
        self.assertEqual(lookup("packed decimal")["term"], "COMP-3")
        self.assertEqual(lookup("odo")["term"], "OCCURS DEPENDING ON")
        self.assertEqual(lookup("condition name")["term"], "88")
        self.assertEqual(lookup("ASRA")["term"], "S0C4")
        self.assertEqual(lookup("dup key... -803?  ") .get("term"),
                         None)   # sentences don't accidentally match

    def test_abends_and_sql_are_first_class(self):
        self.assertIn("Data exception", lookup("soc7")["meaning"])
        self.assertIn("-803", lookup("sqlcode")["meaning"])
        self.assertIn("CANCELLED", lookup("s222")["meaning"])

    def test_miss_refuses_with_suggestions(self):
        out = lookup("OCCURZ")
        self.assertIn("error", out)
        self.assertIn("hint", out)
        out = lookup("COMP")
        self.assertEqual(out["term"], "COMP")   # exact beats fuzzy

    def test_entry_hygiene(self):
        for key, e in REFERENCE.items():
            self.assertTrue(e.get("what"), f"{key} lacks a meaning")
            self.assertLess(len(e["what"]), 600, f"{key} rambles")

    def test_gotchas_ride_along(self):
        out = lookup("REDEFINES")
        self.assertIn("production_gotcha", out)
        self.assertIn("same bytes", out["production_gotcha"])


if __name__ == "__main__":
    unittest.main()
