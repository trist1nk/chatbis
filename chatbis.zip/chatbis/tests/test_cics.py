"""CICS mining + execution-mode classification.

The invariant that matters to this shop: a pure business-function module
CALLed by the nightly driver AND LINKed from a CICS screen is BOTH batch
and online — and the modes come from evidence (EXEC CICS in the source, a
mined JCL step) propagated through the call graph, never from naming.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from chatbis import db
from chatbis.mine import mine, normalize_lines
from chatbis.server import program_modes


def run(src: str):
    return mine(normalize_lines(src.split("\n"), "free"))


PROC = """       IDENTIFICATION DIVISION.
       PROGRAM-ID. T1.
       PROCEDURE DIVISION.
       MAIN.
"""


class TestCicsMining(unittest.TestCase):
    def test_link_and_xctl_are_call_edges(self):
        r = run(PROC + """           EXEC CICS LINK PROGRAM('BFRET') END-EXEC
           EXEC CICS XCTL PROGRAM('NEXTPGM') END-EXEC""")
        self.assertEqual([(c.op, c.ref) for c in r.cics],
                         [("link", "BFRET"), ("xctl", "NEXTPGM")])
        self.assertEqual([c.name for c in r.calls], ["BFRET", "NEXTPGM"])

    def test_maps_with_mapset(self):
        r = run(PROC + "           EXEC CICS SEND MAP('PS220M')"
                       " MAPSET('PS220S') ERASE END-EXEC")
        self.assertEqual(r.cics[0].op, "send-map")
        self.assertEqual(r.cics[0].ref, "PS220M")
        self.assertEqual(r.cics[0].mapset, "PS220S")

    def test_abend_code_becomes_an_emission(self):
        r = run(PROC + "           EXEC CICS ABEND ABCODE('AP22') END-EXEC")
        self.assertEqual([(e.code, e.field) for e in r.emissions],
                         [("AP22", "ABEND")])

    def test_abend_without_abcode_claims_nothing(self):
        r = run(PROC + "           EXEC CICS ABEND END-EXEC")
        self.assertEqual(r.emissions, [])

    def test_multiline_command_joins(self):
        r = run(PROC + """           EXEC CICS LINK PROGRAM('BFRET')
                COMMAREA(WS-COMM) END-EXEC""")
        self.assertEqual(r.calls[0].name, "BFRET")


class TestModes(unittest.TestCase):
    def setUp(self):
        import tempfile
        self.tmp = tempfile.TemporaryDirectory()
        self.conn = db.connect(str(Path(self.tmp.name) / "t.db"))
        c = self.conn

        def prog(name, cics=False, calls=()):
            c.execute("INSERT INTO source_file (path, name, kind, encoding,"
                      " fmt, line_count, content_hash, ingested_at)"
                      " VALUES (?,?,?,?,?,?,?,?)",
                      (f"/x/{name}.cbl", f"{name}.cbl", "cobol", "utf-8",
                       "fixed", 10, name, db.now()))
            fid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            c.execute("INSERT INTO program (source_file_id, name) VALUES (?,?)",
                      (fid, name))
            pid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            if cics:
                c.execute("INSERT INTO program_facet (program_id, kind, ref,"
                          " line, detail) VALUES (?,'cics','M',1,'{}')", (pid,))
            for callee in calls:
                c.execute("INSERT INTO program_facet (program_id, kind, ref,"
                          " line, detail) VALUES (?,'call',?,1,'{}')",
                          (pid, callee))

        # OPS220 (CICS screen) links BFRET; batch driver BATDRV calls BFRET;
        # BFRET calls PIACOMP; ORPHAN has no evidence at all.
        prog("OPS220", cics=True, calls=["BFRET"])
        prog("BATDRV", calls=["BFRET"])
        prog("BFRET", calls=["PIACOMP"])
        prog("PIACOMP")
        prog("ORPHAN")
        c.execute("INSERT INTO source_file (path, name, kind, encoding, fmt,"
                  " line_count, content_hash, ingested_at)"
                  " VALUES ('/x/j.jcl','j.jcl','jcl','utf-8','free',5,'j',?)",
                  (db.now(),))
        fid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
        c.execute("INSERT INTO jcl_job (source_file_id, name) VALUES (?,'J')",
                  (fid,))
        jid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
        c.execute("INSERT INTO jcl_step (job_id, seq, step_name, pgm)"
                  " VALUES (?,1,'S1','BATDRV')", (jid,))
        c.commit()

    def tearDown(self):
        self.conn.close()
        self.tmp.cleanup()

    def test_direct_evidence(self):
        m = program_modes(self.conn)
        self.assertEqual(m["OPS220"], {"online"})
        self.assertIn("batch", m["BATDRV"])

    def test_dual_mode_module(self):
        # BFRET: LINKed by the screen, CALLed by the batch driver → BOTH.
        m = program_modes(self.conn)
        self.assertEqual(m["BFRET"], {"online", "batch"})

    def test_modes_propagate_transitively(self):
        # PIACOMP is only called by BFRET, and inherits both of its modes.
        m = program_modes(self.conn)
        self.assertEqual(m["PIACOMP"], {"online", "batch"})

    def test_no_evidence_no_claim(self):
        m = program_modes(self.conn)
        self.assertEqual(m.get("ORPHAN", set()), set())


if __name__ == "__main__":
    unittest.main()
