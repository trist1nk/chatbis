"""The readiness cache: computed once per corpus generation, invalidated
by ANY change to what readiness depends on — including direct SQL edits
that leave row counts and timestamps untouched."""
import tempfile
import time
import unittest
from pathlib import Path

from chatbis import db
from chatbis.ingest import ingest_paths
from chatbis.server import Handler, corpus_generation


def build_corpus(conn, src: Path, n_programs=40):
    aid = db.get_or_create_app(conn, "SCALE")
    for i in range(6):
        (src / f"CB{i}.cpy").write_text(
            f"       01  CB{i}-AREA.\n"
            f"           05  CB{i}-F1        PIC X(10).\n")
    for n in range(n_programs):
        (src / f"RP{n:03}.cbl").write_text(
            "       IDENTIFICATION DIVISION.\n"
            f"       PROGRAM-ID. RP{n:03}.\n"
            "       DATA DIVISION.\n"
            "       WORKING-STORAGE SECTION.\n"
            f"       COPY CB{n % 6}.\n"
            "       01  WS-PGM              PIC X(08).\n"
            "       01  WS-E                PIC X(05).\n"
            "       PROCEDURE DIVISION.\n"
            "       MAIN.\n"
            f"           MOVE 'RP{(n + 1) % n_programs:03}' TO WS-PGM\n"
            "           CALL WS-PGM USING WS-E\n"
            "           CALL 'MISSUTIL' USING WS-E\n"
            "           GOBACK.\n")
    ingest_paths(conn, sorted(src.glob("*.cpy")) + sorted(src.glob("*.cbl")),
                 app_id=aid)
    conn.commit()


PROGS_SQL = """SELECT p.id, p.name, f.id AS file_id, a.name AS app_name,
               a.id AS app_id, a.pipeline, a.stage_seq
               FROM program p JOIN source_file f ON f.id = p.source_file_id
               LEFT JOIN application a ON a.id = f.application_id"""


class ReadinessCache(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.conn = db.connect(str(Path(cls.tmp.name) / "t.db"))
        build_corpus(cls.conn, Path(cls.tmp.name))
        cls.h = Handler.__new__(Handler)
        cls.progs = cls.conn.execute(PROGS_SQL).fetchall()

    @classmethod
    def tearDownClass(cls):
        cls.conn.close()
        cls.tmp.cleanup()

    def test_warm_pass_is_effectively_free(self):
        self.h._cobrun_worklist(self.conn, self.progs)   # cold
        t0 = time.time()
        self.h._cobrun_worklist(self.conn, self.progs)   # warm
        self.assertLess(time.time() - t0, 0.05,
                        "the cached pass must not recompute closures")

    def test_stubbing_invalidates_and_flips_verdicts(self):
        wl = self.h._cobrun_worklist(self.conn, self.progs)
        blocked_before = len(wl["verdicts"]["blocked"])
        self.assertEqual(blocked_before, len(self.progs))   # MISSUTIL
        self.conn.execute(
            "INSERT INTO runner_stub (name, created_at) VALUES (?, ?)",
            ("MISSUTIL", db.now()))
        self.conn.commit()
        wl2 = self.h._cobrun_worklist(self.conn, self.progs)
        self.assertEqual(len(wl2["verdicts"]["blocked"]), 0,
                         "stub must invalidate the cache and unblock")
        self.conn.execute("DELETE FROM runner_stub WHERE name='MISSUTIL'")
        self.conn.commit()

    def test_direct_sql_edit_moves_the_generation(self):
        # An UPDATE that changes no count, no id, no length — the exact
        # case a MAX/COUNT fingerprint misses. The digest must move.
        self.conn.execute(
            """INSERT INTO field_map (label, db2_column, json_path, format,
               updated_by, updated_at) VALUES ('G','S.T.C','a.b','decimal',
               't','2026-01-01T00:00:00')""")
        self.conn.commit()
        g1 = corpus_generation(self.conn)
        self.conn.execute(
            "UPDATE field_map SET format='integer' WHERE db2_column='S.T.C'")
        self.conn.commit()
        g2 = corpus_generation(self.conn)
        self.assertNotEqual(g1, g2)
        self.conn.execute("DELETE FROM field_map WHERE db2_column='S.T.C'")
        self.conn.commit()

    def test_dynamic_calls_resolve_through_the_literal_index(self):
        calls = self.h._call_closure(self.conn, self.progs[0]["name"])
        self.assertTrue(any(via.startswith("dynamic via") and st == "resolved"
                            for _, st, via, _ in calls),
                        f"dynamic chain broken: {calls[:4]}")


if __name__ == "__main__":
    unittest.main()
