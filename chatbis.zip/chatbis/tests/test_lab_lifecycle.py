"""Recipe lifecycle over real HTTP: list -> new -> create -> edit -> delete.

Runs the actual handler against a temp database, so the routes, the redirects
and the two-step delete are exercised the way an analyst hits them.

The invariant worth guarding: deleting a recipe must remove the authored work
and NOTHING else. The exception code, its mined source links and its MI
history are shared assets — losing them to a recipe delete would be silent
data loss that no one notices until the catalog is wrong.
"""
import json
import sqlite3
import sys
import tempfile
import threading
import unittest
import urllib.parse
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from chatbis import db
from chatbis.server import Handler


class LabLifecycle(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.db_path = str(Path(cls.tmp.name) / "t.db")
        conn = db.connect(cls.db_path)   # connect() applies the schema
        # One code the miner understood, one it could not, one with volume.
        eid = db.upsert_exception(conn, "E4417", category="exception",
                                  meaning="DOB after entitlement")
        db.add_link(conn, eid, "program", "POLVAL01", "emitted_by",
                    detail={"condition": "IF WS-BENE-DOB > WS-EFF-DATE",
                            "file": "polval01.cbl", "line": 412})
        hard = db.upsert_exception(conn, "E5005", category="exception",
                                   meaning="Term plan over age 70")
        db.add_link(conn, hard, "program", "PREMCALC", "emitted_by",
                    detail={"condition": "IF PLAN-TERM AND WS-ISSUE-AGE > 70",
                            "file": "premcalc.cbl", "line": 88})
        db.add_event(conn, eid, "mi", payload={"count": 1240, "period": "2026-07"})
        for label, cob, jp in (("DOB", "WS-BENE-DOB", "claimant.dateOfBirth"),
                               ("Eff date", "WS-EFF-DATE", "claim.entitlementDate")):
            conn.execute("INSERT INTO field_map (label, cobol_field, json_path,"
                         " updated_by, updated_at) VALUES (?,?,?,?,?)",
                         (label, cob, jp, "test", db.now()))
        conn.commit()
        conn.close()

        Handler.db_path = cls.db_path
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.httpd.server_address[1]
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.tmp.cleanup()

    def get(self, path, follow=True):
        url = f"http://127.0.0.1:{self.port}{path}"
        if follow:
            with urllib.request.urlopen(url) as r:
                return r.status, r.read().decode(), r.url
        req = urllib.request.Request(url)
        op = urllib.request.build_opener(NoRedirect)
        try:
            with op.open(req) as r:
                return r.status, r.read().decode(), r.headers.get("Location")
        except urllib.error.HTTPError as e:
            return e.code, "", e.headers.get("Location")

    def post(self, path, data):
        body = urllib.parse.urlencode(data).encode()
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}{path}", body) as r:
            return r.status, r.read().decode()

    def playbook(self, code="4417"):
        c = sqlite3.connect(self.db_path)
        c.row_factory = sqlite3.Row
        r = c.execute("SELECT p.* FROM playbook p JOIN exception_code e"
                      " ON e.id = p.exception_id WHERE e.normalized = ?",
                      (code,)).fetchone()
        c.close()
        return r

    # ── ordered: the lifecycle is the test ────────────────────────────
    def test_01_empty_list_invites_the_first_recipe(self):
        _, html, _ = self.get("/lab")
        self.assertIn("No recipes yet", html)
        self.assertIn("/lab/new", html)

    def test_02_new_screen_ranks_and_reports_draftability(self):
        _, html, _ = self.get("/lab/new")
        self.assertIn("Start with 1 drafted check", html)   # E4417 is draftable
        self.assertIn("1 draftable", html)
        # E5005's AND cannot be translated, and we say so rather than guess.
        self.assertIn("none translatable", html)
        self.assertLess(html.index("E4417"), html.index("E5005"))  # volume first

    def test_03_create_seeds_from_source_as_likely(self):
        _, html = self.post("/lab/create", {"code": "4417", "seed": "1"})
        self.assertIn("Recipe created for E4417", html)
        checks = json.loads(self.playbook()["checks"])
        self.assertEqual(len(checks), 1)
        self.assertEqual(checks[0]["path"], "claimant.dateOfBirth")
        self.assertEqual(checks[0]["op"], "gt")
        self.assertEqual(checks[0]["value"], "$$.claim.entitlementDate")
        self.assertEqual(checks[0]["confidence"], "likely")

    def test_04_created_recipe_appears_in_the_list_with_its_volume(self):
        _, html, _ = self.get("/lab")
        self.assertIn("E4417", html)
        self.assertIn("1240", html)                 # MI volume drives the order
        self.assertIn("/lab/edit?code=4417", html)

    def test_05_new_screen_no_longer_offers_it(self):
        _, html, _ = self.get("/lab/new")
        self.assertNotIn(">E4417<", html)

    def test_06_creating_twice_just_opens_the_existing_recipe(self):
        before = self.playbook()["checks"]
        _, html = self.post("/lab/create", {"code": "4417", "seed": "1"})
        self.assertEqual(self.playbook()["checks"], before)   # not duplicated

    def test_07_edit_without_a_code_returns_to_the_list(self):
        status, _, loc = self.get("/lab/edit", follow=False)
        self.assertEqual(status, 303)
        self.assertEqual(loc, "/lab")

    def test_08_delete_asks_first_and_shows_what_is_lost(self):
        _, html = self.post("/lab/delete", {"code": "4417"})
        self.assertIn("Delete the recipe for E4417?", html)
        self.assertIn("You would lose", html)
        self.assertIn("claimant.dateOfBirth", html)      # the check, in English
        self.assertIsNotNone(self.playbook())            # nothing deleted yet

    def test_09_confirmed_delete_removes_only_the_recipe(self):
        c = sqlite3.connect(self.db_path)
        links_before = c.execute("SELECT COUNT(*) FROM exception_link").fetchone()[0]
        mi_before = c.execute("SELECT COUNT(*) FROM exception_event"
                              " WHERE kind='mi'").fetchone()[0]
        c.close()

        _, html = self.post("/lab/delete", {"code": "4417", "confirm": "1"})
        self.assertIn("deleted", html)
        self.assertIsNone(self.playbook())

        c = sqlite3.connect(self.db_path)
        self.assertIsNotNone(c.execute("SELECT 1 FROM exception_code"
                                       " WHERE normalized='4417'").fetchone())
        self.assertEqual(c.execute("SELECT COUNT(*) FROM exception_link"
                                   ).fetchone()[0], links_before)
        self.assertEqual(c.execute("SELECT COUNT(*) FROM exception_event"
                                   " WHERE kind='mi'").fetchone()[0], mi_before)
        self.assertIsNotNone(c.execute(
            "SELECT 1 FROM exception_event WHERE"
            " json_extract(payload,'$.via')='lab-delete'").fetchone())
        c.close()

    def test_10_deleted_code_is_offered_again(self):
        _, html, _ = self.get("/lab/new")
        self.assertIn("Start with 1 drafted check", html)

    def test_11_deleting_a_missing_recipe_is_not_an_error(self):
        _, html = self.post("/lab/delete", {"code": "4417", "confirm": "1"})
        self.assertIn("no longer exists", html)


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **kw):
        return None


if __name__ == "__main__":
    unittest.main()
