"""Compared-to modes: "a value" vs "another field".

The engine's field references need a $. (same occurrence) or $$. (case
level) prefix. Analysts should never have to know that: in field mode a
bare path is prefixed on save — same-occurrence when the check reads a
repeating group, case-level otherwise — and explicit prefixes always win.
"""
import json
import sqlite3
import sys
import tempfile
import threading
import unittest
import urllib.parse
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from chatbis import db
from chatbis.server import Handler


class ValueModes(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.db_path = str(Path(cls.tmp.name) / "t.db")
        conn = db.connect(cls.db_path)
        db.upsert_exception(conn, "E1000", category="exception")
        conn.commit()
        conn.close()
        Handler.db_path = cls.db_path
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.httpd.server_address[1]
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.tmp.cleanup()

    def save(self, **check_fields):
        data = {"code": "1000", "actor": "t",
                "gc_group_0": "", "gc_order_0": "", "gc_latest_0": "max_start"}
        defaults = {"kind_0": "compare", "group_0": "", "scope_0": "latest",
                    "path_0": "a.b", "op_0": "eq", "value_0": "", "vmode_0": "value",
                    "cause_0": "", "screen_0": "", "fix_0": "",
                    "conf_0": "definitive", "steps_0": ""}
        defaults.update(check_fields)
        data.update(defaults)
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}/lab/save",
                urllib.parse.urlencode(data).encode()) as r:
            r.read()
        c = sqlite3.connect(self.db_path)
        row = c.execute("SELECT checks FROM playbook p JOIN exception_code e"
                        " ON e.id=p.exception_id WHERE e.normalized='1000'"
                        ).fetchone()
        c.close()
        return json.loads(row[0])[0]

    def test_field_mode_prefixes_case_level(self):
        c = self.save(vmode_0="field", value_0="claim.entitlementDate")
        self.assertEqual(c["value"], "$$.claim.entitlementDate")

    def test_field_mode_prefixes_same_row_inside_a_group(self):
        c = self.save(vmode_0="field", value_0="startDate",
                      group_0="entitlementPeriods", path_0="endDate")
        self.assertEqual(c["value"], "$.startDate")

    def test_explicit_prefix_wins_over_the_heuristic(self):
        c = self.save(vmode_0="field", value_0="$$.dateOfDeath",
                      group_0="entitlementPeriods", path_0="endDate")
        self.assertEqual(c["value"], "$$.dateOfDeath")   # not re-prefixed

    def test_value_mode_stays_literal(self):
        c = self.save(vmode_0="value", value_0="RETIREMENT")
        self.assertEqual(c["value"], "RETIREMENT")

    def test_editor_reopens_in_the_right_mode(self):
        self.save(vmode_0="field", value_0="claim.entitlementDate")
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}/lab/edit?code=1000") as r:
            html = r.read().decode()
        self.assertIn("<option value=field selected>another field", html)
        # And a literal check renders in value mode.
        self.save(vmode_0="value", value_0="RETIREMENT")
        with urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}/lab/edit?code=1000") as r:
            html = r.read().decode()
        self.assertIn("<option value=value selected>a value", html)


if __name__ == "__main__":
    unittest.main()
