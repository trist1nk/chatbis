"""ChatBIS mining invariants: normalization variants collapse, EBCDIC decodes,
fixed-format strips, the MOVE/88-level miners find codes, and the walk-back
heuristic quotes the governing IF. Run: python3 -m unittest discover tests"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from chatbis.db import normalize_code
from chatbis.mine import (
    decode_bytes, detect_format, mine, normalize_lines, search_tokens,
    split_records,
)


def prep(src: str):
    lines = src.strip("\n").split("\n")
    return normalize_lines(lines, detect_format(lines))


class TestNormalize(unittest.TestCase):
    def test_variants_collapse(self):
        self.assertEqual(normalize_code("E4417"), "4417")
        self.assertEqual(normalize_code("4417"), "4417")
        self.assertEqual(normalize_code("ERR-4417"), "4417")
        self.assertEqual(normalize_code("err_4417"), "4417")

    def test_system_codes_keep_identity(self):
        self.assertEqual(normalize_code("S0C7"), "S0C7")
        self.assertEqual(normalize_code("ASRA"), "ASRA")
        self.assertNotEqual(normalize_code("S222"), normalize_code("E222"))


class TestDecoding(unittest.TestCase):
    def test_ebcdic_roundtrip(self):
        src = "MOVE 'E4417' TO WS-ERR-CD"
        text, enc = decode_bytes(src.encode("cp037"))
        self.assertEqual(enc, "cp037")
        self.assertIn("E4417", text)

    def test_utf8_passthrough(self):
        text, enc = decode_bytes(b"PROGRAM-ID. TEST.")
        self.assertEqual(enc, "utf-8")

    def test_80_byte_records_without_newlines(self):
        rec = ("A" * 80) + ("B" * 80)
        self.assertEqual(len(split_records(rec)), 2)


class TestFixedFormat(unittest.TestCase):
    SRC = "\n".join([
        "000100 IDENTIFICATION DIVISION.                                         SEQNAME1",
        "000200 PROGRAM-ID. FIXTEST.                                             SEQNAME1",
        "000300* A COMMENT LINE                                                  SEQNAME1",
    ])

    def test_detect_and_strip(self):
        lines = self.SRC.split("\n")
        self.assertEqual(detect_format(lines), "fixed")
        norm = normalize_lines(lines, "fixed")
        self.assertNotIn("000100", norm[0].text)
        self.assertNotIn("SEQNAME1", norm[0].text)
        self.assertTrue(norm[2].comment)


class TestMining(unittest.TestCase):
    def test_move_emission_with_walkback(self):
        res = mine(prep("""
       PROGRAM-ID. T1.
       PROCEDURE DIVISION.
       CHECK-PARA.
           IF WS-BENE-DOB > WS-EFF-DATE
              MOVE 'E4417' TO WS-ERR-CD
           END-IF.
"""))
        self.assertEqual(len(res.emissions), 1)
        em = res.emissions[0]
        self.assertEqual(em.code, "E4417")
        self.assertEqual(em.field, "WS-ERR-CD")
        self.assertEqual(em.paragraph, "CHECK-PARA")
        self.assertIn("WS-BENE-DOB > WS-EFF-DATE", em.condition)
        self.assertGreaterEqual(em.confidence, 0.7)

    def test_move_to_non_error_field_ignored(self):
        res = mine(prep("""
       PROCEDURE DIVISION.
       P1.
           MOVE 'HELLO' TO WS-GREETING-TEXT.
"""))
        self.assertEqual(res.emissions, [])

    def test_88_levels_and_copy_and_call(self):
        res = mine(prep("""
       01 WS-ERR-CD PIC X(5).
          88 ERR-DUP VALUE 'E2088'.
           COPY ERRCODES.
       PROCEDURE DIVISION.
       P1.
           CALL 'SUBPROG' USING WS-ERR-CD.
"""))
        self.assertIn(("ERR-DUP", "E2088", 2), res.level88)
        self.assertEqual(res.copies[0][0], "ERRCODES")
        self.assertEqual(res.calls[0].name, "SUBPROG")

    def test_sql_block_tables(self):
        res = mine(prep("""
       PROCEDURE DIVISION.
       P1.
           EXEC SQL
              INSERT INTO CLAIM_LEDGER (A) VALUES (:B)
           END-EXEC.
"""))
        self.assertEqual(len(res.sql), 1)
        self.assertIn("CLAIM_LEDGER", res.sql[0].tables)


class TestSearchTokens(unittest.TestCase):
    def test_hyphenated_identifier_matches_both_ways(self):
        toks = search_tokens("MOVE WS-CUST-NAME TO OUT-REC")
        self.assertIn("wsxcustxname", toks.split())  # verbatim form, one token
        self.assertIn("cust", toks.split())          # component form
        # And a query for the full identifier produces the same joined token.
        self.assertIn("wsxcustxname", search_tokens("WS-CUST-NAME").split())


class TestDataItems(unittest.TestCase):
    def test_pic_lengths(self):
        from chatbis.mine import pic_info
        self.assertEqual(pic_info("X(10)"), ("alphanumeric", 10))
        self.assertEqual(pic_info("9(8)"), ("numeric", 8))
        self.assertEqual(pic_info("S9(7)V99", "COMP-3"), ("packed", 5))
        self.assertEqual(pic_info("9(4)", "COMP"), ("binary", 2))
        self.assertEqual(pic_info("S9(9)", "COMP"), ("binary", 4))
        self.assertEqual(pic_info("ZZ,ZZ9.99"), ("numeric-edited", 9))
        self.assertEqual(pic_info(None), ("group", None))

    def test_data_item_mining(self):
        res = mine(prep("""
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-POLICY-REC.
           05 WS-POL-NUMBER      PIC X(10).
           05 WS-PREM-AMT        PIC S9(7)V99 COMP-3.
           05 WS-BENE-ENTRY OCCURS 500 TIMES.
              10 WS-BENE-ID      PIC X(9).
           05 FILLER             PIC X(5).
       PROCEDURE DIVISION.
       MAIN-PARA.
           MOVE ZERO TO WS-PREM-AMT.
"""))
        names = {d.name: d for d in res.data_items}
        self.assertIn("WS-POLICY-REC", names)
        self.assertEqual(names["WS-POLICY-REC"].item_type, "group")
        self.assertEqual(names["WS-POL-NUMBER"].length, 10)
        self.assertEqual(names["WS-PREM-AMT"].item_type, "packed")
        self.assertEqual(names["WS-PREM-AMT"].length, 5)
        self.assertEqual(names["WS-BENE-ENTRY"].occurs, 500)
        self.assertNotIn("FILLER", names)
        # Nothing from PROCEDURE DIVISION leaks in as a data item.
        self.assertNotIn("MAIN-PARA", names)




class TestBusinessRules(unittest.TestCase):
    def test_translate_condition(self):
        from chatbis.mine import translate_condition as t
        self.assertEqual(t("IF WS-ELIG-DATE < 20160101"),
                         "ELIG DATE is before 2016-01-01")
        self.assertEqual(t("IF WS-PLAN-CODE = SPACES"), "PLAN CODE is blank")
        self.assertEqual(t("IF WS-BENE-COUNT >= WS-BENE-MAX"),
                         "BENE COUNT is at least BENE MAX")
        self.assertEqual(t("IF WS-PREM-AMT NOT NUMERIC"), "PREM AMT is not numeric")
        self.assertEqual(t("IF A = 1 AND B NOT = 2"), "A is 1 and B is not 2")

    def test_rule_extraction_with_consequences(self):
        res = mine(prep("""
       PROCEDURE DIVISION.
       MAIN-PARA.
           IF WS-ELIG-DATE < 20160101
              MOVE 'E7001' TO WS-ERR-CD
              PERFORM WRITE-REJECT
           END-IF
           IF WS-PLAN-CODE = SPACES
              DISPLAY 'WARNING - PLAN CODE MISSING'
           END-IF.
"""))
        self.assertEqual(len(res.rules), 2)
        r1, r2 = res.rules
        self.assertEqual(r1.code, "E7001")
        self.assertIn("raises E7001", r1.actions)
        self.assertIn("performs WRITE-REJECT", r1.actions)
        self.assertEqual(r1.paragraph, "MAIN-PARA")
        self.assertEqual(r1.english, "ELIG DATE is before 2016-01-01")
        self.assertIsNone(r2.code)
        self.assertTrue(any("WARNING" in a for a in r2.actions))

    def test_evaluate_when_gets_its_subject(self):
        res = mine(prep("""
       PROCEDURE DIVISION.
       P1.
           EVALUATE SQLCODE
              WHEN -803
                 MOVE 'E2088' TO WS-ERR-CD
              WHEN OTHER
                 CONTINUE
           END-EVALUATE.
"""))
        rules = [r for r in res.rules if r.code == "E2088"]
        self.assertEqual(len(rules), 1)
        self.assertEqual(rules[0].english, "SQLCODE is -803")
        # WHEN OTHER is a catch-all, not a rule
        self.assertEqual(len(res.rules), 1)




class TestComplexRules(unittest.TestCase):
    def test_nested_if_context_and_action_ownership(self):
        res = mine(prep("""
       PROCEDURE DIVISION.
       P1.
           IF PLAN-WHOLE
              IF WS-ISSUE-AGE > 75
                 IF WS-FACE-AMT > 100000
                    MOVE 'E5011' TO WS-ERR-CD
                 END-IF
              END-IF
           END-IF.
"""))
        outer, mid, inner = res.rules
        self.assertEqual(outer.actions, [])          # gates claim nothing
        self.assertEqual(mid.context, ["PLAN WHOLE"])
        self.assertEqual(inner.context,
                         ["PLAN WHOLE", "ISSUE AGE is greater than 75"])
        self.assertEqual(inner.code, "E5011")        # only the innermost raises

    def test_period_ends_if_scope(self):
        res = mine(prep("""
       PROCEDURE DIVISION.
       P1.
           IF WS-A = 1
              MOVE 'E1001' TO WS-ERR-CD.
           IF WS-B = 2
              MOVE 'E1002' TO WS-ERR-CD.
"""))
        self.assertEqual(res.rules[1].context, [])   # old-style period scoping

    def test_sign_condition_and_setter_actions(self):
        from chatbis.mine import translate_condition as t
        self.assertEqual(t("IF WS-FACE-AMT IS NEGATIVE"), "FACE AMT is negative")
        res = mine(prep("""
       PROCEDURE DIVISION.
       P1.
           EVALUATE TRUE
              WHEN WS-ISSUE-AGE < 18
                 MOVE 'JUV' TO WS-RATE-CLASS
              WHEN OTHER
                 COMPUTE WS-ANNUAL-PREM = 1
           END-EVALUATE.
"""))
        self.assertIn("sets RATE CLASS to JUV", res.rules[0].actions)



if __name__ == "__main__":
    unittest.main()
