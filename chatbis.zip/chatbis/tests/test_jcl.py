"""JCL parser invariants: step order is preserved, continuations join,
comments never become statements, IF gates scope the steps inside them,
and dataset seams only connect steps that genuinely share a DSN — with
direction claimed only when DISP proves the writer.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from chatbis.jcl import dataset_seams, looks_like_jcl, parse_jcl

CORPUS = (Path(__file__).resolve().parent.parent
          / "content/t2-test/jcl/T2NIGHT.jcl").read_text()


class TestSniff(unittest.TestCase):
    def test_jcl_detected(self):
        self.assertTrue(looks_like_jcl(CORPUS))
        self.assertTrue(looks_like_jcl("\n\n//A JOB X\n"))

    def test_cobol_is_not_jcl(self):
        self.assertFalse(looks_like_jcl("       IDENTIFICATION DIVISION."))


class TestParse(unittest.TestCase):
    def setUp(self):
        self.job = parse_jcl(CORPUS)

    def test_job_name(self):
        self.assertEqual(self.job.name, "T2NIGHT")

    def test_steps_in_order_with_programs(self):
        self.assertEqual([s.pgm for s in self.job.steps],
                         ["TDABUILD", "EVNTANLZ", "WEEDCHK", "PDABUILD",
                          "BFRETIRE", "BFSURV", "BFDISAB", "DBPUT",
                          "NOTIFDRV"])
        self.assertEqual([s.name for s in self.job.steps],
                         ["STEP010", "STEP020", "STEP030", "STEP040",
                          "STEP050", "STEP055", "STEP057", "STEP060",
                          "STEP070"])

    def test_continuation_joins_the_job_card(self):
        # NOTIFY rode a continuation line; parsing must not create a
        # phantom statement from it.
        self.assertEqual(len(self.job.steps), 9)

    def test_comments_are_not_statements(self):
        self.assertNotIn("T2 NIGHTLY - BUILDS",
                         " ".join(s.name for s in self.job.steps))

    def test_dd_dsn_and_disp(self):
        s1 = self.job.steps[0]
        dds = {d.dd: (d.dsn, d.disp) for d in s1.dds if d.dsn}
        self.assertEqual(dds["INTRAN"], ("PROD.DAILY.TRANS", "SHR"))
        self.assertEqual(dds["TDAOUT"], ("PROD.T2.TDA.WORK", "NEW"))

    def test_sysout_dd_has_no_dsn(self):
        s1 = self.job.steps[0]
        sysout = [d for d in s1.dds if d.dd == "SYSOUT"]
        self.assertEqual(len(sysout), 1)
        self.assertIsNone(sysout[0].dsn)

    def test_if_gate_scopes_the_steps_inside(self):
        gates = {s.name: s.gate for s in self.job.steps}
        self.assertIsNone(gates["STEP030"])
        self.assertIn("STEP030.RC", gates["STEP040"])
        self.assertIn("STEP030.RC", gates["STEP060"])

    def test_cond_captured_verbatim(self):
        s5 = self.job.steps[4]
        self.assertEqual(s5.cond, "(8,LE,STEP040)")

    def test_bare_exec_is_a_proc(self):
        job = parse_jcl("//J JOB A\n//S1 EXEC MYPROC,PARM1=X\n")
        self.assertIsNone(job.steps[0].pgm)
        self.assertEqual(job.steps[0].proc, "MYPROC")


class TestSeams(unittest.TestCase):
    def test_shared_datasets_connect_steps(self):
        seams = dataset_seams(parse_jcl(CORPUS))
        tda = [s for s in seams if s["dsn"] == "PROD.T2.TDA.WORK"]
        pda = [s for s in seams if s["dsn"] == "PROD.T2.PDA.WORK"]
        # TDA written by STEP010, read by 020/030/040.
        self.assertEqual({s["to_step"] for s in tda},
                         {"STEP020", "STEP030", "STEP040"})
        self.assertTrue(all(s["from_step"] == "STEP010" and s["directed"]
                            for s in tda))
        self.assertEqual({s["to_step"] for s in pda},
                         {"STEP050", "STEP055", "STEP057", "STEP060"})

    def test_unshared_datasets_make_no_seam(self):
        seams = dataset_seams(parse_jcl(CORPUS))
        self.assertNotIn("PROD.T2.REJECTS", {s["dsn"] for s in seams})

    def test_gdg_generations_are_one_dataset(self):
        seams = dataset_seams(parse_jcl(CORPUS))
        audit = [s for s in seams if s["dsn"] == "PROD.T2.AUDIT"]
        self.assertEqual(len(audit), 1)
        self.assertEqual((audit[0]["from_step"], audit[0]["to_step"]),
                         ("STEP060", "STEP070"))
        self.assertTrue(audit[0]["directed"])    # (+1) created NEW = writer
        self.assertTrue(audit[0]["gdg"])

    def test_non_gdg_seams_unmarked(self):
        seams = dataset_seams(parse_jcl(CORPUS))
        tda = [s for s in seams if s["dsn"] == "PROD.T2.TDA.WORK"]
        self.assertTrue(tda and not tda[0]["gdg"])

    def test_shr_first_reference_is_not_claimed_as_writer(self):
        job = parse_jcl("//J JOB A\n"
                        "//S1 EXEC PGM=A\n//X DD DSN=P.Q,DISP=SHR\n"
                        "//S2 EXEC PGM=B\n//Y DD DSN=P.Q,DISP=SHR\n")
        seams = dataset_seams(job)
        self.assertEqual(len(seams), 1)
        self.assertFalse(seams[0]["directed"])   # both read; no writer proven


if __name__ == "__main__":
    unittest.main()
