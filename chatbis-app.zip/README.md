# ChatBIS — Exception Triage Workbench (prototype)

A feasibility prototype of the Exception Triage & Analysis Workbench spec
(v0.2). **Stock Python 3.9+ and SQLite only — nothing to install** — so the
folder can be copied onto any machine inside the network and pointed at real
source.

## Run it

```bash
python3 chatbis.py ingest fixtures/ --app POLICY-ADMIN   # a source tree / PDS dump + DFRs
python3 chatbis.py seed-demo           # optional: synthetic history for stats
python3 chatbis.py serve               # → http://127.0.0.1:8765
python3 chatbis.py lookup E4417        # console resolution summary
python3 -m unittest discover tests   # mining invariants
```

## What it demonstrates (maps to spec)

| Spec | Here |
|---|---|
| §5 exception catalog as the core | `exception_code` hub + typed `exception_link` edges |
| §5.1 code sources | MOVE-literal mining, 88-level mining, DISPLAY mining, error-table CSV import, built-in platform codes (S0C7, SQLCODE, ABENDs) |
| §5.2 triggering condition | IF/EVALUATE walk-back heuristic, quoted verbatim with confidence |
| §5.3 DFR rule linking | DFRs (`.md`/`.txt`/`.docx` via stdlib zip+XML) split into sections; explicit code mentions become `governed_by` links, quoted on the resolution page |
| §5.4 feedback loop | append-only `exception_event`; **lookups auto-logged**, resolutions via a 20-second form; stats computed from events |
| Finding taxonomy | every entry categorised **exception / alert / processing limitation**; DISPLAYed alerts and limitations get stable synthetic `ALT-`/`LIM-` codes when no literal code exists |
| Applications | register apps (`--app NAME` on ingest, or the Applications screen); files and DFRs carry their app |
| Analyst curation | resolution page → "curate this entry": the slow-path investigation becomes the curated fast-path answer |
| FR-3.5/3.6 EBCDIC + fixed format | cp037 decode, 80-byte record split, cols 1–6/73–80 strip — all tested |
| FR-4.2 hyphen-aware search | identifiers indexed verbatim **and** split (`WS-CUST-NAME` matches `cust`) |
| §11 screens | catalog (category tabs), **dashboard** (totals, coverage, hottest codes, recent resolutions), resolution page, log-resolution, curation, search (source + DFR hits), source viewer, **program detail** (paragraphs, copybooks, calls, SQL, messages, codes raised), applications |

## The future-proofing (the part to keep even if everything else is rewritten)

1. **`exception_code` is the hub.** Every fact attaches to an exception.
2. **`exception_link` is one typed edge table** — `target_kind` + `relation` +
   JSON `detail`. Screens, JCL jobs, tickets, run records: new strings, not
   new schema.
3. **`exception_event` is append-only.** Occurrences, runs, lookups,
   resolutions. Success rates and MTTR are queries, never counters, so new
   metrics need no backfill.

Swap SQLite→Postgres by rewriting `achat/db.py` only; the model transfers
unchanged (spec §9's recommendation).

## Deliberate prototype cuts

Pattern-based mining only (no grammar, no `COPY REPLACING`); dynamic codes
unresolved by design; DFR ingest (`.docx`/PDF) not wired (drop text files in
for now — `governed_by` links render when present); no auth; single user;
fixtures are **synthetic** COBOL.
