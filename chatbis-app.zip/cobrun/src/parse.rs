//! Source → AST. Recursive descent over a token stream; total over the
//! supported grammar, and a named refusal (never a guess) on the rest.

use crate::layout::{parse_pic, Item, Usage};

#[derive(Debug, Clone)]
pub struct Tok {
    pub text: String, // uppercased except quoted literals (kept verbatim)
    pub line: u32,
    pub is_lit: bool, // quoted literal
}

#[derive(Debug, Clone, PartialEq)]
pub enum Operand {
    Field(String),
    /// NAME (subscript) — one dimension; more is a ledger line.
    Sub(String, Box<Operand>),
    NumLit(String),
    StrLit(String),
    Zeros,
    Spaces,
    HighValues,
    LowValues,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RelOp {
    Eq,
    Ne,
    Gt,
    Lt,
    Ge,
    Le,
}

#[derive(Debug, Clone)]
pub enum Cond {
    Rel(Operand, RelOp, Operand),
    Is88(String),
    Not(Box<Cond>),
    And(Box<Cond>, Box<Cond>),
    Or(Box<Cond>, Box<Cond>),
}

#[derive(Debug, Clone)]
pub enum Expr {
    Op(Operand),
    Bin(char, Box<Expr>, Box<Expr>), // + - * /
}

#[derive(Debug, Clone)]
pub enum Stmt {
    Move { src: Operand, dsts: Vec<Operand>, line: u32 },
    Compute { dst: String, rounded: bool, expr: Expr, line: u32 },
    Arith { op: char, operand: Expr, tgt: String, giving: bool, line: u32 },
    If { cond: Cond, then: Vec<Stmt>, els: Vec<Stmt>, line: u32 },
    Evaluate { subject: Option<Operand>, // None = EVALUATE TRUE
               whens: Vec<(Vec<Operand>, Vec<Stmt>)>,
               when88: Vec<(String, Vec<Stmt>)>,
               other: Vec<Stmt>, line: u32 },
    Perform { para: String, thru: Option<String>, until: Option<Cond>,
              times: Option<Operand>, line: u32 },
    /// Inline PERFORM … END-PERFORM, with or without VARYING.
    PerformInline { var: Option<String>, from: Option<Operand>,
                    by: Option<Operand>, until: Option<Cond>,
                    body: Vec<Stmt>, line: u32 },
    SetTrue { cond: String, line: u32 },
    Display { parts: Vec<Operand>, line: u32 },
    Goback { line: u32 },
    Continue_,
    Call { target: Operand, using: Vec<String>, line: u32 },
    ExecSql { text: String, line: u32 },
    Open { mode: String, files: Vec<String>, line: u32 },
    Close { files: Vec<String>, line: u32 },
    Read { file: String, into: Option<String>, at_end: Vec<Stmt>, line: u32 },
    Write { rec: String, from: Option<String>, rewrite: bool, line: u32 },
}

#[derive(Debug)]
pub struct Program {
    pub name: String,
    /// SELECT <logical> ASSIGN TO <ddname>
    pub files: Vec<(String, String)>,
    /// EXEC SQL blocks outside the procedure division — cursor DECLAREs
    /// live in WORKING-STORAGE, and a cursor nobody registered cannot be
    /// opened.
    pub sql_declares: Vec<(String, u32)>,
    pub ws: Vec<Item>,
    pub linkage: Vec<Item>,
    pub using: Vec<String>,
    pub paragraphs: Vec<(String, Vec<Stmt>)>,
}

pub fn refuse(line: u32, what: &str) -> String {
    format!("HALT line {}: {} not implemented — refused, not guessed",
            line, what)
}

// ── tokenizer ─────────────────────────────────────────────────────────

pub fn tokenize(src: &str) -> Vec<Tok> {
    let mut out = Vec::new();
    for (ln, raw) in src.lines().enumerate() {
        let line = ln as u32 + 1;
        // fixed format: indicator col 7, code area 8..72
        let text: &str = if raw.len() > 6 {
            if raw.as_bytes()[6] == b'*' {
                continue;
            }
            let end = raw.len().min(72);
            &raw[7..end]
        } else {
            continue;
        };
        let b = text.as_bytes();
        let mut i = 0;
        while i < b.len() {
            let c = b[i];
            if c == b' ' {
                i += 1;
            } else if c == b'\'' || c == b'"' {
                let q = c;
                let start = i + 1;
                let mut j = start;
                while j < b.len() && b[j] != q {
                    j += 1;
                }
                out.push(Tok { text: text[start..j].to_string(), line,
                               is_lit: true });
                i = j + 1;
            } else {
                let start = i;
                while i < b.len() && b[i] != b' ' {
                    i += 1;
                }
                let mut t = &text[start..i];
                // split a trailing period off (sentence end) — but keep
                // periods inside numeric literals like 49.40 / .750
                while t.ends_with('.')
                    && !t[..t.len() - 1].bytes().all(|x| x.is_ascii_digit()
                                                     || x == b'.')
                {
                    t = &t[..t.len() - 1];
                    if !t.is_empty() {
                        out.push(Tok { text: t.to_uppercase(), line,
                                       is_lit: false });
                    }
                    out.push(Tok { text: ".".into(), line, is_lit: false });
                    t = "";
                }
                if !t.is_empty() {
                    if t.ends_with('.') && t[..t.len() - 1].bytes()
                        .all(|x| x.is_ascii_digit() || x == b'.')
                        && t.matches('.').count() > 1
                    {
                        // "49.40." — literal then sentence period
                        out.push(Tok { text: t[..t.len() - 1].into(), line,
                                       is_lit: false });
                        out.push(Tok { text: ".".into(), line,
                                       is_lit: false });
                    } else {
                        out.push(Tok { text: t.to_uppercase(), line,
                                       is_lit: false });
                    }
                }
            }
        }
    }
    out
}

// ── parser ────────────────────────────────────────────────────────────

pub struct P {
    pub toks: Vec<Tok>,
    pub pos: usize,
}

const VERBS: &[&str] = &[
    "MOVE", "COMPUTE", "ADD", "SUBTRACT", "MULTIPLY", "DIVIDE", "IF",
    "EVALUATE", "PERFORM", "SET", "DISPLAY", "GOBACK", "STOP", "CONTINUE",
    "EXIT", "CALL", "INITIALIZE", "INSPECT", "STRING", "UNSTRING", "SEARCH",
    "ACCEPT", "OPEN", "CLOSE", "READ", "WRITE", "REWRITE", "GO", "ALTER",
    "SORT", "MERGE", "CANCEL", "EXEC",
];

impl P {
    fn peek(&self) -> Option<&Tok> {
        self.toks.get(self.pos)
    }

    fn at(&self, s: &str) -> bool {
        self.peek().map(|t| !t.is_lit && t.text == s).unwrap_or(false)
    }

    fn eat(&mut self, s: &str) -> bool {
        if self.at(s) {
            self.pos += 1;
            true
        } else {
            false
        }
    }

    fn next(&mut self) -> Option<Tok> {
        let t = self.toks.get(self.pos).cloned();
        if t.is_some() {
            self.pos += 1;
        }
        t
    }

    fn line(&self) -> u32 {
        self.peek().map(|t| t.line).unwrap_or(0)
    }
}

/// Expand COPY members before tokenizing. Nested COPYs expand too; a cycle
/// or an absent member is a named halt, never a silent skip — the layout is
/// the storage, so a missing copybook cannot be papered over.
pub fn expand_copies(src: &str, books: &std::collections::HashMap<String, String>,
                     depth: usize, seen: &mut Vec<String>)
    -> Result<String, String> {
    if depth > 16 {
        return Err("COPY nesting too deep".into());
    }
    let mut out = String::new();
    for (ln, raw) in src.lines().enumerate() {
        let code = if raw.len() > 6 && raw.as_bytes()[6] != b'*' {
            &raw[7..raw.len().min(72)]
        } else {
            out.push_str(raw);
            out.push('\n');
            continue;
        };
        let up = code.to_uppercase();
        if let Some(rest) = up.trim_start().strip_prefix("COPY ") {
            if rest.contains(" REPLACING") {
                return Err(refuse(ln as u32 + 1, "COPY ... REPLACING"));
            }
            let name = rest.trim().trim_end_matches('.').trim().to_string();
            if seen.contains(&name) {
                return Err(format!("COPY cycle at {}", name));
            }
            let book = books.get(&name).ok_or_else(|| format!(
                "HALT line {}: COPY {} — copybook not supplied",
                ln as u32 + 1, name))?;
            seen.push(name.clone());
            let inner = expand_copies(book, books, depth + 1, seen)?;
            seen.pop();
            out.push_str(&inner);
            if !inner.ends_with('\n') {
                out.push('\n');
            }
            continue;
        }
        out.push_str(raw);
        out.push('\n');
    }
    Ok(out)
}

pub fn parse_program(src: &str) -> Result<Program, String> {
    let toks = tokenize(src);
    let mut p = P { toks, pos: 0 };

    // PROGRAM-ID.
    let mut name = String::new();
    while let Some(t) = p.peek() {
        if t.text == "PROGRAM-ID" {
            p.next();
            p.eat(".");
            name = p.next().map(|t| t.text).unwrap_or_default();
            break;
        }
        p.next();
    }
    if name.is_empty() {
        return Err("no PROGRAM-ID".into());
    }

    // Walk to the sections we implement; refuse FILE SECTION by name.
    let mut ws = Vec::new();
    let mut linkage = Vec::new();
    let mut sql_declares: Vec<(String, u32)> = Vec::new();
    let mut files: Vec<(String, String)> = Vec::new();
    loop {
        let Some(t) = p.peek().cloned() else { break };
        if !t.is_lit && t.text == "EXEC" {
            let line = t.line;
            p.next();
            let dialect = p.next().map(|d| d.text).unwrap_or_default();
            let mut words: Vec<String> = Vec::new();
            while let Some(x) = p.peek().cloned() {
                if !x.is_lit && x.text == "END-EXEC" {
                    p.next();
                    break;
                }
                let x = p.next().unwrap();
                words.push(if x.is_lit { format!("'{}'", x.text) } else { x.text });
            }
            p.eat(".");
            if dialect == "SQL" {
                sql_declares.push((words.join(" "), line));
            }
            continue;
        }
        match t.text.as_str() {
            "FILE-CONTROL" => {
                p.next();
                p.eat(".");
                while p.at("SELECT") {
                    p.next();
                    let logical = p.next().ok_or("SELECT name")?.text;
                    p.eat("ASSIGN");
                    p.eat("TO");
                    let dd = p.next().ok_or("ASSIGN TO ddname")?.text;
                    files.push((logical, dd));
                    // consume the rest of the entry
                    while let Some(x) = p.peek().cloned() {
                        if !x.is_lit && x.text == "." {
                            p.next();
                            break;
                        }
                        p.next();
                    }
                }
            }
            "FILE" if peek2(&p) == Some("SECTION") => {
                p.next();
                p.eat("SECTION");
                p.eat(".");
                // FD entries introduce record descriptions; skip the FD
                // clauses, keep the 01s as ordinary storage.
                loop {
                    if p.eat("FD") {
                        while let Some(x) = p.peek().cloned() {
                            if !x.is_lit && x.text == "." {
                                p.next();
                                break;
                            }
                            p.next();
                        }
                        ws.extend(parse_data_items(&mut p)?);
                    } else {
                        break;
                    }
                }
            }
            "WORKING-STORAGE" => {
                p.next();
                p.eat("SECTION");
                p.eat(".");
                // extend, never assign — the FILE SECTION's record
                // descriptions are already in ws and must survive.
                ws.extend(parse_data_items(&mut p)?);
            }
            "LINKAGE" => {
                p.next();
                p.eat("SECTION");
                p.eat(".");
                linkage = parse_data_items(&mut p)?;
            }
            "PROCEDURE" => break,
            _ => {
                p.next();
            }
        }
    }

    // PROCEDURE DIVISION [USING a b].
    let mut using = Vec::new();
    if p.eat("PROCEDURE") {
        p.eat("DIVISION");
        if p.eat("USING") {
            while let Some(t) = p.peek() {
                if t.text == "." {
                    break;
                }
                using.push(p.next().unwrap().text);
            }
        }
        p.eat(".");
    } else {
        return Err("no PROCEDURE DIVISION".into());
    }

    // Paragraphs.
    let mut paragraphs: Vec<(String, Vec<Stmt>)> = Vec::new();
    while let Some(t) = p.peek().cloned() {
        if !t.is_lit && !VERBS.contains(&t.text.as_str())
            && peek2(&p) == Some(".")
        {
            p.next();
            p.eat(".");
            paragraphs.push((t.text, Vec::new()));
            continue;
        }
        let stmts = parse_sentence(&mut p)?;
        match paragraphs.last_mut() {
            Some((_, body)) => body.extend(stmts),
            None => paragraphs.push(("(MAIN)".into(), stmts)),
        }
    }
    Ok(Program { name, sql_declares, files, ws, linkage, using,
                 paragraphs })
}

fn peek2(p: &P) -> Option<&str> {
    p.toks.get(p.pos + 1).map(|t| t.text.as_str())
}

fn parse_data_items(p: &mut P) -> Result<Vec<Item>, String> {
    let mut items = Vec::new();
    while let Some(t) = p.peek().cloned() {
        if t.is_lit || t.text.parse::<u8>().is_err() {
            break; // next section/division
        }
        let level: u8 = t.text.parse().unwrap();
        let line = t.line;
        p.next();
        let name = p.next().ok_or("data entry cut short")?.text;
        let mut it = Item {
            level,
            name,
            pic: None,
            usage: Usage::Display,
            occurs: 1,
            redefines: None,
            value: None,
            cond_values: vec![],
            line,
        };
        while let Some(t) = p.peek().cloned() {
            if t.text == "." && !t.is_lit {
                p.next();
                break;
            }
            match t.text.as_str() {
                "PIC" | "PICTURE" => {
                    p.next();
                    p.eat("IS");
                    let ptok = p.next().ok_or("PIC without picture")?;
                    it.pic = Some(parse_pic(&ptok.text).ok_or_else(|| {
                        refuse(ptok.line,
                               &format!("PICTURE '{}'", ptok.text))
                    })?);
                }
                "COMP-3" | "PACKED-DECIMAL" => {
                    p.next();
                    it.usage = Usage::Comp3;
                }
                "COMP" | "COMP-4" | "BINARY" => {
                    p.next();
                    it.usage = Usage::Binary;
                }
                "USAGE" => {
                    p.next();
                    p.eat("IS");
                }
                "DISPLAY" => {
                    p.next();
                }
                "VALUE" | "VALUES" => {
                    p.next();
                    p.eat("IS");
                    p.eat("ARE");
                    if level == 88 {
                        while let Some(v) = p.peek().cloned() {
                            if !v.is_lit && (v.text == "." || v.text.parse::<u8>().is_ok()) {
                                break;
                            }
                            it.cond_values.push(p.next().unwrap().text);
                        }
                    } else {
                        let v = p.next().ok_or("VALUE without literal")?;
                        it.value = Some(match v.text.as_str() {
                            "SPACES" | "SPACE" if !v.is_lit => " ".into(),
                            "ZEROS" | "ZERO" | "ZEROES" if !v.is_lit => "0".into(),
                            _ => v.text,
                        });
                    }
                }
                "OCCURS" => {
                    p.next();
                    let n = p.next().ok_or("OCCURS without count")?;
                    it.occurs = n.text.parse().map_err(|_| {
                        refuse(n.line, "non-literal OCCURS")
                    })?;
                    p.eat("TIMES");
                }
                "REDEFINES" => {
                    p.next();
                    it.redefines = Some(p.next().ok_or("REDEFINES")?.text);
                }
                other => {
                    return Err(refuse(t.line,
                                      &format!("data clause {}", other)));
                }
            }
        }
        items.push(it);
    }
    Ok(items)
}

fn operand(p: &mut P) -> Result<Operand, String> {
    let t = p.next().ok_or("operand expected")?;
    if t.is_lit {
        return Ok(Operand::StrLit(t.text));
    }
    Ok(match t.text.as_str() {
        "ZEROS" | "ZERO" | "ZEROES" => Operand::Zeros,
        "SPACES" | "SPACE" => Operand::Spaces,
        "HIGH-VALUES" | "HIGH-VALUE" => Operand::HighValues,
        "LOW-VALUES" | "LOW-VALUE" => Operand::LowValues,
        s if s.bytes().next().map(|c| c.is_ascii_digit() || c == b'.'
                                  || c == b'-' || c == b'+')
              .unwrap_or(false)
            && crate::num::Dec::parse(s).is_some() =>
            Operand::NumLit(s.into()),
        s => {
            // NAME(IDX) in one token, or NAME followed by a (IDX) token.
            if let Some((base, rest)) = s.split_once('(') {
                let inner = rest.trim_end_matches(')').trim().to_string();
                return Ok(Operand::Sub(base.into(),
                                       Box::new(sub_operand(&inner, t.line)?)));
            }
            let subbed = p.peek().map(|n| !n.is_lit && n.text.starts_with('('))
                .unwrap_or(false);
            if subbed {
                let tok = p.next().unwrap();
                let inner = tok.text.trim_start_matches('(')
                    .trim_end_matches(')').trim().to_string();
                return Ok(Operand::Sub(s.into(),
                                       Box::new(sub_operand(&inner, t.line)?)));
            }
            Operand::Field(s.into())
        }
    })
}

/// The inside of a subscript: an index name or a literal. Arithmetic in a
/// subscript is refused rather than half-supported.
fn sub_operand(text: &str, line: u32) -> Result<Operand, String> {
    let t = text.trim();
    if t.is_empty() {
        return Err(refuse(line, "empty subscript"));
    }
    if t.split_whitespace().count() > 1 {
        return Err(refuse(line, "expression in a subscript"));
    }
    Ok(if crate::num::Dec::parse(t).is_some() {
        Operand::NumLit(t.into())
    } else {
        Operand::Field(t.into())
    })
}

fn rel_op(p: &mut P) -> Result<(RelOp, bool), String> {
    p.eat("IS");
    let neg = p.eat("NOT");
    let t = p.next().ok_or("relation expected")?;
    let op = match t.text.as_str() {
        "=" | "EQUAL" | "EQUALS" => {
            p.eat("TO");
            RelOp::Eq
        }
        ">" | "GREATER" => {
            p.eat("THAN");
            if p.eat("OR") {
                p.eat("EQUAL");
                p.eat("TO");
                RelOp::Ge
            } else {
                RelOp::Gt
            }
        }
        "<" | "LESS" => {
            p.eat("THAN");
            if p.eat("OR") {
                p.eat("EQUAL");
                p.eat("TO");
                RelOp::Le
            } else {
                RelOp::Lt
            }
        }
        ">=" => RelOp::Ge,
        "<=" => RelOp::Le,
        other => return Err(refuse(t.line, &format!("relation {}", other))),
    };
    Ok((if neg {
        match op {
            RelOp::Eq => RelOp::Ne,
            RelOp::Gt => RelOp::Le,
            RelOp::Lt => RelOp::Ge,
            o => o,
        }
    } else {
        op
    }, false))
}

fn condition(p: &mut P, conds88: &dyn Fn(&str) -> bool) -> Result<Cond, String> {
    let mut left = condition_one(p, conds88)?;
    loop {
        if p.eat("AND") {
            let r = condition_one(p, conds88)?;
            left = Cond::And(Box::new(left), Box::new(r));
        } else if p.eat("OR") {
            let r = condition_one(p, conds88)?;
            left = Cond::Or(Box::new(left), Box::new(r));
        } else {
            return Ok(left);
        }
    }
}

fn condition_one(p: &mut P, conds88: &dyn Fn(&str) -> bool)
    -> Result<Cond, String> {
    if p.eat("NOT") {
        let inner = condition_one(p, conds88)?;
        return Ok(Cond::Not(Box::new(inner)));
    }
    let a = operand(p)?;
    if let Operand::Field(name) = &a {
        // an 88 name stands alone as a condition
        if conds88(name) {
            // A condition ends where a statement begins: any verb closes
            // it, as do the connectives and scope terminators. Without
            // this, "IF NOT TDA-EDIT-PASS MOVE …" looks for a relation and
            // finds MOVE.
            let ends = p.peek().map(|t| !t.is_lit
                && (VERBS.contains(&t.text.as_str())
                    || matches!(t.text.as_str(),
                                "." | "AND" | "OR" | "THEN" | "END-IF"
                                | "ELSE" | "WHEN" | "END-EVALUATE"
                                | "END-PERFORM" | "END-READ")))
                .unwrap_or(true);
            if ends {
                return Ok(Cond::Is88(name.clone()));
            }
        }
    }
    let (op, _) = rel_op(p)?;
    let b = operand(p)?;
    Ok(Cond::Rel(a, op, b))
}

fn expr(p: &mut P) -> Result<Expr, String> {
    // precedence: * / over + -
    fn term(p: &mut P) -> Result<Expr, String> {
        let mut l = Expr::Op(operand(p)?);
        loop {
            if p.eat("*") {
                l = Expr::Bin('*', Box::new(l), Box::new(Expr::Op(operand(p)?)));
            } else if p.eat("/") {
                l = Expr::Bin('/', Box::new(l), Box::new(Expr::Op(operand(p)?)));
            } else {
                return Ok(l);
            }
        }
    }
    let mut l = term(p)?;
    loop {
        if p.eat("+") {
            l = Expr::Bin('+', Box::new(l), Box::new(term(p)?));
        } else if p.eat("-") {
            l = Expr::Bin('-', Box::new(l), Box::new(term(p)?));
        } else {
            return Ok(l);
        }
    }
}

/// One sentence: statements up to the period (which closes every open IF).
fn parse_sentence(p: &mut P) -> Result<Vec<Stmt>, String> {
    let stmts = parse_stmts(p, &["."])?;
    p.eat(".");
    Ok(stmts)
}

fn parse_stmts(p: &mut P, until: &[&str]) -> Result<Vec<Stmt>, String> {
    let mut out = Vec::new();
    loop {
        let Some(t) = p.peek().cloned() else { return Ok(out) };
        if !t.is_lit && until.contains(&t.text.as_str()) {
            return Ok(out);
        }
        // A paragraph label ends the current run of statements. EXEC SQL
        // swallows its own period, so without this the next label reads as
        // an unknown verb.
        if !t.is_lit && !VERBS.contains(&t.text.as_str())
            && p.toks.get(p.pos + 1).map(|n| n.text == "." && !n.is_lit)
                .unwrap_or(false)
        {
            return Ok(out);
        }
        let line = t.line;
        match t.text.as_str() {
            "MOVE" => {
                p.next();
                let src = operand(p)?;
                if !p.eat("TO") {
                    return Err(refuse(line, "MOVE without TO"));
                }
                let mut dsts = Vec::new();
                while let Some(n) = p.peek() {
                    if n.is_lit || n.text == "." || VERBS.contains(&n.text.as_str())
                        || until.contains(&n.text.as_str()) {
                        break;
                    }
                    dsts.push(operand(p)?);
                }
                out.push(Stmt::Move { src, dsts, line });
            }
            "COMPUTE" => {
                p.next();
                let dst = p.next().ok_or("COMPUTE target")?.text;
                let rounded = p.eat("ROUNDED");
                if !p.eat("=") {
                    return Err(refuse(line, "COMPUTE without ="));
                }
                out.push(Stmt::Compute { dst, rounded, expr: expr(p)?, line });
            }
            "ADD" | "SUBTRACT" => {
                // Three real forms: ADD a TO b · ADD a b GIVING c ·
                // ADD a TO b GIVING c (and SUBTRACT … FROM …).
                let op = if t.text == "ADD" { '+' } else { '-' };
                p.next();
                let mut terms = vec![operand(p)?];
                while !p.at("TO") && !p.at("FROM") && !p.at("GIVING") {
                    let Some(n) = p.peek().cloned() else { break };
                    if n.is_lit || n.text == "."
                        || VERBS.contains(&n.text.as_str())
                        || until.contains(&n.text.as_str()) {
                        break;
                    }
                    terms.push(operand(p)?);
                }
                let mut acc = Expr::Op(terms.remove(0));
                for t2 in terms {
                    acc = Expr::Bin('+', Box::new(acc),
                                    Box::new(Expr::Op(t2)));
                }
                let joined = p.eat("TO") || p.eat("FROM");
                let base = if joined {
                    Some(p.next().ok_or("arith target")?.text)
                } else {
                    None
                };
                let giving = p.eat("GIVING");
                if !joined && !giving {
                    return Err(refuse(line, "ADD/SUBTRACT without TO/FROM/GIVING"));
                }
                if giving {
                    let tgt = p.next().ok_or("GIVING target")?.text;
                    // SUBTRACT a FROM b GIVING c is b - a; ADD a TO b
                    // GIVING c is b + a; without a base, the accumulated
                    // terms are the whole expression.
                    let e = match base {
                        Some(b) => {
                            let bx = Box::new(Expr::Op(Operand::Field(b)));
                            if op == '-' {
                                Expr::Bin('-', bx, Box::new(acc))
                            } else {
                                Expr::Bin('+', bx, Box::new(acc))
                            }
                        }
                        None => acc,
                    };
                    out.push(Stmt::Arith { op, operand: e, tgt, giving: true,
                                           line });
                } else {
                    out.push(Stmt::Arith { op, operand: acc,
                                           tgt: base.unwrap(),
                                           giving: false, line });
                }
            }
            "IF" => {
                p.next();
                let c = condition(p, &|_| true)?; // resolved 88s at exec
                p.eat("THEN");
                let then = parse_stmts(p, &["ELSE", "END-IF", "."])?;
                let els = if p.eat("ELSE") {
                    parse_stmts(p, &["END-IF", "."])?
                } else {
                    Vec::new()
                };
                p.eat("END-IF");
                out.push(Stmt::If { cond: c, then, els, line });
            }
            "EVALUATE" => {
                p.next();
                let subject = if p.eat("TRUE") {
                    None
                } else {
                    Some(operand(p)?)
                };
                let mut whens: Vec<(Vec<Operand>, Vec<Stmt>)> = Vec::new();
                let mut when88: Vec<(String, Vec<Stmt>)> = Vec::new();
                let mut other = Vec::new();
                while p.eat("WHEN") {
                    if p.eat("OTHER") {
                        other = parse_stmts(p, &["WHEN", "END-EVALUATE", "."])?;
                    } else if subject.is_none() {
                        let name = p.next().ok_or("WHEN condition")?.text;
                        let body =
                            parse_stmts(p, &["WHEN", "END-EVALUATE", "."])?;
                        when88.push((name, body));
                    } else {
                        let mut vals = vec![operand(p)?];
                        while p.eat("ALSO") {
                            vals.push(operand(p)?);
                        }
                        let body =
                            parse_stmts(p, &["WHEN", "END-EVALUATE", "."])?;
                        whens.push((vals, body));
                    }
                }
                p.eat("END-EVALUATE");
                out.push(Stmt::Evaluate { subject, whens, when88, other,
                                          line });
            }
            "PERFORM" => {
                p.next();
                // Inline forms end at END-PERFORM and carry their own body.
                if p.at("VARYING") || p.at("UNTIL") {
                    let mut var = None;
                    let mut from = None;
                    let mut by = None;
                    if p.eat("VARYING") {
                        var = Some(p.next().ok_or("VARYING name")?.text);
                        if p.eat("FROM") {
                            from = Some(operand(p)?);
                        }
                        if p.eat("BY") {
                            by = Some(operand(p)?);
                        }
                    }
                    let until = if p.eat("UNTIL") {
                        Some(condition(p, &|_| true)?)
                    } else {
                        None
                    };
                    if p.at("AFTER") {
                        return Err(refuse(line, "PERFORM VARYING ... AFTER"));
                    }
                    let body = parse_stmts(p, &["END-PERFORM", "."])?;
                    p.eat("END-PERFORM");
                    out.push(Stmt::PerformInline { var, from, by, until,
                                                   body, line });
                    continue;
                }
                let para = p.next().ok_or("PERFORM target")?.text;
                if para.parse::<u32>().is_ok() {
                    return Err(refuse(line, "inline PERFORM n TIMES"));
                }
                let thru = if p.eat("THRU") || p.eat("THROUGH") {
                    Some(p.next().ok_or("THRU target")?.text)
                } else {
                    None
                };
                let mut until = None;
                let mut times = None;
                if p.eat("UNTIL") {
                    until = Some(condition(p, &|_| true)?);
                } else if p.peek().map(|t| !t.is_lit
                        && t.text.parse::<u32>().is_ok()).unwrap_or(false) {
                    times = Some(operand(p)?);
                    p.eat("TIMES");
                }
                out.push(Stmt::Perform { para, thru, until, times, line });
            }
            "SET" => {
                p.next();
                let name = p.next().ok_or("SET target")?.text;
                if p.eat("TO") && p.eat("TRUE") {
                    out.push(Stmt::SetTrue { cond: name, line });
                } else {
                    return Err(refuse(line, "SET form other than TO TRUE"));
                }
            }
            "DISPLAY" => {
                p.next();
                let mut parts = Vec::new();
                while let Some(n) = p.peek() {
                    if !n.is_lit && (n.text == "."
                        || VERBS.contains(&n.text.as_str())
                        || until.contains(&n.text.as_str())) {
                        break;
                    }
                    parts.push(operand(p)?);
                }
                out.push(Stmt::Display { parts, line });
            }
            "GOBACK" => {
                p.next();
                out.push(Stmt::Goback { line });
            }
            "STOP" => {
                p.next();
                p.eat("RUN");
                out.push(Stmt::Goback { line });
            }
            "CONTINUE" => {
                p.next();
                out.push(Stmt::Continue_);
            }
            "EXIT" => {
                p.next();
                p.eat("PROGRAM");
                out.push(Stmt::Goback { line });
            }
            "OPEN" => {
                p.next();
                let mode = p.next().ok_or("OPEN mode")?.text;
                let mut fs = Vec::new();
                while let Some(n) = p.peek() {
                    if n.is_lit || n.text == "."
                        || VERBS.contains(&n.text.as_str())
                        || until.contains(&n.text.as_str()) { break; }
                    fs.push(p.next().unwrap().text);
                }
                out.push(Stmt::Open { mode, files: fs, line });
            }
            "CLOSE" => {
                p.next();
                let mut fs = Vec::new();
                while let Some(n) = p.peek() {
                    if n.is_lit || n.text == "."
                        || VERBS.contains(&n.text.as_str())
                        || until.contains(&n.text.as_str()) { break; }
                    fs.push(p.next().unwrap().text);
                }
                out.push(Stmt::Close { files: fs, line });
            }
            "READ" => {
                p.next();
                let file = p.next().ok_or("READ file")?.text;
                p.eat("NEXT");
                p.eat("RECORD");
                let into = if p.eat("INTO") {
                    Some(p.next().ok_or("READ INTO")?.text)
                } else {
                    None
                };
                let mut at_end = Vec::new();
                if p.eat("AT") {
                    p.eat("END");
                    at_end = parse_stmts(p, &["END-READ", "NOT", "."])?;
                }
                p.eat("END-READ");
                out.push(Stmt::Read { file, into, at_end, line });
            }
            "WRITE" | "REWRITE" => {
                let rewrite = t.text == "REWRITE";
                p.next();
                let rec = p.next().ok_or("WRITE record")?.text;
                let from = if p.eat("FROM") {
                    Some(p.next().ok_or("WRITE FROM")?.text)
                } else {
                    None
                };
                out.push(Stmt::Write { rec, from, rewrite, line });
            }
            "EXEC" => {
                p.next();
                let dialect = p.next().ok_or("EXEC without a dialect")?;
                let mut words: Vec<String> = Vec::new();
                while let Some(t) = p.peek().cloned() {
                    if !t.is_lit && t.text == "END-EXEC" {
                        p.next();
                        break;
                    }
                    let t = p.next().unwrap();
                    words.push(if t.is_lit {
                        format!("'{}'", t.text)
                    } else {
                        t.text
                    });
                }
                p.eat(".");
                match dialect.text.as_str() {
                    "SQL" => out.push(Stmt::ExecSql {
                        text: words.join(" "), line }),
                    other => return Err(refuse(
                        line, &format!("EXEC {}", other))),
                }
            }
            "CALL" => {
                p.next();
                let target = operand(p)?;
                let mut using = Vec::new();
                if p.eat("USING") {
                    while let Some(n) = p.peek() {
                        if n.is_lit || n.text == "."
                            || VERBS.contains(&n.text.as_str())
                            || until.contains(&n.text.as_str()) {
                            break;
                        }
                        using.push(p.next().unwrap().text);
                    }
                }
                out.push(Stmt::Call { target, using, line });
            }
            other => return Err(refuse(line, &format!("verb {}", other))),
        }
    }
}
