//! The interpreter: a byte arena, program frames over it, and a trace of
//! every mutation.
//!
//! BY REFERENCE is the load-bearing idea of this phase: a callee's LINKAGE
//! record does not get its own storage — it is bound to (arena slot, byte
//! offset) of the caller's field, so the callee's writes ARE the caller's
//! writes, exactly as on the host. That is why PIA-RESULT set inside
//! PIACOMP is visible to BFRETIRE the moment the CALL returns.

use crate::charset;
use crate::layout::{Item, Kind, Layout, Usage};
use crate::num::{self, Dec, NumErr};
use crate::parse::{self, Cond, Expr, Operand, Program, RelOp, Stmt};
use crate::files::{self, World};
use crate::sql::{self, AreaMap, Snapshot};
use serde_json::{json, Value};
use std::collections::HashMap;

pub struct Loaded {
    pub prog: Program,
    pub layout: Layout,
}

/// One activation: which loaded program, and where each of its records
/// lives in the arena (slot + base offset — the offset is what makes an
/// aliased sub-field binding work).
pub struct Frame {
    pub li: usize,
    pub bufs: Vec<(usize, usize)>,
}

pub struct Machine {
    pub arena: Vec<Vec<u8>>,
    pub loaded: Vec<Loaded>,
    pub by_name: HashMap<String, usize>,
    pub frames: Vec<Frame>,
    pub sources: HashMap<String, String>,
    pub copybooks: HashMap<String, String>,
    pub stubs: Vec<String>,
    pub trace: Vec<Value>,
    pub budget: u64,
    pub depth_limit: usize,
    pub snap: Option<Snapshot>,
    pub world: World,
    /// name → (columns, host variables, current row, open)
    pub cursors: HashMap<String, Cursor>,
    pub sqlcode: i64,
}

#[derive(Debug, Clone)]
pub struct Cursor {
    pub cols: Vec<String>,
    pub table: String,
    pub row: usize,
    pub open: bool,
}

pub enum Flow {
    Normal,
    Goback,
}

#[derive(Debug)]
pub enum RunErr {
    Halt(String),
    Abend { code: String, line: u32, detail: String },
}

impl Machine {
    pub fn new(sources: HashMap<String, String>, stubs: Vec<String>,
               budget: u64) -> Machine {
        Machine {
            arena: Vec::new(),
            loaded: Vec::new(),
            by_name: HashMap::new(),
            frames: Vec::new(),
            sources,
            copybooks: HashMap::new(),
            stubs,
            trace: Vec::new(),
            budget,
            depth_limit: 32,
            snap: None,
            world: World::default(),
            cursors: HashMap::new(),
            sqlcode: 0,
        }
    }

    /// Parse + lay out a program once; cached by name. Lazy per program, so
    /// an unparseable member only halts runs that actually reach it.
    pub fn load(&mut self, name: &str) -> Result<usize, RunErr> {
        let up = name.to_uppercase();
        if let Some(i) = self.by_name.get(&up) {
            return Ok(*i);
        }
        let src = self.sources.get(&up).cloned().ok_or_else(|| {
            RunErr::Halt(format!(
                "no source for {} — ingest it or mark it a stub", up))
        })?;
        let expanded = parse::expand_copies(&src, &self.copybooks, 0,
                                            &mut Vec::new())
            .map_err(RunErr::Halt)?;
        let prog = parse::parse_program(&expanded).map_err(RunErr::Halt)?;
        let mut layout = Layout::default();
        layout.build(&prog.ws, false)
            .map_err(|e| RunErr::Halt(format!("{}: {}", up, e)))?;
        // SQLCA is supplied by the precompiler on the host; programs read
        // SQLCODE without declaring it. Synthesize when absent.
        if !prog.sql_declares.is_empty()
            || prog.paragraphs.iter().any(|(_, b)| has_sql(b))
        {
            if layout.find("SQLCODE").is_none() {
                layout.build(&[Item {
                    level: 1, name: "SQLCODE".into(),
                    pic: crate::layout::parse_pic("S9(9)"),
                    usage: crate::layout::Usage::Binary, occurs: 1,
                    redefines: None, value: None, cond_values: vec![],
                    line: 0,
                }], false).map_err(RunErr::Halt)?;
            }
        }
        layout.build(&prog.linkage, true)
            .map_err(|e| RunErr::Halt(format!("{}: {}", up, e)))?;
        let i = self.loaded.len();
        self.loaded.push(Loaded { prog, layout });
        self.by_name.insert(up, i);
        Ok(i)
    }

    /// Push an activation. `args` are (arena slot, base offset) bindings for
    /// the PROCEDURE DIVISION USING names, in order.
    pub fn push_frame(&mut self, li: usize, args: &[(usize, usize)])
        -> Result<(), RunErr> {
        if self.frames.len() >= self.depth_limit {
            return Err(RunErr::Halt("call depth limit exceeded".into()));
        }
        let nrec = self.loaded[li].layout.records.len();
        let using: Vec<String> = self.loaded[li].prog.using.clone();
        let mut bufs = vec![(usize::MAX, 0usize); nrec];
        for r in 0..nrec {
            let rec = &self.loaded[li].layout.records[r];
            if rec.linkage {
                // bound positionally through PROCEDURE DIVISION USING
                if let Some(pos) = using.iter().position(|u| *u == rec.name) {
                    if let Some(&(slot, off)) = args.get(pos) {
                        bufs[r] = (slot, off);
                        continue;
                    }
                }
                // Declared but not passed: on the host this is the storage
                // nobody owns. Give it a private buffer and say so.
                let init = self.loaded[li].layout.init_buffer(r);
                self.arena.push(init);
                bufs[r] = (self.arena.len() - 1, 0);
                let (pgm, rname) =
                    (self.loaded[li].prog.name.clone(), rec.name.clone());
                self.trace.push(json!({
                    "kind": "note", "pgm": pgm,
                    "text": format!("LINKAGE {} not passed by the caller — \
                                     private storage, values are not the \
                                     caller's", rname),
                }));
            } else {
                let init = self.loaded[li].layout.init_buffer(r);
                self.arena.push(init);
                bufs[r] = (self.arena.len() - 1, 0);
            }
        }
        self.frames.push(Frame { li, bufs });
        // Register cursors declared in the data division.
        let decls = self.loaded[li].prog.sql_declares.clone();
        for (text, line) in decls {
            self.exec_sql(&text, line)?;
        }
        Ok(())
    }

    // ── frame-relative access ─────────────────────────────────────────

    fn li(&self) -> usize {
        self.frames.last().unwrap().li
    }

    pub fn lay(&self) -> &Layout {
        &self.loaded[self.li()].layout
    }

    pub fn pgm(&self) -> String {
        self.loaded[self.li()].prog.name.clone()
    }

    fn field(&self, name: &str) -> Result<usize, RunErr> {
        self.lay().find(name).ok_or_else(|| {
            RunErr::Halt(format!("unknown data name {} in {}", name,
                                 self.pgm()))
        })
    }

    /// (arena slot, absolute offset, length) for a field in this frame.
    fn place(&self, fi: usize) -> (usize, usize, usize) {
        self.place_at(fi, 0)
    }

    /// The `occ`-th occurrence (0-based) of a field inside an OCCURS table.
    fn place_at(&self, fi: usize, occ: usize) -> (usize, usize, usize) {
        let f = &self.lay().fields[fi];
        let (slot, base) = self.frames.last().unwrap().bufs[f.record];
        let stride = if occ == 0 { 0 } else {
            self.lay().stride_for(fi).unwrap_or(0)
        };
        (slot, base + f.offset + occ * stride, f.len)
    }

    /// An operand naming storage → (field index, 0-based occurrence).
    fn resolve(&self, o: &Operand, line: u32) -> Result<(usize, usize), RunErr> {
        match o {
            Operand::Field(n) => Ok((self.field(n)?, 0)),
            Operand::Sub(n, idx) => {
                let fi = self.field(n)?;
                if self.lay().stride_for(fi).is_none() {
                    return Err(RunErr::Halt(format!(
                        "line {}: {} is subscripted but does not OCCURS",
                        line, n)));
                }
                let one = self.op_num(idx, line)?.mant;
                if one < 1 {
                    return Err(RunErr::Abend {
                        code: "SUBSCRIPT".into(), line,
                        detail: format!("{} subscript {} is below 1", n, one),
                    });
                }
                let f = &self.lay().fields[fi];
                let limit = if f.occurs > 1 { f.occurs } else {
                    let mut p = f.parent;
                    let mut lim = 1;
                    while let Some(pi) = p {
                        if self.lay().fields[pi].occurs > 1 {
                            lim = self.lay().fields[pi].occurs;
                            break;
                        }
                        p = self.lay().fields[pi].parent;
                    }
                    lim
                };
                if one as usize > limit {
                    return Err(RunErr::Abend {
                        code: "SUBSCRIPT".into(), line,
                        detail: format!("{} subscript {} exceeds OCCURS {}",
                                        n, one, limit),
                    });
                }
                Ok((fi, one as usize - 1))
            }
            other => Err(RunErr::Halt(format!(
                "line {}: {:?} does not name storage", line, other))),
        }
    }

    /// Whole-area byte snapshot, for the pipeline driver's carry
    /// mechanism (the TDAIO seam). Raw bytes — a carried area is state,
    /// not a conversion.
    pub fn area_bytes(&self, name: &str) -> Option<Vec<u8>> {
        let fi = self.lay().find(name)?;
        Some(self.read_bytes(fi).to_vec())
    }

    pub fn set_area_bytes(&mut self, name: &str, bytes: &[u8]) -> bool {
        let Some(fi) = self.lay().find(name) else { return false };
        let (s, o, l) = self.place(fi);
        let n = l.min(bytes.len());
        self.arena[s][o..o + n].copy_from_slice(&bytes[..n]);
        true
    }

    fn read_bytes(&self, fi: usize) -> &[u8] {
        self.read_bytes_at(fi, 0)
    }

    fn read_bytes_at(&self, fi: usize, occ: usize) -> &[u8] {
        let (s, o, l) = self.place_at(fi, occ);
        &self.arena[s][o..o + l]
    }

    fn read_num(&self, fi: usize, line: u32) -> Result<Dec, RunErr> {
        self.read_num_at(fi, 0, line)
    }

    fn read_num_at(&self, fi: usize, occ: usize, line: u32)
        -> Result<Dec, RunErr> {
        let f = self.lay().fields[fi].clone();
        let b = self.read_bytes_at(fi, occ);
        let r = match f.usage {
            Usage::Display => num::zoned_decode(b, f.scale, f.signed),
            Usage::Comp3 => num::packed_decode(b, f.scale),
            Usage::Binary => Ok(num::binary_decode(b, f.scale)),
        };
        r.map_err(|e| match e {
            NumErr::S0C7 { bytes } => RunErr::Abend {
                code: "S0C7".into(),
                line,
                detail: format!("invalid decimal data in {}: {:02X?}",
                                f.name, bytes),
            },
            NumErr::S0CB => RunErr::Abend {
                code: "S0CB".into(), line, detail: "divide by zero".into(),
            },
            NumErr::SizeError => RunErr::Halt("size error".into()),
        })
    }

    pub fn show(&self, fi: usize) -> String {
        self.show_at(fi, 0)
    }

    pub fn show_at(&self, fi: usize, occ: usize) -> String {
        let f = &self.lay().fields[fi];
        match f.kind {
            Kind::Numeric => match self.read_num_at(fi, occ, 0) {
                Ok(d) => d.to_string_plain(),
                Err(_) => format!("«invalid:{}»",
                                  hex(self.read_bytes_at(fi, occ))),
            },
            _ => charset::ebcdic_to_string(self.read_bytes_at(fi, occ))
                .trim_end().to_string(),
        }
    }

    fn write_field(&mut self, fi: usize, bytes: Vec<u8>, line: u32,
                   cause: &str) {
        self.write_field_at(fi, 0, bytes, line, cause)
    }

    fn write_field_at(&mut self, fi: usize, occ: usize, bytes: Vec<u8>,
                      line: u32, cause: &str) {
        let before = self.show_at(fi, occ);
        let (s, o, l) = self.place_at(fi, occ);
        self.arena[s][o..o + l].copy_from_slice(&bytes[..l]);
        let after = self.show_at(fi, occ);
        let base = self.lay().fields[fi].name.clone();
        let fname = if occ > 0 { format!("{}({})", base, occ + 1) } else { base };
        let pgm = self.pgm();
        self.trace.push(json!({
            "kind": "move", "pgm": pgm, "line": line,
            "field": fname, "before": before, "after": after,
            "cause": cause,
        }));
        if is_error_field(&fname) && after != before && looks_like_code(&after) {
            self.trace.push(json!({
                "kind": "exception", "pgm": self.pgm(), "line": line,
                "field": fname, "code": after,
            }));
        }
    }

    fn op_num(&self, o: &Operand, line: u32) -> Result<Dec, RunErr> {
        match o {
            Operand::NumLit(s) => Ok(Dec::parse(s).unwrap()),
            Operand::Zeros => Ok(Dec::zero()),
            Operand::Field(_) | Operand::Sub(..) => {
                let (fi, occ) = self.resolve(o, line)?;
                self.read_num_at(fi, occ, line)
            }
            other => Err(RunErr::Halt(format!(
                "operand {:?} is not numeric", other))),
        }
    }

    fn op_is_numeric(&self, o: &Operand) -> bool {
        match o {
            Operand::NumLit(_) | Operand::Zeros => true,
            Operand::Field(n) | Operand::Sub(n, _) => self.lay().find(n)
                .map(|fi| self.lay().fields[fi].kind == Kind::Numeric)
                .unwrap_or(false),
            _ => false,
        }
    }

    fn op_bytes(&self, o: &Operand, width: usize) -> Result<Vec<u8>, RunErr> {
        Ok(match o {
            Operand::StrLit(s) => charset::str_to_ebcdic(s),
            Operand::Spaces => vec![charset::SPACE; width.max(1)],
            Operand::HighValues => vec![charset::HIGH; width.max(1)],
            Operand::LowValues => vec![charset::LOW; width.max(1)],
            Operand::Zeros => vec![0xF0; width.max(1)],
            Operand::NumLit(s) => charset::str_to_ebcdic(s),
            Operand::Field(_) | Operand::Sub(..) => {
                let (fi, occ) = self.resolve(o, 0)?;
                self.read_bytes_at(fi, occ).to_vec()
            }
        })
    }

    fn eval_expr(&self, e: &Expr, line: u32) -> Result<Dec, RunErr> {
        match e {
            Expr::Op(o) => self.op_num(o, line),
            Expr::Bin(op, l, r) => {
                let a = self.eval_expr(l, line)?;
                let b = self.eval_expr(r, line)?;
                Ok(match op {
                    '+' => Dec::add(a, b),
                    '-' => Dec::sub(a, b),
                    '*' => Dec::mul(a, b),
                    '/' => Dec::div(a, b).map_err(|_| RunErr::Abend {
                        code: "S0CB".into(), line,
                        detail: "divide by zero".into() })?,
                    _ => unreachable!(),
                })
            }
        }
    }

    fn cond(&self, c: &Cond, line: u32) -> Result<bool, RunErr> {
        Ok(match c {
            Cond::Not(i) => !self.cond(i, line)?,
            Cond::And(a, b) => self.cond(a, line)? && self.cond(b, line)?,
            Cond::Or(a, b) => self.cond(a, line)? || self.cond(b, line)?,
            Cond::Is88(name) => self.test88(name, line)?,
            Cond::Rel(a, op, b) => {
                let ord = if self.op_is_numeric(a) && self.op_is_numeric(b) {
                    Dec::cmp(self.op_num(a, line)?, self.op_num(b, line)?)
                } else {
                    let x = self.op_bytes(a, 0)?;
                    let y = self.op_bytes(b, 0)?;
                    let n = x.len().max(y.len());
                    let pad = |v: &Vec<u8>| {
                        let mut w = v.clone();
                        w.resize(n, charset::SPACE);
                        w
                    };
                    pad(&x).cmp(&pad(&y))
                };
                match op {
                    RelOp::Eq => ord.is_eq(),
                    RelOp::Ne => !ord.is_eq(),
                    RelOp::Gt => ord.is_gt(),
                    RelOp::Lt => ord.is_lt(),
                    RelOp::Ge => !ord.is_lt(),
                    RelOp::Le => !ord.is_gt(),
                }
            }
        })
    }

    fn test88(&self, name: &str, line: u32) -> Result<bool, RunErr> {
        let c = self.lay().find_cond(name).cloned().ok_or_else(|| {
            RunErr::Halt(format!("unknown condition name {}", name))
        })?;
        let fi = c.field;
        let f = self.lay().fields[fi].clone();
        for v in &c.values {
            let hit = if f.kind == Kind::Numeric {
                match Dec::parse(v) {
                    Some(d) => Dec::cmp(self.read_num(fi, line)?, d).is_eq(),
                    None => false,
                }
            } else {
                let mut want = charset::str_to_ebcdic(v);
                want.resize(f.len, charset::SPACE);
                self.read_bytes(fi) == &want[..]
            };
            if hit {
                return Ok(true);
            }
        }
        Ok(false)
    }

    fn set88(&mut self, name: &str, line: u32) -> Result<(), RunErr> {
        let c = self.lay().find_cond(name).cloned().ok_or_else(|| {
            RunErr::Halt(format!("unknown condition name {}", name))
        })?;
        let v = c.values.first().cloned().unwrap_or_default();
        self.store_operand(&Operand::StrLit(v), c.field, line, "SET TO TRUE")
    }

    fn store_operand(&mut self, src: &Operand, dst: usize, line: u32,
                     cause: &str) -> Result<(), RunErr> {
        self.store_operand_at(src, dst, 0, line, cause)
    }

    fn store_operand_at(&mut self, src: &Operand, dst: usize, occ: usize,
                        line: u32, cause: &str) -> Result<(), RunErr> {
        let f = self.lay().fields[dst].clone();
        let bytes = match f.kind {
            Kind::Numeric => {
                let v = match src {
                    Operand::StrLit(s) => Dec::parse(s).ok_or_else(|| {
                        RunErr::Halt(format!(
                            "alphanumeric '{}' into numeric {}", s, f.name))
                    })?,
                    other => self.op_num(other, line)?,
                };
                self.lay().encode_numeric(&f, v)
            }
            Kind::Group => {
                // Group MOVE is a byte copy — no conversion, no validation.
                // This is how invalid decimal data gets planted.
                let src_b = self.op_bytes(src, f.len)?;
                let mut b = vec![charset::SPACE; f.len];
                num::alnum_store(&mut b, &src_b);
                b
            }
            _ => {
                let src_b = match src {
                    Operand::Field(_) | Operand::Sub(..) => {
                        let (sfi, socc) = self.resolve(src, line)?;
                        let sf = self.lay().fields[sfi].clone();
                        if sf.kind == Kind::Numeric
                            && sf.usage != Usage::Display {
                            charset::str_to_ebcdic(
                                &self.read_num_at(sfi, socc, line)?
                                    .to_string_plain().replace('.', ""))
                        } else {
                            self.read_bytes_at(sfi, socc).to_vec()
                        }
                    }
                    other => self.op_bytes(other, f.len)?,
                };
                let mut b = vec![charset::SPACE; f.len];
                num::alnum_store(&mut b, &src_b);
                b
            }
        };
        self.write_field_at(dst, occ, bytes, line, cause);
        Ok(())
    }

    // ── CALL ──────────────────────────────────────────────────────────

    fn do_call(&mut self, target: &Operand, using: &[String], line: u32)
        -> Result<(), RunErr> {
        let (name, via) = match target {
            Operand::StrLit(s) => (s.to_uppercase(), "static".to_string()),
            Operand::Field(f) => {
                let fi = self.field(f)?;
                (self.show(fi).trim().to_uppercase(),
                 format!("dynamic via {}", f))
            }
            other => return Err(RunErr::Halt(format!(
                "CALL target {:?} unsupported", other))),
        };
        // Bind the arguments in the CALLER's frame before switching.
        let mut args = Vec::new();
        for u in using {
            let fi = self.field(u)?;
            let (slot, off, _) = self.place(fi);
            args.push((slot, off));
        }
        let caller = self.pgm();

        if self.stubs.iter().any(|s| s.eq_ignore_ascii_case(&name)) {
            let vals: Vec<String> = using.iter()
                .filter_map(|u| self.field(u).ok())
                .map(|fi| format!("{}={}", self.lay().fields[fi].name,
                                  self.show(fi)))
                .collect();
            self.trace.push(json!({
                "kind": "call", "pgm": caller, "line": line,
                "target": name, "resolution": "stub", "via": via,
                "using": vals,
            }));
            return Ok(());
        }

        let li = self.load(&name)?;
        self.trace.push(json!({
            "kind": "call", "pgm": caller, "line": line, "target": name,
            "resolution": "interpreted", "via": via,
            "depth": self.frames.len(),
        }));
        self.push_frame(li, &args)?;
        let stmts: Vec<Stmt> = self.loaded[li].prog.paragraphs
            .first().map(|(_, b)| b.clone()).unwrap_or_default();
        let res = self.run_entry(li, stmts);
        self.frames.pop();
        res?;
        self.trace.push(json!({
            "kind": "return", "pgm": self.pgm(), "line": line,
            "from": name,
        }));
        Ok(())
    }

    /// Run a loaded program from its first paragraph, falling through.
    fn run_entry(&mut self, li: usize, first: Vec<Stmt>) -> Result<(), RunErr> {
        let n = self.loaded[li].prog.paragraphs.len();
        if let Flow::Goback = self.run_stmts(&first)? {
            return Ok(());
        }
        for i in 1..n {
            let body = self.loaded[li].prog.paragraphs[i].1.clone();
            if let Flow::Goback = self.run_stmts(&body)? {
                return Ok(());
            }
        }
        Ok(())
    }

    pub fn run_stmts(&mut self, stmts: &[Stmt]) -> Result<Flow, RunErr> {
        for s in stmts {
            self.budget = self.budget.checked_sub(1).ok_or_else(|| {
                RunErr::Halt("statement budget exhausted".into())
            })?;
            match s {
                Stmt::Continue_ => {}
                Stmt::Goback { .. } => return Ok(Flow::Goback),
                Stmt::Move { src, dsts, line } => {
                    for d in dsts {
                        let (fi, occ) = self.resolve(d, *line)?;
                        self.store_operand_at(src, fi, occ, *line, "MOVE")?;
                    }
                }
                Stmt::Compute { dst, rounded, expr, line } => {
                    let v = self.eval_expr(expr, *line)?;
                    let fi = self.field(dst)?;
                    let f = self.lay().fields[fi].clone();
                    let v = if *rounded {
                        v.round_to(f.scale)
                    } else {
                        v.rescale(f.scale)
                    };
                    let bytes = self.lay().encode_numeric(&f, v);
                    self.write_field(fi, bytes, *line, "COMPUTE");
                }
                Stmt::Arith { operand, tgt, line, giving, op } => {
                    let fi = self.field(tgt)?;
                    let f = self.lay().fields[fi].clone();
                    let v = if *giving {
                        self.eval_expr(operand, *line)?
                    } else {
                        let cur = self.read_num(fi, *line)?;
                        let e = self.eval_expr(operand, *line)?;
                        if *op == '+' { Dec::add(cur, e) }
                        else { Dec::sub(cur, e) }
                    };
                    let bytes = self.lay().encode_numeric(&f, v.rescale(f.scale));
                    self.write_field(fi, bytes, *line, "ARITH");
                }
                Stmt::If { cond, then, els, line } => {
                    let hit = self.cond(cond, *line)?;
                    let pgm = self.pgm();
                    self.trace.push(json!({
                        "kind": "branch", "pgm": pgm, "line": line,
                        "outcome": hit,
                    }));
                    let body = if hit { then } else { els };
                    if let Flow::Goback = self.run_stmts(body)? {
                        return Ok(Flow::Goback);
                    }
                }
                Stmt::Evaluate { subject, whens, when88, other, line } => {
                    let mut taken = false;
                    if subject.is_none() {
                        for (name, body) in when88 {
                            if self.test88(name, *line)? {
                                taken = true;
                                if let Flow::Goback = self.run_stmts(body)? {
                                    return Ok(Flow::Goback);
                                }
                                break;
                            }
                        }
                    } else {
                        let subj = subject.clone().unwrap();
                        for (vals, body) in whens {
                            let mut hit = false;
                            for v in vals {
                                let c = Cond::Rel(subj.clone(), RelOp::Eq,
                                                  v.clone());
                                if self.cond(&c, *line)? {
                                    hit = true;
                                    break;
                                }
                            }
                            if hit {
                                taken = true;
                                if let Flow::Goback = self.run_stmts(body)? {
                                    return Ok(Flow::Goback);
                                }
                                break;
                            }
                        }
                    }
                    if !taken {
                        if let Flow::Goback = self.run_stmts(other)? {
                            return Ok(Flow::Goback);
                        }
                    }
                }
                Stmt::Perform { para, thru, until, times, line } => {
                    let li = self.li();
                    let paras = &self.loaded[li].prog.paragraphs;
                    let start = paras.iter().position(|(n, _)| n == para)
                        .ok_or_else(|| RunErr::Halt(format!(
                            "PERFORM of unknown paragraph {}", para)))?;
                    let end = match thru {
                        Some(t) => paras.iter().position(|(n, _)| n == t)
                            .ok_or_else(|| RunErr::Halt(format!(
                                "THRU unknown paragraph {}", t)))?,
                        None => start,
                    };
                    if let Some(u) = until {
                        while !self.cond(u, *line)? {
                            if let Flow::Goback = self.perform_range(li, start, end)? {
                                return Ok(Flow::Goback);
                            }
                        }
                    } else if let Some(t) = times {
                        let n = self.op_num(t, *line)?.mant.max(0) as u64;
                        for _ in 0..n {
                            if let Flow::Goback = self.perform_range(li, start, end)? {
                                return Ok(Flow::Goback);
                            }
                        }
                    } else if let Flow::Goback = self.perform_range(li, start, end)? {
                        return Ok(Flow::Goback);
                    }
                }
                Stmt::PerformInline { var, from, by, until, body, line } => {
                    if let (Some(v), Some(f)) = (var, from) {
                        let fi = self.field(v)?;
                        let start = self.op_num(f, *line)?;
                        let fl = self.lay().fields[fi].clone();
                        let bytes = self.lay().encode_numeric(&fl, start);
                        self.write_field(fi, bytes, *line, "PERFORM VARYING");
                    }
                    loop {
                        if let Some(u) = until {
                            if self.cond(u, *line)? {   // TEST BEFORE
                                break;
                            }
                        }
                        if let Flow::Goback = self.run_stmts(body)? {
                            return Ok(Flow::Goback);
                        }
                        match (var, by) {
                            (Some(v), Some(b)) => {
                                let fi = self.field(v)?;
                                let cur = self.read_num(fi, *line)?;
                                let step = self.op_num(b, *line)?;
                                let fl = self.lay().fields[fi].clone();
                                let next = Dec::add(cur, step);
                                let bytes =
                                    self.lay().encode_numeric(&fl, next);
                                self.write_field(fi, bytes, *line,
                                                 "PERFORM VARYING");
                            }
                            _ if until.is_none() => break, // no loop control
                            _ => {}
                        }
                        self.budget = self.budget.checked_sub(1)
                            .ok_or_else(|| RunErr::Halt(
                                "statement budget exhausted".into()))?;
                    }
                }
                Stmt::SetTrue { cond, line } => self.set88(cond, *line)?,
                Stmt::Display { parts, line } => {
                    let mut text = String::new();
                    for p in parts {
                        match p {
                            Operand::Field(_) | Operand::Sub(..) => {
                                let (fi, occ) = self.resolve(p, *line)?;
                                text.push_str(&self.show_at(fi, occ));
                            }
                            Operand::StrLit(s) | Operand::NumLit(s) =>
                                text.push_str(s),
                            _ => {}
                        }
                    }
                    let pgm = self.pgm();
                    self.trace.push(json!({
                        "kind": "display", "pgm": pgm, "line": line,
                        "text": text,
                    }));
                }
                Stmt::Call { target, using, line } =>
                    self.do_call(target, using, *line)?,
                Stmt::ExecSql { text, line } => self.exec_sql(text, *line)?,
                Stmt::Open { mode, files: fs, line } =>
                    self.do_open(mode, fs, *line)?,
                Stmt::Close { files: fs, line } => {
                    for f in fs {
                        self.world.close_file(f);
                    }
                    let pgm = self.pgm();
                    self.trace.push(json!({
                        "kind": "file", "pgm": pgm, "line": line,
                        "op": "close", "files": fs,
                    }));
                }
                Stmt::Read { file, into, at_end, line } => {
                    if let Flow::Goback =
                        self.do_read(file, into, at_end, *line)? {
                        return Ok(Flow::Goback);
                    }
                }
                Stmt::Write { rec, from, rewrite, line } => {
                    if *rewrite {
                        return Err(RunErr::Halt(parse::refuse(
                            *line, "REWRITE")));
                    }
                    self.do_write(rec, from, *line)?;
                }
            }
        }
        Ok(Flow::Normal)
    }

    // ── EXEC SQL: the case snapshot is the database, for reads ────────

    fn set_sqlcode(&mut self, code: i64) {
        self.sqlcode = code;
        // SQLCODE is a real field when the program declares one.
        if let Some(fi) = self.lay().find("SQLCODE") {
            let f = self.lay().fields[fi].clone();
            if f.kind == Kind::Numeric {
                let bytes = self.lay().encode_numeric(
                    &f, Dec { mant: code as i128, scale: 0 });
                let (s, o, l) = self.place(fi);
                self.arena[s][o..o + l].copy_from_slice(&bytes[..l]);
            }
        }
    }

    fn store_text(&mut self, host: &str, text: &str, line: u32,
                  cause: &str) -> Result<(), RunErr> {
        let fi = self.field(host)?;
        self.store_text_fi(fi, 0, text, line, cause)
    }

    fn store_text_fi(&mut self, fi: usize, occ: usize, text: &str,
                     line: u32, cause: &str) -> Result<(), RunErr> {
        let f = self.lay().fields[fi].clone();
        let bytes = match f.kind {
            Kind::Numeric => {
                let d = Dec::parse(text.trim()).unwrap_or(Dec::zero());
                self.lay().encode_numeric(&f, d)
            }
            _ => {
                let mut b = vec![charset::SPACE; f.len];
                num::alnum_store(&mut b, &charset::str_to_ebcdic(text));
                b
            }
        };
        self.write_field_at(fi, occ, bytes, line, cause);
        Ok(())
    }

    /// OCCURS limit governing a field — its own, or the nearest OCCURS
    /// ancestor's. 1 when it does not repeat.
    fn occurs_limit(&self, fi: usize) -> usize {
        let f = &self.lay().fields[fi];
        if f.occurs > 1 {
            return f.occurs;
        }
        let mut p = f.parent;
        while let Some(pi) = p {
            if self.lay().fields[pi].occurs > 1 {
                return self.lay().fields[pi].occurs;
            }
            p = self.lay().fields[pi].parent;
        }
        1
    }

    /// Seed the declared interface areas from the case, through each
    /// mapping's format. An absent path leaves the field alone and is
    /// REPORTED — a blank seed three steps before the exception it
    /// causes must be findable. An unconvertible value halts: bad data
    /// must not silently become blank data. Areas in `skip` (already
    /// carried) are left untouched.
    pub fn apply_area_maps(&mut self, maps: &[AreaMap], case: &Value,
                           skip: &std::collections::HashSet<String>)
        -> Result<(), RunErr> {
        use std::collections::BTreeMap;
        let mut by_area: BTreeMap<&str, Vec<&AreaMap>> = BTreeMap::new();
        for m in maps {
            by_area.entry(m.area.as_str()).or_default().push(m);
        }
        for (area, rows) in by_area {
            if skip.contains(area) || self.lay().find(area).is_none() {
                continue;
            }
            let mut filled = 0usize;
            let mut blank: Vec<String> = Vec::new();
            for m in rows {
                let Some(fi) = self.lay().find(&m.field) else {
                    continue;   // the area is present, this field is not
                };
                if let Some((head, tail)) = m.path.split_once("[]") {
                    let leaf = tail.trim_start_matches('.');
                    let arr = sql::dig(case, head)
                        .and_then(|v| v.as_array().cloned())
                        .unwrap_or_default();
                    if arr.is_empty() {
                        blank.push(m.field.clone());
                        continue;
                    }
                    let limit = self.occurs_limit(fi);
                    if arr.len() > limit {
                        return Err(RunErr::Halt(format!(
                            "{}: the case carries {} occurrences of {} \
                             but {} OCCURS {} — the table cannot hold \
                             this case", m.field, arr.len(), head,
                            m.field, limit)));
                    }
                    for (idx, row) in arr.iter().enumerate() {
                        let v = if leaf.is_empty() { Some(row) }
                                else { sql::dig(row, leaf) };
                        let Some(v) = v else { continue };
                        let text = sql::convert(v, &m.format, &m.field)
                            .map_err(RunErr::Halt)?;
                        if text.is_empty() {
                            continue;
                        }
                        self.store_text_fi(fi, idx, &text, 0, "seed")?;
                        filled += 1;
                    }
                } else {
                    match sql::dig(case, &m.path) {
                        None | Some(Value::Null) => {
                            blank.push(m.field.clone());
                        }
                        Some(v) => {
                            let text = sql::convert(v, &m.format, &m.field)
                                .map_err(RunErr::Halt)?;
                            if text.is_empty() {
                                blank.push(m.field.clone());
                            } else {
                                self.store_text_fi(fi, 0, &text, 0,
                                                   "seed")?;
                                filled += 1;
                            }
                        }
                    }
                }
            }
            let pgm = self.pgm();
            self.trace.push(json!({
                "kind": "seed", "area": area, "pgm": pgm,
                "filled": filled, "blank": blank,
                "source": if blank.is_empty() { "case" }
                          else { "case (partial)" },
            }));
        }
        Ok(())
    }

    fn exec_sql(&mut self, text: &str, line: u32) -> Result<(), RunErr> {
        let up = text.to_uppercase();
        let pgm = self.pgm();
        let words: Vec<&str> = up.split_whitespace().collect();
        let verb = words.first().copied().unwrap_or("");

        macro_rules! need_snap {
            () => {
                if self.snap.is_none() {
                    return Err(RunErr::Halt(format!(
                        "line {}: EXEC SQL with no case snapshot supplied",
                        line)));
                }
            };
        }

        match verb {
            "INCLUDE" | "WHENEVER" => {
                // SQLCA is synthesized; WHENEVER's checks are the program's
                // own IFs in this interpreter.
                Ok(())
            }
            "DECLARE" => {
                // DECLARE <name> CURSOR FOR SELECT <cols> FROM <table> …
                let name = words.get(1).copied().unwrap_or("").to_string();
                let (cols, table) = sql_select_parts(&up).ok_or_else(|| {
                    RunErr::Halt(format!(
                        "line {}: cursor DECLARE not understood: {}",
                        line, text))
                })?;
                self.cursors.insert(name.clone(), Cursor {
                    cols: cols.iter().map(|c| format!("{}.{}", table, c))
                        .collect(),
                    table, row: 0, open: false });
                self.trace.push(json!({
                    "kind": "sql", "pgm": pgm, "line": line,
                    "op": "declare", "cursor": name,
                }));
                Ok(())
            }
            "OPEN" => {
                let name = words.get(1).copied().unwrap_or("").to_string();
                let c = self.cursors.get_mut(&name).ok_or_else(|| {
                    RunErr::Halt(format!("line {}: OPEN of undeclared cursor {}",
                                         line, name))
                })?;
                c.row = 0;
                c.open = true;
                let cols = c.cols.clone();
                need_snap!();
                let n = self.snap.as_ref().unwrap().group_len(&cols);
                self.trace.push(json!({
                    "kind": "sql", "pgm": pgm, "line": line, "op": "open",
                    "cursor": name, "rows": n,
                }));
                self.set_sqlcode(0);
                Ok(())
            }
            "CLOSE" => {
                if let Some(c) = self.cursors
                    .get_mut(words.get(1).copied().unwrap_or("")) {
                    c.open = false;
                }
                self.set_sqlcode(0);
                Ok(())
            }
            "FETCH" => {
                need_snap!();
                let name = words.get(1).copied().unwrap_or("").to_string();
                let hosts = host_vars_after(&up, "INTO");
                let c = self.cursors.get(&name).cloned().ok_or_else(|| {
                    RunErr::Halt(format!("line {}: FETCH of undeclared cursor {}",
                                         line, name))
                })?;
                if c.cols.len() != hosts.len() {
                    return Err(RunErr::Halt(format!(
                        "line {}: FETCH {} — {} columns into {} host \
                         variables; a shifted pairing would be worse than \
                         none", line, name, c.cols.len(), hosts.len())));
                }
                let total = self.snap.as_ref().unwrap()
                    .group_len(&c.cols).unwrap_or(0);
                if c.row >= total {
                    self.set_sqlcode(100);
                    self.trace.push(json!({
                        "kind": "sql", "pgm": pgm, "line": line,
                        "op": "fetch", "cursor": name, "sqlcode": 100,
                    }));
                    return Ok(());
                }
                let mut vals = Vec::new();
                for col in &c.cols {
                    let v = self.snap.as_ref().unwrap()
                        .read_at(col, c.row)
                        .map_err(|e| RunErr::Halt(format!("line {}: {}",
                                                          line, e)))?;
                    vals.push(v);
                }
                for (h, v) in hosts.iter().zip(vals.iter()) {
                    self.store_text(h, v, line, "SQL FETCH")?;
                }
                self.cursors.get_mut(&name).unwrap().row += 1;
                self.set_sqlcode(0);
                self.trace.push(json!({
                    "kind": "sql", "pgm": pgm, "line": line, "op": "fetch",
                    "cursor": name, "row": c.row, "sqlcode": 0,
                }));
                Ok(())
            }
            "SELECT" => {
                need_snap!();
                let (cols, table) = sql_select_parts(&up).ok_or_else(|| {
                    RunErr::Halt(format!("line {}: SELECT not understood: {}",
                                         line, text))
                })?;
                let hosts = host_vars_after(&up, "INTO");
                if cols.len() != hosts.len() {
                    return Err(RunErr::Halt(format!(
                        "line {}: SELECT — {} columns into {} host \
                         variables", line, cols.len(), hosts.len())));
                }
                let mut vals = Vec::new();
                for c in &cols {
                    let full = format!("{}.{}", table, c);
                    let v = self.snap.as_ref().unwrap().read(&full)
                        .map_err(|e| RunErr::Halt(format!("line {}: {}",
                                                          line, e)))?;
                    vals.push((full, v));
                }
                for (h, (_, v)) in hosts.iter().zip(vals.iter()) {
                    self.store_text(h, v, line, "SQL SELECT")?;
                }
                self.set_sqlcode(0);
                self.trace.push(json!({
                    "kind": "sql", "pgm": pgm, "line": line, "op": "select",
                    "table": table,
                    "columns": vals.iter().map(|(c, v)| format!("{}={}", c, v))
                        .collect::<Vec<_>>(),
                    "sqlcode": 0,
                }));
                Ok(())
            }
            "INSERT" | "UPDATE" => {
                need_snap!();
                let pairs = write_pairs(&up);
                if pairs.is_empty() {
                    return Err(RunErr::Halt(format!(
                        "line {}: {} not understood: {}", line, verb, text)));
                }
                let mut recorded = Vec::new();
                for (col, host) in &pairs {
                    let fi = self.field(host)?;
                    let v = self.show(fi);
                    self.snap.as_mut().unwrap()
                        .write(&verb.to_lowercase(), col, &v);
                    recorded.push(format!("{}={}", col, v));
                }
                self.set_sqlcode(0);
                self.trace.push(json!({
                    "kind": "sql", "pgm": pgm, "line": line,
                    "op": verb.to_lowercase(), "would_write": recorded,
                    "sqlcode": 0,
                }));
                Ok(())
            }
            other => Err(RunErr::Halt(parse::refuse(
                line, &format!("EXEC SQL {}", other)))),
        }
    }

    // ── file I-O over the dataset world ───────────────────────────────

    fn ddname_for(&self, logical: &str) -> Result<String, RunErr> {
        let li = self.li();
        self.loaded[li].prog.files.iter()
            .find(|(l, _)| l.eq_ignore_ascii_case(logical))
            .map(|(_, dd)| dd.clone())
            .ok_or_else(|| RunErr::Halt(format!(
                "{} has no SELECT ... ASSIGN TO — cannot bind it to a dataset",
                logical)))
    }

    fn do_open(&mut self, mode: &str, fs: &[String], line: u32)
        -> Result<(), RunErr> {
        let m = match mode {
            "INPUT" => files::Mode::Input,
            "OUTPUT" => files::Mode::Output,
            "I-O" => files::Mode::Io,
            "EXTEND" => files::Mode::Extend,
            other => return Err(RunErr::Halt(parse::refuse(
                line, &format!("OPEN {}", other)))),
        };
        for f in fs {
            let dd = self.ddname_for(f)?;
            let dsn = self.world.open_file(f, &dd, m)
                .map_err(|e| RunErr::Halt(format!("line {}: {}", line, e)))?;
            let pgm = self.pgm();
            self.trace.push(json!({
                "kind": "file", "pgm": pgm, "line": line,
                "op": format!("open-{}", mode.to_lowercase()),
                "file": f, "dd": dd, "dsn": dsn,
            }));
        }
        Ok(())
    }

    fn do_read(&mut self, file: &str, into: &Option<String>,
               at_end: &[Stmt], line: u32) -> Result<Flow, RunErr> {
        let rec = self.world.read(file)
            .map_err(|e| RunErr::Halt(format!("line {}: {}", line, e)))?;
        let pgm = self.pgm();
        match rec {
            None => {
                self.trace.push(json!({
                    "kind": "file", "pgm": pgm, "line": line,
                    "op": "read", "file": file, "at_end": true,
                }));
                self.run_stmts(at_end)
            }
            Some(bytes) => {
                // The record area is the FD's 01; INTO copies onward.
                let target = into.clone().or_else(|| {
                    self.loaded[self.li()].layout.records.iter()
                        .find(|r| !r.linkage).map(|r| r.name.clone())
                });
                if let Some(t) = target {
                    if let Ok(fi) = self.field(&t) {
                        let f = self.lay().fields[fi].clone();
                        let mut b = vec![charset::SPACE; f.len];
                        num::alnum_store(&mut b, &bytes);
                        self.write_field(fi, b, line, "READ");
                    }
                }
                self.trace.push(json!({
                    "kind": "file", "pgm": pgm, "line": line,
                    "op": "read", "file": file, "bytes": bytes.len(),
                }));
                Ok(Flow::Normal)
            }
        }
    }

    fn do_write(&mut self, rec: &str, from: &Option<String>, line: u32)
        -> Result<(), RunErr> {
        // WRITE names the RECORD; the file is the one whose record it is.
        let src = from.clone().unwrap_or_else(|| rec.to_string());
        let fi = self.field(&src)?;
        let bytes = self.read_bytes(fi).to_vec();
        // Find the open file this record belongs to: the FD record shares
        // the program's record table, so fall back to the single open
        // output file when the association is not explicit.
        let logical = {
            let open: Vec<String> = self.world.open.iter()
                .filter(|(_, f)| f.mode != files::Mode::Input)
                .map(|(k, _)| k.clone()).collect();
            if open.len() == 1 {
                open[0].clone()
            } else {
                return Err(RunErr::Halt(format!(
                    "line {}: WRITE {} — {} files open for output; the \
                     record-to-file association needs the FD hierarchy",
                    line, rec, open.len())));
            }
        };
        let dsn = self.world.write(&logical, bytes.clone())
            .map_err(|e| RunErr::Halt(format!("line {}: {}", line, e)))?;
        let pgm = self.pgm();
        self.trace.push(json!({
            "kind": "file", "pgm": pgm, "line": line, "op": "write",
            "file": logical, "dsn": dsn, "bytes": bytes.len(),
            "preview": charset::ebcdic_to_string(&bytes[..bytes.len().min(60)])
                .trim_end().to_string(),
        }));
        Ok(())
    }

    fn perform_range(&mut self, li: usize, start: usize, end: usize)
        -> Result<Flow, RunErr> {
        for i in start..=end {
            let body = self.loaded[li].prog.paragraphs[i].1.clone();
            if let Flow::Goback = self.run_stmts(&body)? {
                return Ok(Flow::Goback);
            }
        }
        Ok(Flow::Normal)
    }

    /// Top-level: run the entry program to completion.
    pub fn run_top(&mut self, li: usize) -> Result<(), RunErr> {
        let first = self.loaded[li].prog.paragraphs
            .first().map(|(_, b)| b.clone()).unwrap_or_default();
        self.run_entry(li, first)
    }

    /// Seed a field in the CURRENT frame from request JSON.
    pub fn seed_field(&mut self, name: &str, text: &str) -> Result<(), String> {
        let fi = self.lay().find(name)
            .ok_or_else(|| format!("seed: unknown field {}", name))?;
        let f = self.lay().fields[fi].clone();
        let bytes = match f.kind {
            Kind::Numeric => {
                let d = Dec::parse(text).ok_or_else(|| {
                    format!("seed {}: '{}' not numeric", name, text)
                })?;
                self.lay().encode_numeric(&f, d)
            }
            _ => {
                let mut b = vec![charset::SPACE; f.len];
                num::alnum_store(&mut b, &charset::str_to_ebcdic(text));
                b
            }
        };
        let (s, o, l) = self.place(fi);
        self.arena[s][o..o + l].copy_from_slice(&bytes[..l]);
        Ok(())
    }

    /// Every non-group field of the current frame, for final_state.
    pub fn snapshot(&self) -> Vec<(String, String)> {
        let n = self.lay().fields.len();
        (0..n).filter(|i| {
            let f = &self.lay().fields[*i];
            f.kind != Kind::Group && f.occurs == 1
        }).map(|i| (self.lay().fields[i].name.clone(), self.show(i)))
          .collect()
    }
}

/// "SELECT A , B INTO :X , :Y FROM SCH.T WHERE …" → (["A","B"], "SCH.T")
fn sql_select_parts(up: &str) -> Option<(Vec<String>, String)> {
    let sel = up.find("SELECT")? + 6;
    let from = up.find(" FROM ")?;
    let end_cols = up[..from].find(" INTO ").unwrap_or(from);
    let cols: Vec<String> = up[sel..end_cols]
        .split(',')
        .map(|c| c.trim().to_string())
        .filter(|c| !c.is_empty())
        .collect();
    let table = up[from + 6..].split_whitespace().next()?.to_string();
    if cols.is_empty() || cols.iter().any(|c| c.contains('(')) {
        return None;   // expressions are not columns
    }
    Some((cols, table))
}

/// Host variables following a keyword, up to the next clause.
fn host_vars_after(up: &str, kw: &str) -> Vec<String> {
    let Some(at) = up.find(&format!(" {} ", kw)) else { return Vec::new() };
    let rest = &up[at + kw.len() + 2..];
    let stop = ["FROM", "WHERE", "ORDER", "FOR", "GROUP", "HAVING"];
    let mut out = Vec::new();
    for tok in rest.split(|c: char| c == ',' || c.is_whitespace()) {
        let t = tok.trim();
        if t.is_empty() {
            continue;
        }
        if stop.contains(&t) {
            break;
        }
        if let Some(h) = t.strip_prefix(':') {
            out.push(h.to_string());
        }
    }
    out
}

/// INSERT INTO T (A, B) VALUES (:X, :Y) and UPDATE T SET A = :X, B = :Y
/// → [(qualified column, host variable)]. WHERE-clause hosts are not
/// writes and are deliberately excluded.
fn write_pairs(up: &str) -> Vec<(String, String)> {
    let mut out = Vec::new();
    if up.starts_with("INSERT") {
        let Some(into) = up.find(" INTO ") else { return out };
        let rest = &up[into + 6..];
        let table = rest.split_whitespace().next().unwrap_or("").to_string();
        let (Some(o1), Some(c1)) = (rest.find('('), rest.find(')')) else {
            return out
        };
        let cols: Vec<String> = rest[o1 + 1..c1].split(',')
            .map(|c| c.trim().to_string()).collect();
        let after = &rest[c1 + 1..];
        let Some(vpos) = after.find("VALUES") else { return out };
        let vs = &after[vpos..];
        let (Some(o2), Some(c2)) = (vs.find('('), vs.rfind(')')) else {
            return out
        };
        let hosts: Vec<String> = vs[o2 + 1..c2].split(',')
            .filter_map(|h| h.trim().strip_prefix(':').map(|s| s.to_string()))
            .collect();
        if cols.len() == hosts.len() {
            for (c, h) in cols.into_iter().zip(hosts) {
                out.push((format!("{}.{}", table, c), h));
            }
        }
    } else if up.starts_with("UPDATE") {
        let table = up[6..].split_whitespace().next().unwrap_or("").to_string();
        let Some(setp) = up.find(" SET ") else { return out };
        let body = &up[setp + 5..];
        let body = body.split(" WHERE ").next().unwrap_or(body);
        for clause in body.split(',') {
            let Some((c, v)) = clause.split_once('=') else { continue };
            if let Some(h) = v.trim().strip_prefix(':') {
                out.push((format!("{}.{}", table, c.trim()),
                          h.split_whitespace().next().unwrap_or(h).to_string()));
            }
        }
    }
    out
}

fn has_sql(stmts: &[Stmt]) -> bool {
    stmts.iter().any(|s| match s {
        Stmt::ExecSql { .. } => true,
        Stmt::If { then, els, .. } => has_sql(then) || has_sql(els),
        Stmt::Evaluate { whens, when88, other, .. } =>
            whens.iter().any(|(_, b)| has_sql(b))
                || when88.iter().any(|(_, b)| has_sql(b))
                || has_sql(other),
        _ => false,
    })
}

fn hex(b: &[u8]) -> String {
    b.iter().map(|x| format!("{:02X}", x)).collect::<Vec<_>>().join(" ")
}

fn is_error_field(name: &str) -> bool {
    // Return-code fields (-RC) carry status, not exception identity: '00'
    // is success. Only error/code-bearing fields nominate exceptions.
    name.contains("ERR") || name.contains("CODE") || name.ends_with("-CD")
}

/// An exception code looks like E4417 / S0C7 / ALT-8594 / LIM-49E1: a
/// letter-led token with digits and some length. A bare numeric status
/// ('00', '08') is a return code, and claiming it as an exception would be
/// exactly the kind of plausible-but-wrong finding this project refuses.
fn looks_like_code(v: &str) -> bool {
    let t = v.trim();
    t.len() >= 3
        && t.bytes().next().map(|c| c.is_ascii_alphabetic()).unwrap_or(false)
        && t.bytes().any(|c| c.is_ascii_digit())
        && t.bytes().all(|c| c.is_ascii_alphanumeric() || c == b'-')
}

/// Items helper for tests that build layouts by hand.
pub fn _unused(_: &Item) {}
