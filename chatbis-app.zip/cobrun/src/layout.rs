//! Data division → storage layout: a byte image per 01-level record, with
//! elementary fields as (offset, length, type) views. REDEFINES is another
//! view over the same bytes; 88-levels are named conditions on their
//! parent; OCCURS multiplies extents.

use crate::charset;
use crate::num::{self, Dec};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Usage {
    Display,
    Comp3,
    Binary,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Kind {
    Group,
    Alnum,   // X/A
    Numeric, // 9 with optional S/V
}

#[derive(Debug, Clone)]
pub struct Field {
    pub name: String,
    pub level: u8,
    pub kind: Kind,
    pub usage: Usage,
    pub offset: usize,   // within the 01 record buffer
    pub len: usize,      // byte length of ONE occurrence
    pub digits: usize,   // numeric only
    pub scale: u32,
    pub signed: bool,
    pub occurs: usize,       // 1 = not a table
    pub occ_stride: usize,   // byte stride between occurrences
    pub parent: Option<usize>,
    pub record: usize,       // index of owning 01 record
    pub line: u32,
}

#[derive(Debug, Clone)]
pub struct Cond88 {
    pub name: String,
    pub field: usize,        // index into fields
    pub values: Vec<String>, // literal texts as written
}

#[derive(Debug, Clone)]
pub struct Record {
    pub name: String,
    pub len: usize,
    pub linkage: bool,
}

#[derive(Debug, Default, Clone)]
pub struct Layout {
    pub records: Vec<Record>,
    pub fields: Vec<Field>,
    pub conds: Vec<Cond88>,
    pub values: Vec<(usize, String)>, // (field idx, VALUE literal) initializers
}

#[derive(Debug, Clone)]
pub struct Pic {
    pub kind: Kind,
    pub digits: usize,
    pub scale: u32,
    pub signed: bool,
    pub alnum_len: usize,
}

/// Parse a PICTURE clause: 9(5)V99, S9(3)V9(2), X(10), V999, 9, XX.
pub fn parse_pic(pic: &str) -> Option<Pic> {
    let up = pic.to_uppercase();
    let bytes = up.as_bytes();
    let mut i = 0;
    let mut signed = false;
    let mut before = 0usize;
    let mut after = 0usize;
    let mut alnum = 0usize;
    let mut seen_v = false;
    let mut is_num = false;
    let mut is_x = false;
    if i < bytes.len() && bytes[i] == b'S' {
        signed = true;
        i += 1;
    }
    while i < bytes.len() {
        let c = bytes[i];
        let mut count = 1usize;
        if i + 1 < bytes.len() && bytes[i + 1] == b'(' {
            let close = up[i + 2..].find(')')? + i + 2;
            count = up[i + 2..close].parse().ok()?;
            i = close;
        }
        match c {
            b'9' => {
                is_num = true;
                if seen_v { after += count } else { before += count }
            }
            b'V' => seen_v = true,
            b'X' | b'A' => {
                is_x = true;
                alnum += count;
            }
            _ => return None, // edited pictures land in a later phase
        }
        i += 1;
    }
    if is_x && !is_num {
        Some(Pic { kind: Kind::Alnum, digits: 0, scale: 0, signed: false,
                   alnum_len: alnum })
    } else if is_num && !is_x {
        Some(Pic { kind: Kind::Numeric, digits: before + after,
                   scale: after as u32, signed, alnum_len: 0 })
    } else {
        None
    }
}

pub fn byte_len(p: &Pic, usage: Usage) -> usize {
    match (p.kind, usage) {
        (Kind::Alnum, _) => p.alnum_len,
        (Kind::Numeric, Usage::Display) => p.digits,
        (Kind::Numeric, Usage::Comp3) => (p.digits + 2) / 2,
        (Kind::Numeric, Usage::Binary) => num::comp_bytes_for_digits(p.digits),
        (Kind::Group, _) => 0,
    }
}

/// One parsed data-division entry, before layout.
#[derive(Debug, Clone)]
pub struct Item {
    pub level: u8,
    pub name: String,
    pub pic: Option<Pic>,
    pub usage: Usage,
    pub occurs: usize,
    pub redefines: Option<String>,
    pub value: Option<String>,
    pub cond_values: Vec<String>, // for level 88
    pub line: u32,
}

impl Layout {
    pub fn find(&self, name: &str) -> Option<usize> {
        let up = name.to_uppercase();
        self.fields.iter().position(|f| f.name == up)
    }

    /// The stride to advance one occurrence of `fi`: its own if it is the
    /// table, else the nearest ancestor group that OCCURS. None = not
    /// subscriptable, which makes a subscript on it an error, not a guess.
    pub fn stride_for(&self, fi: usize) -> Option<usize> {
        let f = &self.fields[fi];
        if f.occurs > 1 {
            return Some(f.occ_stride);
        }
        let mut p = f.parent;
        while let Some(pi) = p {
            if self.fields[pi].occurs > 1 {
                return Some(self.fields[pi].occ_stride);
            }
            p = self.fields[pi].parent;
        }
        None
    }

    pub fn find_cond(&self, name: &str) -> Option<&Cond88> {
        let up = name.to_uppercase();
        self.conds.iter().find(|c| c.name == up)
    }

    /// Build from a stream of items (one data section, WS or LINKAGE).
    pub fn build(&mut self, items: &[Item], linkage: bool) -> Result<(), String> {
        let mut stack: Vec<usize> = Vec::new(); // open group field indexes
        let mut cur_record: usize = usize::MAX;
        let mut last_field: Option<usize> = None;

        for it in items {
            if it.level == 88 {
                // An 88 conditions the item it FOLLOWS — the previous
                // elementary (or group) entry, never the open group.
                let parent = last_field.ok_or_else(|| {
                    format!("88 {} with no preceding field", it.name)
                })?;
                self.conds.push(Cond88 {
                    name: it.name.clone(),
                    field: parent,
                    values: it.cond_values.clone(),
                });
                continue;
            }
            // close groups at deeper-or-equal levels
            while let Some(&top) = stack.last() {
                if self.fields[top].level >= it.level {
                    stack.pop();
                } else {
                    break;
                }
            }
            if it.level == 1 {
                cur_record = self.records.len();
                self.records.push(Record {
                    name: it.name.to_uppercase(),
                    len: 0,
                    linkage,
                });
            }
            if cur_record == usize::MAX {
                return Err(format!("{} before any 01 level", it.name));
            }
            let offset = if let Some(rd) = &it.redefines {
                let tgt = self.find(rd)
                    .ok_or_else(|| format!("REDEFINES {}: unknown", rd))?;
                self.fields[tgt].offset
            } else if let Some(&parent) = stack.last() {
                self.fields[parent].offset + self.fields[parent].len
            } else {
                0
            };
            let (kind, len, digits, scale, signed) = match &it.pic {
                Some(p) => (p.kind, byte_len(p, it.usage), p.digits, p.scale,
                            p.signed),
                None => (Kind::Group, 0, 0, 0, false),
            };
            let idx = self.fields.len();
            last_field = Some(idx);
            self.fields.push(Field {
                name: it.name.to_uppercase(),
                level: it.level,
                kind,
                usage: it.usage,
                offset,
                len,
                digits,
                scale,
                signed,
                occurs: it.occurs,
                occ_stride: len, // set after children for groups
                parent: stack.last().copied(),
                record: cur_record,
                line: it.line,
            });
            if let Some(v) = &it.value {
                self.values.push((idx, v.clone()));
            }
            if kind == Kind::Group {
                stack.push(idx);
            } else {
                // grow ancestors by this field's full (occurs) extent —
                // unless it redefines, which consumes no new space
                if it.redefines.is_none() {
                    let extent = len * it.occurs;
                    let mut p = stack.last().copied();
                    while let Some(pi) = p {
                        self.fields[pi].len += extent;
                        p = self.fields[pi].parent;
                    }
                    self.records[cur_record].len =
                        self.records[cur_record].len.max(offset + extent);
                }
            }
        }
        // finalize group strides and record lengths from group extents
        for i in 0..self.fields.len() {
            if self.fields[i].kind == Kind::Group {
                self.fields[i].occ_stride = self.fields[i].len;
                let rec = self.fields[i].record;
                let ext = self.fields[i].offset
                    + self.fields[i].len * self.fields[i].occurs;
                self.records[rec].len = self.records[rec].len.max(ext);
            }
        }
        Ok(())
    }

    /// Initialize a record buffer: spaces for alnum/group, encoded zeros
    /// for numeric, then VALUE clauses.
    pub fn init_buffer(&self, rec: usize) -> Vec<u8> {
        let mut buf = vec![charset::SPACE; self.records[rec].len];
        for f in self.fields.iter().filter(|f| f.record == rec) {
            if f.kind == Kind::Numeric {
                for k in 0..f.occurs {
                    let off = f.offset + k * f.occ_stride;
                    let z = self.encode_numeric(f, Dec::zero());
                    buf[off..off + f.len].copy_from_slice(&z);
                }
            }
        }
        for (idx, lit) in &self.values {
            let f = &self.fields[*idx];
            if f.record != rec {
                continue;
            }
            let bytes = self.encode_value(f, lit);
            let off = f.offset;
            buf[off..off + bytes.len().min(f.len.max(bytes.len()))]
                .copy_from_slice(&bytes);
        }
        buf
    }

    pub fn encode_numeric(&self, f: &Field, v: Dec) -> Vec<u8> {
        match f.usage {
            Usage::Display => num::zoned_encode(v, f.digits, f.scale, f.signed),
            Usage::Comp3 => num::packed_encode(v, f.digits, f.scale),
            Usage::Binary => num::binary_encode(v, f.digits, f.scale),
        }
    }

    fn encode_value(&self, f: &Field, lit: &str) -> Vec<u8> {
        match f.kind {
            Kind::Numeric => {
                let v = Dec::parse(lit).unwrap_or(Dec::zero());
                self.encode_numeric(f, v)
            }
            _ => {
                let mut b = vec![charset::SPACE; f.len];
                let src = charset::str_to_ebcdic(lit);
                num::alnum_store(&mut b, &src);
                b
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn item(level: u8, name: &str, pic: Option<&str>, usage: Usage) -> Item {
        Item {
            level,
            name: name.into(),
            pic: pic.map(|p| parse_pic(p).unwrap()),
            usage,
            occurs: 1,
            redefines: None,
            value: None,
            cond_values: vec![],
            line: 0,
        }
    }

    #[test]
    fn pic_parsing() {
        let p = parse_pic("S9(5)V99").unwrap();
        assert_eq!((p.digits, p.scale, p.signed), (7, 2, true));
        let x = parse_pic("X(10)").unwrap();
        assert_eq!(x.alnum_len, 10);
        let v = parse_pic("V999").unwrap();
        assert_eq!((v.digits, v.scale), (3, 3));
        assert!(parse_pic("Z(5)9").is_none()); // edited: refused for now
    }

    #[test]
    fn offsets_groups_and_occurs() {
        let mut l = Layout::default();
        let mut it3 = item(5, "T-ENT", None, Usage::Display);
        it3.occurs = 3;
        l.build(&[
            item(1, "REC", None, Usage::Display),
            item(5, "A", Some("X(4)"), Usage::Display),
            item(5, "B", Some("9(3)"), Usage::Display),
            it3,
            item(10, "T-S", Some("X(2)"), Usage::Display),
            item(10, "T-E", Some("X(2)"), Usage::Display),
        ], false).unwrap();
        let b = &l.fields[l.find("B").unwrap()];
        assert_eq!(b.offset, 4);
        let t = &l.fields[l.find("T-ENT").unwrap()];
        assert_eq!((t.offset, t.occ_stride, t.occurs), (7, 4, 3));
        let te = &l.fields[l.find("T-E").unwrap()];
        assert_eq!(te.offset, 9);
        assert_eq!(l.records[0].len, 7 + 4 * 3);
    }

    #[test]
    fn redefines_shares_offset() {
        let mut l = Layout::default();
        let mut rd = item(5, "B-NUM", Some("9(4)"), Usage::Display);
        rd.redefines = Some("B-CHR".into());
        l.build(&[
            item(1, "R", None, Usage::Display),
            item(5, "B-CHR", Some("X(4)"), Usage::Display),
            rd,
        ], false).unwrap();
        assert_eq!(l.fields[l.find("B-NUM").unwrap()].offset,
                   l.fields[l.find("B-CHR").unwrap()].offset);
        assert_eq!(l.records[0].len, 4); // redefines consumes no space
    }

    #[test]
    fn init_values_and_zeros() {
        let mut l = Layout::default();
        let mut v = item(5, "PCT", Some("V999"), Usage::Display);
        v.value = Some(".750".into());
        l.build(&[item(1, "W", None, Usage::Display),
                  item(5, "AMT", Some("9(3)V99"), Usage::Display), v],
                false).unwrap();
        let buf = l.init_buffer(0);
        // AMT initialized to encoded zeros, not spaces
        assert_eq!(&buf[0..5], &[0xF0; 5]);
        // PCT carries .750
        assert_eq!(&buf[5..8], &[0xF7, 0xF5, 0xF0]);
    }
}
