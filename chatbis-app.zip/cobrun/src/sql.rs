//! The snapshot shim: the case JSON is the database, for reads.
//!
//! Two jobs. `convert` turns a JSON value into the text the COBOL field
//! expects, per the mapping's declared format — the mainframe nuances live
//! here (Julian dates, windowed two-digit years, CCYYMMDD) and an
//! unconvertible value is an error naming the mapping, never a silent
//! store of bytes that would detonate later as S0C7.
//!
//! `Snapshot` resolves SELECT/FETCH against the case through the field map,
//! and holds the run-local overlay so a write made earlier in the run is
//! visible to a read made later — DBPUT posts, NOTIFDRV sees it.

use serde_json::Value;
use std::collections::HashMap;

/// A copybook-scoped seed mapping: how the case JSON fills one field of
/// an interface area. Owned by the AREA (the 01-level), not by any
/// application or pipeline — true wherever the copybook appears.
#[derive(Debug, Clone)]
pub struct AreaMap {
    pub area: String,    // 01-level name, e.g. EE-RECORD
    pub field: String,   // field within it
    pub path: String,    // case JSON path; [] marks a repeating group
    pub format: String,
}

#[derive(Debug, Clone)]
pub struct Mapping {
    pub db2: String,     // SCHEMA.TABLE.COLUMN, uppercased
    pub path: String,    // dot path into the case JSON
    pub format: String,  // text | iso-date | yyyymmdd | julian-* | decimal…
}

/// Two-digit-year window: 69 → 1969, 68 → 2068. The pivot is explicit
/// because it is a business decision, not a fact.
const PIVOT: u32 = 69;

fn days_in_month(y: u32, m: u32) -> u32 {
    match m {
        1 | 3 | 5 | 7 | 8 | 10 | 12 => 31,
        4 | 6 | 9 | 11 => 30,
        2 if (y % 4 == 0 && y % 100 != 0) || y % 400 == 0 => 29,
        2 => 28,
        _ => 0,
    }
}

fn day_of_year(y: u32, m: u32, d: u32) -> u32 {
    (1..m).map(|mm| days_in_month(y, mm)).sum::<u32>() + d
}

fn from_day_of_year(y: u32, doy: u32) -> Option<(u32, u32)> {
    let mut rest = doy;
    for m in 1..=12 {
        let dim = days_in_month(y, m);
        if rest <= dim {
            return Some((m, rest));
        }
        rest -= dim;
    }
    None
}

fn parse_iso(s: &str) -> Option<(u32, u32, u32)> {
    let p: Vec<&str> = s.split('-').collect();
    if p.len() != 3 {
        return None;
    }
    let (y, m, d) = (p[0].parse().ok()?, p[1].parse().ok()?, p[2].parse().ok()?);
    if m == 0 || m > 12 || d == 0 || d > days_in_month(y, m) {
        return None;
    }
    Some((y, m, d))
}

/// JSON value → the text to store, per the declared format.
/// Err names the mapping so the halt is actionable.
pub fn convert(v: &Value, format: &str, col: &str) -> Result<String, String> {
    let raw = match v {
        Value::Null => return Ok(String::new()),
        Value::String(s) => s.trim().to_string(),
        Value::Number(n) => n.to_string(),
        Value::Bool(b) => (if *b { "Y" } else { "N" }).to_string(),
        other => other.to_string(),
    };
    if raw.is_empty() {
        return Ok(String::new());
    }
    let bad = |why: &str| {
        Err(format!("{}: cannot convert {:?} as {} — {}", col, raw, format, why))
    };
    Ok(match format {
        "" | "text" | "flag" => raw,
        "integer" | "decimal" => {
            // A sign only at the front, digits, at most one point. Naively
            // allowing '-' anywhere accepts "1958-04-02" as a number — the
            // exact silent corruption this format column exists to stop.
            let body = raw.strip_prefix(['-', '+']).unwrap_or(&raw);
            let ok = !body.is_empty()
                && body.matches('.').count() <= 1
                && body.bytes().all(|c| c.is_ascii_digit() || c == b'.')
                && (format != "integer" || !body.contains('.'));
            if !ok {
                return bad("not numeric");
            }
            raw
        }
        "iso-date" => {
            // Stored as written; the field is alphanumeric by construction.
            if parse_iso(&raw).is_none() {
                return bad("not an ISO date");
            }
            raw
        }
        "yyyymmdd" => match parse_iso(&raw) {
            Some((y, m, d)) => format!("{:04}{:02}{:02}", y, m, d),
            None if raw.len() == 8 && raw.bytes().all(|c| c.is_ascii_digit())
                => raw,
            None => return bad("expected an ISO date or 8 digits"),
        },
        "yymmdd" => match parse_iso(&raw) {
            Some((y, m, d)) => format!("{:02}{:02}{:02}", y % 100, m, d),
            None if raw.len() == 6 && raw.bytes().all(|c| c.is_ascii_digit())
                => raw,
            None => return bad("expected an ISO date or 6 digits"),
        },
        "julian-ccyyddd" => match parse_iso(&raw) {
            Some((y, m, d)) => format!("{:04}{:03}", y, day_of_year(y, m, d)),
            None if raw.len() == 7 && raw.bytes().all(|c| c.is_ascii_digit())
                => raw,
            None => return bad("expected an ISO date or CCYYDDD"),
        },
        "julian-yyddd" => match parse_iso(&raw) {
            Some((y, m, d)) => format!("{:02}{:03}", y % 100,
                                       day_of_year(y, m, d)),
            None if raw.len() == 5 && raw.bytes().all(|c| c.is_ascii_digit())
                => raw,
            None => return bad("expected an ISO date or YYDDD"),
        },
        other => return Err(format!(
            "{}: unknown format '{}' — declare a supported one", col, other)),
    })
}

/// Stored COBOL text → the JSON-shaped value, for would-write events and
/// for handing values back to ChatBIS. The inverse of `convert`.
pub fn unconvert(text: &str, format: &str) -> String {
    let t = text.trim();
    if t.is_empty() {
        return String::new();
    }
    let digits = |s: &str| s.bytes().all(|c| c.is_ascii_digit());
    match format {
        "yyyymmdd" if t.len() == 8 && digits(t) =>
            format!("{}-{}-{}", &t[0..4], &t[4..6], &t[6..8]),
        "yymmdd" if t.len() == 6 && digits(t) => {
            let yy: u32 = t[0..2].parse().unwrap();
            let y = if yy > PIVOT { 1900 + yy } else { 2000 + yy };
            format!("{:04}-{}-{}", y, &t[2..4], &t[4..6])
        }
        "julian-ccyyddd" if t.len() == 7 && digits(t) => {
            let y: u32 = t[0..4].parse().unwrap();
            let doy: u32 = t[4..7].parse().unwrap();
            match from_day_of_year(y, doy) {
                Some((m, d)) => format!("{:04}-{:02}-{:02}", y, m, d),
                None => t.to_string(),
            }
        }
        "julian-yyddd" if t.len() == 5 && digits(t) => {
            let yy: u32 = t[0..2].parse().unwrap();
            let y = if yy > PIVOT { 1900 + yy } else { 2000 + yy };
            let doy: u32 = t[2..5].parse().unwrap();
            match from_day_of_year(y, doy) {
                Some((m, d)) => format!("{:04}-{:02}-{:02}", y, m, d),
                None => t.to_string(),
            }
        }
        _ => t.to_string(),
    }
}

pub struct Snapshot {
    pub case: Value,
    pub maps: HashMap<String, Mapping>,   // keyed by uppercased DB2 column
    /// Run-local writes: column → value. Reads see these on top of the case.
    pub overlay: HashMap<String, String>,
    pub writes: Vec<(String, String, String)>, // (stmt, column, value)
}

pub(crate) fn dig<'a>(v: &'a Value, path: &str) -> Option<&'a Value> {
    let mut cur = v;
    for part in path.split('.') {
        let base = part.trim_end_matches("[]");
        cur = cur.get(base)?;
        if part.ends_with("[]") {
            cur = cur.get(0)?;
        }
    }
    Some(cur)
}

impl Snapshot {
    pub fn new(case: Value, maps: Vec<Mapping>) -> Snapshot {
        Snapshot {
            case,
            maps: maps.into_iter()
                .map(|m| (m.db2.to_uppercase(), m)).collect(),
            overlay: HashMap::new(),
            writes: Vec::new(),
        }
    }

    /// One column's value for the case, as storable text.
    /// Err = halt-worthy: no mapping, absent in the case, or unconvertible.
    pub fn read(&self, column: &str) -> Result<String, String> {
        let key = column.to_uppercase();
        if let Some(v) = self.overlay.get(&key) {
            return Ok(v.clone());
        }
        let m = self.maps.get(&key).ok_or_else(|| format!(
            "no field mapping for {} — map it in Settings › Mapping", key))?;
        let raw = dig(&self.case, &m.path).ok_or_else(|| format!(
            "{} maps to {}, which the case data does not carry", key, m.path))?;
        convert(raw, &m.format, &key)
    }

    /// Rows for a cursor over a repeating group, e.g. MCS.ENT_PERIODS.
    /// Returns the group's length; column reads then index into it.
    pub fn group_len(&self, columns: &[String]) -> Option<usize> {
        for c in columns {
            if let Some(m) = self.maps.get(&c.to_uppercase()) {
                if let Some((head, _)) = m.path.split_once("[]") {
                    if let Some(Value::Array(a)) = dig_array(&self.case, head) {
                        return Some(a.len());
                    }
                }
            }
        }
        None
    }

    pub fn read_at(&self, column: &str, idx: usize) -> Result<String, String> {
        let key = column.to_uppercase();
        let m = self.maps.get(&key).ok_or_else(|| format!(
            "no field mapping for {} — map it in Settings › Mapping", key))?;
        let (head, tail) = m.path.split_once("[]").ok_or_else(|| format!(
            "{} maps to {}, which is not a repeating group", key, m.path))?;
        let arr = dig_array(&self.case, head).ok_or_else(|| format!(
            "{}: the case data does not carry {}", key, head))?;
        let Value::Array(a) = arr else {
            return Err(format!("{}: {} is not an array", key, head));
        };
        let row = a.get(idx).ok_or_else(|| format!("{}: row {} past the end",
                                                   key, idx))?;
        let leaf = tail.trim_start_matches('.');
        let v = dig(row, leaf).ok_or_else(|| format!(
            "{}: occurrence {} has no {}", key, idx, leaf))?;
        convert(v, &m.format, &key)
    }

    /// A write: recorded AND applied to the overlay, so later reads in this
    /// run see it. Nothing outside this process is touched.
    pub fn write(&mut self, stmt: &str, column: &str, value: &str) {
        let key = column.to_uppercase();
        self.overlay.insert(key.clone(), value.to_string());
        self.writes.push((stmt.to_string(), key, value.to_string()));
    }
}

fn dig_array<'a>(v: &'a Value, path: &str) -> Option<&'a Value> {
    dig_raw(v, path)
}

fn dig_raw<'a>(v: &'a Value, path: &str) -> Option<&'a Value> {
    let mut cur = v;
    for part in path.split('.') {
        if part.is_empty() {
            continue;
        }
        cur = cur.get(part)?;
    }
    Some(cur)
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    #[test]
    fn iso_to_ccyymmdd() {
        assert_eq!(convert(&json!("1958-04-02"), "yyyymmdd", "C").unwrap(),
                   "19580402");
        // already in host shape: passes through
        assert_eq!(convert(&json!("19580402"), "yyyymmdd", "C").unwrap(),
                   "19580402");
    }

    #[test]
    fn julian_both_widths() {
        // 2026-02-01 is day 32
        assert_eq!(convert(&json!("2026-02-01"), "julian-ccyyddd", "C")
                   .unwrap(), "2026032");
        assert_eq!(convert(&json!("2026-02-01"), "julian-yyddd", "C")
                   .unwrap(), "26032");
        // leap year: 2024-03-01 is day 61, not 60
        assert_eq!(convert(&json!("2024-03-01"), "julian-ccyyddd", "C")
                   .unwrap(), "2024061");
    }

    #[test]
    fn round_trips_through_unconvert() {
        for (iso, fmt) in [("1958-04-02", "yyyymmdd"),
                           ("2026-02-01", "julian-ccyyddd"),
                           ("2026-02-01", "julian-yyddd"),
                           ("1999-12-31", "yymmdd")] {
            let stored = convert(&json!(iso), fmt, "C").unwrap();
            assert_eq!(unconvert(&stored, fmt), iso, "{} via {}", iso, fmt);
        }
    }

    #[test]
    fn two_digit_year_windowing() {
        // 99 → 1999 (above the pivot), 26 → 2026 (below)
        assert_eq!(unconvert("991231", "yymmdd"), "1999-12-31");
        assert_eq!(unconvert("260201", "yymmdd"), "2026-02-01");
    }

    #[test]
    fn garbage_refuses_rather_than_planting_bytes() {
        let e = convert(&json!("1958-04-02"), "decimal", "MCS.CLAIM.AMT")
            .unwrap_err();
        assert!(e.contains("MCS.CLAIM.AMT"), "{}", e);
        assert!(e.contains("not numeric"), "{}", e);
        assert!(convert(&json!("not-a-date"), "yyyymmdd", "C").is_err());
        assert!(convert(&json!("2026-13-45"), "iso-date", "C").is_err());
        assert!(convert(&json!("x"), "moon-phase", "C").is_err());
    }

    #[test]
    fn null_and_empty_are_empty_not_garbage() {
        assert_eq!(convert(&Value::Null, "yyyymmdd", "C").unwrap(), "");
        assert_eq!(convert(&json!(""), "decimal", "C").unwrap(), "");
    }

    fn snap() -> Snapshot {
        Snapshot::new(json!({
            "claimant": {"ssn": "900010002", "dateOfBirth": "1958-04-02"},
            "claim": {"mba": "1842.50"},
            "entitlementPeriods": [
                {"startDate": "2019-01-01"},
                {"startDate": "2021-06-01"},
            ],
        }), vec![
            Mapping { db2: "MCS.CLAIM.BENE_DOB".into(),
                      path: "claimant.dateOfBirth".into(),
                      format: "yyyymmdd".into() },
            Mapping { db2: "MCS.CLAIM.MBA".into(), path: "claim.mba".into(),
                      format: "decimal".into() },
            Mapping { db2: "MCS.ENT_PERIODS.ENT_STRT_DT".into(),
                      path: "entitlementPeriods[].startDate".into(),
                      format: "yyyymmdd".into() },
        ])
    }

    #[test]
    fn reads_convert_through_the_map() {
        assert_eq!(snap().read("MCS.CLAIM.BENE_DOB").unwrap(), "19580402");
        assert_eq!(snap().read("mcs.claim.mba").unwrap(), "1842.50");
    }

    #[test]
    fn unmapped_and_absent_are_distinct_errors() {
        let s = snap();
        assert!(s.read("MCS.CLAIM.NOPE").unwrap_err()
                 .contains("no field mapping"));
        let s2 = Snapshot::new(json!({}), vec![Mapping {
            db2: "T.C".into(), path: "a.b".into(), format: "text".into() }]);
        assert!(s2.read("T.C").unwrap_err().contains("does not carry"));
    }

    #[test]
    fn cursor_walks_the_repeating_group() {
        let s = snap();
        let cols = vec!["MCS.ENT_PERIODS.ENT_STRT_DT".to_string()];
        assert_eq!(s.group_len(&cols), Some(2));
        assert_eq!(s.read_at(&cols[0], 0).unwrap(), "20190101");
        assert_eq!(s.read_at(&cols[0], 1).unwrap(), "20210601");
        assert!(s.read_at(&cols[0], 2).is_err()); // past the end → +100
    }

    #[test]
    fn writes_are_visible_to_later_reads_in_the_same_run() {
        let mut s = snap();
        assert_eq!(s.read("MCS.CLAIM.MBA").unwrap(), "1842.50");
        s.write("insert", "MCS.CLAIM.MBA", "1350.00");
        assert_eq!(s.read("MCS.CLAIM.MBA").unwrap(), "1350.00");
        assert_eq!(s.writes.len(), 1);
        // …and the case itself is untouched
        assert_eq!(s.case["claim"]["mba"], json!("1842.50"));
    }
}
