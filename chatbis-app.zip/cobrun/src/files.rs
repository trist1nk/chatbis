//! The dataset world: in-memory datasets keyed by DDNAME, so a step writes
//! what a later step reads. The JCL binding (DD → DSN) is what makes the
//! seam real — two steps naming the same DSN share the dataset even under
//! different DDNAMEs, exactly as on the host.
//!
//! Records are byte images (EBCDIC), never decoded — a dataset is bytes.

use std::collections::HashMap;

#[derive(Debug, Default, Clone)]
pub struct Dataset {
    pub records: Vec<Vec<u8>>,
    /// GDG base, when the DSN carried a generation.
    pub gdg: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Mode {
    Input,
    Output,
    Io,
    Extend,
}

#[derive(Debug, Clone)]
pub struct OpenFile {
    pub dsn: String,
    pub mode: Mode,
    pub pos: usize,
}

#[derive(Debug, Default)]
pub struct World {
    /// DSN (GDG base) → dataset
    pub sets: HashMap<String, Dataset>,
    /// This step's DD → DSN bindings, from the mined JCL.
    pub dd_to_dsn: HashMap<String, String>,
    /// Logical file name in the running program → its open state.
    pub open: HashMap<String, OpenFile>,
}

/// 'PROD.T2.AUDIT(+1)' → ('PROD.T2.AUDIT', true): generations of one GDG
/// are the same dataset for handoff purposes.
pub fn gdg_base(dsn: &str) -> (String, bool) {
    if let Some(o) = dsn.rfind('(') {
        if dsn.ends_with(')') {
            let inner = &dsn[o + 1..dsn.len() - 1];
            let numeric = inner.strip_prefix(['+', '-']).unwrap_or(inner);
            if !numeric.is_empty() && numeric.bytes().all(|c| c.is_ascii_digit()) {
                return (dsn[..o].to_string(), true);
            }
        }
    }
    (dsn.to_string(), false)
}

impl World {
    /// Resolve a DDNAME to its dataset key. Without a JCL binding the
    /// DDNAME itself is the key — honest, and it still lets a single-step
    /// run work; the trace records which it used.
    pub fn key_for(&self, ddname: &str) -> (String, bool) {
        match self.dd_to_dsn.get(&ddname.to_uppercase()) {
            Some(dsn) => gdg_base(dsn),
            None => (ddname.to_uppercase(), false),
        }
    }

    pub fn open_file(&mut self, logical: &str, ddname: &str, mode: Mode)
        -> Result<String, String> {
        let (dsn, gdg) = self.key_for(ddname);
        match mode {
            Mode::Input | Mode::Io => {
                if !self.sets.contains_key(&dsn) {
                    return Err(format!(
                        "OPEN INPUT {} ({}) — no dataset: supply its contents \
                         or run the step that writes it first", ddname, dsn));
                }
            }
            Mode::Output => {
                // OPEN OUTPUT replaces, as the host does.
                self.sets.insert(dsn.clone(), Dataset { records: Vec::new(), gdg });
            }
            Mode::Extend => {
                self.sets.entry(dsn.clone()).or_default();
            }
        }
        self.open.insert(logical.to_uppercase(),
                         OpenFile { dsn: dsn.clone(), mode, pos: 0 });
        Ok(dsn)
    }

    pub fn close_file(&mut self, logical: &str) {
        self.open.remove(&logical.to_uppercase());
    }

    /// Sequential READ. Ok(None) = at end (AT END / SQLCODE-equivalent).
    pub fn read(&mut self, logical: &str) -> Result<Option<Vec<u8>>, String> {
        let f = self.open.get_mut(&logical.to_uppercase()).ok_or_else(|| {
            format!("READ {} before OPEN", logical)
        })?;
        if f.mode == Mode::Output {
            return Err(format!("READ {} opened OUTPUT", logical));
        }
        let ds = self.sets.get(&f.dsn).ok_or_else(|| {
            format!("READ {}: dataset {} vanished", logical, f.dsn)
        })?;
        if f.pos >= ds.records.len() {
            return Ok(None);
        }
        let rec = ds.records[f.pos].clone();
        f.pos += 1;
        Ok(Some(rec))
    }

    pub fn write(&mut self, logical: &str, bytes: Vec<u8>)
        -> Result<String, String> {
        let f = self.open.get(&logical.to_uppercase()).ok_or_else(|| {
            format!("WRITE {} before OPEN", logical)
        })?;
        if f.mode == Mode::Input {
            return Err(format!("WRITE {} opened INPUT", logical));
        }
        let dsn = f.dsn.clone();
        self.sets.entry(dsn.clone()).or_default().records.push(bytes);
        Ok(dsn)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn gdg_generations_share_a_base() {
        assert_eq!(gdg_base("PROD.T2.AUDIT(+1)"),
                   ("PROD.T2.AUDIT".into(), true));
        assert_eq!(gdg_base("PROD.T2.AUDIT(0)"),
                   ("PROD.T2.AUDIT".into(), true));
        assert_eq!(gdg_base("PROD.DAILY.TRANS"),
                   ("PROD.DAILY.TRANS".into(), false));
        // not a generation — a qualified name that merely has parens
        assert_eq!(gdg_base("PROD.LIB(MEMBER)").1, false);
    }

    #[test]
    fn a_step_reads_what_an_earlier_step_wrote() {
        let mut w = World::default();
        w.dd_to_dsn.insert("OUTDD".into(), "P.WORK(+1)".into());
        w.dd_to_dsn.insert("INDD".into(), "P.WORK(0)".into());
        w.open_file("OUT-FILE", "OUTDD", Mode::Output).unwrap();
        w.write("OUT-FILE", b"row-one".to_vec()).unwrap();
        w.write("OUT-FILE", b"row-two".to_vec()).unwrap();
        w.close_file("OUT-FILE");
        // different DD, same GDG base → the same dataset
        w.open_file("IN-FILE", "INDD", Mode::Input).unwrap();
        assert_eq!(w.read("IN-FILE").unwrap().unwrap(), b"row-one".to_vec());
        assert_eq!(w.read("IN-FILE").unwrap().unwrap(), b"row-two".to_vec());
        assert!(w.read("IN-FILE").unwrap().is_none()); // AT END
    }

    #[test]
    fn open_input_without_contents_says_what_to_do() {
        let mut w = World::default();
        let e = w.open_file("F", "MISSING", Mode::Input).unwrap_err();
        assert!(e.contains("no dataset"), "{}", e);
        assert!(e.contains("run the step that writes it"), "{}", e);
    }

    #[test]
    fn open_output_replaces_like_the_host() {
        let mut w = World::default();
        w.open_file("F", "DD1", Mode::Output).unwrap();
        w.write("F", b"old".to_vec()).unwrap();
        w.open_file("F", "DD1", Mode::Output).unwrap();
        assert!(w.sets["DD1"].records.is_empty());
    }

    #[test]
    fn mode_violations_are_errors_not_silent() {
        let mut w = World::default();
        w.open_file("F", "DD1", Mode::Output).unwrap();
        assert!(w.read("F").is_err());
        w.open_file("G", "DD1", Mode::Input).unwrap();
        assert!(w.write("G", b"x".to_vec()).is_err());
    }
}
