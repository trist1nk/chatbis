//! CP037 — internal storage is EBCDIC, exactly like the host, so collation
//! and class conditions answer the way the machine answers. Unmappable
//! characters become the EBCDIC substitute rather than being guessed.

const SUB: u8 = 0x6F; // '?'

/// ASCII (printable subset) → CP037.
pub fn a2e(b: u8) -> u8 {
    match b {
        b' ' => 0x40,
        b'.' => 0x4B,
        b'<' => 0x4C,
        b'(' => 0x4D,
        b'+' => 0x4E,
        b'|' => 0x4F,
        b'&' => 0x50,
        b'!' => 0x5A,
        b'$' => 0x5B,
        b'*' => 0x5C,
        b')' => 0x5D,
        b';' => 0x5E,
        b'-' => 0x60,
        b'/' => 0x61,
        b',' => 0x6B,
        b'%' => 0x6C,
        b'_' => 0x6D,
        b'>' => 0x6E,
        b'?' => 0x6F,
        b'`' => 0x79,
        b':' => 0x7A,
        b'#' => 0x7B,
        b'@' => 0x7C,
        b'\'' => 0x7D,
        b'=' => 0x7E,
        b'"' => 0x7F,
        b'a'..=b'i' => 0x81 + (b - b'a'),
        b'j'..=b'r' => 0x91 + (b - b'j'),
        b's'..=b'z' => 0xA2 + (b - b's'),
        b'A'..=b'I' => 0xC1 + (b - b'A'),
        b'J'..=b'R' => 0xD1 + (b - b'J'),
        b'S'..=b'Z' => 0xE2 + (b - b'S'),
        b'0'..=b'9' => 0xF0 + (b - b'0'),
        _ => SUB,
    }
}

/// CP037 → ASCII ('?' for the unprintable rest).
pub fn e2a(b: u8) -> u8 {
    match b {
        0x40 => b' ',
        0x4B => b'.',
        0x4C => b'<',
        0x4D => b'(',
        0x4E => b'+',
        0x4F => b'|',
        0x50 => b'&',
        0x5A => b'!',
        0x5B => b'$',
        0x5C => b'*',
        0x5D => b')',
        0x5E => b';',
        0x60 => b'-',
        0x61 => b'/',
        0x6B => b',',
        0x6C => b'%',
        0x6D => b'_',
        0x6E => b'>',
        0x6F => b'?',
        0x79 => b'`',
        0x7A => b':',
        0x7B => b'#',
        0x7C => b'@',
        0x7D => b'\'',
        0x7E => b'=',
        0x7F => b'"',
        0x81..=0x89 => b'a' + (b - 0x81),
        0x91..=0x99 => b'j' + (b - 0x91),
        0xA2..=0xA9 => b's' + (b - 0xA2),
        0xC1..=0xC9 => b'A' + (b - 0xC1),
        0xD1..=0xD9 => b'J' + (b - 0xD1),
        0xE2..=0xE9 => b'S' + (b - 0xE2),
        0xF0..=0xF9 => b'0' + (b - 0xF0),
        _ => b'?',
    }
}

pub fn str_to_ebcdic(s: &str) -> Vec<u8> {
    s.bytes().map(a2e).collect()
}

pub fn ebcdic_to_string(b: &[u8]) -> String {
    b.iter().map(|&x| e2a(x) as char).collect()
}

pub const SPACE: u8 = 0x40;
pub const LOW: u8 = 0x00;
pub const HIGH: u8 = 0xFF;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn round_trip_printables() {
        for c in b"ABCXYZabcxyz0189 .,-/'=():$*+<>&;#@_%\"!|?".iter() {
            assert_eq!(e2a(a2e(*c)), *c, "byte {}", *c as char);
        }
    }

    #[test]
    fn collation_letters_below_digits() {
        // The EBCDIC fact the whole design leans on: 'A' < '0'.
        assert!(a2e(b'A') < a2e(b'0'));
        assert!(a2e(b'z') < a2e(b'0'));
    }
}
