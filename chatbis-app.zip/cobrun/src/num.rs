//! Numeric encodings and the decimal engine.
//!
//! Zoned (DISPLAY), packed (COMP-3), and binary (COMP) encode/decode over
//! EBCDIC byte images. Invalid decimal digits surface as S0C7 — on USE,
//! which is the caller's job to enforce; these functions just refuse to
//! decode garbage silently.
//!
//! Decimal values are i128 mantissa + scale. Phase-1 arithmetic is exact
//! in i128 and truncates at the destination — WIDER than the host's
//! intermediate-result rules. That deviation is a ledger line
//! (`arith-intermediate: partial`), not a secret.

use crate::charset;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Dec {
    pub mant: i128,
    pub scale: u32,
}

#[derive(Debug, Clone, PartialEq)]
pub enum NumErr {
    S0C7 { bytes: Vec<u8> },
    S0CB,           // divide by zero
    SizeError,      // overflow with ON SIZE ERROR semantics pending
}

impl Dec {
    pub fn zero() -> Dec {
        Dec { mant: 0, scale: 0 }
    }

    pub fn rescale(&self, scale: u32) -> Dec {
        if scale == self.scale {
            *self
        } else if scale > self.scale {
            Dec { mant: self.mant * 10i128.pow(scale - self.scale), scale }
        } else {
            // Truncation toward zero — the host's default on store.
            Dec { mant: self.mant / 10i128.pow(self.scale - scale), scale }
        }
    }

    /// Round to `scale`: nearest, ties away from zero (the IBM ROUNDED rule).
    pub fn round_to(&self, scale: u32) -> Dec {
        if scale >= self.scale {
            return self.rescale(scale);
        }
        let f = 10i128.pow(self.scale - scale);
        let q = self.mant / f;
        let r = (self.mant % f).abs();
        let bump = if r * 2 >= f { self.mant.signum() } else { 0 };
        Dec { mant: q + bump, scale }
    }

    fn align(a: Dec, b: Dec) -> (i128, i128, u32) {
        let s = a.scale.max(b.scale);
        (a.rescale(s).mant, b.rescale(s).mant, s)
    }

    pub fn add(a: Dec, b: Dec) -> Dec {
        let (x, y, s) = Dec::align(a, b);
        Dec { mant: x + y, scale: s }
    }

    pub fn sub(a: Dec, b: Dec) -> Dec {
        let (x, y, s) = Dec::align(a, b);
        Dec { mant: x - y, scale: s }
    }

    pub fn mul(a: Dec, b: Dec) -> Dec {
        Dec { mant: a.mant * b.mant, scale: a.scale + b.scale }
    }

    /// Division carries extra precision (host keeps intermediate digits);
    /// we compute at max(scales)+9 and let the store truncate/round.
    pub fn div(a: Dec, b: Dec) -> Result<Dec, NumErr> {
        if b.mant == 0 {
            return Err(NumErr::S0CB);
        }
        let target = a.scale.max(b.scale) + 9;
        let x = a.rescale(target + b.scale);
        Ok(Dec { mant: x.mant / b.mant, scale: target })
    }

    pub fn cmp(a: Dec, b: Dec) -> std::cmp::Ordering {
        let (x, y, _) = Dec::align(a, b);
        x.cmp(&y)
    }

    /// Parse a COBOL numeric literal: 123, 1.5, .750, -0.9, +49.40
    pub fn parse(lit: &str) -> Option<Dec> {
        let lit = lit.trim();
        let (neg, rest) = match lit.strip_prefix('-') {
            Some(r) => (true, r),
            None => (false, lit.strip_prefix('+').unwrap_or(lit)),
        };
        let (int, frac) = match rest.split_once('.') {
            Some((i, f)) => (i, f),
            None => (rest, ""),
        };
        if int.is_empty() && frac.is_empty() {
            return None;
        }
        if !int.bytes().all(|b| b.is_ascii_digit())
            || !frac.bytes().all(|b| b.is_ascii_digit())
        {
            return None;
        }
        let mant: i128 = format!("{}{}", int, frac).parse().ok()?;
        Some(Dec { mant: if neg { -mant } else { mant }, scale: frac.len() as u32 })
    }

    /// Display form at own scale (for traces and alphanumeric conversion).
    pub fn to_string_plain(&self) -> String {
        let neg = self.mant < 0;
        let digits = self.mant.unsigned_abs().to_string();
        let s = self.scale as usize;
        let padded = if digits.len() <= s {
            format!("{}{}", "0".repeat(s + 1 - digits.len()), digits)
        } else {
            digits
        };
        let (i, f) = padded.split_at(padded.len() - s);
        let body = if s == 0 { i.to_string() } else { format!("{}.{}", i, f) };
        if neg { format!("-{}", body) } else { body }
    }
}

// ── zoned decimal (USAGE DISPLAY) ─────────────────────────────────────

/// Decode zoned: EBCDIC F0–F9 digits, sign overpunched in the last byte's
/// zone nibble (C/F = +, D = −).
pub fn zoned_decode(bytes: &[u8], scale: u32, signed: bool) -> Result<Dec, NumErr> {
    if bytes.is_empty() {
        return Err(NumErr::S0C7 { bytes: bytes.to_vec() });
    }
    let mut mant: i128 = 0;
    for (i, &b) in bytes.iter().enumerate() {
        let last = i == bytes.len() - 1;
        let zone = b >> 4;
        let digit = b & 0x0F;
        if digit > 9 {
            return Err(NumErr::S0C7 { bytes: bytes.to_vec() });
        }
        let zone_ok = if last && signed {
            matches!(zone, 0xC | 0xD | 0xF)
        } else {
            zone == 0xF
        };
        if !zone_ok {
            return Err(NumErr::S0C7 { bytes: bytes.to_vec() });
        }
        mant = mant * 10 + digit as i128;
    }
    let neg = signed && (bytes[bytes.len() - 1] >> 4) == 0xD;
    Ok(Dec { mant: if neg { -mant } else { mant }, scale })
}

/// Encode zoned with digit count = bytes.len(); truncates high-order
/// digits on overflow exactly as the host does.
pub fn zoned_encode(v: Dec, digits: usize, scale: u32, signed: bool) -> Vec<u8> {
    let v = v.rescale(scale);
    let neg = v.mant < 0;
    let m = v.mant.unsigned_abs() % 10u128.pow(digits as u32);
    let s = format!("{:0>width$}", m, width = digits);
    let mut out: Vec<u8> = s.bytes().map(|d| 0xF0 | (d - b'0')).collect();
    if signed {
        let last = out.last_mut().unwrap();
        *last = (*last & 0x0F) | if neg { 0xD0 } else { 0xC0 };
    }
    out
}

// ── packed decimal (COMP-3) ───────────────────────────────────────────

pub fn packed_decode(bytes: &[u8], scale: u32) -> Result<Dec, NumErr> {
    if bytes.is_empty() {
        return Err(NumErr::S0C7 { bytes: bytes.to_vec() });
    }
    let mut mant: i128 = 0;
    for (i, &b) in bytes.iter().enumerate() {
        let hi = b >> 4;
        let lo = b & 0x0F;
        let last = i == bytes.len() - 1;
        if hi > 9 {
            return Err(NumErr::S0C7 { bytes: bytes.to_vec() });
        }
        mant = mant * 10 + hi as i128;
        if last {
            if !matches!(lo, 0xC | 0xD | 0xF) {
                return Err(NumErr::S0C7 { bytes: bytes.to_vec() });
            }
        } else {
            if lo > 9 {
                return Err(NumErr::S0C7 { bytes: bytes.to_vec() });
            }
            mant = mant * 10 + lo as i128;
        }
    }
    let neg = (bytes[bytes.len() - 1] & 0x0F) == 0xD;
    Ok(Dec { mant: if neg { -mant } else { mant }, scale })
}

pub fn packed_encode(v: Dec, digits: usize, scale: u32) -> Vec<u8> {
    let v = v.rescale(scale);
    let neg = v.mant < 0;
    let m = v.mant.unsigned_abs() % 10u128.pow(digits as u32);
    // digits may be even; the encoded field holds an odd digit count with
    // a leading zero when needed: bytes = ceil((digits+1)/2)
    let nbytes = (digits + 2) / 2;
    let ndigits = nbytes * 2 - 1;
    let s = format!("{:0>width$}", m, width = ndigits);
    let mut out = Vec::with_capacity(nbytes);
    let d: Vec<u8> = s.bytes().map(|b| b - b'0').collect();
    let mut i = 0;
    while i + 1 < d.len() {
        out.push((d[i] << 4) | d[i + 1]);
        i += 2;
    }
    out.push((d[d.len() - 1] << 4) | if neg { 0x0D } else { 0x0C });
    out
}

// ── binary (COMP / COMP-4) ────────────────────────────────────────────

pub fn comp_bytes_for_digits(digits: usize) -> usize {
    match digits {
        0..=4 => 2,
        5..=9 => 4,
        _ => 8,
    }
}

pub fn binary_decode(bytes: &[u8], scale: u32) -> Dec {
    let mut v: i128 = if bytes[0] & 0x80 != 0 { -1 } else { 0 };
    for &b in bytes {
        v = (v << 8) | b as i128;
    }
    // sign-extension via the -1 seed keeps two's complement intact
    Dec { mant: v, scale }
}

pub fn binary_encode(v: Dec, digits: usize, scale: u32) -> Vec<u8> {
    let v = v.rescale(scale);
    // TRUNC(STD): truncate to the PICTURE's digit count.
    let modu = 10i128.pow(digits as u32);
    let m = v.mant % modu;
    let n = comp_bytes_for_digits(digits);
    let mut out = vec![0u8; n];
    let mut x = m;
    for i in (0..n).rev() {
        out[i] = (x & 0xFF) as u8;
        x >>= 8;
    }
    out
}

// ── alphanumeric helpers ──────────────────────────────────────────────

pub fn alnum_store(dst: &mut [u8], src: &[u8]) {
    // left-justified, space-padded / right-truncated
    let n = dst.len().min(src.len());
    dst[..n].copy_from_slice(&src[..n]);
    for b in dst[n..].iter_mut() {
        *b = charset::SPACE;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn zoned_round_trip_signs() {
        let v = Dec { mant: -12345, scale: 2 }; // -123.45
        let b = zoned_encode(v, 5, 2, true);
        assert_eq!(b, vec![0xF1, 0xF2, 0xF3, 0xF4, 0xD5]);
        assert_eq!(zoned_decode(&b, 2, true).unwrap(), v);
        let p = zoned_encode(Dec { mant: 12345, scale: 2 }, 5, 2, true);
        assert_eq!(p[4], 0xC5);
        // unsigned keeps F zones
        let u = zoned_encode(Dec { mant: 90, scale: 0 }, 2, 0, false);
        assert_eq!(u, vec![0xF9, 0xF0]);
    }

    #[test]
    fn zoned_garbage_is_s0c7() {
        assert!(matches!(zoned_decode(&[0xC1, 0xF2], 0, true),
                         Err(NumErr::S0C7 { .. }))); // 'A' in a numeric field
        assert!(matches!(zoned_decode(&[0x40, 0x40], 0, false),
                         Err(NumErr::S0C7 { .. }))); // spaces
    }

    #[test]
    fn packed_round_trip() {
        let v = Dec { mant: 1234567, scale: 2 }; // 12345.67  PIC S9(5)V99
        let b = packed_encode(v, 7, 2);
        assert_eq!(b, vec![0x12, 0x34, 0x56, 0x7C]);
        assert_eq!(packed_decode(&b, 2).unwrap(), v);
        let n = packed_encode(Dec { mant: -42, scale: 0 }, 3, 0);
        assert_eq!(n, vec![0x04, 0x2D]);
        assert_eq!(packed_decode(&n, 0).unwrap().mant, -42);
    }

    #[test]
    fn packed_even_digit_count_gets_leading_zero() {
        let b = packed_encode(Dec { mant: 99, scale: 0 }, 2, 0);
        assert_eq!(b, vec![0x09, 0x9C]); // 2 digits → 2 bytes, 3 digit slots
    }

    #[test]
    fn binary_sizes_and_truncation() {
        assert_eq!(comp_bytes_for_digits(4), 2);
        assert_eq!(comp_bytes_for_digits(9), 4);
        assert_eq!(comp_bytes_for_digits(18), 8);
        let b = binary_encode(Dec { mant: -2, scale: 0 }, 4, 0);
        assert_eq!(b, vec![0xFF, 0xFE]);
        assert_eq!(binary_decode(&b, 0).mant, -2);
        // TRUNC(STD): 12345 into PIC 9(4) COMP keeps 2345
        let t = binary_encode(Dec { mant: 12345, scale: 0 }, 4, 0);
        assert_eq!(binary_decode(&t, 0).mant, 2345);
    }

    #[test]
    fn rounding_ties_away_from_zero() {
        let v = Dec { mant: 125, scale: 2 }; // 1.25
        assert_eq!(v.round_to(1).mant, 13);
        let n = Dec { mant: -125, scale: 2 };
        assert_eq!(n.round_to(1).mant, -13); // away from zero, NOT half-up
        assert_eq!(Dec { mant: 124, scale: 2 }.round_to(1).mant, 12);
    }

    #[test]
    fn literal_parse() {
        assert_eq!(Dec::parse(".750").unwrap(),
                   Dec { mant: 750, scale: 3 });
        assert_eq!(Dec::parse("49.40").unwrap(),
                   Dec { mant: 4940, scale: 2 });
        assert_eq!(Dec::parse("-0.9").unwrap(),
                   Dec { mant: -9, scale: 1 });
        assert_eq!(Dec::parse("1979").unwrap(),
                   Dec { mant: 1979, scale: 0 });
    }

    #[test]
    fn division_carries_precision() {
        let a = Dec { mant: 1, scale: 0 };
        let b = Dec { mant: 3, scale: 0 };
        let q = Dec::div(a, b).unwrap();
        assert_eq!(q.round_to(2).mant, 33); // 0.33
        assert!(matches!(Dec::div(a, Dec::zero()), Err(NumErr::S0CB)));
    }
}
