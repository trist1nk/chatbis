//! cobrun — tracing COBOL interpreter. Phase 1: the data core.
//!
//! stdin:  {"sources": {"PIACOMP": "…"}, "entry": "PIACOMP",
//!          "linkage": {"PIA-AIME": "1000.00", …}, "ws": {…},
//!          "options": {"budget": 1000000}}
//! stdout: {"status": "completed|halted|abended", "trace": […],
//!          "final_state": {…}, "exceptions": […], "halt"/"abend": {…}}

mod charset;
mod exec;
mod layout;
mod num;
mod parse;
mod files;
mod sql;

use exec::{Machine, RunErr};
use serde_json::{json, Map, Value};
use std::collections::HashMap;
use std::io::Read;

fn fail(msg: &str) -> ! {
    println!("{}", json!({"status": "halted", "halt": {"reason": msg}}));
    std::process::exit(0);
}

fn main() {
    let mut input = String::new();
    std::io::stdin().read_to_string(&mut input).unwrap_or(0);
    let req: Value = match serde_json::from_str(&input) {
        Ok(v) => v,
        Err(e) => fail(&format!("bad request JSON: {}", e)),
    };
    let entry = req["entry"].as_str().unwrap_or_default().to_uppercase();

    let mut sources: HashMap<String, String> = HashMap::new();
    if let Some(obj) = req["sources"].as_object() {
        for (k, v) in obj {
            if let Some(s) = v.as_str() {
                sources.insert(k.to_uppercase(), s.to_string());
            }
        }
    }
    let stubs: Vec<String> = req["stubs"].as_array().map(|a| {
        a.iter().filter_map(|v| v.as_str().map(|s| s.to_uppercase())).collect()
    }).unwrap_or_default();
    let budget = req["options"]["budget"].as_u64().unwrap_or(1_000_000);

    if let Some(steps) = req["steps"].as_array().cloned() {
        let mut m = Machine::new(sources.clone(), stubs.clone(), budget);
        if let Some(obj) = req["copybooks"].as_object() {
            for (k, v) in obj {
                if let Some(t) = v.as_str() {
                    m.copybooks.insert(k.to_uppercase(), t.to_string());
                }
            }
        }
        let out = run_pipeline(&mut m, &req, &steps);
        println!("{}", serde_json::to_string(&out).unwrap());
        return;
    }

    let entry = if entry.is_empty() {
        sources.keys().next().cloned().unwrap_or_default()
    } else {
        entry
    };
    let mut m = Machine::new(sources, stubs, budget);
    if let Some(obj) = req["copybooks"].as_object() {
        for (k, v) in obj {
            if let Some(t) = v.as_str() {
                m.copybooks.insert(k.to_uppercase(), t.to_string());
            }
        }
    }
    let li = match m.load(&entry) {
        Ok(i) => i,
        Err(RunErr::Halt(msg)) => fail(&msg),
        Err(e) => fail(&format!("{:?}", e)),
    };
    if let Err(RunErr::Halt(msg)) = m.push_frame(li, &[]) {
        fail(&msg);
    }
    {
        let maps = parse_area_maps(&req);
        if !maps.is_empty() && !req["case"].is_null() {
            let case = req["case"].clone();
            if let Err(RunErr::Halt(msg)) = m.apply_area_maps(
                &maps, &case, &Default::default()) {
                fail(&msg);
            }
        }
    }
    for section in ["linkage", "ws"] {
        if let Some(obj) = req[section].as_object() {
            for (name, val) in obj {
                let text = match val {
                    Value::String(s) => s.clone(),
                    Value::Number(n) => n.to_string(),
                    other => other.to_string(),
                };
                if let Err(e) = m.seed_field(name, &text) {
                    fail(&e);
                }
            }
        }
    }

    // The case snapshot IS the database, for reads.
    if !req["case"].is_null() {
        let maps: Vec<sql::Mapping> = req["field_map"].as_array()
            .map(|a| a.iter().filter_map(|m| {
                Some(sql::Mapping {
                    db2: m["db2_column"].as_str()?.to_uppercase(),
                    path: m["json_path"].as_str()?.to_string(),
                    format: m["format"].as_str().unwrap_or("text").to_string(),
                })
            }).collect())
            .unwrap_or_default();
        m.snap = Some(sql::Snapshot::new(req["case"].clone(), maps));
    }

    let outcome = m.run_top(li);

    let mut final_state = Map::new();
    for (k, v) in m.snapshot() {
        final_state.insert(k, json!(v));
    }
    let exceptions: Vec<Value> = m.trace.iter()
        .filter(|e| e["kind"] == "exception").cloned().collect();

    let writes: Vec<Value> = m.snap.as_ref().map(|s| {
        s.writes.iter().map(|(stmt, col, val)| json!({
            "stmt": stmt, "column": col, "value": val,
        })).collect()
    }).unwrap_or_default();
    let mut out = json!({
        "writes": writes,
        "trace": m.trace,
        "final_state": final_state,
        "exceptions": exceptions,
        "statements_left": m.budget,
    });
    match outcome {
        Ok(()) => out["status"] = json!("completed"),
        Err(RunErr::Halt(msg)) => {
            out["status"] = json!("halted");
            out["halt"] = json!({"reason": msg});
        }
        Err(RunErr::Abend { code, line, detail }) => {
            out["status"] = json!("abended");
            out["abend"] = json!({"code": code, "line": line,
                                  "detail": detail});
        }
    }
    println!("{}", serde_json::to_string(&out).unwrap());
}

/// Run mined JCL steps in order, sharing one world (datasets + SQL
/// overlay) across them. Program storage never survives a step — each
/// EXEC PGM is a fresh enclave, as on the host. COND / IF gates are
/// evaluated against recorded return codes; a skipped step says so.
fn parse_area_maps(req: &Value) -> Vec<sql::AreaMap> {
    req["area_maps"].as_array().map(|a| a.iter().filter_map(|x| {
        Some(sql::AreaMap {
            area: x["area"].as_str()?.to_uppercase(),
            field: x["field"].as_str()?.to_uppercase(),
            path: x["path"].as_str()?.to_string(),
            format: x["format"].as_str().unwrap_or("text").to_string(),
        })
    }).collect()).unwrap_or_default()
}

fn run_pipeline(m: &mut Machine, req: &Value, steps: &[Value]) -> Value {
    let maps: Vec<sql::Mapping> = req["field_map"].as_array()
        .map(|a| a.iter().filter_map(|x| Some(sql::Mapping {
            db2: x["db2_column"].as_str()?.to_uppercase(),
            path: x["json_path"].as_str()?.to_string(),
            format: x["format"].as_str().unwrap_or("text").to_string(),
        })).collect())
        .unwrap_or_default();
    if !req["case"].is_null() {
        m.snap = Some(sql::Snapshot::new(req["case"].clone(), maps));
    }
    if let Some(obj) = req["datasets"].as_object() {
        for (dsn, recs) in obj {
            let (base, gdg) = files::gdg_base(&dsn.to_uppercase());
            let mut ds = files::Dataset { records: Vec::new(), gdg };
            if let Some(a) = recs.as_array() {
                for r in a {
                    if let Some(t) = r.as_str() {
                        ds.records.push(charset::str_to_ebcdic(t));
                    }
                }
            }
            m.world.sets.insert(base, ds);
        }
    }

    let mut rcs: HashMap<String, i64> = HashMap::new();
    let mut results: Vec<Value> = Vec::new();
    let mut halted: Option<Value> = None;
    // Declared carry areas — the TDAIO seam. On the host these 01-levels
    // persist between steps; the analyst declares that, the driver moves
    // the bytes, and the trace shows every handoff.
    let carry_names: Vec<String> = req["carry"].as_array()
        .map(|a| a.iter().filter_map(|v| v.as_str())
             .map(|t| t.to_uppercase()).collect())
        .unwrap_or_default();
    let mut carried: HashMap<String, Vec<u8>> = HashMap::new();
    let area_maps = parse_area_maps(req);
    let case_for_seed = req["case"].clone();

    for st in steps {
        let name = st["step"].as_str().unwrap_or("STEP").to_string();
        let pgm = st["pgm"].as_str().unwrap_or("").to_uppercase();
        if let Some(skip) = gate_blocks(st, &rcs) {
            results.push(json!({"step": name, "pgm": pgm,
                                "status": "skipped", "why": skip}));
            m.trace.push(json!({"kind": "step", "step": name, "pgm": pgm,
                                "status": "skipped", "why": skip}));
            continue;
        }
        m.world.dd_to_dsn.clear();
        if let Some(dds) = st["dds"].as_array() {
            for d in dds {
                if let (Some(dd), Some(dsn)) =
                    (d["dd"].as_str(), d["dsn"].as_str()) {
                    m.world.dd_to_dsn.insert(dd.to_uppercase(),
                                             dsn.to_uppercase());
                }
            }
        }
        m.world.open.clear();
        m.frames.clear();
        m.cursors.clear();

        m.trace.push(json!({"kind": "step", "step": name, "pgm": pgm,
                            "status": "start"}));
        let before = m.trace.len();
        let li = match m.load(&pgm) {
            Ok(i) => i,
            Err(RunErr::Halt(msg)) => {
                results.push(json!({"step": name, "pgm": pgm,
                                    "status": "halted", "reason": msg}));
                halted = Some(json!({"step": name, "reason": msg}));
                break;
            }
            Err(e) => {
                halted = Some(json!({"step": name,
                                     "reason": format!("{:?}", e)}));
                break;
            }
        };
        if let Err(RunErr::Halt(msg)) = m.push_frame(li, &[]) {
            results.push(json!({"step": name, "pgm": pgm,
                                "status": "halted", "reason": msg.clone()}));
            halted = Some(json!({"step": name, "reason": msg}));
            break;
        }
        // Mapped areas fill from the case first (carried areas are
        // skipped — mid-pipeline, the carry IS the value)…
        if !area_maps.is_empty() && !case_for_seed.is_null() {
            let skip: std::collections::HashSet<String> =
                carried.keys().cloned().collect();
            if let Err(RunErr::Halt(msg)) =
                m.apply_area_maps(&area_maps, &case_for_seed, &skip) {
                results.push(json!({"step": name, "pgm": pgm,
                                    "status": "halted",
                                    "reason": msg.clone()}));
                halted = Some(json!({"step": name, "reason": msg}));
                break;
            }
        }
        // …then request-level seeds land in whichever step declares the
        // field — manual seeds OVERRIDE mapped ones.
        if let Some(obj) = req["ws"].as_object() {
            for (fname, val) in obj {
                let text = match val {
                    Value::String(t) => t.clone(),
                    other => other.to_string(),
                };
                let _ = m.seed_field(fname, &text);
            }
        }
        // Carried state lands after seeds: it IS the area's value now.
        for name in &carry_names {
            if let Some(bytes) = carried.get(name) {
                if m.set_area_bytes(name, bytes) {
                    m.trace.push(json!({"kind": "carry", "area": name,
                                        "into": pgm, "bytes": bytes.len()}));
                }
            }
        }
        match m.run_top(li) {
            Ok(()) => {
                for name in &carry_names {
                    if let Some(bytes) = m.area_bytes(name) {
                        carried.insert(name.clone(), bytes);
                    }
                }
                let exc = m.trace[before..].iter()
                    .filter(|e| e["kind"] == "exception").count();
                let rc = if exc > 0 { 8 } else { 0 };
                rcs.insert(name.clone(), rc);
                results.push(json!({"step": name, "pgm": pgm,
                                    "status": "completed", "rc": rc,
                                    "exceptions": exc}));
            }
            Err(RunErr::Halt(msg)) => {
                results.push(json!({"step": name, "pgm": pgm,
                                    "status": "halted", "reason": msg.clone()}));
                halted = Some(json!({"step": name, "reason": msg}));
                break;
            }
            Err(RunErr::Abend { code, line, detail }) => {
                rcs.insert(name.clone(), 12);
                results.push(json!({"step": name, "pgm": pgm,
                                    "status": "abended", "code": code,
                                    "line": line, "detail": detail.clone()}));
                halted = Some(json!({"step": name, "abend": code,
                                     "detail": detail}));
                break;
            }
        }
    }

    let writes: Vec<Value> = m.snap.as_ref().map(|s| s.writes.iter()
        .map(|(stmt, col, val)| json!({"stmt": stmt, "column": col,
                                       "value": val})).collect())
        .unwrap_or_default();
    let datasets: Map<String, Value> = m.world.sets.iter().map(|(k, v)| {
        (k.clone(), json!(v.records.iter()
            .map(|r| charset::ebcdic_to_string(r).trim_end().to_string())
            .collect::<Vec<_>>()))
    }).collect();
    let exceptions: Vec<Value> = m.trace.iter()
        .filter(|e| e["kind"] == "exception").cloned().collect();

    let mut out = json!({
        "status": if halted.is_some() { "halted" } else { "completed" },
        "steps": results,
        "trace": m.trace,
        "writes": writes,
        "datasets": datasets,
        "exceptions": exceptions,
    });
    if let Some(h) = halted {
        out["halt"] = h;
    }
    out
}

/// Returns Some(reason) when the step must be skipped.
fn gate_blocks(st: &Value, rcs: &HashMap<String, i64>) -> Option<String> {
    if let Some(gate) = st["gate"].as_str() {
        if let Some((step, op, n)) = parse_rc_test(gate) {
            let rc = *rcs.get(&step).unwrap_or(&0);
            let holds = match op.as_str() {
                "<=" => rc <= n, "<" => rc < n, ">=" => rc >= n,
                ">" => rc > n, "=" => rc == n, _ => true,
            };
            if !holds {
                return Some(format!("{} ({}.RC = {})", gate, step, rc));
            }
        }
    }
    if let Some(cond) = st["cond"].as_str() {
        let body = cond.trim_matches(|c| c == '(' || c == ')');
        let parts: Vec<&str> = body.split(',').map(|x| x.trim()).collect();
        if parts.len() == 3 {
            if let Ok(n) = parts[0].parse::<i64>() {
                let rc = *rcs.get(parts[2]).unwrap_or(&0);
                let skip = match parts[1] {
                    "LE" => n <= rc, "LT" => n < rc, "GE" => n >= rc,
                    "GT" => n > rc, "EQ" => n == rc, "NE" => n != rc,
                    _ => false,
                };
                if skip {
                    return Some(format!("COND={} ({}.RC = {})", cond,
                                        parts[2], rc));
                }
            }
        }
    }
    None
}

fn parse_rc_test(gate: &str) -> Option<(String, String, i64)> {
    let g = gate.trim_matches(|c| c == '(' || c == ')');
    let (lhs, rest) = g.split_once(".RC")?;
    let rest = rest.trim();
    for op in ["<=", ">=", "<", ">", "="] {
        if let Some(v) = rest.strip_prefix(op) {
            return Some((lhs.trim().to_string(), op.to_string(),
                         v.trim().parse().ok()?));
        }
    }
    None
}

#[cfg(test)]
mod corpus {
    use super::*;
    use std::path::PathBuf;

    fn corpus_src(member: &str) -> (String, String) {
        let path = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("../content/t2-test").join(member);
        let src = std::fs::read_to_string(&path)
            .unwrap_or_else(|_| panic!("missing corpus member {:?}", path));
        let name = member.rsplit('/').next().unwrap()
            .trim_end_matches(".cbl").to_uppercase();
        (name, src)
    }

    /// Load several corpus members, run `entry`, seed its fields first.
    fn run(members: &[&str], entry: &str, stubs: &[&str],
           seeds: &[(&str, &str)]) -> (Machine, Result<(), RunErr>) {
        let mut sources = HashMap::new();
        for m in members {
            let (n, s) = corpus_src(m);
            sources.insert(n, s);
        }
        let mut m = Machine::new(
            sources, stubs.iter().map(|s| s.to_string()).collect(), 200_000);
        let books = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("../content/t2-test/copybooks");
        if let Ok(rd) = std::fs::read_dir(&books) {
            for e in rd.flatten() {
                let pth = e.path();
                if pth.extension().map(|x| x == "cpy").unwrap_or(false) {
                    let n = pth.file_stem().unwrap().to_string_lossy()
                        .to_uppercase();
                    m.copybooks.insert(
                        n, std::fs::read_to_string(&pth).unwrap());
                }
            }
        }
        let li = m.load(entry).expect("load entry");
        m.push_frame(li, &[]).expect("frame");
        for (k, v) in seeds {
            m.seed_field(k, v).expect("seed");
        }
        let out = m.run_top(li);
        (m, out)
    }

    fn val(m: &Machine, name: &str) -> String {
        m.show(m.lay().find(name).expect(name))
    }

    // ── phase 1 gate: the computational utilities ─────────────────────

    #[test]
    fn piacomp_happy_path() {
        let (m, out) = run(&["utilities/PIACOMP.cbl"], "PIACOMP", &[],
            &[("PIA-AIME", "1000.00"), ("PIA-ELIG-YEAR", "1985")]);
        out.unwrap();
        assert_eq!(val(&m, "PIA-RESULT"), "900.00");
        assert_eq!(val(&m, "PIA-RC"), "00");
        assert!(m.trace.iter().any(|e| e["kind"] == "move"
            && e["field"] == "PIA-RESULT"
            && e["after"].as_str().unwrap().contains("900")));
    }

    #[test]
    fn piacomp_zero_aime_is_rc_08() {
        let (m, out) = run(&["utilities/PIACOMP.cbl"], "PIACOMP", &[],
            &[("PIA-AIME", "0"), ("PIA-ELIG-YEAR", "1985")]);
        out.unwrap();
        assert_eq!(val(&m, "PIA-RC"), "08");
        assert!(m.trace.iter().any(|e| e["kind"] == "exception"
            && e["code"] == "E7101"));
    }

    #[test]
    fn piacomp_old_law_is_rc_12() {
        let (m, out) = run(&["utilities/PIACOMP.cbl"], "PIACOMP", &[],
            &[("PIA-AIME", "500.00"), ("PIA-ELIG-YEAR", "1978")]);
        out.unwrap();
        assert_eq!(val(&m, "PIA-RC"), "12");
    }

    #[test]
    fn mbacomp_relationship_percentages() {
        for (rel, pia, want) in [("A", "1842.50", "1842.50"),
                                 ("C", "1000.00", "750.00"),
                                 ("W", "1234.56", "882.71")] {
            let (m, out) = run(&["utilities/MBACOMP.cbl"], "MBACOMP", &[],
                &[("MBA-PIA-IN", pia), ("MBA-REL-CD", rel)]);
            out.unwrap();
            assert_eq!(val(&m, "MBA-RESULT"), want, "rel {}", rel);
        }
    }

    #[test]
    fn mbacomp_floor_at_statutory_minimum() {
        let (m, out) = run(&["utilities/MBACOMP.cbl"], "MBACOMP", &[],
            &[("MBA-PIA-IN", "50.00"), ("MBA-REL-CD", "C")]);
        out.unwrap();
        assert_eq!(val(&m, "MBA-RESULT"), "49.40");
        assert_eq!(val(&m, "MBA-RC"), "04");
    }

    // ── phase 2 gate: programs calling programs ───────────────────────

    #[test]
    fn bfsurv_runs_through_both_utilities() {
        // The phase-2 acceptance gate: a business function, its two
        // computation utilities, and a stubbed sink — one run.
        let (m, out) = run(&["business-functions/BFSURV.cbl",
                             "utilities/PIACOMP.cbl",
                             "utilities/MBACOMP.cbl"],
                           "BFSURV", &["EXCEPTRN"],
                           &[("PDA-CLM-TYPE", "RET"),
                             ("PIA-AIME", "2000.00"),
                             ("PIA-ELIG-YEAR", "1990"),
                             ("MBA-REL-CD", "A")]);
        out.unwrap();
        // PIACOMP wrote PIA-RESULT through BY REFERENCE: 2000 * .9 = 1800
        assert_eq!(val(&m, "PIA-RESULT"), "1800.00");
        // BFSURV moved it into MBA-PIA-IN, MBACOMP returned it as PDA-MBA
        assert_eq!(val(&m, "PDA-MBA"), "1800.00");
        let targets: Vec<&str> = m.trace.iter()
            .filter(|e| e["kind"] == "call")
            .map(|e| e["target"].as_str().unwrap()).collect();
        assert_eq!(targets, vec!["PIACOMP", "MBACOMP"]);
    }

    #[test]
    fn survivor_edits_fire_and_stub_is_visible() {
        let (m, out) = run(&["business-functions/BFSURV.cbl",
                             "utilities/PIACOMP.cbl",
                             "utilities/MBACOMP.cbl"],
                           "BFSURV", &["EXCEPTRN"],
                           &[("PDA-CLM-TYPE", "SUR"),
                             ("PDA-BENE-DOD", ""),
                             ("PIA-AIME", "1000.00"),
                             ("PIA-ELIG-YEAR", "1990"),
                             ("MBA-REL-CD", "C")]);
        out.unwrap();
        // survivor claim with no date of death → E7301
        assert!(m.trace.iter().any(|e| e["kind"] == "exception"
            && e["code"] == "E7301"));
        // the stubbed sink is in the trace, carrying what it was passed
        let stub = m.trace.iter().find(|e| e["resolution"] == "stub")
            .expect("stub call traced");
        assert_eq!(stub["target"], "EXCEPTRN");
        assert!(stub["using"].as_array().unwrap()[0]
            .as_str().unwrap().contains("E7301"));
    }

    #[test]
    fn bfretire_end_to_end() {
        let (m, out) = run(&["business-functions/BFRETIRE.cbl",
                             "utilities/PIACOMP.cbl"],
                           "BFRETIRE", &["EXCEPTRN"],
                           &[("PIA-AIME", "1500.00"),
                             ("PIA-ELIG-YEAR", "1995")]);
        out.unwrap();
        assert_eq!(val(&m, "PDA-PIA"), "1350.00");   // 1500 * .9
        assert_eq!(val(&m, "PDA-MBA"), "1350.00");   // 2000-SET-MBA
    }

    #[test]
    fn dynamic_call_resolves_through_the_field() {
        let (m, out) = run(&["business-functions/BFDISAB.cbl",
                             "business-functions/EEGET.cbl",
                             "business-functions/EEPUT.cbl",
                             "utilities/PIACOMP.cbl"],
                           "BFDISAB", &[],
                           &[("PIA-AIME", "1000.00"),
                             ("PIA-ELIG-YEAR", "1990")]);
        out.unwrap();
        let call = m.trace.iter().find(|e| e["kind"] == "call").unwrap();
        assert_eq!(call["target"], "PIACOMP");
        assert_eq!(call["via"], "dynamic via WS-COMP-PGM");
        assert_eq!(val(&m, "PDA-PIA"), "900.00");
    }

    #[test]
    fn missing_callee_halts_with_the_ask() {
        let (_, out) = run(&["business-functions/BFRETIRE.cbl",
                             "utilities/PIACOMP.cbl"],
                           "BFRETIRE", &[], &[("PIA-AIME", "1.00")]);
        match out {
            Err(RunErr::Halt(msg)) => {
                assert!(msg.contains("EXCEPTRN"), "{}", msg);
                assert!(msg.contains("stub"), "{}", msg);
            }
            other => panic!("expected a halt naming EXCEPTRN, got {:?}", other),
        }
    }
}

#[cfg(test)]
mod snapshot_runs {
    use super::*;
    use serde_json::json;
    use std::path::PathBuf;

    fn corpus(member: &str) -> (String, String) {
        let path = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("../content/t2-test").join(member);
        let name = member.rsplit('/').next().unwrap()
            .trim_end_matches(".cbl").to_uppercase();
        (name, std::fs::read_to_string(&path).unwrap())
    }

    fn machine(members: &[&str], case: Value, maps: Vec<sql::Mapping>)
        -> Machine {
        let mut sources = HashMap::new();
        for m in members {
            let (n, s) = corpus(m);
            sources.insert(n, s);
        }
        let mut m = Machine::new(sources, vec!["EXCEPTRN".into()], 200_000);
        let books = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("../content/t2-test/copybooks");
        for e in std::fs::read_dir(&books).unwrap().flatten() {
            let p = e.path();
            if p.extension().map(|x| x == "cpy").unwrap_or(false) {
                m.copybooks.insert(
                    p.file_stem().unwrap().to_string_lossy().to_uppercase(),
                    std::fs::read_to_string(&p).unwrap());
            }
        }
        m.snap = Some(sql::Snapshot::new(case, maps));
        m
    }

    fn map(db2: &str, path: &str, format: &str) -> sql::Mapping {
        sql::Mapping { db2: db2.into(), path: path.into(),
                       format: format.into() }
    }

    fn case() -> Value {
        json!({
            "claim": {"mba": "1842.50", "entitlementDate": "2026-01-15",
                      "status": "AC"},
            "entitlementPeriods": [
                {"startDate": "2019-01-01", "endDate": "2020-12-31",
                 "rsmpDate": ""},
                {"startDate": "2021-06-01", "endDate": "",
                 "rsmpDate": "2021-06-01"},
            ],
        })
    }

    fn period_maps() -> Vec<sql::Mapping> {
        vec![map("MCS.ENT_PERIODS.ENT_STRT_DT",
                 "entitlementPeriods[].startDate", "yyyymmdd"),
             map("MCS.ENT_PERIODS.ENT_END_DT",
                 "entitlementPeriods[].endDate", "yyyymmdd"),
             map("MCS.ENT_PERIODS.RSMP_DT",
                 "entitlementPeriods[].rsmpDate", "yyyymmdd")]
    }

    #[test]
    fn select_into_converts_through_the_declared_format() {
        let mut m = machine(&["pda-build/PDAGET.cbl"], case(), vec![
            map("MCS.CLAIM_HISTORY.MBA", "claim.mba", "decimal"),
            map("MCS.CLAIM_HISTORY.ENT_DT", "claim.entitlementDate",
                "yyyymmdd"),
            map("MCS.CLAIM_HISTORY.CLM_STAT", "claim.status", "text"),
        ]);
        let li = m.load("PDAGET").unwrap();
        m.push_frame(li, &[]).unwrap();
        m.run_top(li).unwrap();
        // The ISO date in the case became CCYYMMDD in the host variable —
        // storing "2026-01-15" would have planted invalid decimal data.
        assert_eq!(m.show(m.lay().find("WS-PRIOR-ENT-DT").unwrap()),
                   "20260115");
        assert_eq!(m.show(m.lay().find("PDA-PIA").unwrap()), "1842.50");
        assert!(m.trace.iter().any(|e| e["kind"] == "sql"
            && e["op"] == "select" && e["sqlcode"] == 0));
    }

    #[test]
    fn cursor_walks_the_group_and_ends_at_sqlcode_100() {
        let mut m = machine(&["pda-build/PDAHIST.cbl"], case(), period_maps());
        let li = m.load("PDAHIST").unwrap();
        m.push_frame(li, &[]).unwrap();
        m.run_top(li).unwrap();
        let ops: Vec<&str> = m.trace.iter().filter(|e| e["kind"] == "sql")
            .map(|e| e["op"].as_str().unwrap()).collect();
        assert_eq!(ops, vec!["declare", "open", "fetch", "fetch", "fetch"]);
        let codes: Vec<i64> = m.trace.iter()
            .filter(|e| e["kind"] == "sql" && e["op"] == "fetch")
            .map(|e| e["sqlcode"].as_i64().unwrap()).collect();
        assert_eq!(codes, vec![0, 0, 100]);   // two rows, then end of group
    }

    #[test]
    fn subscripted_stores_land_in_the_right_occurrence() {
        let mut m = machine(&["pda-build/PDAHIST.cbl"], case(), period_maps());
        let li = m.load("PDAHIST").unwrap();
        m.push_frame(li, &[]).unwrap();
        m.run_top(li).unwrap();
        let wrote: Vec<(String, String)> = m.trace.iter()
            .filter(|e| e["kind"] == "move"
                    && e["field"].as_str().unwrap().starts_with("PDA-ENT-STRT"))
            .map(|e| (e["field"].as_str().unwrap().to_string(),
                      e["after"].as_str().unwrap().to_string()))
            .collect();
        assert_eq!(wrote, vec![
            ("PDA-ENT-STRT-DT".to_string(), "20190101".to_string()),
            ("PDA-ENT-STRT-DT(2)".to_string(), "20210601".to_string()),
        ]);
    }

    #[test]
    fn unmapped_column_halts_naming_the_mapping_to_add() {
        let mut m = machine(&["pda-build/PDAGET.cbl"], case(), vec![]);
        let li = m.load("PDAGET").unwrap();
        m.push_frame(li, &[]).unwrap();
        match m.run_top(li) {
            Err(RunErr::Halt(msg)) => {
                assert!(msg.contains("MCS.CLAIM_HISTORY.MBA"), "{}", msg);
                assert!(msg.contains("no field mapping"), "{}", msg);
            }
            other => panic!("expected a halt naming the column, got {:?}",
                            other),
        }
    }

    #[test]
    fn writes_record_and_are_visible_to_later_reads() {
        let mut m = machine(&["put/DBPUT.cbl"], case(), vec![
            map("MCS.CLAIM.SSN", "claimant.ssn", "text"),
            map("MCS.CLAIM.BIC", "claimant.bic", "text"),
            map("MCS.CLAIM.BENE_DOB", "claimant.dateOfBirth", "yyyymmdd"),
            map("MCS.CLAIM.CLM_TYPE", "claim.claimType", "text"),
            map("MCS.CLAIM.ENT_DT", "claim.entitlementDate", "yyyymmdd"),
            map("MCS.CLAIM.MBA", "claim.mba", "decimal"),
            map("MCS.CLAIM_CONTROL.LAST_RUN_DT", "control.lastRun",
                "yyyymmdd"),
            map("MCS.CLAIM_CONTROL.RUN_STAT", "control.status", "text"),
        ]);
        let li = m.load("DBPUT").unwrap();
        m.push_frame(li, &[]).unwrap();
        m.run_top(li).unwrap();
        let s = m.snap.as_ref().unwrap();
        // The INSERT recorded every bound column…
        assert!(s.writes.iter().any(|(st, c, _)|
            st == "insert" && c == "MCS.CLAIM.BENE_DOB"));
        // …and the UPDATE too, without ever touching the case itself.
        assert!(s.writes.iter().any(|(st, _, _)| st == "update"));
        assert_eq!(s.case["claim"]["mba"], json!("1842.50"));
    }
}

#[cfg(test)]
mod pipeline {
    use super::*;
    use serde_json::json;

    const WRITER: &str = concat!(
        "       IDENTIFICATION DIVISION.\n",
        "       PROGRAM-ID. PWRITE.\n",
        "       ENVIRONMENT DIVISION.\n",
        "       INPUT-OUTPUT SECTION.\n",
        "       FILE-CONTROL.\n",
        "           SELECT WORK-FILE ASSIGN TO OUTDD.\n",
        "       DATA DIVISION.\n",
        "       FILE SECTION.\n",
        "       FD  WORK-FILE.\n",
        "       01  WORK-REC                PIC X(10).\n",
        "       WORKING-STORAGE SECTION.\n",
        "       01  WS-LINE                 PIC X(10).\n",
        "       PROCEDURE DIVISION.\n",
        "       MAIN.\n",
        "           OPEN OUTPUT WORK-FILE\n",
        "           MOVE 'HANDOFF-01' TO WS-LINE\n",
        "           WRITE WORK-REC FROM WS-LINE\n",
        "           CLOSE WORK-FILE\n",
        "           GOBACK.\n");

    const READER: &str = concat!(
        "       IDENTIFICATION DIVISION.\n",
        "       PROGRAM-ID. PREAD.\n",
        "       ENVIRONMENT DIVISION.\n",
        "       INPUT-OUTPUT SECTION.\n",
        "       FILE-CONTROL.\n",
        "           SELECT IN-FILE ASSIGN TO INDD.\n",
        "       DATA DIVISION.\n",
        "       FILE SECTION.\n",
        "       FD  IN-FILE.\n",
        "       01  IN-REC                  PIC X(10).\n",
        "       WORKING-STORAGE SECTION.\n",
        "       01  WS-GOT                  PIC X(10).\n",
        "       PROCEDURE DIVISION.\n",
        "       MAIN.\n",
        "           OPEN INPUT IN-FILE\n",
        "           READ IN-FILE INTO WS-GOT\n",
        "           DISPLAY 'READ ' WS-GOT\n",
        "           CLOSE IN-FILE\n",
        "           GOBACK.\n");

    /// A program that always raises, so its step returns 8 and the gate
    /// downstream of it can be exercised.
    const RAISER: &str = concat!(
        "       IDENTIFICATION DIVISION.\n",
        "       PROGRAM-ID. PRAISE.\n",
        "       DATA DIVISION.\n",
        "       WORKING-STORAGE SECTION.\n",
        "       01  WS-ERROR-CODE           PIC X(05).\n",
        "       PROCEDURE DIVISION.\n",
        "       MAIN.\n",
        "           MOVE 'E9999' TO WS-ERROR-CODE\n",
        "           GOBACK.\n");

    fn run(req: Value) -> Value {
        let sources: HashMap<String, String> = req["sources"].as_object()
            .unwrap().iter()
            .map(|(k, v)| (k.to_uppercase(), v.as_str().unwrap().to_string()))
            .collect();
        let mut m = Machine::new(sources, vec![], 100_000);
        let steps = req["steps"].as_array().unwrap().clone();
        // capture stdout by rebuilding what run_pipeline reports
        let maps: Vec<sql::Mapping> = vec![];
        if !req["case"].is_null() {
            m.snap = Some(sql::Snapshot::new(req["case"].clone(), maps));
        }
        // exercise the same logic the binary uses
        let mut rcs: HashMap<String, i64> = HashMap::new();
        let mut out = Vec::new();
        for st in &steps {
            let name = st["step"].as_str().unwrap().to_string();
            let pgm = st["pgm"].as_str().unwrap().to_uppercase();
            if let Some(why) = gate_blocks(st, &rcs) {
                out.push(json!({"step": name, "status": "skipped",
                                "why": why}));
                continue;
            }
            m.world.dd_to_dsn.clear();
            if let Some(dds) = st["dds"].as_array() {
                for d in dds {
                    m.world.dd_to_dsn.insert(
                        d["dd"].as_str().unwrap().to_uppercase(),
                        d["dsn"].as_str().unwrap().to_uppercase());
                }
            }
            m.world.open.clear();
            m.frames.clear();
            let before = m.trace.len();
            let li = m.load(&pgm).expect("load");
            m.push_frame(li, &[]).expect("frame");
            m.run_top(li).expect("run");
            let exc = m.trace[before..].iter()
                .filter(|e| e["kind"] == "exception").count();
            let rc = if exc > 0 { 8 } else { 0 };
            rcs.insert(name.clone(), rc);
            out.push(json!({"step": name, "status": "completed", "rc": rc}));
        }
        json!({"steps": out, "trace": m.trace,
               "datasets": m.world.sets.keys().cloned()
                   .collect::<Vec<_>>()})
    }

    #[test]
    fn a_later_step_reads_what_an_earlier_step_wrote() {
        let r = run(json!({
            "sources": {"PWRITE": WRITER, "PREAD": READER},
            "steps": [
                {"step": "S1", "pgm": "PWRITE",
                 "dds": [{"dd": "OUTDD", "dsn": "P.HANDOFF(+1)"}]},
                {"step": "S2", "pgm": "PREAD",
                 "dds": [{"dd": "INDD", "dsn": "P.HANDOFF(0)"}]},
            ],
        }));
        // Different DDNAMEs, different GDG generations, one dataset.
        let read = r["trace"].as_array().unwrap().iter()
            .find(|e| e["kind"] == "display")
            .expect("the reader displayed what it read");
        assert!(read["text"].as_str().unwrap().contains("HANDOFF-01"),
                "{:?}", read);
    }

    #[test]
    fn a_cond_gate_skips_the_downstream_step() {
        let r = run(json!({
            "sources": {"PRAISE": RAISER, "PWRITE": WRITER},
            "steps": [
                {"step": "S1", "pgm": "PRAISE"},
                {"step": "S2", "pgm": "PWRITE", "cond": "(8,LE,S1)",
                 "dds": [{"dd": "OUTDD", "dsn": "P.X"}]},
            ],
        }));
        let steps = r["steps"].as_array().unwrap();
        assert_eq!(steps[0]["rc"], 8);          // the raiser returned 8
        assert_eq!(steps[1]["status"], "skipped");
        assert!(steps[1]["why"].as_str().unwrap().contains("S1.RC = 8"));
    }

    #[test]
    fn an_if_gate_lets_a_clean_step_through() {
        let r = run(json!({
            "sources": {"PWRITE": WRITER},
            "steps": [
                {"step": "S1", "pgm": "PWRITE",
                 "dds": [{"dd": "OUTDD", "dsn": "P.X"}]},
                {"step": "S2", "pgm": "PWRITE", "gate": "(S1.RC <= 4)",
                 "dds": [{"dd": "OUTDD", "dsn": "P.Y"}]},
            ],
        }));
        assert_eq!(r["steps"][1]["status"], "completed");
    }

    #[test]
    fn program_storage_does_not_survive_a_step() {
        // PWRITE runs twice; OPEN OUTPUT replaces, so the second run's
        // dataset holds exactly one record — not two.
        let r = run(json!({
            "sources": {"PWRITE": WRITER},
            "steps": [
                {"step": "S1", "pgm": "PWRITE",
                 "dds": [{"dd": "OUTDD", "dsn": "P.SAME"}]},
                {"step": "S2", "pgm": "PWRITE",
                 "dds": [{"dd": "OUTDD", "dsn": "P.SAME"}]},
            ],
        }));
        let opens = r["trace"].as_array().unwrap().iter()
            .filter(|e| e["kind"] == "file" && e["op"] == "open-output")
            .count();
        assert_eq!(opens, 2);   // each step opened its own enclave's file
    }
}

#[cfg(test)]
mod carry_flow {
    //! The capstone: state mutated by code logic in one step is what a
    //! later step posts. This is the scenario the whole interpreter was
    //! built for — a value changed mid-flight, invisible to any static
    //! check, visible here.
    use super::*;
    use serde_json::json;
    use std::path::PathBuf;

    fn corpus_req() -> Value {
        let root = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("../content/t2-test");
        let mut sources = serde_json::Map::new();
        for sub in ["infrastructure", "event-analyzer", "weeder",
                    "pda-build", "business-functions", "utilities",
                    "put", "notify"] {
            let dir = root.join(sub);
            for e in std::fs::read_dir(&dir).unwrap().flatten() {
                let path = e.path();
                if path.extension().map(|x| x == "cbl").unwrap_or(false) {
                    let name = path.file_stem().unwrap()
                        .to_string_lossy().to_uppercase();
                    sources.insert(
                        name, json!(std::fs::read_to_string(&path).unwrap()));
                }
            }
        }
        let mut books = serde_json::Map::new();
        for e in std::fs::read_dir(root.join("copybooks")).unwrap().flatten() {
            let path = e.path();
            if path.extension().map(|x| x == "cpy").unwrap_or(false) {
                books.insert(path.file_stem().unwrap()
                             .to_string_lossy().to_uppercase(),
                             json!(std::fs::read_to_string(&path).unwrap()));
            }
        }
        json!({
            "sources": sources,
            "copybooks": books,
            "stubs": ["EXCEPTRN", "ABENDRTN", "TDAIO", "REJWRT01",
                      "SUSWRT01"],
            "steps": [
                {"step": "STEP010", "pgm": "TDABUILD"},
                {"step": "STEP020", "pgm": "EVNTANLZ"},
                {"step": "STEP030", "pgm": "WEEDCHK",
                 "dds": [{"dd": "REJECTS", "dsn": "PROD.T2.REJECTS"}]},
                {"step": "STEP040", "pgm": "PDABUILD"},
                {"step": "STEP050", "pgm": "BFRETIRE",
                 "cond": "(8,LE,STEP040)"},
                {"step": "STEP055", "pgm": "BFSURV",
                 "cond": "(8,LE,STEP040)"},
                {"step": "STEP057", "pgm": "BFDISAB",
                 "cond": "(8,LE,STEP040)"},
                {"step": "STEP060", "pgm": "DBPUT"},
                {"step": "STEP070", "pgm": "NOTIFDRV"},
            ],
            "carry": ["TDA-RECORD", "PDA-RECORD"],
            "ws": {
                "IN-SSN": "900010002", "IN-BIC": "A",
                "IN-DOB": "1958-04-02", "IN-NAME": "HALVORSEN MARIT",
                "IN-CLM-TYPE": "RET", "IN-FILING-DT": "2026-01-15",
                "PIA-AIME": "2000.00", "PIA-ELIG-YEAR": "1990",
                "MBA-REL-CD": "A",
            },
            "case": {
                "claimant": {"name": "HALVORSEN MARIT"},
                "claim": {"mba": "1842.50"},
                "address": {"line1": "12 BIRCH LANE", "city": "ARLINGTON",
                            "state": "VA", "zip": "220011234"},
            },
            "field_map": [
                {"db2_column": "MCS.CLAIMANT.BENE_NAME",
                 "json_path": "claimant.name", "format": "text"},
                {"db2_column": "MCS.CLAIMANT.ADDR_LINE1",
                 "json_path": "address.line1", "format": "text"},
                {"db2_column": "MCS.CLAIMANT.CITY",
                 "json_path": "address.city", "format": "text"},
                {"db2_column": "MCS.CLAIMANT.ST",
                 "json_path": "address.state", "format": "text"},
                {"db2_column": "MCS.CLAIMANT.ZIP",
                 "json_path": "address.zip", "format": "text"},
                {"db2_column": "MCS.CLAIMANT.MBA",
                 "json_path": "claim.mba", "format": "decimal"},
            ],
        })
    }

    fn run() -> Value {
        let req = corpus_req();
        let sources: HashMap<String, String> = req["sources"].as_object()
            .unwrap().iter()
            .map(|(k, v)| (k.clone(), v.as_str().unwrap().to_string()))
            .collect();
        let stubs: Vec<String> = req["stubs"].as_array().unwrap().iter()
            .map(|v| v.as_str().unwrap().to_string()).collect();
        let mut m = Machine::new(sources, stubs, 500_000);
        for (k, v) in req["copybooks"].as_object().unwrap() {
            m.copybooks.insert(k.clone(), v.as_str().unwrap().to_string());
        }
        let steps = req["steps"].as_array().unwrap().clone();
        run_pipeline(&mut m, &req, &steps)
    }

    fn run_with(overrides: &[(&str, &str)]) -> Value {
        let mut req = corpus_req();
        for (k, v) in overrides {
            req["ws"][*k] = json!(v);
        }
        let sources: HashMap<String, String> = req["sources"].as_object()
            .unwrap().iter()
            .map(|(k, v)| (k.clone(), v.as_str().unwrap().to_string()))
            .collect();
        let stubs: Vec<String> = req["stubs"].as_array().unwrap().iter()
            .map(|v| v.as_str().unwrap().to_string()).collect();
        let mut m = Machine::new(sources, stubs, 500_000);
        for (k, v) in req["copybooks"].as_object().unwrap() {
            m.copybooks.insert(k.clone(), v.as_str().unwrap().to_string());
        }
        let steps = req["steps"].as_array().unwrap().clone();
        run_pipeline(&mut m, &req, &steps)
    }

    fn posted(r: &Value, col: &str) -> String {
        r["writes"].as_array().unwrap().iter()
            .find(|w| w["column"] == col)
            .unwrap_or_else(|| panic!("no write to {}", col))["value"]
            .as_str().unwrap().to_string()
    }

    fn mba_history(r: &Value) -> Vec<(String, String)> {
        r["trace"].as_array().unwrap().iter()
            .filter(|e| e["kind"] == "move" && e["field"] == "PDA-MBA")
            .map(|e| (e["pgm"].as_str().unwrap().to_string(),
                      e["after"].as_str().unwrap().to_string()))
            .collect()
    }

    #[test]
    fn the_whole_pipeline_runs_from_the_case_alone() {
        // The end state of the mapping design: no manual seeds at all.
        // The case JSON fills IN-TRANSACTION (the transaction entering
        // the flow) and the parameter areas, everything downstream flows
        // by carry and code, and the computed MBA posts.
        let mut req = corpus_req();
        req["ws"] = json!({});
        req["case"]["claimant"] = json!({
            "ssn": "900010002", "bic": "A", "name": "HALVORSEN MARIT",
            "dateOfBirth": "1958-04-02"});
        req["case"]["claim"] = json!({
            "claimType": "RET", "filingDate": "2026-01-15",
            "mba": "1842.50", "relationshipCode": "A"});
        req["case"]["wageRecord"] = json!({
            "aime": "2000.00", "eligibilityYear": "1990"});
        req["area_maps"] = json!([
            {"area": "IN-TRANSACTION", "field": "IN-SSN",
             "path": "claimant.ssn", "format": "integer"},
            {"area": "IN-TRANSACTION", "field": "IN-BIC",
             "path": "claimant.bic", "format": "text"},
            {"area": "IN-TRANSACTION", "field": "IN-DOB",
             "path": "claimant.dateOfBirth", "format": "iso-date"},
            {"area": "IN-TRANSACTION", "field": "IN-NAME",
             "path": "claimant.name", "format": "text"},
            {"area": "IN-TRANSACTION", "field": "IN-CLM-TYPE",
             "path": "claim.claimType", "format": "text"},
            {"area": "IN-TRANSACTION", "field": "IN-FILING-DT",
             "path": "claim.filingDate", "format": "iso-date"},
            {"area": "PIA-PARM-AREA", "field": "PIA-AIME",
             "path": "wageRecord.aime", "format": "decimal"},
            {"area": "PIA-PARM-AREA", "field": "PIA-ELIG-YEAR",
             "path": "wageRecord.eligibilityYear", "format": "integer"},
            {"area": "MBA-PARM-AREA", "field": "MBA-REL-CD",
             "path": "claim.relationshipCode", "format": "flag"},
        ]);
        let sources: HashMap<String, String> = req["sources"].as_object()
            .unwrap().iter()
            .map(|(k, v)| (k.clone(), v.as_str().unwrap().to_string()))
            .collect();
        let stubs: Vec<String> = req["stubs"].as_array().unwrap().iter()
            .map(|v| v.as_str().unwrap().to_string()).collect();
        let mut m = Machine::new(sources, stubs, 500_000);
        for (k, v) in req["copybooks"].as_object().unwrap() {
            m.copybooks.insert(k.clone(), v.as_str().unwrap().to_string());
        }
        let steps = req["steps"].as_array().unwrap().clone();
        let r = run_pipeline(&mut m, &req, &steps);
        assert_eq!(r["status"], "completed", "{:?}", r["halt"]);
        assert_eq!(r["exceptions"].as_array().unwrap().len(), 0,
                   "{:?}", r["exceptions"]);
        assert_eq!(posted(&r, "MCS.CLAIM.MBA"), "1800.00");
        assert_eq!(posted(&r, "MCS.CLAIM.ENT_DT"), "2026-01-15");
        // and nothing was hand-seeded: every input entered as a mapped
        // area seed, visible in the trace
        assert!(r["trace"].as_array().unwrap().iter().any(|e|
            e["kind"] == "seed" && e["area"] == "IN-TRANSACTION"
            && e["filled"] == 6));
    }

    #[test]
    fn the_ee_roundtrip_mutates_through_four_renames() {
        // The shop's real pattern: the business function never touches
        // the PDA directly. EEGET projects PDA → EE, the function works
        // in WS, EEPUT posts back. One datum, four names — and no
        // configured mapping anywhere: the code does it, and BY
        // REFERENCE aliasing makes the callee's writes land in the
        // caller's storage.
        let r = run_with(&[("IN-CLM-TYPE", "DIS")]);
        assert_eq!(r["status"], "completed", "{:?}", r["halt"]);
        // 1800.00 entered the EE area, 85% came back: 1530.00 posted.
        assert_eq!(posted(&r, "MCS.CLAIM.MBA"), "1530.00");
        // The DOB made the same trip and came back UNCHANGED — renames
        // must not corrupt what they merely carry.
        assert_eq!(posted(&r, "MCS.CLAIM.BENE_DOB"), "1958-04-02");
        // The write that lands the mutation in the PDA is attributed to
        // EEPUT — the put module, three renames away from where the 85%
        // was computed. That attribution is only possible because the
        // linkage aliasing is real.
        let hist = mba_history(&r);
        assert_eq!(hist, vec![
            ("BFRETIRE".to_string(), "1800.00".to_string()),
            ("BFSURV".to_string(), "1800.00".to_string()),
            ("EEPUT".to_string(), "1530.00".to_string()),
        ]);
        // Every hop of the rename chain is in the trace, each attributed
        // to the program that made it.
        let hop = |pgm: &str, field: &str, after: &str| {
            r["trace"].as_array().unwrap().iter().any(|e|
                e["kind"] == "move" && e["pgm"] == pgm
                && e["field"] == field && e["after"] == after)
        };
        assert!(hop("EEGET", "EE-MBA", "1800.00"),   "PDA → EE");
        assert!(hop("BFDISAB", "WS-MBA", "1800.00"), "EE → WS");
        assert!(hop("BFDISAB", "WS-MBA", "1530.00"), "the computation");
        assert!(hop("BFDISAB", "EE-MBA", "1530.00"), "WS → EE");
        assert!(hop("EEPUT", "PDA-MBA", "1530.00"),  "EE → PDA");
        assert!(hop("EEGET", "EE-DOB", "1958-04-02"), "DOB out");
        assert!(hop("EEPUT", "PDA-BENE-DOB", "1958-04-02"), "DOB back");
    }

    #[test]
    fn a_non_disability_claim_leaves_the_ee_stage_inert() {
        // RET claim: EEGET still projects (reads are free), but the
        // apply paragraph never runs and EEPUT is never called — the
        // PDA-MBA history must NOT contain an EEPUT write.
        let r = run_with(&[]);
        assert_eq!(r["status"], "completed", "{:?}", r["halt"]);
        assert_eq!(posted(&r, "MCS.CLAIM.MBA"), "1800.00");
        assert!(r["trace"].as_array().unwrap().iter().any(|e|
            e["kind"] == "move" && e["pgm"] == "EEGET"));
        assert!(mba_history(&r).iter().all(|(pgm, _)| pgm != "EEPUT"));
    }

    // ── the differential matrix: change one input, the posted value ──
    // must change exactly as the code dictates. This is the proof that
    // data mutates per code logic rather than echoing the seeds.

    #[test]
    fn changing_the_wage_input_changes_the_posted_mba() {
        // PIACOMP: PIA = AIME × 0.9. Nothing else changed.
        let r = run_with(&[("PIA-AIME", "3000.00")]);
        assert_eq!(r["status"], "completed", "{:?}", r["halt"]);
        assert_eq!(posted(&r, "MCS.CLAIM.MBA"), "2700.00");
    }

    #[test]
    fn a_widow_relationship_cuts_the_mba_mid_flight() {
        // BFRETIRE sets PDA-MBA = PIA (1800.00). BFSURV then runs MBACOMP
        // with REL-CD 'W' and OVERWRITES it at 71.5% — a later business
        // function changing an earlier one's value. The PUT posts the
        // overwritten number.
        let r = run_with(&[("MBA-REL-CD", "W")]);
        assert_eq!(r["status"], "completed", "{:?}", r["halt"]);
        assert_eq!(posted(&r, "MCS.CLAIM.MBA"), "1287.00");
        let hist = mba_history(&r);
        assert_eq!(hist, vec![
            ("BFRETIRE".to_string(), "1800.00".to_string()),
            ("BFSURV".to_string(), "1287.00".to_string()),
        ], "the overwrite chain must be visible in the field history");
    }

    #[test]
    fn the_statutory_floor_engages_and_raises() {
        // AIME 50.00 → PIA 45.00 → below the 49.40 minimum. MBACOMP
        // floors the amount AND returns rc 04, which BFSURV reports as
        // E7401. Both effects must appear: the floored value posts, the
        // exception fires.
        let r = run_with(&[("PIA-AIME", "50.00")]);
        assert_eq!(r["status"], "completed", "{:?}", r["halt"]);
        assert_eq!(posted(&r, "MCS.CLAIM.MBA"), "49.40");
        assert!(r["exceptions"].as_array().unwrap().iter()
                .any(|e| e["code"] == "E7401" && e["pgm"] == "BFSURV"),
                "{:?}", r["exceptions"]);
    }

    #[test]
    fn the_disability_reduction_undercuts_the_statutory_floor() {
        // Found by the verification battery, pinned here: with no wage
        // record the PIA computes zero, MBACOMP floors the MBA at the
        // statutory minimum 49.40 — and then BFDISAB applies its 85% to
        // the FLOORED amount, posting 41.99. The floor is not re-applied
        // after later adjustments. Whether that is intended is a policy
        // question; that it HAPPENS is now a pinned fact of this corpus,
        // and the kind of ordering defect a dry run exists to surface.
        let mut req = corpus_req();
        req["case"]["claim"]["claimType"] = json!("DIS");
        req["ws"]["IN-CLM-TYPE"] = json!("DIS");
        req["ws"].as_object_mut().unwrap().remove("PIA-AIME");
        req["ws"].as_object_mut().unwrap().remove("PIA-ELIG-YEAR");
        let sources: HashMap<String, String> = req["sources"].as_object()
            .unwrap().iter()
            .map(|(k, v)| (k.clone(), v.as_str().unwrap().to_string()))
            .collect();
        let stubs: Vec<String> = req["stubs"].as_array().unwrap().iter()
            .map(|v| v.as_str().unwrap().to_string()).collect();
        let mut m = Machine::new(sources, stubs, 500_000);
        for (k, v) in req["copybooks"].as_object().unwrap() {
            m.copybooks.insert(k.clone(), v.as_str().unwrap().to_string());
        }
        let steps = req["steps"].as_array().unwrap().clone();
        let r = run_pipeline(&mut m, &req, &steps);
        assert_eq!(r["status"], "completed", "{:?}", r["halt"]);
        let codes: Vec<&str> = r["exceptions"].as_array().unwrap().iter()
            .map(|e| e["code"].as_str().unwrap()).collect();
        assert!(codes.contains(&"E7201"), "{:?}", codes);
        assert!(codes.contains(&"E7401"), "{:?}", codes);
        assert_eq!(posted(&r, "MCS.CLAIM.MBA"), "41.99",
                   "the floored 49.40 reduced by 85% — below the minimum");
    }

    #[test]
    fn a_future_dob_weeds_out_and_the_whole_flow_reacts() {
        // DOB after the filing date: EVNTANLZ raises E6102, the weeder
        // rejects to suspense and marks EDIT-FAIL, the carried verdict
        // blocks the PDA build, the gates close both business functions,
        // and the PUT posts a zero MBA. One bad input, five downstream
        // consequences — each visible.
        let r = run_with(&[("IN-DOB", "2030-01-01")]);
        assert_eq!(r["status"], "completed", "{:?}", r["halt"]);
        let codes: Vec<&str> = r["exceptions"].as_array().unwrap().iter()
            .map(|e| e["code"].as_str().unwrap()).collect();
        assert!(codes.contains(&"E6102"), "{:?}", codes);
        assert!(codes.contains(&"E6201"), "{:?}", codes);
        assert!(codes.contains(&"E6301"), "{:?}", codes);
        // the reject landed in the suspense dataset
        let rejects = r["datasets"]["PROD.T2.REJECTS"].as_array().unwrap();
        assert_eq!(rejects.len(), 1);
        assert!(rejects[0].as_str().unwrap().contains("900010002"));
        // the gates closed
        let skipped: Vec<&str> = r["steps"].as_array().unwrap().iter()
            .filter(|s| s["status"] == "skipped")
            .map(|s| s["pgm"].as_str().unwrap()).collect();
        assert_eq!(skipped, vec!["BFRETIRE", "BFSURV", "BFDISAB"]);
        assert_eq!(posted(&r, "MCS.CLAIM.MBA"), "0.00");
    }

    #[test]
    fn the_computed_mba_is_what_gets_posted() {
        let r = run();
        assert_eq!(r["status"], "completed", "halt: {:?}", r["halt"]);
        // every step ran — the gates stayed open because the carried
        // edit status was PASS
        for s in r["steps"].as_array().unwrap() {
            assert_eq!(s["status"], "completed", "{:?}", s);
        }
        assert_eq!(r["exceptions"].as_array().unwrap().len(), 0,
                   "clean path: {:?}", r["exceptions"]);
        // BFRETIRE computed PIA = 2000.00 * 0.9 = 1800.00 in ITS enclave;
        // DBPUT posted it from the carried PDA. No seed carries this
        // number — only the carry mechanism can have moved it.
        let writes = r["writes"].as_array().unwrap();
        let mba = writes.iter()
            .find(|w| w["column"] == "MCS.CLAIM.MBA").unwrap();
        assert_eq!(mba["value"], "1800.00");
        // The entitlement date DBPUT posted was set mid-flight by
        // EVNTANLZ (from the filing date) — the original motivating
        // scenario. TDABUILD never set it; the seed never contained it.
        let ent = writes.iter()
            .find(|w| w["column"] == "MCS.CLAIM.ENT_DT").unwrap();
        assert_eq!(ent["value"], "2026-01-15");
        let set_by = r["trace"].as_array().unwrap().iter()
            .find(|e| e["kind"] == "move" && e["field"] == "TDA-ENT-DT"
                  && e["after"] == "2026-01-15")
            .expect("the mid-flight mutation is in the trace");
        assert_eq!(set_by["pgm"], "EVNTANLZ");
    }

    #[test]
    fn every_handoff_is_in_the_trace() {
        let r = run();
        let carries: Vec<(String, String)> = r["trace"].as_array().unwrap()
            .iter().filter(|e| e["kind"] == "carry")
            .map(|e| (e["area"].as_str().unwrap().to_string(),
                      e["into"].as_str().unwrap().to_string()))
            .collect();
        // TDA flows into every stage that declares it; the PDA starts
        // at the build and flows through both business functions to
        // the PUT.
        assert!(carries.contains(&("TDA-RECORD".into(), "EVNTANLZ".into())));
        assert!(carries.contains(&("TDA-RECORD".into(), "WEEDCHK".into())));
        assert!(carries.contains(&("TDA-RECORD".into(), "PDABUILD".into())));
        assert!(carries.contains(&("PDA-RECORD".into(), "BFRETIRE".into())));
        assert!(carries.contains(&("PDA-RECORD".into(), "BFSURV".into())));
        assert!(carries.contains(&("PDA-RECORD".into(), "DBPUT".into())));
    }

    #[test]
    fn without_carry_the_gates_close_and_values_post_blank() {
        // The control: same corpus, same seeds, NO carry declaration.
        // Each enclave starts cold, the weeder's PASS never reaches the
        // PDA build, the business functions are skipped, and the posted
        // MBA is zero. The difference between the two runs IS the
        // demonstration.
        let mut req = corpus_req();
        req["carry"] = json!([]);
        let sources: HashMap<String, String> = req["sources"].as_object()
            .unwrap().iter()
            .map(|(k, v)| (k.clone(), v.as_str().unwrap().to_string()))
            .collect();
        let stubs: Vec<String> = req["stubs"].as_array().unwrap().iter()
            .map(|v| v.as_str().unwrap().to_string()).collect();
        let mut m = Machine::new(sources, stubs, 500_000);
        for (k, v) in req["copybooks"].as_object().unwrap() {
            m.copybooks.insert(k.clone(), v.as_str().unwrap().to_string());
        }
        let steps = req["steps"].as_array().unwrap().clone();
        let r = run_pipeline(&mut m, &req, &steps);
        let skipped: Vec<&str> = r["steps"].as_array().unwrap().iter()
            .filter(|s| s["status"] == "skipped")
            .map(|s| s["pgm"].as_str().unwrap()).collect();
        assert_eq!(skipped, vec!["BFRETIRE", "BFSURV", "BFDISAB"]);
        let mba = r["writes"].as_array().unwrap().iter()
            .find(|w| w["column"] == "MCS.CLAIM.MBA").unwrap();
        assert_eq!(mba["value"], "0.00");
    }
}

#[cfg(test)]
mod area_maps {
    //! Copybook-scoped seed maps: the case JSON fills the interface
    //! areas through declared, formatted mappings — so a business
    //! function can be entered STANDALONE, with the case as the only
    //! input.
    use super::*;
    use serde_json::json;
    use std::path::PathBuf;

    fn corpus(member: &str) -> (String, String) {
        let path = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("../content/t2-test").join(member);
        (path.file_stem().unwrap().to_string_lossy().to_uppercase(),
         std::fs::read_to_string(&path).unwrap())
    }

    fn machine(members: &[&str]) -> Machine {
        let mut sources = HashMap::new();
        for m in members {
            let (n, s) = corpus(m);
            sources.insert(n, s);
        }
        let mut m = Machine::new(sources, vec!["EXCEPTRN".into()], 200_000);
        let books = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("../content/t2-test/copybooks");
        for e in std::fs::read_dir(&books).unwrap().flatten() {
            let p = e.path();
            if p.extension().map(|x| x == "cpy").unwrap_or(false) {
                m.copybooks.insert(
                    p.file_stem().unwrap().to_string_lossy().to_uppercase(),
                    std::fs::read_to_string(&p).unwrap());
            }
        }
        m
    }

    fn amap(area: &str, field: &str, path: &str, fmt: &str) -> sql::AreaMap {
        sql::AreaMap { area: area.into(), field: field.into(),
                       path: path.into(), format: fmt.into() }
    }

    fn case() -> Value {
        json!({
            "claimant": {"ssn": "900010002",
                         "dateOfBirth": "1958-04-02"},
            "claim": {"claimType": "DIS", "mba": "1842.50",
                      "entitlementDate": "2026-01-15"},
            "wageRecord": {"aime": "2000.00", "eligibilityYear": "1990"},
            "entitlementPeriods": [
                {"startDate": "2019-01-01"},
                {"startDate": "2021-06-01"},
            ],
        })
    }

    fn pda_maps() -> Vec<sql::AreaMap> {
        vec![amap("PDA-RECORD", "PDA-SSN", "claimant.ssn", "integer"),
             amap("PDA-RECORD", "PDA-BENE-DOB", "claimant.dateOfBirth",
                  "iso-date"),
             amap("PDA-RECORD", "PDA-CLM-TYPE", "claim.claimType", "text"),
             amap("PDA-RECORD", "PDA-ENT-DT", "claim.entitlementDate",
                  "iso-date"),
             amap("PDA-RECORD", "PDA-MBA", "claim.mba", "decimal"),
             amap("PIA-PARM-AREA", "PIA-AIME", "wageRecord.aime",
                  "decimal"),
             amap("PIA-PARM-AREA", "PIA-ELIG-YEAR",
                  "wageRecord.eligibilityYear", "integer")]
    }

    #[test]
    fn a_business_function_runs_standalone_from_the_case_alone() {
        // No pipeline, no manual seeds — the case JSON, through the
        // area maps, is the whole input. BFDISAB gets its PDA and its
        // PIA parameters, works through the EE interface, and the 85%
        // lands back in the PDA.
        let mut m = machine(&["business-functions/BFDISAB.cbl",
                              "business-functions/EEGET.cbl",
                              "business-functions/EEPUT.cbl",
                              "utilities/PIACOMP.cbl"]);
        let li = m.load("BFDISAB").unwrap();
        m.push_frame(li, &[]).unwrap();
        m.apply_area_maps(&pda_maps(), &case(), &Default::default())
            .unwrap();
        m.run_top(li).unwrap();
        // 1842.50 from the case × .85 = 1566.12 (truncated), written
        // back by EEPUT through the linkage aliasing.
        let fi = m.lay().find("PDA-MBA").unwrap();
        assert_eq!(m.show(fi), "1566.12");
        // the seed itself is in the trace, attributed as such
        assert!(m.trace.iter().any(|e| e["kind"] == "seed"
            && e["area"] == "PDA-RECORD" && e["filled"] == 5));
        assert!(m.trace.iter().any(|e| e["kind"] == "move"
            && e["field"] == "PDA-MBA" && e["cause"] == "seed"
            && e["after"] == "1842.50"));
    }

    #[test]
    fn a_repeating_group_fills_the_occurs_table() {
        let mut m = machine(&["event-analyzer/EVNTANLZ.cbl"]);
        let li = m.load("EVNTANLZ").unwrap();
        m.push_frame(li, &[]).unwrap();
        let maps = vec![
            amap("TDA-RECORD", "TDA-BENE-DOB", "claimant.dateOfBirth",
                 "iso-date"),
            amap("TDA-RECORD", "TDA-FILING-DT", "claim.entitlementDate",
                 "iso-date"),
            amap("TDA-RECORD", "TDA-ENT-STRT-DT",
                 "entitlementPeriods[].startDate", "iso-date"),
        ];
        m.apply_area_maps(&maps, &case(), &Default::default()).unwrap();
        let f = m.lay().find("TDA-ENT-STRT-DT").unwrap();
        assert_eq!(m.show_at(f, 0), "2019-01-01");
        assert_eq!(m.show_at(f, 1), "2021-06-01");
        assert_eq!(m.show_at(f, 2), "");        // untouched beyond the case
    }

    #[test]
    fn more_periods_than_the_table_holds_is_a_halt_not_a_truncation() {
        let mut m = machine(&["event-analyzer/EVNTANLZ.cbl"]);
        let li = m.load("EVNTANLZ").unwrap();
        m.push_frame(li, &[]).unwrap();
        let mut c = case();
        c["entitlementPeriods"] = json!(
            (0..13).map(|i| json!({"startDate":
                format!("20{:02}-01-01", i + 10)}))
            .collect::<Vec<_>>());
        let maps = vec![amap("TDA-RECORD", "TDA-ENT-STRT-DT",
                             "entitlementPeriods[].startDate", "iso-date")];
        let err = m.apply_area_maps(&maps, &c, &Default::default())
            .unwrap_err();
        let RunErr::Halt(msg) = err else { panic!("expected halt") };
        assert!(msg.contains("13"), "{}", msg);
        assert!(msg.contains("OCCURS 12"), "{}", msg);
    }

    #[test]
    fn an_absent_path_seeds_blank_and_says_so() {
        let mut m = machine(&["business-functions/BFDISAB.cbl",
                              "business-functions/EEGET.cbl",
                              "business-functions/EEPUT.cbl",
                              "utilities/PIACOMP.cbl"]);
        let li = m.load("BFDISAB").unwrap();
        m.push_frame(li, &[]).unwrap();
        let maps = vec![amap("PDA-RECORD", "PDA-BENE-DOD",
                             "claimant.dateOfDeath", "iso-date")];
        m.apply_area_maps(&maps, &case(), &Default::default()).unwrap();
        let e = m.trace.iter().find(|e| e["kind"] == "seed").unwrap();
        assert_eq!(e["filled"], 0);
        assert_eq!(e["blank"][0], "PDA-BENE-DOD");
    }

    #[test]
    fn an_unconvertible_value_halts_rather_than_blanking() {
        let mut m = machine(&["business-functions/BFDISAB.cbl",
                              "business-functions/EEGET.cbl",
                              "business-functions/EEPUT.cbl",
                              "utilities/PIACOMP.cbl"]);
        let li = m.load("BFDISAB").unwrap();
        m.push_frame(li, &[]).unwrap();
        let mut c = case();
        c["claim"]["mba"] = json!("not-a-number");
        let err = m.apply_area_maps(&pda_maps(), &c, &Default::default())
            .unwrap_err();
        let RunErr::Halt(msg) = err else { panic!("expected halt") };
        assert!(msg.contains("PDA-MBA"), "{}", msg);
        assert!(msg.contains("not numeric"), "{}", msg);
    }

    #[test]
    fn a_carried_area_is_not_reseeded() {
        let mut m = machine(&["business-functions/BFDISAB.cbl",
                              "business-functions/EEGET.cbl",
                              "business-functions/EEPUT.cbl",
                              "utilities/PIACOMP.cbl"]);
        let li = m.load("BFDISAB").unwrap();
        m.push_frame(li, &[]).unwrap();
        let skip: std::collections::HashSet<String> =
            ["PDA-RECORD".to_string()].into();
        m.apply_area_maps(&pda_maps(), &case(), &skip).unwrap();
        // PIA-PARM-AREA seeded, PDA-RECORD untouched
        assert!(m.trace.iter().any(|e| e["kind"] == "seed"
            && e["area"] == "PIA-PARM-AREA"));
        assert!(!m.trace.iter().any(|e| e["kind"] == "seed"
            && e["area"] == "PDA-RECORD"));
        let fi = m.lay().find("PDA-MBA").unwrap();
        assert_eq!(m.show(fi), "0.00");
    }
}

#[cfg(test)]
mod abends {
    use super::*;

    /// The pairing no rule model can produce: a GROUP move plants invalid
    /// decimal bytes (no conversion, no validation), and the arithmetic
    /// that touches them later is where the machine actually fails.
    const S0C7_SRC: &str = concat!(
        "       IDENTIFICATION DIVISION.\n",
        "       PROGRAM-ID. BADPACK.\n",
        "       DATA DIVISION.\n",
        "       WORKING-STORAGE SECTION.\n",
        "       01  IN-REC.\n",
        "           05  IN-TEXT             PIC X(05).\n",
        "       01  WORK-REC.\n",
        "           05  WK-AMT              PIC S9(5) COMP-3.\n",
        "       01  WS-TOTAL                PIC S9(7) COMP-3.\n",
        "       PROCEDURE DIVISION.\n",
        "       0000-MAIN.\n",
        "           MOVE 'ABCDE' TO IN-TEXT\n",
        "           MOVE IN-REC TO WORK-REC\n",
        "           ADD WK-AMT TO WS-TOTAL\n",
        "           GOBACK.\n");

    #[test]
    fn s0c7_raises_on_use_not_on_the_planting_move() {
        let mut sources = HashMap::new();
        sources.insert("BADPACK".to_string(), S0C7_SRC.to_string());
        let mut m = Machine::new(sources, vec![], 10_000);
        let li = m.load("BADPACK").unwrap();
        m.push_frame(li, &[]).unwrap();
        let out = m.run_top(li);
        match out {
            Err(RunErr::Abend { code, line, detail }) => {
                assert_eq!(code, "S0C7");
                assert!(detail.contains("WK-AMT"), "{}", detail);
                // line 14 is the ADD — the detonation. The group MOVE on
                // line 13 planted the bytes and completed quietly.
                assert_eq!(line, 14);
            }
            other => panic!("expected S0C7, got {:?}", other),
        }
        // and the planting group MOVE completed quietly, in the trace
        assert!(m.trace.iter().any(|e| e["kind"] == "move"
            && e["field"] == "WORK-REC"));
    }
}
