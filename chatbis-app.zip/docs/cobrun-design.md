# cobrun — a tracing COBOL interpreter in Rust

**Status:** design · v0.2 (reviewed) · 2026-08-02
**Companions:** `dry-run-what-if.md` (the product idea), `agent-architecture.md` (the deterministic-first doctrine this inherits)

---

## 1. Purpose

Run the shop's actual COBOL against a real case, off-host, and produce a
**trace**: every statement executed, every field mutation with before/after
values, every exception raised — each cited to member and line.

The trace is the product. Stage replay with authored transform rules predicts
what the pipeline does; cobrun *shows* it, with the real code making the
decisions — including the branch in a business function that nobody modeled.
That is the direct answer to the founding worry: *"the entitlement date might
get changed along the way and our checks would miss it."* With an
interpreter, the change **is the trace line**.

### Non-goals

- Not a compiler, not a rehosting platform, not a performance play. One case,
  one run, milliseconds-to-seconds is fine.
- Not a replacement for the host. The test-region rerun remains the fidelity
  ceiling; cobrun is the everyday approximation that runs at a desk.
- Not an emulator of z/OS. No LE internals, no storage protection, no
  scheduler. The machine is simulated only where its behavior is visible to
  business logic (data encodings, abend conditions, collation).

---

## 2. Fidelity doctrine

The miner's rule, promoted to an execution engine: **refuse, don't guess.**

1. **An unsupported statement halts the run** with member, line, and verb,
   e.g. `HALT: UNSTRING not implemented — BENELOAD.cbl:214`. It never skips,
   never no-ops, never approximates. A partial trace that is honest beats a
   complete one that is fiction.
2. **Coverage is a ledger, not a claim.** The binary ships a
   `cobrun --coverage` report: every verb/clause → `full | partial(caveat) |
   refused`. ChatBIS shows the ledger; "we run your code" is never said,
   only "we ran *this* code, and here is what we could not."
3. **Environment effects are recorded, not performed.** Database writes,
   file writes, CICS sends, notices — all become trace events ("would write
   MBA=1842.50 to MCS.CLAIM"). cobrun mutates nothing outside its own
   memory. This is also the security posture: the binary needs no network
   and no write access beyond its output file.
4. **Divergence is measured.** The accuracy meter (replaying cases with
   MI-recorded outcomes) judges cobrun exactly as it judges the rule model.
   Where the trace and reality disagree, the first divergent statement is
   the bug report — against cobrun or against our understanding.

---

## 3. Architecture

```
ChatBIS (Python, stdlib)                cobrun (Rust, single static binary)
────────────────────────                ───────────────────────────────────
case JSON  ─┐
field map  ─┤                            ┌─ preprocessor (COPY/REPLACING,
sources    ─┼──▶  run-request JSON ──▶   │   EXEC SQL/CICS extraction)
entry pgm  ─┤        (stdin)             ├─ parser → AST + storage layout
JCL steps  ─┘                            ├─ interpreter + shims
                                         └─ trace writer
   ◀─────────  trace JSON (stdout) ──────┘
```

- **Sidecar, not a library.** ChatBIS stays stdlib-Python; it shells out to
  `cobrun`, exactly as the test API is a sidecar. One request per process:
  no daemon state, no ports, kill-safe.
- **Request:** `{sources: {name: text|ebcdic-base64}, copybooks: {...},
  entry: "BFRETIRE", case: {...}, field_map: [...], screen_input: {...},
  steps: [...], options: {...}}`.
- **Response:** `{status: completed|halted|abended, trace: [...],
  final_state: {...}, writes: [...], exceptions: [...], halt: {...}}`.
- Resource limits enforced by cobrun itself: statement budget (default 1M),
  wall-clock timeout, trace-size cap. Runaway `PERFORM UNTIL` becomes a
  clean `halted: statement budget exhausted at WEEDEDIT.cbl:31`, mirroring
  what AICA means on the host.

---

## 4. The storage model — bytes, like the machine

The single most important design decision: **working storage is a byte
image, and fields are typed views over it** — exactly as on the host.

- Each 01-level item allocates a contiguous buffer. Elementary items are
  `(offset, length, type)` views computed from the data division.
- **REDEFINES costs nothing**: a redefine is another view over the same
  bytes. Group MOVEs are `memcpy` — byte-for-byte, no conversion — which is
  IBM's rule and a place naive implementations go wrong.
- **Internal character encoding is EBCDIC (CP037).** Not a nicety:
  alphanumeric comparison uses the machine's collation, and in EBCDIC
  letters sort *below* digits — the opposite of ASCII. `IF WS-CODE > '9'`
  answers differently under each. Storing EBCDIC bytes makes host semantics
  the default rather than a patch. JSON case data converts at the boundary
  in both directions.
- `OCCURS DEPENDING ON` recomputes group extents from the controlling field
  at reference time. Variable-length groups shift subordinate offsets;
  layout is therefore an object that can answer `resolve(field, subscripts,
  refmod)` dynamically, not a frozen table.
- Reference modification `X(start:len)` is a sub-view (1-based, checked).
- `INDEXED BY` indexes are **occurrence-scaled cells**, not subscripts:
  `SET IDX UP BY 1` advances one occurrence, and index/subscript mixing
  follows the book. They live beside the buffer, not in it.
- Figurative constants take their **EBCDIC** values — `HIGH-VALUES` is
  X'FF', `SPACES` X'40' — which comparisons and group moves then treat
  like any other bytes.
- `SIGN IS SEPARATE` (leading/trailing): v2 ledger line, refused in v1.

### Numeric encodings (the part that must be exactly right)

| Usage | Encoding | Size rule |
|---|---|---|
| `DISPLAY` (zoned) | one digit per byte, EBCDIC F0–F9; sign overpunched in the last byte's zone nibble (C=+, D=−, F=unsigned) | n digits → n bytes |
| `COMP-3` (packed) | two digits per byte, sign in the final low nibble (C/D/F) | n digits → ⌈(n+1)/2⌉ bytes |
| `COMP`/`COMP-4`/`BINARY` | big-endian two's complement | 1–4 digits → 2 bytes, 5–9 → 4, 10–18 → 8 |
| `COMP-1`/`COMP-2` | hex floating point on the host | v1: **refused** (rare in business logic; floating point invites silent divergence) |

Compiler-option sensitivities are explicit `options` with host-default
values, because they change results: `TRUNC(STD|OPT|BIN)` for binary
truncation, `NUMPROC` for sign handling of "dirty" zoned data. Default
`TRUNC(STD)`, `NUMPROC(NOPFD)`.

---

## 5. Decimal arithmetic

- Fixed-point decimal on **i128 mantissa + scale**. v1 targets
  `ARITH(COMPAT)`: 18-digit items, whose worst products (18×18 = 36
  digits) fit i128's 38. `ARITH(EXTEND)` (31-digit items — whose products
  do NOT fit i128) is **refused as an option**, a ledger line, until a
  real member demands a wide-decimal engine.
- **Intermediate results follow the IBM rules**, not "as much precision as
  we have." Enterprise COBOL's appendix defines the derived digit counts
  per operation; a chained `COMPUTE` can truncate mid-expression on the
  host, and matching that is part of fidelity. v1 implements the standard
  rules for `+ − × ÷`; exponentiation is refused.
- `ROUNDED` = nearest, **ties away from zero** (the IBM rule — "half-up"
  is wrong for negative amounts, and adjustment/recovery amounts go
  negative), at the target's scale. `ON SIZE ERROR` honored;
  without it, overflow truncates high-order digits exactly as the host
  does — silently, into the trace (flagged as a `size-truncation` event,
  because silent-on-host does not mean invisible-in-trace).
- `DIVIDE ... REMAINDER`, `GIVING` forms, mixed-usage operands: all
  normalize through the decimal engine; conversion happens at field
  boundaries per MOVE rules.

---

## 6. MOVE, comparison, and the abend that matters

- **MOVE matrix implemented as a table**, not ad-hoc: numeric→numeric
  aligns decimal points, truncates/pads by PICTURE; alphanumeric→
  alphanumeric left-justifies and pads with spaces; numeric→alphanumeric
  moves the display form; alphanumeric→numeric is accepted the way the
  host accepts it (and is a classic S0C7 seed); **group↔anything is a raw
  byte move**. Editing PICTUREs (`Z`, insertion, floating `$`, `BLANK WHEN
  ZERO`, `CR/DB`) implemented for output fields.
- Comparison: numeric compares by value; alphanumeric compares byte-wise
  in EBCDIC, shorter operand space-padded. Class conditions (`NUMERIC`,
  `ALPHABETIC`) test the actual bytes per usage.
- **S0C7 is raised faithfully**: when packed/zoned bytes are invalid and
  the field is *used numerically* — arithmetic, numeric comparison, or an
  elementary numeric→numeric MOVE (which converts, and therefore
  validates). A **group** MOVE is a byte copy and can never raise — it is
  how the garbage gets planted. The trace shows both moments: the group MOVE that smuggled
  garbage in, and the ADD that detonated. That pairing is one of the most
  valuable triage artifacts this tool can produce, and no rule model can
  produce it.
- Also raised: S0CB (divide by zero, absent `ON SIZE ERROR`); subscript
  out of range (reported in SSRANGE style — configurable check, default
  on, because finding it is the point).

---

## 7. Control flow

- `PERFORM` out-of-line (paragraph, `THRU`, `TIMES`, `UNTIL` with
  `TEST BEFORE/AFTER`, `VARYING ... AFTER`), inline `PERFORM ... END-PERFORM`.
  Implemented with an explicit return stack, honoring the COBOL rule that
  the return point is the *range end* — so overlapping PERFORM ranges and
  **fall-through into the next paragraph** behave as the machine behaves,
  because forty-year-old code exploits both.
- `GO TO` within section/program; `GO TO DEPENDING ON`. `ALTER`: **refused**
  (trace cites the line; a member using ALTER earns a human's eyes, not an
  interpreter's guess).
- `EVALUATE` incl. `ALSO`, `TRUE/FALSE` subjects, `THRU` ranges in WHEN.
- `IF/ELSE/END-IF`, nested; `CONTINUE`, `NEXT SENTENCE` (with its real,
  surprising scope: to the next *period*, not END-IF).
- `STOP RUN` / `GOBACK` / `EXIT PROGRAM` with their distinct semantics in
  called programs.

---

## 8. Statement coverage plan

**v1 (corpus green):** MOVE, COMPUTE/ADD/SUBTRACT/MULTIPLY/DIVIDE, IF,
EVALUATE, PERFORM (all forms), GO TO (+DEPENDING), SET (88s, indexes),
INITIALIZE, INSPECT (TALLYING/REPLACING), STRING/UNSTRING, SEARCH (linear),
CALL/GOBACK/EXIT, ACCEPT (from request only), DISPLAY (→ trace), OPEN/
READ/WRITE/REWRITE/CLOSE (shimmed), EXEC SQL/CICS (shimmed, §10).

**v2 (as real members demand):** SEARCH ALL, SORT/MERGE (in-memory),
intrinsic functions (dates first — `CURRENT-DATE` from the request, never
the wall clock, for reproducibility), COMP-1/2 if actually encountered,
POINTER usage.

**Refused on principle until proven needed:** ALTER, EXHIBIT/READY TRACE
(archaeology), self-modifying tricks, unresolvable dynamic CALL targets.

Every refusal is a ledger line, and the ledger is sorted by *how often real
members hit it* — the acid test drives the roadmap, not taste.

---

## 9. Programs, CALL, and the pipeline driver

- Static and dynamic `CALL`: targets resolve against the ingested corpus
  (the registry ChatBIS already holds). Dynamic targets resolve through the
  current value of the name field at call time — the trace shows the
  resolution (`CALL WS-COMP-PGM → 'PIACOMP'`). An unresolvable target
  halts, unless the analyst marked it as a **stub** in ChatBIS with declared
  outputs (stub applications are trace-visible: `STUB EXCEPTRN: recorded
  error E6201, returned`). EXCEPTRN-style sinks are the first stubs.
- `BY REFERENCE` (aliased bytes — caller sees callee's writes, faithfully),
  `BY CONTENT` (copy), `BY VALUE` for the rare cases. LINKAGE SECTION maps
  onto caller storage; `PROCEDURE DIVISION USING` order checked against the
  CALL's operand count — mismatch halts (on the host it's how S0C4s happen).
- `CANCEL` resets a program's working storage (initial-state rules).
- **The pipeline driver replays the mined JCL**: steps in order, `COND`/`IF`
  gates evaluated against recorded step outcomes, GDG names resolved by
  base. Each step = one interpreted program run over the same case world.
  **Program storage never survives a step boundary** — each EXEC PGM is a
  fresh enclave, as on the host; only the world (datasets + the SQL
  overlay) carries state between steps. The dry run's outer loop is
  therefore *the job we already mined*, not a hand-written script.

---

## 10. Environment shims — the deliberate boundary

The founding insight: **ChatBIS already fetched the case.** The snapshot is
the database, for reads.

### SQL
- A preprocessor pass extracts `EXEC SQL` blocks (already proven in the
  miner) and replaces them with shim calls.
- `SELECT ... INTO` / cursor `DECLARE/OPEN/FETCH/CLOSE`: resolved from the
  case JSON **through the field map** — `MCS.CLAIM.BENE_DOB → claimant.
  dateOfBirth`. Repeating groups back cursors; `ORDER BY` honored on the
  group's fields; `FETCH` past the end sets `SQLCODE=+100`. A column with
  no field-map entry and no case data → **halt** with the exact mapping
  that is missing (which is also the work item).
- `INSERT/UPDATE/DELETE`: recorded as `would-write` events with the bound
  values; `SQLCODE=0`. **And applied to a run-local overlay**: within one
  dry run, later reads see the snapshot *plus* every write made so far —
  DBPUT posts the claim, NOTIFDRV's SELECT finds it. The overlay lives and
  dies with the run; the snapshot and the world outside are never touched.
  (Without this, the SQL world and the file world would disagree — files
  already carry writes forward — and the Phase 3 gate would be
  unsatisfiable.) Simulating DB2 errors (−803 duplicate key) is a v2
  option driven from case data, not a default.
- `INCLUDE SQLCA` synthesized; `WHENEVER` translated to the checks it
  generates. NULL indicators supported (case JSON `null` → −1).

### CICS
- `LINK`/`XCTL` → interpreted calls with COMMAREA as shared bytes.
- `RECEIVE MAP` → filled from `screen_input` in the request (the analyst
  types into the rendered green screen in ChatBIS — the BMS preview we
  already have becomes the *input form* for online dry runs).
- `SEND MAP` → trace event carrying the symbolic map's output fields
  (renderable as an after-screen). `RETURN TRANSID` ends the run.
  `ABEND ABCODE` → recorded abend, run stops.

### IDMS
- v1: every DML verb is a recorded event; `OBTAIN` may resolve from case
  JSON where a record↔JSON mapping exists (same field-map machinery,
  records instead of tables); otherwise halt-with-missing-mapping.
  Currency/set-walking emulation is explicitly out of scope until real
  members force the question.

### Files
- QSAM: in-memory sequential datasets keyed by DDNAME, seeded from the
  request (the JCL miner already binds DD→DSN; ChatBIS supplies contents
  where it has them, e.g. the one-transaction input). VSAM KSDS: an
  ordered map over the record key. All writes land in the trace *and* in
  the run's dataset world, so a downstream step reads what an upstream
  step wrote — the seam behavior, live.

---

## 11. The trace

Events, one JSON object each, in execution order:

```
{seq, kind, pgm, line, ...}
kinds:
  stmt        — statement executed (sampled or full, option)
  move        — field, before, after, cause (MOVE/COMPUTE/…)
  call        — target, resolution (static|dynamic|stub), depth
  branch      — condition text, outcome
  sql | cics | idms | file — shim events, incl. would-writes
  exception   — code, field, line (the MOVE-to-error-field pattern,
                recognized live, not just mined)
  abend       — S0C7 etc., with the offending bytes hex-dumped and the
                planting event's seq cross-referenced
  halt        — verb, line, ledger key
```

- Field mutation events are the spine; `stmt` events are optional volume.
  Budget: full mutation trace of a single-case pipeline run is thousands
  of events, not millions — no sampling needed at v1; caps exist anyway.
- ChatBIS renders the trace with the house UI grammar: stage-grouped like
  Scan, citations click through to `/file/N?hl=line`, the failing check's
  verdict bar on top, a field-history view ("every write to TDA-ENT-DT
  this run") — the interactive answer to *who changed the entitlement
  date*.

---

## 12. Parser & preprocessor

- Hand-written recursive descent (the house style; error messages cite
  member/line/column in listing style). Two passes: data division →
  layouts; procedure division → AST with resolved data references.
- Source formats: fixed (7–72, sequence columns ignored, continuation
  column 7 `-` for literals), free. EBCDIC or ASCII input, sniffed like
  the miner does.
- `COPY` incl. **REPLACING with pseudo-text** (`==X== BY ==Y==`), nested
  copies, cycle detection. The library is the request's copybook set — the
  same members ChatBIS ingested.
- `EXEC SQL INCLUDE` handled by the SQL pass. `REPLACE` statement: v2.
- The parser is *total* over its supported grammar and **halts** on the
  rest — parse errors are ledger lines too, so an unparseable member is a
  report, not a crash.
- Parsing is **lazy, per program**: members parse when first entered or
  CALLed. A member with an unsupported corner only halts the runs that
  actually reach it; it is reported at load either way. One archaic
  utility must not brick the whole pipeline's dry run.

---

## 13. Rust engineering

- Crates: `cobrun-syntax` (lexer/parser/AST), `cobrun-data` (layouts,
  encodings, decimal), `cobrun-exec` (interpreter, shims, trace),
  `cobrun-cli`. `#![forbid(unsafe_code)]` throughout — an interpreter over
  byte buffers is exactly where Rust's guarantees pay.
- No async, no threads in v1: one case, one run, deterministic.
- Determinism as an invariant: no wall clock (dates from the request), no
  RNG, no environment reads. Same request → byte-identical trace. This is
  what makes the accuracy meter and regression tests meaningful.
- Testing, four layers:
  1. **Encoding unit tests** — packed/zoned/binary round-trips, MOVE
     matrix cells, editing pictures, EBCDIC collation table checks.
  2. **Semantics golden tests** — small programs with hand-computed
     expected traces (the fall-through PERFORM, the mid-COMPUTE
     truncation, the S0C7 pairing).
  3. **Differential testing vs GnuCOBOL** as an oracle for the pure
     computational subset: same program, same inputs, compare outputs.
     Caveat: GnuCOBOL executes in ASCII collation by default, so the
     differential suite is restricted to collation-insensitive programs
     (numeric compute, no alphanumeric ordering) unless its EBCDIC
     collation mode is configured — otherwise the oracle itself diverges.
     Divergence = investigate; the host manual referees.
  4. **The corpus** — every t2-test member runs green end-to-end, traces
     snapshot-tested; then real members, where the ledger fills in.
- Fuzzing (`cargo-fuzz`) on the parser and the decimal engine — the two
  components that eat untrusted bytes.

---

## 14. Security & operations

- Single static binary (musl), no network capability compiled in, reads
  the request from stdin, writes trace to stdout, nothing else. Runs as a
  subprocess with a timeout ChatBIS enforces on top of cobrun's own.
- Case data discipline unchanged from ChatBIS core: the trace contains
  case values by design (that is its job) — it is **session-held like the
  Lab's case store, never written to chatbis.db**; the identifier-masking
  rules apply at render.
- Corp-network story: drop one binary next to chatbis.py. No toolchain,
  no package manager, no admin rights.

---

## 15. Phases & acceptance gates

| Phase | Delivers | Gate |
|---|---|---|
| **1. Data core** | layouts, encodings, decimal engine, MOVE/COMPUTE/IF/EVALUATE/PERFORM, trace | PIACOMP + MBACOMP run green; encoding suites pass; differential vs GnuCOBOL clean on both |
| **2. Programs** | CALL/linkage/stubs, remaining v1 verbs, S0C7/S0CB | every business function in the corpus runs; the S0C7 pairing demo works |
| **3. World** | SQL-from-snapshot, cursors, files, CICS shim, JCL driver | **the full T2NIGHT dry run**: one case in, trace out, first-failure identified; WEEDCHK's reject lands in the suspense dataset and NOTIFDRV reads the posted values |
| **4. Product** | ChatBIS trace screens, field-history view, screen-input form, accuracy meter wiring | analyst answers "if I fix the DOB, what happens?" end-to-end at a desk |
| **5. Reality** | real sanitized members; ledger-driven verb work; NUMPROC/TRUNC tuning | measured accuracy on MI-known cases published in the UI |

Phase 1 is days of focused work. Phase 5 never ends, and the ledger keeps
it honest about that.

---

## 16. Risks

| Risk | Mitigation |
|---|---|
| Dialect long tail (40 years of house style) | halt-with-ledger; acid test ranks the work; never guess |
| Silent numeric divergence (intermediate results, TRUNC) | IBM rules implemented, options explicit, differential + golden tests, size-truncation trace events |
| Shim divergence (SQL/IDMS behavior differs from host) | shims record their assumptions in the trace; accuracy meter localizes; host rerun as escalation |
| Binary-only subroutines (assembler, vendor) | stub mechanism with declared outputs, stub calls trace-visible |
| Scope creep toward "emulator" | non-goals §1; anything not visible to business logic stays out |
| Trust collapse from one wrong claim | doctrine §2; every claim cited; refusals loud |

---

## 17. Open decisions (founder input wanted)

1. **EBCDIC-internal confirmed?** Costs a conversion layer at every JSON
   boundary; buys host-true collation and byte-level trace dumps. (Design
   says yes; cheap to revisit before Phase 1 code.)
2. Default `TRUNC`/`NUMPROC` — match the shop's actual compile options
   (read them off a compile listing when available).
3. Stub library seed list — EXCEPTRN/ABENDRTN first; what else is called
   everywhere but lives in assembler?
4. Trace retention — session-only (like Lab cases) is the default; is an
   analyst "save this trace redacted" export wanted, and does the
   redaction pass the same review as Lab fixtures?
5. GnuCOBOL in CI as oracle only — acceptable to depend on it in the dev
   loop (never shipped)?
