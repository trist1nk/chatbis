# Agent Architecture — Deterministic Triage + the Lab

**Status:** Design — 1 August 2026
**Related:** `docs/resolution-loop.md` (the capture loop), `docs/dry-run-what-if.md` (the gauntlet)
**Screen introduced here:** **Lab** — where recipes get built.

---

## 0. The decision this document records

An earlier framing had a fine-tuned LLM as the engine, with tools hung off it.
Working the workflow through step by step showed the opposite is true:

> **The deterministic engine IS the product. The LLM is a bounded fallback
> for the cases the engine cannot yet handle — and every time it helps, it
> shrinks its own remaining scope.**

Walk the intended workflow and check which steps need a model:

| Step | Needs a model? |
|---|---|
| Case excepts out with code `E4417` | No — it's a key |
| Know which recipe applies | No — lookup on `playbook.exception_id` |
| Pull the case data | No — an API/SQL call |
| Analyze the data groups | No — field paths into the response |
| Match against policy → why it failed | No — `run_recipe()` is deterministic |
| Tell the analyst specifically why | No — a template, with evidence |

Zero of six. The recipe *is* the program.

## 1. Why not fine-tune (at least, not now)

1. **Fine-tuning teaches behaviour, not facts.** Format, tone, vocabulary —
   not "what does E4417 mean." Facts are the whole problem here.
2. **The knowledge changes constantly.** Every new recipe, re-ingest, or DFR
   update. Fine-tuned knowledge freezes at training time; a `playbook` edit
   costs nothing today and would cost a retrain then.
3. **The training data does not exist yet.** It only accumulates once
   analysts use the tool (see `resolution-loop.md`).
4. **It would sit off the critical path.** If the deterministic engine
   answers known codes, a fine-tune improves the *fallback* — the least
   valuable place to spend.

Revisit only against a **measured** deficiency (most likely output format or
COBOL vocabulary), with real resolution data as the training set.

## 2. Division of labour

**Code decides. The model explains or proposes — never adjudicates.**

| Concern | Owner | Why |
|---|---|---|
| Which recipe applies | code | a lookup |
| Did check *n* fire | **code** | a wrong comparison on a live case is the worst failure mode |
| Field values, dates, arithmetic | **code** | must be exact |
| Narrating a matched result | template | already precise; fluency isn't worth hallucination risk |
| Proposing a cause when NO recipe matches | model | genuinely open-ended |
| Drafting a recipe from an investigation | model | the compounding step |
| Prose symptom → likely code | model | keyword search is weak here |
| Summarising across many resolutions | model | open-ended |

Corollary: the diagnosis path stays unit-testable without a model, and a
model outage degrades the tool rather than breaking it.

## 3. The Lab — where recipes are built

Today's recipe editor is a blind form: you type field paths with no feedback
and hope they match. The **Lab** replaces it with a workbench — effectively a
REPL for recipes, where you author against a *real failing case* and watch
checks fire.

### Layout

```
┌── LAB ──────────────────────────────────────────────────────┐
│ Exception: [E4417 ▾]        Case: [POL7734120] [Pull]       │
├──────────────────────────┬──────────────────────────────────┤
│ EVIDENCE (read-only)     │ CASE DATA (live JSON)            │
│ • emitting COBOL + gate  │   { "beneficiary": {             │
│   IF WS-BENE-DOB >       │       "dob": "2027-03-15",       │
│      WS-EFF-DATE         │       "effectiveDate": …         │
│ • DFR §3.1 (quoted)      │   click a field → inserts its    │
│ • data layout: BENE-DOB  │   path into a check              │
│   PIC 9(8), 8 bytes      │                                  │
│ • past resolutions (12)  │                                  │
│ • MI: 1,240 occurrences  │                                  │
├──────────────────────────┴──────────────────────────────────┤
│ CHECKS                                    [+ Suggest (AI)]  │
│ ✅ beneficiary.dob  is after  $.beneficiary.effectiveDate    │
│    → cause: DOB keyed after policy effective date           │
│    → steps: verify DOB · correct on PS220 · resubmit        │
│    FIRES on this case ✓                                     │
│ ⚪ premium.amount  ≤  0   → cause: …        does not fire    │
├─────────────────────────────────────────────────────────────┤
│ RESULT PREVIEW — exactly what the analyst will see          │
│ [Test against another case…]              [Save recipe]     │
└─────────────────────────────────────────────────────────────┘
```

### Why this shape

- **Author against reality.** A check is written while looking at the case
  that failed, so field paths are correct by construction — the single
  biggest source of broken recipes.
- **Immediate feedback.** Each check shows FIRES / does-not-fire against the
  loaded case. Recipe authoring becomes test-driven.
- **Evidence in the same view.** The mined gate, the DFR rule, and the data
  layout are what the analyst needs to decide *what* to check; today they
  live on three different screens.
- **Regression-test recipes.** "Test against another case" catches an
  over-broad check that fires on healthy cases — the failure mode that
  quietly destroys trust.
- **AI is one optional button.** `Suggest` proposes checks from the evidence;
  the analyst edits and approves. The model never writes to the catalog.

### Data
Reuses `playbook` (`checks`, `general_steps`, `endpoint_id`). Add:
- `playbook_test_case` — saved case snapshots per recipe, for regression runs
  (store the case ref + a redacted snapshot; **never raw SSN**)
- `checks[].last_verified_at` / `last_verified_case` — provenance per check

---

## 3a. The check schema

Checks are JSON inside `playbook.checks` — schema-free by design, so new
fields and new kinds never require a migration (same posture as
`exception_link` and the MI row payloads).

```
check
  ── KIND (the versatility hinge) ───────────────────────────
  kind        compare | presence | set | pattern | period | manual
              unknown kinds are SKIPPED AND SURFACED, never fatal —
              an older build reading a newer recipe degrades, not breaks

  ── SCOPE (repeating groups only; omit for scalar checks) ──
  group       "entitlementPeriods"
  scope       latest (DEFAULT) | any | all | none | count

  ── WHERE TO LOOK ──────────────────────────────────────────
  source      "case"                  named source, see §3c
  path        "endDate"               relative to the occurrence when scoped
  cobol_field "WS-ENT-END-DT"         traceability to the mined gate + layout

  ── THE COMPARISON ─────────────────────────────────────────
  op          gt | lt | eq | ne | ge | le | blank | not_blank
              | missing | contains | in | matches
  value       literal | $.same_occurrence_field | $$.case_level_field | [list]

  ── WHAT IT MEANS ──────────────────────────────────────────
  cause       "Period end date precedes its start date"
  confidence  definitive | likely       does this PROVE it or suggest it?

  ── WHAT TO DO ─────────────────────────────────────────────
  screen      "PS220"                  per-CAUSE, not per-code
  fix_field   "ENT-END-DT"
  steps       [ ... ]

  ── PROVENANCE ─────────────────────────────────────────────
  derived_from  "POLVAL01:19" | "DFR §3.1" | "analyst"
  verified_case / verified_at
  when        optional ONE-LEVEL guard, e.g. plan.type = "T"
```

**Scalar checks omit `group`/`scope` entirely** and behave exactly as the
shipped evaluator already does — repeating-group support is purely additive.

### `period` — a first-class kind, because the data demands it

Case data carries repeating groups with **start / end / resumption** dates,
and period-logic failures look like a large share of real exceptions. That
earns a purpose-built kind rather than a generic expression language: each
rule is a small, testable function, and the analyst picks *"overlap"* instead
of constructing boolean logic.

```
kind:   period
group:  "entitlementPeriods"
start:  "startDate"   end: "endDate"   resume: "resumptionDate"
rule:   end_before_start | overlap | gap | missing_end
      | resume_before_end | multiple_open
```
*(rule list is provisional — confirm against real exception patterns)*

### ⚠️ "latest" is ambiguous — define it per group

**Usually the latest occurrence is the one that matters**, so `scope: latest`
is the default. But "latest" has four defensible meanings that disagree
exactly in the messy cases which generate exceptions (resumed periods,
overlaps, future-dated entitlements):

| Reading | Risk |
|---|---|
| last array element | fragile — depends on API response ordering, can change silently |
| highest `start` date | usually intended |
| the open period (no end) | "current", but there may be none, or several |
| the period covering today | "in effect", different again from most-recently-started |

If the tool picks a different row than the analyst assumes, it reports the
wrong values **with full confidence**. So configure it explicitly, once per
group, and **echo the choice in the result** —
*"latest = period starting 2023-01-01"* — which kills the whole class of
silent mis-diagnosis with one line of output.

```
group      entitlementPeriods
order_by   startDate
latest_is  max_start | open_period | covers_today
```

### The layout constrains the editor

`data_item` already mines `OCCURS` from the COBOL. The Lab uses it to:
- detect repeating groups automatically and offer the right check shape
- **warn on a scalar check against a repeating group** — *"entitlementPeriods
  repeats; did you mean latest/any?"* — preventing the most likely category
  of broken recipe
- pre-fill period fields by matching layout names (`*-STRT-DT`, `*-END-DT`)
  against the case JSON

## 3b. Instrumentation — how results tune the design

Log every check evaluation, not just final outcomes, as
`exception_event kind='check_eval'` (no schema change):

| Signal | Tells you |
|---|---|
| fire rate per check | a check that never fires in 200 cases is noise, wrong, or dead |
| precision per check | when it fired, did the analyst confirm that cause? |
| no-match rate per code | the recipe-gap metric — where Lab time should go |
| multi-fire frequency | settles "show all vs first" with data, not opinion |
| **errored paths** | fields analysts *expected* to exist → the COBOL↔JSON mapping backlog |
| operator/kind usage | what to build next, what to retire |
| manual-step outcomes | which manual steps are ripe for automation |
| time-to-resolution pre/post recipe | the number that justifies the tool |

Instrumentation must ship **with** the first evaluation — it cannot be
backfilled.

## 3c. Sources and the lookup key

The analyst arrives knowing the exception code and identifies the case by
**SSN + BIC** (the compound claim key — neither identifies a beneficiary
alone). That pair returns the right case.

**Two stages: pull once, evaluate many.** The case is fetched once and held
in session; the code selector stays live so several codes can be evaluated
against the same data with no second API call.

```
SSN [ •••••6789 ]   BIC [ A ▾ ]   [Look up]        ← BIC is a dropdown:
        ↓ held in session, never written to disk      small enumerated set,
   [ E4417 ▾ ]  [Evaluate]                            a typo returns the
        ↓                                             wrong beneficiary
   cause · evidence · steps
```

Recipes declare **named sources** (`case`, `suspense`, …) from day one — one
source is populated now, more is a config change rather than a refactor.

### 🔒 PII posture — a design constraint, not hygiene

SSN + BIC is directly identifying beneficiary data. Therefore:

- **`chatbis.db` NEVER writes case data.** Catalog, recipes, mined COBOL and
  DFRs only. Live case data lives in memory for the session and is gone.
  This keeps the tool **out of scope for a data-protection review** — a much
  shorter conversation when asking to point it at production-adjacent
  systems — and the DB is unencrypted SQLite on a laptop, fine for a catalog
  and not fine for claim data.
- **Mask on entry**; the full SSN exists only in the outbound request.
- **Lab test snapshots are redacted** — store the case *shape*, identifiers
  stripped. The purpose is regression-testing check logic, not preserving a
  real person's record.
- **Log the lookup, not the subject** — who, which code, when, outcome.
- **Deliberately DO NOT build "recent lookups."** It is the obvious
  convenience feature and here it means a list of SSNs in a file.

## 4. Tool surface

Build these as **plain internal functions first**. Their first consumer is
the UI (Lab + triage), not a model; wrapping them for tool-calling later is
mechanical.

```
get_exception(code)            → meaning, screen, field, category, status
get_recipe(code)               → checks, general_steps, endpoint
pull_case(endpoint_id, params) → live case JSON      [PII masked in logs]
run_diagnostics(code, case)    → verdict + evidence  ← deterministic core
get_business_rules(program)    → mined gates w/ nested context, file:line
get_dfr_sections(code)         → governing requirement text + §
get_layout(program|copybook)   → data groups: name, PIC, type, bytes, occurs
get_history(code)              → past resolutions, causes, MI volume by period
```

**Every tool returns citations natively** — `file:line`, `DFR §3.1`,
`resolution #482`. If evidence rides with the data, the model cites by
default rather than by instruction, and the UI gets click-through for free.

## 5. End-to-end workflow

```
exception fires (code + case ref)
        │
        ├── recipe exists? ─── YES ──▶ pull case → run_diagnostics()
        │                              → template renders cause + evidence
        │                                + steps.  NO MODEL INVOLVED.
        │
        └── NO ──▶ "Investigate" (the model's only entry point)
                     reads: mined gates, DFR, layout, similar codes, case
                     produces: ranked candidate causes, each CITED
                     analyst confirms → opens in the Lab, prefilled
                     → analyst saves the recipe
                     → next occurrence takes the deterministic path forever
```

That last arrow is the whole strategy: **the fallback path feeds the fast
path.** Model usage decays as coverage grows.

## 6. What exists vs what is new

| Piece | State |
|---|---|
| `run_recipe()` deterministic evaluator | ✅ built, 5 tests |
| `playbook` (checks, steps, endpoint) | ✅ built |
| Case pull — REST + SQL rails | ✅ built |
| Mined gates w/ nested context | ✅ built, stress-tested |
| DFR sections + `governed_by` links | ✅ built |
| Data layouts (PIC → type/bytes) | ✅ built |
| MI volumes + history | ✅ built |
| Triage result rendering | ✅ built |
| **Lab screen** | ⬜ new |
| **Tool wrappers** | ⬜ new (thin) |
| **Investigate (model) path** | ⬜ new |
| **Gauntlet / next-failure prediction** | ⬜ new — see `dry-run-what-if.md` |

Most of the substrate is done. The new work is a screen, thin wrappers, and
one bounded model call.

## 7. The feature worth building next after the Lab

The rule extractor already knows the **ordered gauntlet** per program. With
case data, triage stops at "why it failed" and becomes:

> ✅ Fixing `BENE-DOB` clears E4417 — but this case will then hit **E4102**
> (premium field is blank).

Analysts resubmit and wait a full cycle to discover the second failure.
Removing that round trip is the thing they would evangelise. Two small
components away: the condition evaluator (largely present in `run_recipe`'s
comparison logic) and PIC-layout record decoding (layouts already mined).

## 8. Constraints and risks

1. **Case data contains SSNs.** The deterministic path keeps case data
   inside the network entirely — a real compliance advantage. Only the
   Investigate path would send anything to a model: **strip identifiers
   first**, and require an in-network model or a written zero-retention
   endpoint. Decide this before building around any provider.
2. **Mining accuracy is unvalidated on real source.** The model inherits
   that ceiling; grounded in 60%-accurate rules it produces fluent, cited,
   wrong answers — the worst failure mode. The in-network validation day
   still gates the Investigate path (the Lab and deterministic triage do not
   depend on it).
3. **Over-broad checks.** A check that fires on healthy cases is worse than
   no recipe. Mitigated by Lab regression-testing against known-good cases.
4. **Model contradicting the engine.** If both run, `run_diagnostics()`
   always wins and the discrepancy is logged as a defect signal.

## 9. Build order

1. **Lab screen** against the existing deterministic engine — no model.
   Immediately makes recipe authoring viable, which is the real bottleneck.
   Ships with the five base kinds + `period`, `latest`-by-default scoping,
   and `check_eval` instrumentation from the first run.
2. **Simplified Evaluate screen** — SSN + BIC → pull once → pick code →
   evaluate. Environments/endpoints/SQL move to Settings and Research;
   the fast path becomes two inputs and an answer.
3. **Tool wrappers** as internal functions with citations; refactor triage
   and Lab to consume them.
4. **Gauntlet / next-failure prediction** — highest analyst-visible value.
5. **Investigate path** (model, bounded, cited, no-recipe only) — after the
   real-source validation day.
6. **Fine-tune** — only against a measured deficiency, only with real
   resolution data. Probably never.

## 10. Open questions for the founder

Answering these sharpens the shipped rule set; none block starting.

1. **Real period rules.** The six `period` rules are inferred from the data
   shape. Which actually cause exceptions? Must periods be contiguous, or
   are gaps legitimate? Can more than one be open at once?
2. **Resumption semantics.** Is `resumptionDate` on the *same* occurrence as
   the suspension it resumes, or does it point at a different period?
3. **Cross-group rules** — must a period fall inside an entitlement window
   held elsewhere on the case? Decides whether `period` checks need
   case-level context or stay self-contained.
4. **Typical occurrence count** — a handful or hundreds? Affects the history
   presentation beneath the latest occurrence.
5. **BIC values** — seed the dropdown with the standard set, or populate
   from your system's valid list?
