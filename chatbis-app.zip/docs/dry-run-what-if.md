# Dry-Run / What-If Engine — Design Note

**Status:** Concept — brainstorm captured 30 July 2026
**Depends on:** exception catalog, condition mining, copybook parsing (all in the prototype)
**Candidate phase:** 5 (after mining is validated against real source)

---

## 1. The question this answers

An analyst is looking at a failed case. The exception says the start date
can't be prior to 2016. Before resubmitting, they want to know:

> *If I fix this field, does the case pass — or does it just trip the NEXT
> exception?*

Today the only way to find out is to resubmit and wait for the next cycle.
Every hidden second exception costs a full round trip. Seeing the next
landmine *before* resubmitting saves hours per case, not minutes.

## 2. The key insight: replay the checks, not the program

**No compiler is needed for the valuable 80%.** A validation program is
mostly a gauntlet — an ordered series of gates:

```
IF <condition>  →  MOVE '<code>' TO <err-field>  →  reject
```

We already mine each gate (the walk-back heuristic). The dry run doesn't
execute COBOL; it **re-evaluates the mined gate conditions against the
case's data**, in program order, and reports which gate would fire next.

COBOL gate conditions are a tiny expression language — comparisons, AND /
OR / NOT, 88-level condition names, `NUMERIC` class tests, literal
compares like `WS-START-DATE < 20160101`. An interpreter for *that
grammar* is a small, testable component. A compiler is a project; this is
a component.

## 3. Architecture

```
┌─────────────────────────────────────────────────────────┐
│ What-if screen                                          │
│  case fields (typed, or decoded from a suspense record) │
│  analyst edits the fix → [Dry run]                      │
└──────────────────────────┬──────────────────────────────┘
                           ▼
   1. GAUNTLET EXTRACTION   ordered (condition → code) pairs per program,
                            approximated from paragraph order + the
                            PERFORM chain from the main paragraph
   2. CONDITION EVALUATOR   interprets the COBOL condition grammar against
                            supplied field values; anything it can't
                            evaluate returns UNKNOWN with a reason
   3. RECORD DECODER        copybook PIC clauses → field offsets/types, so
                            a raw suspense-file record decodes into named
                            fields (we already parse copybooks)
                           ▼
┌─────────────────────────────────────────────────────────┐
│ Verdict: ✅ pass · ❌ would fire (code, line, source)    │
│          ❓ unevaluable (reason, source link)            │
└─────────────────────────────────────────────────────────┘
```

### Example output

> 14 checks mined for POLVAL01. With your change (`WS-START-DATE →
> 2017-03-01`):
> - ✅ E4417 gate passes (was the failing check)
> - ✅ 10 further checks pass
> - ❌ **would now trip E4102** — premium not numeric; this case's premium
>   field is blank *(line 24 → source)*
> - ❓ 3 checks unevaluable — depend on values computed mid-program
>   *(listed, each with a source link)*

## 4. The honesty contract

Same philosophy as the walk-back heuristic, extended:

- Every verdict row cites the emitting line; one click to source.
- UNKNOWN is a first-class answer with a stated reason (computed
  intermediate, cross-module value, dynamic code, unparsed condition).
- The engine must detect the program's failure style — stop-at-first-error
  vs collect-all-errors — and say which assumption the verdict uses. If
  undetectable, present all potentially-firing gates rather than guessing.
- A dry run is a **prediction, never a promise.** The UI says so.

## 5. Self-grading — the part that compounds

Every dry-run prediction ("would pass") followed by an actual resubmission
outcome (the resolution event: reprocessed → passed / failed) is a labeled
data point in `exception_event`. That yields, with zero extra analyst
effort:

> "Dry-run accuracy: 96% on E4417 · 60% on E9001 (computed values
> involved)."

Analysts learn exactly when to trust it; we learn exactly which checks
need better extraction. No other approach gets self-measuring honesty this
cheaply — and it falls straight out of the event log we already capture.

## 6. Fidelity ladder

| Level | Approach | Fidelity | Cost | When |
|---|---|---|---|---|
| L0 | **Rule replay** (this note) | Partial, honestly flagged | Small: evaluator + gauntlet order + PIC layout decode | Build first |
| L1 | **GnuCOBOL on a slice** — if validation lives in clean callable modules (no CICS/DB2 inside), compile just those off-platform with stubbed I/O and execute the real logic | High for covered modules | Per-module porting; only viable if validation is isolated | Ask in Phase 0: *is validation isolated in callable modules?* |
| L2 | **Resubmit to test region** — package case + proposed fix into the shop's existing test-LPAR reprocess path and read back the result | Total (it *is* the real system) | Mainframe-side integration, security review | The existing gold standard; integrate, don't rebuild |

L0 is not a lesser L2 — it is instant and interactive (edit a field, see
the gauntlet re-light), which the test region can never be.

## 7. What we will NOT build

- A COBOL compiler or full interpreter.
- General data-flow analysis (UNKNOWN is the honest substitute).
- Anything that writes to the mainframe. L2, if pursued, drives an
  existing resubmission path; the tool never becomes the system of record.

## 8. Questions to answer before building

1. Stop-at-first-error or collect-all? (Per program; detectable in code,
   confirm with analysts.)
2. Are record layouts for the suspense file available as copybooks?
   (Enables decode-the-real-record instead of typing fields.)
3. Is validation isolated in callable modules? (Unlocks L1.)
4. Does a test-region reprocess path exist today, and who owns it? (L2.)
5. What share of gate conditions on real source are simple field
   comparisons? (Sets the honest ceiling for L0 — measure it by running
   the miner over the real corpus and classifying the conditions.)

Question 5 is the go/no-go: the miner can answer it mechanically the day
it meets real source, before any evaluator is written.

## 9. Rough shape of the build (L0)

| Piece | Size | Notes |
|---|---|---|
| Condition-expression evaluator | days | Small grammar; property-test against hand-built cases |
| Gauntlet ordering | days | Paragraph order + PERFORM chain; reuse existing mining |
| PIC layout decode | days | Extends the copybook parser; packed/COMP handling is the fiddly part |
| What-if screen + verdict UI | days | Form pre-filled from a decoded record when available |
| Accuracy grading | free | A query over events already captured |

Prerequisite: mining validated on real source (the same gate as everything
else in the roadmap).
