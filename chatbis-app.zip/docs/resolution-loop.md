# The Closed Resolution Loop — Design Note

**Status:** Concept — captured 30 July 2026
**Supersedes the assumption** that analysts will voluntarily log resolutions.
**Depends on:** dry-run engine (docs/dry-run-what-if.md), Case Lookup rail,
catalog + rules + DFR grounding, the append-only event log.

---

## 1. The insight

The spec's biggest named risk was *"analysts don't log resolutions — the
compounding asset never forms."* The fix is not a better form. It is making
the resolution **happen through the tool**, so the record is exhaust from the
workflow rather than a favor to it. Capture by workflow, not by diligence.

## 2. The loop

| Stage | What happens | Recorded automatically |
|---|---|---|
| DETECTED | Exception fires — MI queue, or analyst arrives with a case | code, case ref, when |
| PULLED | Live case data fetched via a **set query**: curated, parameterized SQL/endpoint against the case store (the Case Lookup template pattern) | which query, masked params, data snapshot hash |
| PROPOSED | LLM drafts the fix: cause + specific field changes, grounded in the catalog entry, mined gate rules, governing DFR section, and past resolutions of this code. **Every claim cites its source; uncited claims are dropped.** | proposal, citations, model, prompt hash |
| APPROVED-1 | Analyst reviews, edits, approves the proposal | analyst, edits, decision |
| DRY-RUN | Gauntlet replay with proposed values → pass, or "would trip Ennnn next" (L0 rule replay) | per-gate verdicts, prediction |
| APPROVED-2 | Analyst approves the **apply** — a second, independent human gate | analyst, decision |
| APPLIED | Update goes through the write API — never hand-typed into green screens | request (masked), response, status |
| VERIFIED | Reprocess / next cycle confirms the case cleared | actual outcome vs dry-run prediction |

Cause, action, outcome, timing, and prediction accuracy all land in
`exception_event` without a single form field. The 20-second resolution modal
remains only as the manual fallback.

## 3. The trust ladder (staged rollout)

Write-back is a **scope change** — the original spec excluded writing to the
mainframe, and the moment the tool can mutate production cases it becomes an
operational system with an operational-system security review. Earn it in
stages, each stage generating the evidence the next one needs:

1. **L1 — Read-only live pull.** Set queries against the case store. Zero
   write risk; already 80% of the analyst's grunt work.
2. **L2 — Proposals + dry-run, manual apply.** The tool proposes and
   predicts; the analyst applies in the existing system of record, then
   one-clicks "applied / cleared / failed" — capture still ~automatic.
3. **L3 — Tool-driven apply.** Only after the dry-run engine has a measured
   accuracy record (self-grading: prediction vs verified outcome). *"96%
   correct over 400 cases"* is what a change-review board can approve.
   Two-gate approval, full audit, per-application enablement, kill switch.

## 4. LLM boundary conditions (per spec §6.5/§7, unchanged)

- In-network model or zero-retention enterprise API only; show what will be
  sent before the first call; per-application disable; all prompts/responses
  logged.
- Proposals are **ranked candidates, never answers**; mandatory citations to
  file+line, DFR section, or a specific past resolution; nothing enters the
  catalog or touches a case without explicit human acceptance.
- Grounding quality ceiling = mining quality. The in-network real-source
  validation day precedes any LLM work, because a model grounded in 60%-true
  mining produces confidently wrong proposals — the one failure mode worse
  than no tool.

## 5. What already exists for this

| Loop stage | Substrate already built |
|---|---|
| PULLED | Case Lookup environments/endpoint templates, JWT proxy, masking |
| PROPOSED (grounding) | catalog, mined rules w/ context, DFR sections + governed_by links, MI volumes, resolution events |
| DRY-RUN | gate mining + PIC layouts (evaluator still to build — the one missing engine) |
| APPLIED | endpoint-template rail extends to POST/PUT write endpoints |
| VERIFIED / audit | append-only exception_event; stats computed, never stored |

## 6. Build order implied

1. In-network real-source validation (mining quality numbers).
2. Dry-run L0 evaluator (docs/dry-run-what-if.md) + set-query support in
   Case Lookup (saved parameterized queries per environment).
3. L2 workflow: proposal screen (initially WITHOUT the LLM — template from
   catalog + top-ranked past resolution is already useful), one-click
   applied/cleared capture.
4. LLM proposal drafting behind the citation guardrails.
5. L3 write-back, last, with the accuracy record as the entry ticket.
