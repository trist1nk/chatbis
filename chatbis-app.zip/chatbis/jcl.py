"""ChatBIS — JCL miner.

A JCL member is the pipeline written down and executable: step order is
stage order, EXEC PGM= names the program each stage runs, and a dataset
that one step writes and a later step reads is the seam between them.
Mining it means the pipeline is DISCOVERED, not hand-entered — and the
hand-entered configuration can be reconciled against what actually runs.

Pattern-based like the COBOL miner: statements are assembled from the
official continuation rule (a statement whose operand field ends with a
comma continues on the next // line), then matched. No full JCL grammar —
symbolic parameters pass through untouched, and anything unparsed is
simply not claimed.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

RE_DSN = re.compile(r"\bDSN(?:AME)?=([A-Z0-9$#@.&()+-]+)", re.I)
RE_DISP = re.compile(r"\bDISP=\(?([A-Z]+)", re.I)
RE_PGM = re.compile(r"\bPGM=([A-Z0-9$#@]+)", re.I)
RE_PROC = re.compile(r"\bPROC=([A-Z0-9$#@]+)", re.I)
RE_COND = re.compile(r"\bCOND=(\([^)]*\)|[A-Z0-9,]+)", re.I)


@dataclass
class JclDD:
    dd: str                  # DDNAME ('' for a concatenation continuation)
    dsn: str | None
    disp: str | None         # NEW | OLD | SHR | MOD | None
    lineno: int


@dataclass
class JclStep:
    name: str
    pgm: str | None          # EXEC PGM=...
    proc: str | None         # EXEC PROC=... or bare EXEC name
    cond: str | None         # COND=(...) verbatim
    gate: str | None         # enclosing IF condition, verbatim
    lineno: int
    dds: list[JclDD] = field(default_factory=list)


@dataclass
class JclJob:
    name: str | None = None
    steps: list[JclStep] = field(default_factory=list)


def looks_like_jcl(text: str) -> bool:
    for line in text.split("\n"):
        if line.strip():
            return line.startswith("//")
    return False


def _statements(lines: list[str]) -> list[tuple[int, str]]:
    """(lineno, joined statement text after //) — continuation-aware,
    comments (//*) dropped, JES2 control (/*) ignored."""
    out: list[tuple[int, str]] = []
    i = 0
    while i < len(lines):
        raw = lines[i]
        i += 1
        if not raw.startswith("//") or raw.startswith("//*"):
            continue
        body = raw[2:72].rstrip()          # cols 73-80 are sequence numbers
        lineno = i
        while body.rstrip().endswith(",") and i < len(lines):
            nxt = lines[i]
            if not nxt.startswith("//") or nxt.startswith("//*"):
                break
            i += 1
            body += " " + nxt[2:72].strip()
        out.append((lineno, body))
    return out


def parse_jcl(text: str) -> JclJob:
    job = JclJob()
    gate: str | None = None
    step: JclStep | None = None

    OPS = {"JOB", "EXEC", "DD", "IF", "ELSE", "ENDIF", "PROC", "PEND",
           "SET", "INCLUDE", "JCLLIB", "OUTPUT"}
    for lineno, body in _statements(text.split("\n")):
        parts = body.strip().split(None, 1)
        if not parts:
            continue
        # The name field is optional: "// IF (...)" has none, "//STEP010
        # EXEC" does. An operation keyword in first position means no name.
        if parts[0].upper() in OPS:
            name, op = "", parts[0].upper()
            rest = parts[1] if len(parts) > 1 else ""
        else:
            name = parts[0]
            sub = (parts[1] if len(parts) > 1 else "").split(None, 1)
            if not sub:
                continue
            op = sub[0].upper()
            rest = sub[1] if len(sub) > 1 else ""

        if op == "JOB":
            job.name = name or None
        elif op == "IF":
            gate = re.sub(r"\s*THEN\s*$", "", rest, flags=re.I).strip() or rest
        elif op in ("ENDIF", "ELSE"):
            gate = None if op == "ENDIF" else gate
        elif op == "EXEC":
            pgm = RE_PGM.search(rest)
            proc = RE_PROC.search(rest)
            bare = None
            if not pgm and not proc:
                first = rest.split(",")[0].strip()
                if re.fullmatch(r"[A-Z0-9$#@]+", first, re.I):
                    bare = first.upper()      # EXEC MYPROC — cataloged proc
            cond = RE_COND.search(rest)
            step = JclStep(
                name=name or f"STEP{len(job.steps) + 1:03d}",
                pgm=pgm.group(1).upper() if pgm else None,
                proc=(proc.group(1).upper() if proc else bare),
                cond=cond.group(1) if cond else None,
                gate=gate, lineno=lineno)
            job.steps.append(step)
        elif op == "DD" and step is not None:
            dsn = RE_DSN.search(rest)
            disp = RE_DISP.search(rest)
            step.dds.append(JclDD(
                dd=name, dsn=dsn.group(1).upper() if dsn else None,
                disp=disp.group(1).upper() if disp else None, lineno=lineno))
    return job


RE_GDG = re.compile(r"\([+-]?\d+\)$")


def gdg_base(dsn: str) -> tuple[str, bool]:
    """'PROD.T2.AUDIT(+1)' -> ('PROD.T2.AUDIT', True). Generations of one
    GDG are the same dataset for seam purposes — a step writing (+1) hands
    off to a step reading it, and across jobs (0) is the same file."""
    return RE_GDG.sub("", dsn), bool(RE_GDG.search(dsn))


def dataset_seams(job: JclJob) -> list[dict]:
    """Datasets shared between steps: {dsn, writer, reader, ...}. DISP=NEW/MOD
    marks the creating step as the writer; a later SHR/OLD reference reads it.
    Direction beyond that heuristic needs the program's OPEN mode, so it is
    not claimed."""
    seen: dict[str, tuple[str, str | None]] = {}   # base -> (first step, disp)
    seams: list[dict] = []
    for st in job.steps:
        for dd in st.dds:
            if not dd.dsn or dd.dsn.startswith("&"):
                continue
            base, is_gdg = gdg_base(dd.dsn)
            if base in seen:
                first_step, first_disp = seen[base]
                if first_step != st.name:
                    seams.append({
                        "dsn": base, "from_step": first_step,
                        "to_step": st.name, "gdg": is_gdg,
                        "directed": first_disp in ("NEW", "MOD")})
            else:
                seen[base] = (st.name, dd.disp)
    return seams
