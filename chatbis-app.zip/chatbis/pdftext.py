"""PDF text extraction, stdlib only — the doctrine's terms apply: extract
what is deterministically extractable, refuse the rest by name.

What this handles: text-layer PDFs — the kind produced by "print to PDF",
Word/browser exports, and policy-site renders. Content streams are
FlateDecode-compressed (zlib is stdlib) or plain; text arrives through the
Tj / TJ / ' operators as literal or hex strings.

What this refuses, and says so: scanned PDFs (images, no text layer) and
CID-keyed fonts whose bytes are code points into an embedded font (the
extracted bytes would be gibberish; shipping gibberish as policy text is
worse than an honest error)."""

from __future__ import annotations

import re
import zlib

# stream dict + body: dict is everything from << to the matching stream kw
RE_STREAM = re.compile(rb"<<(.*?)>>\s*stream\r?\n(.*?)endstream", re.S)
RE_TEXT_BLOCK = re.compile(rb"BT(.*?)ET", re.S)
# operators that place text: (lit) Tj | (lit) ' | [ ... ] TJ | <hex> Tj
RE_SHOW = re.compile(
    rb"(\((?:[^()\\]|\\.)*\)|<[0-9A-Fa-f\s]+>)\s*(Tj|')"
    rb"|\[((?:[^\[\]\\]|\\.)*)\]\s*TJ", re.S)
RE_ARRAY_STR = re.compile(rb"\((?:[^()\\]|\\.)*\)|<[0-9A-Fa-f\s]+>")
RE_NEWLINE_OP = re.compile(rb"\bT\*|-?\d+(?:\.\d+)?\s+-?\d+(?:\.\d+)?\s+Td\b"
                           rb"|-?\d+(?:\.\d+)?\s+-?\d+(?:\.\d+)?\s+TD\b")

_ESCAPES = {b"n": b"\n", b"r": b"\r", b"t": b"\t", b"b": b"\b",
            b"f": b"\f", b"(": b"(", b")": b")", b"\\": b"\\"}


def _decode_literal(raw: bytes) -> bytes:
    """(string) with \\-escapes and \\ddd octal, parens stripped."""
    body = raw[1:-1]
    out = bytearray()
    i = 0
    while i < len(body):
        c = body[i:i + 1]
        if c == b"\\" and i + 1 < len(body):
            nxt = body[i + 1:i + 2]
            if nxt.isdigit():
                oct_ = body[i + 1:i + 4]
                j = 1
                while j < 3 and i + 1 + j < len(body) \
                        and body[i + 1 + j:i + 2 + j].isdigit():
                    j += 1
                out.append(int(body[i + 1:i + 1 + j], 8) & 0xFF)
                i += 1 + j
                continue
            out += _ESCAPES.get(nxt, nxt)
            i += 2
            continue
        out += c
        i += 1
    return bytes(out)


def _decode_hex(raw: bytes) -> bytes:
    h = re.sub(rb"\s", b"", raw[1:-1])
    if len(h) % 2:
        h += b"0"
    return bytes.fromhex(h.decode("ascii"))


def _string_bytes(tok: bytes) -> bytes:
    return _decode_literal(tok) if tok.startswith(b"(") else _decode_hex(tok)


def _stream_text(content: bytes) -> str:
    """Text-showing strings from one content stream, in order, with
    newlines where the text cursor moved."""
    pieces: list[str] = []
    for block in RE_TEXT_BLOCK.findall(content):
        # walk operators in order: shows and line-moves interleaved
        events: list[tuple[int, str]] = []
        for m in RE_SHOW.finditer(block):
            if m.group(1) is not None:
                events.append((m.start(), _string_bytes(m.group(1))
                               .decode("latin-1")))
            else:
                parts = [_string_bytes(t).decode("latin-1")
                         for t in RE_ARRAY_STR.findall(m.group(3))]
                events.append((m.start(), "".join(parts)))
        for m in RE_NEWLINE_OP.finditer(block):
            events.append((m.start(), "\n"))
        events.sort()
        pieces.append("".join(t for _, t in events))
    return "\n".join(pieces)


def extract_pdf_text(data: bytes) -> str:
    """The PDF's text layer. Raises ValueError with a NAMED reason when
    there is nothing honestly extractable."""
    if not data.startswith(b"%PDF"):
        raise ValueError("not a PDF (missing %PDF header)")
    chunks: list[str] = []
    for m in RE_STREAM.finditer(data):
        sdict, body = m.group(1), m.group(2)
        if b"FlateDecode" in sdict:
            try:
                body = zlib.decompress(body.strip(b"\r\n"))
            except zlib.error:
                try:
                    body = zlib.decompress(body)
                except zlib.error:
                    continue        # image or damaged stream — not text
        elif b"DCTDecode" in sdict or b"JPXDecode" in sdict:
            continue                # embedded image
        if b"BT" not in body:
            continue                # a stream with no text operators
        chunks.append(_stream_text(body))
    text = "\n".join(c for c in chunks if c.strip())
    # Honesty gate: CID-keyed fonts yield byte soup. If what came out is
    # not mostly printable prose, refuse rather than catalog gibberish.
    if not text.strip():
        raise ValueError(
            "no text layer — this PDF is a scan or image-only; OCR it or "
            "export the source as text/Word and re-upload")
    printable = sum(1 for ch in text if ch.isprintable() or ch in "\n\t ")
    if printable / len(text) < 0.85:
        raise ValueError(
            "text layer is CID/font-encoded and not recoverable without "
            "the font's map — export the source as text/Word and re-upload")
    # collapse the artifacts of per-glyph positioning
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r" ?\n ?", "\n", text)
    return text.strip()
