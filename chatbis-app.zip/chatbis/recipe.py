"""ChatBIS — triage recipes: automated diagnosis of a live case.

A recipe belongs to an exception code: which Case Lookup endpoint pulls the
case, and an ordered list of diagnostic checks evaluated against the fetched
JSON. Each check maps to a cause and its resolution steps, so the output is
"THIS case fails because X — do Y", with the evidence shown.

Read-only by design: no approval workflow, no mutation. The recipe answers;
the analyst acts in the system of record.

All pure functions — the diagnosis logic is testable without a server.
"""
from __future__ import annotations

_MISSING = object()

OPS = {
    "eq": "is", "ne": "is not", "gt": "is greater than / after",
    "lt": "is less than / before", "ge": "is at least", "le": "is at most",
    "blank": "is blank", "not_blank": "is not blank",
    "missing": "is missing", "contains": "contains",
}
_UNARY = {"blank", "not_blank", "missing"}


def get_path(data, path: str):
    """Dot-path into parsed JSON: 'beneficiary.dob', 'history.0.code'.
    Case-insensitive key fallback (Java APIs camelCase freely)."""
    cur = data
    for part in (path or "").split("."):
        if not part:
            continue
        if isinstance(cur, list):
            try:
                cur = cur[int(part)]
                continue
            except (ValueError, IndexError):
                return _MISSING
        if not isinstance(cur, dict):
            return _MISSING
        if part in cur:
            cur = cur[part]
            continue
        lowered = {k.lower(): k for k in cur}
        if part.lower() in lowered:
            cur = cur[lowered[part.lower()]]
            continue
        return _MISSING
    return cur


def _compare(actual, op: str, expected) -> bool:
    if op == "missing":
        return actual is _MISSING
    if actual is _MISSING:
        return False
    s = str(actual).strip()
    if op == "blank":
        return s == ""
    if op == "not_blank":
        return s != ""
    if op == "contains":
        return str(expected).lower() in s.lower()
    # ORDERING ops treat blank as NOT SET, never as "smaller than everything".
    # Found via the synthetic sandbox: an OPEN period (endDate = "") made
    # `endDate < startDate` fire on every healthy claim, because "" sorts
    # before any date. Use blank/not_blank/missing to test for absence.
    if op in ("gt", "lt", "ge", "le") and (s == "" or str(expected).strip() == ""):
        return False
    try:
        a, b = float(s), float(str(expected).strip())
    except (TypeError, ValueError):
        a, b = s.lower(), str(expected).strip().lower()
    return {"eq": a == b, "ne": a != b, "gt": a > b,
            "lt": a < b, "ge": a >= b, "le": a <= b}[op]


# ── repeating groups ────────────────────────────────────────────────────────
# Case data carries groups that repeat (COBOL OCCURS): entitlement periods
# with start / end / resumption dates. "Usually the latest occurrence matters
# most", so `latest` is the DEFAULT scope — but see pick_latest(): "latest"
# is ambiguous, and picking the wrong row yields a confident WRONG diagnosis.
SCOPES = ("latest", "any", "all", "none", "count")


def occurrences(data, group: str) -> list:
    """The rows of a repeating group. A non-list value is treated as a single
    occurrence so a group that happens to hold one row still evaluates."""
    if not group:
        return []
    val = get_path(data, group)
    if val is _MISSING or val is None:
        return []
    return val if isinstance(val, list) else [val]


def pick_latest(rows: list, order_by: str = "", latest_is: str = "max_start",
                today: str = "") -> tuple:
    """(index, row) of the 'latest' occurrence, or (None, None).

    ⚠️ Deliberately explicit: last-array-element / max-start / open-period /
    covers-today disagree exactly in the messy cases that generate exceptions
    (resumed periods, overlaps, future-dated entitlements). The caller's
    choice is echoed back to the analyst so a wrong pick is visible, not
    silent.
    """
    if not rows:
        return (None, None)
    if latest_is == "array_order" or not order_by:
        return (len(rows) - 1, rows[-1])
    if latest_is == "open_period":
        for i, r in enumerate(rows):          # first row with no end date
            end = get_path(r, order_by)
            if end is _MISSING or not str(end or "").strip():
                return (i, r)
        # fall through to max_start when every period is closed
    if latest_is == "covers_today" and today:
        for i, r in enumerate(rows):
            start = str(get_path(r, order_by) or "")
            if start and start <= today:
                return (i, r)
    best_i, best_key = None, None
    for i, r in enumerate(rows):
        key = get_path(r, order_by)
        if key is _MISSING or key is None:
            continue
        k = str(key)
        if best_key is None or k > best_key:
            best_i, best_key = i, k
    return (best_i, rows[best_i]) if best_i is not None else (len(rows) - 1, rows[-1])


def _resolve_value(raw: str, row, data):
    """`$.x` = this occurrence, `$$.x` = case level, anything else a literal.
    Returns (value, label, is_ref)."""
    raw = (raw or "").strip()
    if raw.startswith("$$."):
        v = get_path(data, raw[3:])
        return v, f"{raw[3:]} = " + ("«missing»" if v is _MISSING else str(v)), True
    if raw.startswith("$."):
        base = row if row is not None else data
        v = get_path(base, raw[2:])
        return v, f"{raw[2:]} = " + ("«missing»" if v is _MISSING else str(v)), True
    return raw, raw, False


def _eval_one(c: dict, row, data) -> tuple:
    """Evaluate a single check against one occurrence (or the case root).
    Returns (hit, actual, expected_label, error)."""
    path = (c.get("path") or "").strip()
    op = (c.get("op") or "eq").strip()
    base = row if row is not None else data
    actual = get_path(base, path)
    expected, label, is_ref = _resolve_value(c.get("value"), row, data)
    if is_ref and expected is _MISSING and op not in _UNARY:
        return (False, actual, label, f"{c.get('value')}: not found in case data")
    try:
        return (_compare(actual, op, expected), actual, label, None)
    except Exception as e:
        return (False, actual, label, f"{path} {op}: {e}")


def run_recipe(checks: list[dict], data, group_config: dict | None = None,
               today: str = "") -> dict:
    """Evaluate every check against the case data. Returns
    {matches: [...], evaluated: n, errors: [...]} — ALL matching causes are
    reported, in authored order; the analyst judges between them.

    Scalar checks omit `group`/`scope` and behave exactly as before —
    repeating-group support is purely additive.
    `group_config`: {group: {order_by, latest_is}} — how to pick "latest".
    """
    matches, errors = [], []
    evaluated = 0
    group_config = group_config or {}
    for c in checks:
        if c.get("kind") == "manual":
            continue                          # human step; never auto-evaluated
        path, op = (c.get("path") or "").strip(), (c.get("op") or "eq").strip()
        if not path or op not in OPS:
            continue
        evaluated += 1

        group = (c.get("group") or "").strip()
        if group:
            scope = (c.get("scope") or "latest").strip()
            if scope not in SCOPES:
                errors.append(f"{group}: unknown scope '{scope}'")
                continue
            rows = occurrences(data, group)
            if not rows:
                errors.append(f"{group}: no occurrences in case data")
                continue
            cfg = group_config.get(group, {})
            hits, first, err_seen = [], None, None
            if scope == "latest":
                idx, row = pick_latest(rows, cfg.get("order_by", ""),
                                       cfg.get("latest_is", "max_start"), today)
                hit, actual, label, err = _eval_one(c, row, data)
                if err:
                    errors.append(err)
                    continue
                if hit:
                    hits.append(idx)
                    first = (idx, actual, label)
            else:
                for i, row in enumerate(rows):
                    hit, actual, label, err = _eval_one(c, row, data)
                    if err:
                        err_seen = err
                        continue
                    if hit:
                        hits.append(i)
                        if first is None:
                            first = (i, actual, label)
                if err_seen and not hits:
                    errors.append(err_seen)
                    continue
            fired = {"any": bool(hits), "all": len(hits) == len(rows),
                     "none": not hits, "count": bool(hits),
                     "latest": bool(hits)}[scope]
            if not fired:
                continue
            idx, actual, label = first if first else (None, "", "")
            matches.append({
                "cause": c.get("cause") or "(unnamed cause)",
                "steps": c.get("steps") or "",
                "path": f"{group}[{idx}].{path}" if idx is not None else f"{group}.{path}",
                "actual": "«missing»" if actual is _MISSING else str(actual),
                "op": OPS[op],
                "expected": label if op not in _UNARY else "",
                "scope": scope,
                "group": group,
                "occurrence": idx,
                "occurrences_total": len(rows),
                "matched_count": len(hits),
                "confidence": c.get("confidence") or "definitive",
                "screen": c.get("screen") or "",
                "fix_field": c.get("fix_field") or "",
            })
            continue

        # ── scalar check (unchanged behaviour) ──
        actual = get_path(data, path)
        raw_expected = (c.get("value") or "").strip()
        if raw_expected.startswith("$."):          # field-to-field compare
            expected = get_path(data, raw_expected[2:])
            expected_label = f"{raw_expected[2:]} = " + (
                "«missing»" if expected is _MISSING else str(expected))
            if expected is _MISSING and op not in _UNARY:
                errors.append(f"{raw_expected}: not found in case data")
                continue
        else:
            expected = raw_expected
            expected_label = raw_expected
        try:
            hit = _compare(actual, op, expected)
        except Exception as e:  # defensive: a bad check must not kill triage
            errors.append(f"{path} {op}: {e}")
            continue
        if hit:
            matches.append({
                "cause": c.get("cause") or "(unnamed cause)",
                "steps": c.get("steps") or "",
                "path": path,
                "actual": "«missing»" if actual is _MISSING else str(actual),
                "op": OPS[op],
                "expected": expected_label if op not in _UNARY else "",
                "confidence": c.get("confidence") or "definitive",
                "screen": c.get("screen") or "",
                "fix_field": c.get("fix_field") or "",
            })
    return {"matches": matches, "evaluated": evaluated, "errors": errors}


def check_fires(check: dict, data, group_config: dict | None = None,
                today: str = "") -> dict:
    """Single-check evaluation for the Lab's live FIRES / does-not-fire
    feedback. Same engine as run_recipe so the workbench can never disagree
    with production triage."""
    out = run_recipe([check], data, group_config, today)
    if out["errors"]:
        return {"state": "error", "detail": out["errors"][0]}
    if out["matches"]:
        m = out["matches"][0]
        evidence = f"{m['path']} = {m['actual']} · {m['op']}"
        if m["expected"]:
            evidence += f" · {m['expected']}"
        return {"state": "fires", "detail": evidence, "match": m}
    if check.get("kind") == "manual":
        return {"state": "manual", "detail": "human step — not auto-evaluated"}
    return {"state": "quiet", "detail": "does not fire on this case"}
