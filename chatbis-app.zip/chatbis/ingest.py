"""ChatBIS prototype — ingestion pipeline.

Ordered passes so later stages can lean on earlier ones:
  1. error-table CSVs   → curated meanings into the hub
  2. COBOL + copybooks  → programs, facets, emissions, alerts, limitations
  3. documents (DFRs)   → sections + rule-level governed_by links, which
                          want the catalog already populated

Everything registers against an application (spec data model). An existing
error-code table ingests as first-class curated content — per §5.1 it is
often the single best source.
"""
from __future__ import annotations

import csv
import hashlib
import json
import re
from pathlib import Path

from . import db
from .docs import extract_docx, find_code_mentions, split_sections
from .jcl import looks_like_jcl, parse_jcl
from .bms import looks_like_bms, parse_bms
from .mine import (
    decode_bytes, detect_format, finding_code, mine, normalize_lines,
    search_tokens, snippet, split_records,
)

COBOL_EXT = {".cbl", ".cob", ".cobol", ".pco", ".sqb", ""}
JCL_EXT = {".jcl", ".cntl", ".proclib", ".prc"}
BMS_EXT = {".bms", ".map"}
COPYBOOK_EXT = {".cpy", ".copy"}
CSV_EXT = {".csv"}
DOC_EXT = {".md", ".txt", ".docx"}

# Platform-standard codes ship built in — free value on day one (§5.1).
PLATFORM_CODES = {
    "S0C7": "Data exception: non-numeric data in a numeric field (COMP-3/packed). "
            "Inspect the input record's numeric fields at the failing statement.",
    "S0C4": "Protection exception: invalid storage reference — usually a bad index, "
            "subscript beyond a table, or an unopened file's record area.",
    "S0CB": "Divide by zero.",
    "ASRA": "CICS program check (maps to an S0Cx under CICS). Check CEDF/dump.",
    "AICA": "CICS runaway task — likely an infinite loop.",
    "S806": "Load module not found: check STEPLIB/JOBLIB and the program name.",
    "S013": "Open failed: DD statement/member missing or misdefined.",
    "S222": "Job or step cancelled by operator or TSO user.",
    "SQLCODE-803": "DB2: duplicate key on insert/update (unique index violation).",
    "SQLCODE-811": "DB2: singleton SELECT returned more than one row.",
    "SQLCODE-911": "DB2: deadlock or timeout; unit of work rolled back.",
    "SQLCODE-904": "DB2: resource unavailable — check the named resource in DSNT408I.",
}


def classify(path: Path) -> str:
    ext = path.suffix.lower()
    if ext in JCL_EXT:
        return "jcl"
    if ext in BMS_EXT:
        return "bms"
    if ext in COPYBOOK_EXT:
        return "copybook"
    if ext in CSV_EXT:
        return "csv"
    if ext in DOC_EXT:
        return "doc"
    if ext in COBOL_EXT:
        return "cobol"
    return "other"


def seed_platform_codes(conn) -> None:
    for code, meaning in PLATFORM_CODES.items():
        db.upsert_exception(conn, code, scope="platform", meaning=meaning,
                            status="curated", curated_by="built-in")


def ingest_error_table(conn, path: Path) -> int:
    """CSV columns: code, meaning[, screen][, field]. Header optional."""
    n = 0
    with path.open(newline="", encoding="utf-8") as fh:
        rows = list(csv.reader(fh))
    for row in rows:
        if not row or not row[0].strip():
            continue
        if row[0].strip().lower() in ("code", "exception", "error"):
            continue
        code = row[0].strip()
        fields = {"status": "imported"}
        if len(row) > 1 and row[1].strip():
            fields["meaning"] = row[1].strip()
        if len(row) > 2 and row[2].strip():
            fields["screen_id"] = row[2].strip()
        if len(row) > 3 and row[3].strip():
            fields["data_element"] = row[3].strip()
        db.upsert_exception(conn, code, **fields)
        n += 1
    return n


def ingest_source_file(conn, path: Path, kind: str, app_id: int | None) -> dict:
    raw = path.read_bytes()
    text, encoding = decode_bytes(raw)
    if kind == "cobol" and looks_like_jcl(text):
        kind = "jcl"            # extension-less PDS member that is really JCL
    if kind in ("cobol", "copybook") and looks_like_bms(text):
        kind = "bms"            # mapset source travels with the copybooks
    records = split_records(text)
    fmt = detect_format(records)
    lines = normalize_lines(records, fmt)
    content_hash = hashlib.sha256(raw).hexdigest()[:16]

    existing = conn.execute(
        "SELECT id, content_hash FROM source_file WHERE path = ?", (str(path),)
    ).fetchone()
    if existing and existing["content_hash"] == content_hash:
        # Self-heal: an unchanged file still reprocesses when it predates a
        # miner upgrade (no data_item rows / no rule facets yet).
        has_items = conn.execute(
            "SELECT COUNT(*) FROM data_item WHERE source_file_id = ?",
            (existing["id"],)).fetchone()[0]
        has_rules = conn.execute(
            """SELECT COUNT(*) FROM program_facet pf
               JOIN program p ON p.id = pf.program_id
               WHERE p.source_file_id = ? AND pf.kind = 'rule'""",
            (existing["id"],)).fetchone()[0]
        if has_items and (kind != "cobol" or has_rules):
            return {"file": path.name, "skipped": "unchanged"}
    if existing:
        # Remove everything derived from the previous ingest of this file so
        # reprocessing never duplicates links or facets. Keyed on file_id —
        # two applications may legitimately carry same-named members.
        conn.execute(
            "DELETE FROM exception_link WHERE json_extract(detail, '$.file_id') = ?"
            " OR (json_extract(detail, '$.file_id') IS NULL"
            "     AND json_extract(detail, '$.file') = ?)",
            (existing["id"], path.name))
        for pr in conn.execute("SELECT id FROM program WHERE source_file_id = ?",
                               (existing["id"],)).fetchall():
            conn.execute("DELETE FROM paragraph WHERE program_id = ?", (pr["id"],))
            conn.execute("DELETE FROM program_facet WHERE program_id = ?", (pr["id"],))
        conn.execute("DELETE FROM program WHERE source_file_id = ?", (existing["id"],))
        conn.execute("DELETE FROM data_item WHERE source_file_id = ?", (existing["id"],))
        for j in conn.execute("SELECT id FROM jcl_job WHERE source_file_id = ?",
                              (existing["id"],)).fetchall():
            conn.execute("DELETE FROM jcl_step WHERE job_id = ?", (j["id"],))
        conn.execute("DELETE FROM jcl_job WHERE source_file_id = ?", (existing["id"],))
        conn.execute("DELETE FROM bms_field WHERE source_file_id = ?", (existing["id"],))
        conn.execute("DELETE FROM line_fts WHERE file_id = ?", (existing["id"],))
        conn.execute("DELETE FROM source_file WHERE id = ?", (existing["id"],))

    cur = conn.execute(
        """INSERT INTO source_file (application_id, path, name, kind, encoding,
           fmt, line_count, content_hash, ingested_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (app_id, str(path), path.name, kind, encoding, fmt, len(lines),
         content_hash, db.now()),
    )
    file_id = cur.lastrowid

    for cl in lines:
        if cl.text.strip():
            conn.execute(
                "INSERT INTO line_fts (file_id, lineno, text, tokens) VALUES (?, ?, ?, ?)",
                (file_id, cl.lineno, cl.text, search_tokens(cl.text)),
            )

    if kind == "bms":
        ms = parse_bms(text)
        n = 0
        for mp in ms.maps:
            for f_ in mp.fields:
                conn.execute(
                    """INSERT INTO bms_field (source_file_id, mapset, map,
                       name, pos_row, pos_col, length, initial, attrb,
                       color, hilight, occurs, map_line, map_col, lineno)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (file_id, ms.name, mp.name, f_.name, f_.row, f_.col,
                     f_.length, f_.initial, f_.attrb, f_.color, f_.hilight,
                     f_.occurs, mp.line, mp.column, f_.lineno))
                n += 1
        return {"file": path.name, "kind": "bms", "mapset": ms.name,
                "maps": len(ms.maps), "fields": n}

    if kind == "jcl":
        jb = parse_jcl(text)
        cur = conn.execute(
            "INSERT INTO jcl_job (source_file_id, name) VALUES (?, ?)",
            (file_id, jb.name or path.stem.upper()))
        job_id = cur.lastrowid
        for seq, st in enumerate(jb.steps, start=1):
            conn.execute(
                """INSERT INTO jcl_step (job_id, seq, step_name, pgm, proc,
                   cond, gate, lineno, dds) VALUES (?,?,?,?,?,?,?,?,?)""",
                (job_id, seq, st.name, st.pgm, st.proc, st.cond, st.gate,
                 st.lineno,
                 json.dumps([{"dd": d.dd, "dsn": d.dsn, "disp": d.disp,
                              "lineno": d.lineno} for d in st.dds])))
        return {"file": path.name, "kind": "jcl", "job": jb.name,
                "steps": len(jb.steps)}

    result = mine(lines)
    prog_name = result.program_name or path.stem.upper()
    program_db_id = None
    if result.program_name or kind == "cobol":
        cur = conn.execute(
            "INSERT INTO program (source_file_id, name) VALUES (?, ?)",
            (file_id, prog_name))
        program_db_id = cur.lastrowid
        for name, start, end in result.paragraphs:
            conn.execute(
                "INSERT INTO paragraph (program_id, name, start_line, end_line)"
                " VALUES (?, ?, ?, ?)", (program_db_id, name, start, end))
        for name, line in result.copies:
            conn.execute("INSERT INTO program_facet (program_id, kind, ref, line)"
                         " VALUES (?, 'copy', ?, ?)", (program_db_id, name, line))
        for cs in result.calls:
            conn.execute(
                "INSERT INTO program_facet (program_id, kind, ref, line, detail)"
                " VALUES (?, 'call', ?, ?, ?)",
                (program_db_id, cs.name, cs.lineno,
                 json.dumps({"using": cs.using, "dynamic": cs.dynamic})))
        for blk in result.sql:
            conn.execute(
                "INSERT INTO program_facet (program_id, kind, ref, line, detail)"
                " VALUES (?, 'sql', ?, ?, ?)",
                (program_db_id, ",".join(blk.tables) or "dynamic", blk.start_line,
                 json.dumps({"text": blk.text[:500], "tables": blk.tables})))
        for msg in result.messages:
            conn.execute(
                "INSERT INTO program_facet (program_id, kind, ref, line, detail)"
                " VALUES (?, 'message', ?, ?, ?)",
                (program_db_id, msg.category, msg.lineno,
                 json.dumps({"text": msg.text, "paragraph": msg.paragraph})))
        for fl in result.flows:
            conn.execute(
                "INSERT INTO program_facet (program_id, kind, ref, line, detail)"
                " VALUES (?, 'flow', ?, ?, ?)",
                (program_db_id, fl.target, fl.lineno,
                 json.dumps({"source": fl.source, "target": fl.target,
                             "verb": fl.verb})))
        for io in result.idms:
            conn.execute(
                "INSERT INTO program_facet (program_id, kind, ref, line, detail)"
                " VALUES (?, 'idms', ?, ?, ?)",
                (program_db_id, io.record, io.lineno,
                 json.dumps({"op": io.op, "qualifier": io.qualifier,
                             "set": io.set_name})))
        for fu in result.files:
            conn.execute(
                "INSERT INTO program_facet (program_id, kind, ref, line, detail)"
                " VALUES (?, 'file', ?, ?, ?)",
                (program_db_id, fu.ddname, fu.lineno,
                 json.dumps({"logical": fu.logical, "org": fu.org,
                             "ops": fu.ops})))
        for cc in result.cics:
            conn.execute(
                "INSERT INTO program_facet (program_id, kind, ref, line, detail)"
                " VALUES (?, 'cics', ?, ?, ?)",
                (program_db_id, cc.ref, cc.lineno,
                 json.dumps({"op": cc.op, "mapset": cc.mapset})))
        for sm in result.sqlmaps:
            conn.execute(
                "INSERT INTO program_facet (program_id, kind, ref, line, detail)"
                " VALUES (?, 'sqlmap', ?, ?, ?)",
                (program_db_id, sm.host, sm.lineno,
                 json.dumps({"column": sm.column, "host": sm.host,
                             "stmt": sm.stmt})))
        for rule in result.rules:
            conn.execute(
                "INSERT INTO program_facet (program_id, kind, ref, line, detail)"
                " VALUES (?, 'rule', ?, ?, ?)",
                (program_db_id, rule.code or "", rule.lineno,
                 json.dumps({"condition": rule.condition, "english": rule.english,
                             "paragraph": rule.paragraph, "actions": rule.actions,
                             "code": rule.code, "context": rule.context})))

    for di in result.data_items:
        conn.execute(
            """INSERT INTO data_item (source_file_id, program_id, level, name,
               pic, usage, item_type, length, occurs, lineno)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (file_id, program_db_id, di.level, di.name, di.pic, di.usage,
             di.item_type, di.length, di.occurs, di.lineno))

    codes_found: list[str] = []

    # Explicit MOVE-to-error-field emissions → exceptions.
    for em in result.emissions:
        exc_id = db.upsert_exception(conn, em.code)
        codes_found.append(em.code)
        db.add_link(conn, exc_id, "program", prog_name, "emitted_by",
                    detail={
                        "file_id": file_id, "file": path.name, "line": em.lineno,
                        "program_db_id": program_db_id,
                        "paragraph": em.paragraph, "field": em.field,
                        "condition": em.condition, "condition_line": em.condition_lineno,
                        "snippet": snippet(lines, em.lineno),
                    },
                    confidence=em.confidence)
        for blk in result.sql:
            if abs(blk.start_line - em.lineno) <= 30:
                db.add_link(conn, exc_id, "sql", ",".join(blk.tables) or "unknown",
                            "uses_sql",
                            detail={"file_id": file_id, "file": path.name,
                                    "line": blk.start_line,
                                    "text": blk.text[:500], "tables": blk.tables},
                            confidence=0.4)
        db.add_link(conn, exc_id, "data_element", em.field, "touches",
                    detail={"file_id": file_id, "file": path.name, "line": em.lineno},
                    confidence=0.6)

    # DISPLAYed alerts and processing limitations → catalog entries too.
    # A literal code inside the message keys the entry; otherwise a stable
    # synthetic ALT-/LIM- code derived from program + message.
    for msg in result.messages:
        # Messages conventionally lead with the program's own name
        # ('OPS220 EDIT FAILED E4417') — the name matches the code pattern
        # but is not a code. Never let a program catalog itself.
        real_codes = [c for c in msg.codes
                      if c != prog_name and c != path.stem.upper()]
        if real_codes:
            code = real_codes[0]
        else:
            code = finding_code(prog_name, msg.category, msg.text)
        exc_id = db.upsert_exception(conn, code, category=msg.category,
                                     meaning=None if msg.codes else msg.text)
        codes_found.append(code)
        db.add_link(conn, exc_id, "program", prog_name, "raised_by",
                    detail={"file_id": file_id, "file": path.name,
                            "program_db_id": program_db_id,
                            "line": msg.lineno, "paragraph": msg.paragraph,
                            "message": msg.text,
                            "snippet": snippet(lines, msg.lineno)},
                    confidence=0.7)

    # 88-levels: condition names whose VALUE looks like a code.
    for name, value, lineno in result.level88:
        if any(k in name for k in ("ERR", "EXC", "CODE", "STAT")) and value.strip():
            exc_id = db.upsert_exception(conn, value.strip())
            codes_found.append(value.strip())
            db.add_link(conn, exc_id, "copybook" if kind == "copybook" else "program",
                        path.stem.upper(), "defined_in",
                        detail={"file_id": file_id, "file": path.name, "line": lineno,
                                "condition_name": name,
                                "snippet": snippet(lines, lineno, 2)},
                        confidence=0.8)

    return {"file": path.name, "kind": kind, "encoding": encoding, "fmt": fmt,
            "lines": len(lines), "codes": sorted(set(codes_found))}


def ingest_document(conn, path: Path, app_id: int | None) -> dict:
    """DFRs: split into sections, link sections that explicitly mention a
    code (governed_by, high confidence — spec §5.3)."""
    if path.suffix.lower() == ".docx":
        text = extract_docx(path.read_bytes())
        doc_type = "docx"
    else:
        text, _enc = decode_bytes(path.read_bytes())
        doc_type = path.suffix.lstrip(".").lower() or "txt"

    existing = conn.execute("SELECT id FROM document WHERE path = ?",
                            (str(path),)).fetchone()
    if existing:
        # Drop the previous ingest's rule links too — their target section ids
        # die with the sections, and stale rows would duplicate on every run.
        conn.execute(
            "DELETE FROM exception_link WHERE target_kind = 'document'"
            " AND json_extract(detail, '$.doc_id') = ?", (existing["id"],))
        conn.execute("DELETE FROM doc_section WHERE document_id = ?", (existing["id"],))
        conn.execute("DELETE FROM document WHERE id = ?", (existing["id"],))
    title = path.stem.replace("_", " ").replace("-", " ").title()
    title = re.sub(r"\bDfrs?\b", lambda m: m.group(0).upper(), title)
    cur = conn.execute(
        "INSERT INTO document (application_id, title, path, doc_type, ingested_at)"
        " VALUES (?, ?, ?, ?, ?)",
        (app_id, title, str(path), doc_type, db.now()))
    doc_id = cur.lastrowid

    known = {r["normalized"]: r["code"] for r in
             conn.execute("SELECT normalized, code FROM exception_code")}
    linked = 0
    for ord_, (heading, body) in enumerate(split_sections(text)):
        cur = conn.execute(
            "INSERT INTO doc_section (document_id, heading, ord, text)"
            " VALUES (?, ?, ?, ?)", (doc_id, heading, ord_, body))
        section_id = cur.lastrowid
        for norm in find_code_mentions(f"{heading}\n{body}", known):
            # Known codes only: the generic pattern also matches screen IDs
            # (PS220 → "220"), so an unknown mention is more likely a screen
            # or paragraph name than a code the source has never emitted.
            if norm not in known:
                continue
            row = conn.execute(
                "SELECT id FROM exception_code WHERE normalized = ?", (norm,)
            ).fetchone()
            exc_id = row["id"]
            db.add_link(conn, exc_id, "document", str(section_id), "governed_by",
                        detail={"doc_id": doc_id, "doc_title": path.stem,
                                "section_id": section_id, "heading": heading,
                                "excerpt": body[:400]},
                        confidence=0.85, provenance="mined")
            linked += 1
    return {"file": path.name, "kind": "document", "type": doc_type,
            "sections": ord_ + 1 if text.strip() else 0, "code_links": linked}


def ingest_paths(conn, paths: list[Path], app_id: int | None = None) -> list[dict]:
    """Ingest a batch of files in dependency order (error tables → source →
    documents). Shared by the CLI tree walk and the web upload. Paths are
    canonicalized — a file ingested via CLI (relative) and browser upload
    (absolute) must land on ONE row."""
    summary: list[dict] = []
    seed_platform_codes(conn)
    buckets = {"csv": [], "cobol": [], "copybook": [], "jcl": [], "bms": [],
               "doc": [], "other": []}
    for p in paths:
        p = Path(p).resolve()
        buckets[classify(p)].append(p)

    for p in buckets["csv"]:
        n = ingest_error_table(conn, p)
        summary.append({"file": p.name, "kind": "error-table", "codes_imported": n})
    for p in buckets["cobol"] + buckets["copybook"] + buckets["jcl"] \
            + buckets["bms"]:
        summary.append(ingest_source_file(conn, p, classify(p), app_id))
    for p in buckets["doc"]:
        summary.append(ingest_document(conn, p, app_id))
    for p in buckets["other"]:
        summary.append({"file": p.name, "skipped": "unrecognised type"})
    conn.commit()
    return summary


def ingest_tree(conn, root: Path, app_name: str | None = None) -> list[dict]:
    app_id = db.get_or_create_app(conn, app_name) if app_name else None
    paths = [p for p in sorted(root.rglob("*"))
             if p.is_file() and not p.name.startswith(".")]
    return ingest_paths(conn, paths, app_id)
