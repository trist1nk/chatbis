"""ChatBIS — turn what we already know into a pre-filled recipe.

Two jobs, both pure functions over data the workbench already holds:

  walk_paths()   the loaded case JSON becomes a pickable field list, so the
                 analyst never types a path from memory (typo'd paths are the
                 worst bug class in the Lab: the check looks authored and
                 silently never fires).

  draft_checks() mined COBOL conditions (exception_link.detail.condition)
                 joined to the field map (COBOL -> JSON path) produce draft
                 checks with provenance. The analyst confirms rather than
                 composes.

Nothing here guesses. A condition we cannot translate faithfully is reported
as blocked, with the reason -- an unmapped COBOL field is a to-do, not a
silently dropped rule. Drafting a wrong rule is far worse than drafting none.
"""
from __future__ import annotations

import re

# COBOL relational operators -> our ops. Order matters: the NOT- and
# compound forms must be tried before the bare ones they contain.
_RELATIONS = (
    (r"NOT\s+EQUAL\s+TO|NOT\s+EQUAL|NOT\s*=", "ne"),
    (r"NOT\s+GREATER\s+THAN|NOT\s+GREATER|NOT\s*>", "le"),
    (r"NOT\s+LESS\s+THAN|NOT\s+LESS|NOT\s*<", "ge"),
    (r"GREATER\s+THAN\s+OR\s+EQUAL\s+TO|>=", "ge"),
    (r"LESS\s+THAN\s+OR\s+EQUAL\s+TO|<=", "le"),
    (r"GREATER\s+THAN|IS\s+GREATER|GREATER|>", "gt"),
    (r"LESS\s+THAN|IS\s+LESS|LESS|<", "lt"),
    (r"EQUAL\s+TO|EQUALS|EQUAL|=", "eq"),
)
_REL_RE = re.compile(r"\s*(?:IS\s+)?(" + "|".join(p for p, _ in _RELATIONS)
                     + r")\s*", re.I)

# Figurative constants. SPACES/LOW-VALUES mean "not set", which our engine
# expresses as blank/not_blank rather than a literal comparison.
_BLANKISH = {"SPACE", "SPACES", "LOW-VALUE", "LOW-VALUES", "NULL", "NULLS"}
_ZEROISH = {"ZERO", "ZEROS", "ZEROES"}
_SIGN = {"NEGATIVE": ("lt", "0"), "POSITIVE": ("gt", "0"), "ZERO": ("eq", "0")}
_LEAD = re.compile(r"^\s*(IF|WHEN|EVALUATE|AND\s+IF|ELSE\s+IF)\s+", re.I)
_TRAIL = re.compile(r"\s+(CONTINUE|THEN|NEXT\s+SENTENCE|GO\s+TO.*)$", re.I)
_IDENT = re.compile(r"^[A-Z0-9][A-Z0-9\-]*$", re.I)


# "GREATER THAN OR EQUAL TO" contains a literal OR, so it must collapse to a
# symbol BEFORE the top-level OR split -- otherwise the operator is torn in half.
_COMPOUND = (
    (re.compile(r"\bNOT\s+(?:IS\s+)?LESS\s+THAN\b", re.I), ">="),
    (re.compile(r"\bNOT\s+(?:IS\s+)?GREATER\s+THAN\b", re.I), "<="),
    (re.compile(r"\b(?:IS\s+)?GREATER\s+THAN\s+OR\s+EQUAL\s+TO\b", re.I), ">="),
    (re.compile(r"\b(?:IS\s+)?LESS\s+THAN\s+OR\s+EQUAL\s+TO\b", re.I), "<="),
    (re.compile(r"\b(?:IS\s+)?NOT\s+EQUAL\s+TO\b", re.I), "NOT ="),
)


def _clean(text: str) -> str:
    s = (text or "").strip().rstrip(".")
    s = _LEAD.sub("", s)
    s = _TRAIL.sub("", s).strip()
    for pat, sym in _COMPOUND:
        s = pat.sub(sym, s)
    return s


def _literal(tok: str):
    """(value, op_override) for a right-hand token, or (None, None) if it is
    an identifier that must be resolved through the field map."""
    t = tok.strip()
    if len(t) >= 2 and t[0] in "'\"" and t[-1] == t[0]:
        return t[1:-1], None
    u = t.upper()
    if u in _BLANKISH:
        return "", "blank"
    if u in _ZEROISH:
        return "0", None
    if re.fullmatch(r"[+-]?\d+(\.\d+)?", t):
        return t, None
    return None, None


def parse_condition(text: str) -> dict:
    """One mined COBOL condition -> {clauses: [...], blocked: reason}.

    A clause is {lhs, op, rhs, rhs_literal}. Top-level OR splits into separate
    clauses (either firing means the exception is raised -- exactly how
    run_recipe reports multiple matches). AND is NOT split: both sides must
    hold, which a flat check list cannot express, so we decline it.
    """
    s = _clean(text)
    if not s:
        return {"clauses": [], "blocked": "empty condition"}
    if re.search(r"\bAND\b", s, re.I):
        return {"clauses": [], "blocked":
                "compound AND -- needs a `when` guard, author by hand"}

    # Class / sign conditions: WS-AMT IS NEGATIVE, WS-X NOT NUMERIC.
    m = re.match(r"^(\S+)\s+(?:IS\s+)?(NOT\s+)?(NUMERIC|ALPHABETIC|NEGATIVE|"
                 r"POSITIVE|ZERO)\s*$", s, re.I)
    if m:
        name, neg, kind = m.group(1), bool(m.group(2)), m.group(3).upper()
        if kind in _SIGN and not neg:
            op, val = _SIGN[kind]
            return {"clauses": [{"lhs": name, "op": op, "rhs": val,
                                 "rhs_literal": True}], "blocked": None}
        return {"clauses": [], "blocked":
                f"class condition ({kind}) has no equivalent check op"}

    parts = re.split(r"\s+OR\s+", s, flags=re.I)
    head = parts[0]
    m = _REL_RE.search(head)
    if not m:
        return {"clauses": [], "blocked":
                "no relational operator (88-level or flag condition?)"}
    lhs = head[:m.start()].strip()
    op = next(o for p, o in _RELATIONS
              if re.fullmatch(p, m.group(1), re.I))
    if not _IDENT.match(lhs):
        return {"clauses": [], "blocked": f"left side is not a field ({lhs})"}

    clauses = []
    for i, part in enumerate(parts):
        raw = part[m.end():].strip() if i == 0 else part.strip()
        c_op = op
        if i and (m2 := _REL_RE.search(part)):     # OR with its own operator
            c_op = next(o for p, o in _RELATIONS
                        if re.fullmatch(p, m2.group(1), re.I))
            l2 = part[:m2.start()].strip()
            raw = part[m2.end():].strip()
            if l2 and l2.upper() != lhs.upper():
                return {"clauses": [], "blocked":
                        "OR compares different fields -- author by hand"}
        val, override = _literal(raw)
        if override:                                # = SPACES -> blank
            c_op = override if c_op == "eq" else "not_blank"
            val = ""
        clauses.append({"lhs": lhs, "op": c_op,
                        "rhs": raw if val is None else val,
                        "rhs_literal": val is not None})
    return {"clauses": clauses, "blocked": None}


def _split_group(json_path: str) -> tuple:
    """'entitlementPeriods[].startDate' -> ('entitlementPeriods', 'startDate').
    A path with no [] is case-level: ('', path)."""
    if "[]" not in json_path:
        return "", json_path
    head, _, tail = json_path.partition("[]")
    return head.strip("."), tail.lstrip(".")


def draft_checks(conditions: list, field_map: list) -> list:
    """conditions: [{condition, program, file, line}]
    field_map:  [{cobol_field, json_path, label}]
    -> drafts, each {check, why, provenance, blocked}."""
    by_cobol = {(f["cobol_field"] or "").strip().upper(): f
                for f in field_map if f.get("cobol_field") and f.get("json_path")}
    drafts = []
    for src in conditions:
        parsed = parse_condition(src.get("condition", ""))
        prov = {k: src.get(k) for k in ("program", "file", "line", "condition")}
        if parsed["blocked"]:
            drafts.append({"check": None, "why": "", "provenance": prov,
                           "blocked": parsed["blocked"]})
            continue
        for c in parsed["clauses"]:
            lf = by_cobol.get(c["lhs"].upper())
            if not lf:
                drafts.append({"check": None, "why": "", "provenance": prov,
                               "blocked": f"{c['lhs']} has no field mapping",
                               "needs_mapping": c["lhs"]})
                continue
            group, path = _split_group(lf["json_path"])
            value, rhs_label = c["rhs"], c["rhs"]
            if not c["rhs_literal"]:
                rf = by_cobol.get(c["rhs"].upper())
                if not rf:
                    drafts.append({"check": None, "why": "", "provenance": prov,
                                   "blocked": f"{c['rhs']} has no field mapping",
                                   "needs_mapping": c["rhs"]})
                    continue
                rgroup, rpath = _split_group(rf["json_path"])
                if rgroup and rgroup != group:
                    drafts.append({"check": None, "why": "", "provenance": prov,
                                   "blocked": "compares across two repeating "
                                              "groups -- author by hand"})
                    continue
                value = f"$.{rpath}" if rgroup else f"$$.{rf['json_path']}"
                rhs_label = rf.get("label") or rf["json_path"]
            else:
                rhs_label = f"'{c['rhs']}'" if c["rhs"] else ""
            drafts.append({
                "check": {"kind": "compare", "group": group,
                          "scope": "latest" if group else "",
                          "path": path, "op": c["op"], "value": value,
                          "cause": "", "confidence": "likely",
                          "screen": "", "fix_field": "", "steps": ""},
                "why": _phrase(lf.get("label") or path, c["op"], rhs_label, group),
                "provenance": prov, "blocked": None})
    return drafts


from .recipe import OPS as _PHRASE          # one vocabulary, not two


def _phrase(lhs_label: str, op: str, rhs_label: str, group: str) -> str:
    lead = f"In the latest {group}, " if group else ""
    tail = f" {rhs_label}" if rhs_label and op not in ("blank", "not_blank",
                                                      "missing") else ""
    return f"{lead}{lhs_label} {_PHRASE.get(op, op)}{tail}".strip()


def walk_paths(data, prefix: str = "", depth: int = 0) -> list:
    """Flatten the loaded case into pickable entries:
    {path, group, field, kind, value, count}. Repeating groups are collapsed
    to one entry per field (group[].field) with a sample value, because that
    is the shape a check needs."""
    out: list = []
    if depth > 6:
        return out
    if isinstance(data, dict):
        for k, v in data.items():
            p = f"{prefix}.{k}" if prefix else k
            if isinstance(v, list) and v and isinstance(v[0], dict):
                out.append({"path": p, "group": p, "field": "", "kind": "group",
                            "value": "", "count": len(v)})
                for child in walk_paths(v[0], f"{p}[]", depth + 1):
                    child["group"] = p
                    # `field` must be relative to the occurrence: a check
                    # inside a group addresses startDate, not the full path.
                    child["field"] = child["path"][len(p) + 3:]
                    out.append(child)
            elif isinstance(v, dict):
                out.extend(walk_paths(v, p, depth + 1))
            elif isinstance(v, list):
                out.append({"path": p, "group": "", "field": p, "kind": "leaf",
                            "value": ", ".join(str(x) for x in v[:3]),
                            "count": len(v)})
            else:
                out.append({"path": p, "group": "", "field": p, "kind": "leaf",
                            "value": "" if v is None else str(v), "count": 0})
    return out
