"""ChatBIS — database connector for Case Lookup research.

Two drivers:
- sqlite  — stdlib, works everywhere today (also useful for local extracts);
            opened read-only via URI so even a hostile query can't write.
- odbc    — the realistic corp bridge to DB2 / Oracle / SQL Server: shops
            already run ODBC DSNs; needs the single pyodbc wheel. Detected
            at call time; a clear message if absent, core stays zero-dep.

Safety is structural, not advisory:
- SELECT/WITH only, single statement (validated before anything connects)
- {placeholders} become BOUND parameters (?, args) — never string-spliced,
  so a parameter value cannot alter the SQL
- row cap on fetch; short connect/query timeouts
"""
from __future__ import annotations

import re
import sqlite3
import time

RE_PLACEHOLDER = re.compile(r"\{([a-zA-Z0-9_]+)\}")


def validate_select(sql: str) -> str:
    """One statement, and it must read. Raises ValueError otherwise."""
    statements = [s for s in (sql or "").split(";") if s.strip()]
    if len(statements) != 1:
        raise ValueError("exactly one SQL statement, please")
    stmt = statements[0].strip()
    head_match = re.match(r"[\s(]*([A-Za-z]+)", stmt)
    head = (head_match.group(1) if head_match else "").upper()
    if head not in ("SELECT", "WITH"):
        raise ValueError("read-only research: the statement must start with "
                         "SELECT or WITH")
    return stmt


def prepare(sql: str, params: dict) -> tuple[str, list, list[str]]:
    """{name} placeholders → bound '?' in order of appearance."""
    order: list[str] = []

    def repl(m):
        order.append(m.group(1))
        return "?"

    bound = RE_PLACEHOLDER.sub(repl, sql)
    missing = [k for k in order if not str(params.get(k, "")).strip()]
    args = [str(params.get(k, "")) for k in order]
    return bound, args, missing


def run_query(driver: str, dsn: str, sql: str, params: dict,
              limit: int = 200) -> dict:
    """Execute one read-only query. Returns
    {columns, rows, truncated, ms, error} — error is a string, never an
    exception, so the UI always renders something honest."""
    started = time.perf_counter()
    out = {"columns": [], "rows": [], "truncated": False, "ms": 0, "error": None}
    try:
        stmt = validate_select(sql)
        bound, args, missing = prepare(stmt, params)
        if missing:
            raise ValueError(f"missing parameter value: {', '.join(missing)}")
        if driver == "sqlite":
            conn = sqlite3.connect(f"file:{dsn}?mode=ro", uri=True, timeout=5)
            try:
                cur = conn.execute(bound, args)
                out["columns"] = [d[0] for d in cur.description or []]
                fetched = cur.fetchmany(limit + 1)
            finally:
                conn.close()
        elif driver == "odbc":
            try:
                import pyodbc  # optional; the one wheel worth installing
            except ImportError:
                raise ValueError(
                    "ODBC sources need the pyodbc package on this machine "
                    "(pip install pyodbc) plus a configured DSN")
            conn = pyodbc.connect(dsn, timeout=5)
            try:
                cur = conn.cursor()
                cur.execute(bound, args)
                out["columns"] = [d[0] for d in cur.description or []]
                fetched = cur.fetchmany(limit + 1)
            finally:
                conn.close()
        else:
            raise ValueError(f"unknown driver: {driver}")
        out["truncated"] = len(fetched) > limit
        out["rows"] = [["" if v is None else str(v) for v in row]
                       for row in fetched[:limit]]
    except Exception as e:
        out["error"] = str(e)
    out["ms"] = int((time.perf_counter() - started) * 1000)
    return out
