"""ChatBIS prototype — storage layer.

The future-proofing lives in three decisions:

1. ``exception_code`` is the HUB entity. Everything the tool knows attaches
   to an exception; the catalog grows code by code.
2. ``exception_link`` is ONE typed edge table. A new kind of related thing
   (screens, JCL jobs, tickets, runs, batch schedules...) is a new
   ``target_kind`` string plus JSON detail — never a schema migration.
3. ``exception_event`` is append-only history. Frequencies, success rates,
   and MTTR are computed over events, never stored as counters, so a new
   metric never needs a backfill.

SQLite on purpose: the prototype must run inside the corporate network on
stock Python with nothing installed. Swapping to Postgres later means
changing this module only.
"""
from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS application (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS source_file (
  id INTEGER PRIMARY KEY,
  application_id INTEGER REFERENCES application(id),
  path TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  kind TEXT NOT NULL,              -- cobol | copybook | csv | doc | other
  encoding TEXT NOT NULL,          -- utf-8 | cp037 | ...
  fmt TEXT NOT NULL,               -- fixed | free
  line_count INTEGER NOT NULL,
  content_hash TEXT NOT NULL,
  ingested_at TEXT NOT NULL
);

-- Program-level structure for the analyze path (copies, calls, SQL,
-- messages) — what a program touches, independent of any exception.
CREATE TABLE IF NOT EXISTS program_facet (
  id INTEGER PRIMARY KEY,
  program_id INTEGER NOT NULL REFERENCES program(id),
  kind TEXT NOT NULL,              -- copy | call | sql | message
  ref TEXT NOT NULL,
  line INTEGER,
  detail TEXT NOT NULL DEFAULT '{}'
);

-- Data-division items with computed storage type/length — the app's data
-- dictionary, and the layout knowledge a future dry-run record decoder
-- needs (docs/dry-run-what-if.md).
CREATE TABLE IF NOT EXISTS data_item (
  id INTEGER PRIMARY KEY,
  source_file_id INTEGER NOT NULL REFERENCES source_file(id),
  program_id INTEGER REFERENCES program(id),
  level INTEGER NOT NULL,
  name TEXT NOT NULL,
  pic TEXT,
  usage TEXT NOT NULL DEFAULT 'DISPLAY',
  item_type TEXT NOT NULL,         -- alphanumeric | numeric | packed | binary | group | ...
  length INTEGER,                  -- bytes; NULL for groups
  occurs INTEGER,
  lineno INTEGER NOT NULL
);

-- Case-lookup integration (spec Phase 4, via the shop's REST API):
-- environments carry base URL + JWT for TEST systems; endpoints are path
-- templates with {placeholders} that become form fields; the call log
-- stores masked params only (never a full SSN).
CREATE TABLE IF NOT EXISTS api_env (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  base_url TEXT NOT NULL,
  token TEXT,
  insecure_tls INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS api_endpoint (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  method TEXT NOT NULL DEFAULT 'GET',
  path TEXT NOT NULL,              -- e.g. /v1/cases/by-ssn?ssn={ssn}
  -- Optional JSON template with {placeholders}. Sent on ANY method that
  -- has one — some enterprise APIs do take a body on GET.
  body TEXT,
  created_at TEXT NOT NULL
);

-- A complete case often needs several calls (claim + entitlement periods +
-- addresses...). A BUNDLE is a named, ordered set of endpoints whose
-- responses are merged into ONE object under per-step mount keys, so recipe
-- paths (claim.claimant.dob, periods[], addresses[]) don't care how many
-- requests produced them. This is the "named sources" model in
-- docs/agent-architecture.md §3c.
CREATE TABLE IF NOT EXISTS case_bundle (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS bundle_step (
  id INTEGER PRIMARY KEY,
  bundle_id INTEGER NOT NULL REFERENCES case_bundle(id),
  endpoint_id INTEGER NOT NULL REFERENCES api_endpoint(id),
  -- Where this response lands in the merged case: {"<mount_key>": <response>}.
  -- Blank merges the response at the ROOT (for the primary call).
  mount_key TEXT NOT NULL DEFAULT '',
  seq INTEGER NOT NULL DEFAULT 0,
  -- required=0: a failure is recorded as a note and the rest continues, so a
  -- missing optional source reads as "unavailable" rather than silently
  -- producing "no diagnostic matched".
  required INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS api_call_log (
  id INTEGER PRIMARY KEY,
  env TEXT, endpoint TEXT,
  params TEXT,                     -- JSON, sensitive values pre-masked
  status INTEGER, ms INTEGER, ok INTEGER,
  ts TEXT NOT NULL
);

-- Database research sources + saved SQL (Case Lookup's second rail beside
-- the REST endpoints). Queries are SELECT-only with bound {placeholders}.
CREATE TABLE IF NOT EXISTS db_source (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  driver TEXT NOT NULL DEFAULT 'sqlite',   -- sqlite | odbc
  dsn TEXT NOT NULL,                       -- file path, or DSN=..;UID=..;PWD=..
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS db_query (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  sql TEXT NOT NULL,
  created_at TEXT NOT NULL
);

-- FIELD MAP — the same business field wears three different names:
--   COBOL   WS-BENE-DOB        (what the analyst and the mined gates say)
--   DB2     MCS.CLAIM.BENE_DOB (what a SQL rail query selects)
--   JSON    claimant.dateOfBirth (what the REST API returns)
-- Recipes path into JSON, evidence is in COBOL, research is in DB2 —
-- without this table nothing joins them up, and an analyst has to
-- translate in their head on every check. Errored check paths are the
-- backlog that feeds this (docs/agent-architecture.md §3b).
CREATE TABLE IF NOT EXISTS field_map (
  id INTEGER PRIMARY KEY,
  application_id INTEGER REFERENCES application(id),
  label TEXT NOT NULL,             -- plain-language name
  cobol_field TEXT,
  db2_column TEXT,                 -- SCHEMA.TABLE.COLUMN
  json_path TEXT,                  -- dot path into the case object
  notes TEXT,
  updated_by TEXT,
  updated_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_field_map_json ON field_map (json_path);
CREATE INDEX IF NOT EXISTS idx_field_map_cobol ON field_map (cobol_field);

-- LLM connector. Used ONLY by the Investigate path (no recipe matched) —
-- never on the deterministic path, which keeps case data in-network
-- entirely. `redact_identifiers` defaults ON and the UI does not offer a
-- way to turn it off (docs/agent-architecture.md §3c PII posture).
CREATE TABLE IF NOT EXISTS llm_config (
  id INTEGER PRIMARY KEY CHECK (id = 1),   -- single row
  provider TEXT NOT NULL DEFAULT 'in-network',
  base_url TEXT,
  model TEXT,
  api_key TEXT,
  enabled INTEGER NOT NULL DEFAULT 0,
  redact_identifiers INTEGER NOT NULL DEFAULT 1,
  zero_retention_confirmed INTEGER NOT NULL DEFAULT 0,
  updated_by TEXT,
  updated_at TEXT
);

-- Triage recipes: per-exception automated diagnosis. Which endpoint pulls
-- the case, ordered diagnostic checks (JSON), and fallback steps. Read-only
-- by design — the recipe answers; the analyst acts in the system of record.
CREATE TABLE IF NOT EXISTS playbook (
  id INTEGER PRIMARY KEY,
  exception_id INTEGER NOT NULL UNIQUE REFERENCES exception_code(id),
  -- A recipe pulls its case from EITHER a single endpoint or a bundle.
  endpoint_id INTEGER REFERENCES api_endpoint(id),
  bundle_id INTEGER REFERENCES case_bundle(id),
  general_steps TEXT,
  checks TEXT NOT NULL DEFAULT '[]',
  -- {group: {order_by, latest_is}} — how "latest" is picked per repeating
  -- group. Explicit because the four readings of "latest" disagree exactly
  -- in the messy cases that generate exceptions (docs/agent-architecture.md).
  group_config TEXT NOT NULL DEFAULT '{}',
  updated_by TEXT,
  updated_at TEXT
);

-- Lab regression fixtures: REDACTED case shapes a recipe is tested against.
-- Identifiers are stripped — the purpose is testing check LOGIC, never
-- preserving a real beneficiary's record. chatbis.db must never hold case
-- data (see the PII posture in docs/agent-architecture.md).
CREATE TABLE IF NOT EXISTS playbook_test_case (
  id INTEGER PRIMARY KEY,
  exception_id INTEGER NOT NULL REFERENCES exception_code(id),
  label TEXT NOT NULL,
  shape TEXT NOT NULL,             -- JSON, redacted
  expect TEXT NOT NULL DEFAULT 'fires',   -- fires | quiet
  created_at TEXT NOT NULL
);

-- Exception-MI imports (statistic-server extracts). One row per imported
-- file; the numbers land as kind='mi' events whose payload keeps EVERY
-- column of the source row — dynamic by construction.
CREATE TABLE IF NOT EXISTS mi_import (
  id INTEGER PRIMARY KEY,
  filename TEXT NOT NULL,
  columns TEXT NOT NULL,           -- JSON: the file's own headers
  mapping TEXT NOT NULL,           -- JSON: confirmed column roles
  rows_imported INTEGER NOT NULL,
  codes INTEGER NOT NULL,
  period_min TEXT, period_max TEXT,
  ts TEXT NOT NULL
);

-- DFRs and other documents, split into sections for rule-level linking.
CREATE TABLE IF NOT EXISTS document (
  id INTEGER PRIMARY KEY,
  application_id INTEGER REFERENCES application(id),
  title TEXT NOT NULL,
  path TEXT NOT NULL UNIQUE,
  doc_type TEXT NOT NULL,          -- md | txt | docx
  ingested_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS doc_section (
  id INTEGER PRIMARY KEY,
  document_id INTEGER NOT NULL REFERENCES document(id),
  heading TEXT,
  ord INTEGER NOT NULL,
  text TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS program (
  id INTEGER PRIMARY KEY,
  source_file_id INTEGER NOT NULL REFERENCES source_file(id),
  name TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS paragraph (
  id INTEGER PRIMARY KEY,
  program_id INTEGER NOT NULL REFERENCES program(id),
  name TEXT NOT NULL,
  start_line INTEGER NOT NULL,
  end_line INTEGER NOT NULL
);

-- The hub.
CREATE TABLE IF NOT EXISTS exception_code (
  id INTEGER PRIMARY KEY,
  code TEXT NOT NULL,              -- as first seen: E4417
  normalized TEXT NOT NULL UNIQUE, -- variants (4417, ERR-4417) collapse here
  scope TEXT NOT NULL DEFAULT 'app',        -- app | platform
  category TEXT NOT NULL DEFAULT 'exception', -- exception | alert | limitation
  meaning TEXT,
  screen_id TEXT,
  data_element TEXT,
  status TEXT NOT NULL DEFAULT 'inferred',  -- inferred | imported | curated
  metadata TEXT NOT NULL DEFAULT '{}',      -- JSON junk drawer for the future
  curated_by TEXT,
  updated_at TEXT
);

-- The typed edges: everything an exception relates to.
CREATE TABLE IF NOT EXISTS exception_link (
  id INTEGER PRIMARY KEY,
  exception_id INTEGER NOT NULL REFERENCES exception_code(id),
  target_kind TEXT NOT NULL,   -- program|paragraph|copybook|data_element|sql|document|policy|screen|...
  target_ref TEXT NOT NULL,    -- id or natural key within that kind
  relation TEXT NOT NULL,      -- emitted_by|defined_in|touches|uses_sql|governed_by|...
  detail TEXT NOT NULL DEFAULT '{}',  -- JSON: line, condition_text, snippet, tables...
  confidence REAL NOT NULL DEFAULT 0.5,
  provenance TEXT NOT NULL DEFAULT 'mined',  -- mined | imported | manual
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_link_exception ON exception_link(exception_id, relation);

-- Append-only history: the compounding asset.
CREATE TABLE IF NOT EXISTS exception_event (
  id INTEGER PRIMARY KEY,
  exception_id INTEGER NOT NULL REFERENCES exception_code(id),
  kind TEXT NOT NULL,          -- occurrence | run | lookup | resolution | edit
  outcome TEXT,                -- resolved | failed | reprocessed | ...
  payload TEXT NOT NULL DEFAULT '{}',  -- JSON: case_ref, cause, field, action, note...
  actor TEXT,
  ts TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_event_exception ON exception_event(exception_id, kind);

-- Full-text over source. tokens holds the search-ready form: identifiers
-- Dry-run stubs: CALL targets the analyst declares out of scope for the
-- interpreter (assembler sinks, vendor modules). A stubbed call is
-- satisfied for readiness and trace-visible at run time.
CREATE TABLE IF NOT EXISTS runner_stub (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  note TEXT,
  created_at TEXT NOT NULL
);

-- Mined BMS: screen fields with positions — the first hop of the flow.
CREATE TABLE IF NOT EXISTS bms_field (
  id INTEGER PRIMARY KEY,
  source_file_id INTEGER NOT NULL REFERENCES source_file(id),
  mapset TEXT,
  map TEXT NOT NULL,
  name TEXT NOT NULL,              -- '' for screen constants
  pos_row INTEGER,
  pos_col INTEGER,
  length INTEGER,
  initial TEXT,
  attrb TEXT,
  color TEXT,
  hilight TEXT,
  occurs INTEGER,
  map_line INTEGER,
  map_col INTEGER,
  lineno INTEGER
);

-- Mined JCL: a job is the pipeline written down. Steps keep their order,
-- program, gates and DD bindings; seams are computed from shared DSNs.
CREATE TABLE IF NOT EXISTS jcl_job (
  id INTEGER PRIMARY KEY,
  source_file_id INTEGER NOT NULL REFERENCES source_file(id),
  name TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS jcl_step (
  id INTEGER PRIMARY KEY,
  job_id INTEGER NOT NULL REFERENCES jcl_job(id),
  seq INTEGER NOT NULL,
  step_name TEXT NOT NULL,
  pgm TEXT,
  proc TEXT,
  cond TEXT,
  gate TEXT,
  lineno INTEGER,
  dds TEXT NOT NULL DEFAULT '[]'
);

-- Indexes for the closure walkers: first real corpus (126 members) put
-- the app screen at minutes per view because these were table scans.
CREATE INDEX IF NOT EXISTS idx_facet_prog ON program_facet(program_id, kind);
CREATE INDEX IF NOT EXISTS idx_program_name ON program(name);
CREATE INDEX IF NOT EXISTS idx_program_file ON program(source_file_id);
CREATE INDEX IF NOT EXISTS idx_data_item_file ON data_item(source_file_id);
CREATE INDEX IF NOT EXISTS idx_doc_section_doc ON doc_section(document_id);
CREATE INDEX IF NOT EXISTS idx_link_target ON exception_link(target_kind, target_ref);
CREATE INDEX IF NOT EXISTS idx_source_file_app ON source_file(application_id);
CREATE INDEX IF NOT EXISTS idx_jcl_step_job ON jcl_step(job_id);

-- kept verbatim AND split, so WS-CUST-NAME matches "ws-cust-name", "cust",
-- and "cust name" (the FR-4.2 requirement everyone gets wrong).
-- The shop quirk: source says U804, the MI reports A2U804 — the business
-- function's reporting prefix in front. Aliases are DECLARED equivalences
-- (from a merge or a registered prefix), never guessed from shape.
CREATE TABLE IF NOT EXISTS code_alias (
  id INTEGER PRIMARY KEY,
  alias TEXT NOT NULL UNIQUE,          -- normalized form of the alias
  exception_id INTEGER NOT NULL REFERENCES exception_code(id),
  source TEXT,                         -- merge | prefix
  created_at TEXT
);
CREATE TABLE IF NOT EXISTS code_prefix (
  prefix TEXT PRIMARY KEY,             -- 'A2' — a reporting prefix the shop uses
  note TEXT,
  created_at TEXT
);

CREATE VIRTUAL TABLE IF NOT EXISTS line_fts USING fts5(
  file_id UNINDEXED, lineno UNINDEXED, text UNINDEXED, tokens
);
"""


def _ensure_column(conn: sqlite3.Connection, table: str, col: str, decl: str) -> None:
    """Prototype-grade forward migration: add a column if an older db lacks it."""
    cols = {r["name"] for r in conn.execute(f"PRAGMA table_info({table})")}
    if col not in cols:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} {decl}")


def connect(db_path: str | Path) -> sqlite3.Connection:
    # timeout: wait for a lock instead of throwing at first contention —
    # a threading server opens one connection per request. WAL: readers
    # never block the writer (and vice versa), which matters on Windows
    # where several browser requests land at once.
    conn = sqlite3.connect(str(db_path), timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout = 30000")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.executescript(SCHEMA)
    _ensure_column(conn, "source_file", "application_id", "INTEGER")
    _ensure_column(conn, "exception_code", "category", "TEXT NOT NULL DEFAULT 'exception'")
    _ensure_column(conn, "playbook", "group_config", "TEXT NOT NULL DEFAULT '{}'")
    _ensure_column(conn, "playbook", "bundle_id", "INTEGER")
    # Pipeline membership (all nullable — a standalone app is one with no
    # pipeline). The flow is CONFIGURATION: stages are rows, data areas are
    # strings, so the next flow the shop describes is data entry, not code.
    _ensure_column(conn, "application", "pipeline", "TEXT")
    _ensure_column(conn, "application", "stage_seq", "INTEGER")
    # The business function's MI reporting prefix: source says U804, the
    # MI says A2U804. Declared on the application that OWNS the prefix, so
    # resolution and attribution come from the same fact.
    _ensure_column(conn, "application", "mi_prefix", "TEXT")
    _ensure_column(conn, "application", "stage_role", "TEXT")
    _ensure_column(conn, "application", "reads", "TEXT")    # JSON array
    _ensure_column(conn, "application", "writes", "TEXT")   # JSON array
    # lane: 'online' marks a pipeline's correction path — it belongs to the
    # pipeline but not to the step sequence; it feeds back INTO it.
    _ensure_column(conn, "application", "lane", "TEXT")
    _ensure_column(conn, "bms_field", "attrb", "TEXT")
    # How a JSON value converts into the COBOL field's bytes. Absent means
    # "text"; a wrong guess here plants invalid decimal data, so the shim
    # halts rather than assumes.
    _ensure_column(conn, "field_map", "format", "TEXT")
    # What a document IS — 'dfr' (per-application resolution evidence) or
    # 'policy' (global reference). Format cannot tell them apart; meaning
    # has to be declared, suggested at upload and confirmed by the analyst.
    _ensure_column(conn, "document", "kind", "TEXT")
    # Copybook-scoped seed maps: how the case JSON fills one field of an
    # interface area. Owned by the AREA (the 01-level), not by any
    # application or pipeline — true wherever the copybook appears.
    conn.execute("""CREATE TABLE IF NOT EXISTS area_map (
        id INTEGER PRIMARY KEY,
        area TEXT NOT NULL,
        cobol_field TEXT NOT NULL,
        json_path TEXT NOT NULL,
        format TEXT,
        notes TEXT,
        updated_by TEXT,
        updated_at TEXT,
        UNIQUE(area, cobol_field))""")
    for col, decl in (("color", "TEXT"), ("hilight", "TEXT"),
                      ("occurs", "INTEGER"), ("map_line", "INTEGER"),
                      ("map_col", "INTEGER")):
        _ensure_column(conn, "bms_field", col, decl)
    return conn


import re as _re

# Keys whose SCALAR values identify a person. Containers are recursed into
# even when their own key matches — redacting a whole `addresses` group
# would also destroy its effective/end dates, which recipe logic and the
# Investigate path both need to reason about.
_SENSITIVE_KEY = _re.compile(
    r"ssn|tin|tax|name|dob|birth|addr(?!ess(es)?$)|street|city|zip|postal"
    r"|phone|email|line\d",
    _re.I)


def redact(value, key: str = ""):
    """Strip identifying VALUES from a case payload, preserving structure.

    Used before anything is written to disk (Lab fixtures) or sent to a
    model (Investigate path). Shape, dates, codes and enumerations survive
    so check logic stays testable; names, SSNs, DOBs and street data do not.
    """
    if isinstance(value, dict):
        return {k: redact(v, k) for k, v in value.items()}
    if isinstance(value, list):
        return [redact(v, key) for v in value]
    if value is None or value == "":
        return value
    return "«redacted»" if _SENSITIVE_KEY.search(key or "") else value


def get_or_create_app(conn: sqlite3.Connection, name: str,
                      description: str | None = None) -> int:
    row = conn.execute("SELECT id FROM application WHERE name = ?", (name,)).fetchone()
    if row:
        return row["id"]
    cur = conn.execute(
        "INSERT INTO application (name, description, created_at) VALUES (?, ?, ?)",
        (name, description, now()))
    return cur.lastrowid


def now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def maintain(conn: sqlite3.Connection) -> None:
    """One-time-per-boot maintenance. NEVER call per request: connect()
    runs on every HTTP request under a threading server, and a write here
    is a lock collision waiting for two concurrent page loads — which is
    exactly how it failed on a real Windows install.

    Current duties: remove mined prose-mention links to sub-3-char codes
    (the letter-chip defect; the fixed matcher cannot create these rows —
    SME links untouched)."""
    conn.execute(
        """DELETE FROM exception_link WHERE relation = 'governed_by'
           AND provenance = 'mined'
           AND exception_id IN (SELECT id FROM exception_code
                                WHERE LENGTH(code) < 3)""")
    conn.commit()


def normalize_code(code: str) -> str:
    """Collapse format variants: E4417 / 4417 / ERR-4417 / err_4417 -> 4417.

    Rule: strip separators; if the tail is digits with a short alpha prefix,
    the digits are the identity. Pure-alpha codes (S0C7, ASRA) keep their
    compact uppercase form.
    """
    compact = "".join(ch for ch in code.upper() if ch.isalnum())
    i = 0
    while i < len(compact) and compact[i].isalpha():
        i += 1
    prefix, tail = compact[:i], compact[i:]
    if tail.isdigit() and tail and len(prefix) <= 4 and not (prefix and prefix[0] == "S"):
        # S0C7-style system codes keep the prefix; E4417-style app codes drop it.
        if prefix in ("SQLCODE",):
            return compact
        return tail
    return compact


def resolve_exception(conn: sqlite3.Connection, code: str) -> int | None:
    """The catalog entry this code refers to, through every declared
    equivalence: exact normalized match, then the alias table, then a
    registered reporting prefix (A2U804 → strip declared 'A2' → U804).
    Returns None when nothing declared matches — the caller decides
    whether to create a new entry. Never guesses: an undeclared prefix
    does not resolve."""
    norm = normalize_code(code)
    row = conn.execute("SELECT id FROM exception_code WHERE normalized = ?",
                       (norm,)).fetchone()
    if row:
        return row["id"]
    row = conn.execute("SELECT exception_id FROM code_alias WHERE alias = ?",
                       (norm,)).fetchone()
    if row:
        return row["exception_id"]
    compact = "".join(ch for ch in code.upper() if ch.isalnum())
    prefixes = [r["mi_prefix"] for r in conn.execute(
        "SELECT mi_prefix FROM application WHERE mi_prefix IS NOT NULL"
        " AND mi_prefix != ''")]
    prefixes += [r["prefix"] for r in conn.execute(
        "SELECT prefix FROM code_prefix")]
    for pfx in prefixes:
        pfx = pfx.upper()
        if compact.startswith(pfx) and len(compact) > len(pfx):
            rest = compact[len(pfx):]
            rid = resolve_exception(conn, rest)
            if rid is not None:
                # record the resolution so the next lookup is O(1) and the
                # code page can show "also reported as A2U804"
                conn.execute(
                    """INSERT OR IGNORE INTO code_alias
                       (alias, exception_id, source, created_at)
                       VALUES (?, ?, 'prefix', ?)""", (norm, rid, now()))
                return rid
    return None


def app_for_code_prefix(conn: sqlite3.Connection, code: str):
    """The application whose declared MI prefix this code wears, or None.
    A2U804 → the business function that registered 'A2' — free
    attribution for MI rows that carry no application column."""
    compact = "".join(ch for ch in code.upper() if ch.isalnum())
    for r in conn.execute(
            "SELECT name, mi_prefix FROM application"
            " WHERE mi_prefix IS NOT NULL AND mi_prefix != ''"):
        pfx = r["mi_prefix"].upper()
        if compact.startswith(pfx) and len(compact) > len(pfx):
            return r["name"]
    return None


def upsert_exception(conn: sqlite3.Connection, code: str, **fields) -> int:
    norm = normalize_code(code)
    row = conn.execute(
        "SELECT id FROM exception_code WHERE normalized = ?", (norm,)
    ).fetchone()
    if row:
        if fields:
            sets = ", ".join(f"{k} = ?" for k in fields)
            conn.execute(
                f"UPDATE exception_code SET {sets}, updated_at = ? WHERE id = ?",
                (*fields.values(), now(), row["id"]),
            )
        return row["id"]
    cols = {"code": code, "normalized": norm, "updated_at": now(), **fields}
    cur = conn.execute(
        f"INSERT INTO exception_code ({', '.join(cols)}) VALUES ({', '.join('?' * len(cols))})",
        tuple(cols.values()),
    )
    return cur.lastrowid


def add_link(conn, exception_id: int, target_kind: str, target_ref: str,
             relation: str, detail: dict | None = None,
             confidence: float = 0.5, provenance: str = "mined") -> None:
    conn.execute(
        """INSERT INTO exception_link
           (exception_id, target_kind, target_ref, relation, detail,
            confidence, provenance, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (exception_id, target_kind, target_ref, relation,
         json.dumps(detail or {}), confidence, provenance, now()),
    )


def add_event(conn, exception_id: int, kind: str, outcome: str | None = None,
              payload: dict | None = None, actor: str | None = None,
              ts: str | None = None) -> None:
    conn.execute(
        """INSERT INTO exception_event (exception_id, kind, outcome, payload, actor, ts)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (exception_id, kind, outcome, json.dumps(payload or {}), actor, ts or now()),
    )


def exception_stats(conn, exception_id: int) -> dict:
    """Computed, never stored: the event log is the source of truth. MI rows
    carry their own counts, so they weigh by count, not by row."""
    stats = {"occurrences": 0, "runs": 0, "lookups": 0, "resolutions": 0, "resolved": 0}
    stats["occurrences"] += conn.execute(
        "SELECT COALESCE(SUM(CAST(json_extract(payload, '$.count') AS INTEGER)), 0)"
        " FROM exception_event WHERE exception_id = ? AND kind = 'mi'",
        (exception_id,)).fetchone()[0]
    rows = conn.execute(
        "SELECT kind, outcome, COUNT(*) AS n FROM exception_event"
        " WHERE exception_id = ? GROUP BY kind, outcome", (exception_id,)
    ).fetchall()
    for r in rows:
        if r["kind"] == "occurrence":
            stats["occurrences"] += r["n"]
        elif r["kind"] == "run":
            stats["runs"] += r["n"]
        elif r["kind"] == "lookup":
            stats["lookups"] += r["n"]
        elif r["kind"] == "resolution":
            stats["resolutions"] += r["n"]
            if r["outcome"] == "resolved":
                stats["resolved"] += r["n"]
    stats["success_rate"] = (
        round(100.0 * stats["resolved"] / stats["resolutions"])
        if stats["resolutions"] else None
    )
    return stats
