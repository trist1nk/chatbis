"""ChatBIS — the DFR assembler: deterministic skeleton, model prose.

For a document that must be COMPLETE, the model is the wrong author —
the miner already extracted every rule, and a 300-rule module must not
be truncated to fit a context window. So the requirements body is
assembled deterministically from the full mined profile (every rule,
any size, milliseconds), and the model contributes only the connective
prose: one bounded module-description paragraph. If the model is
offline, the draft still assembles whole — the description slot says
so instead.

The output is a markdown DRAFT, clearly marked, for SME review. It is
never written into the document library; ingestion stays the only door
and it is human-operated.
"""
from __future__ import annotations

import json
import re

from .investigate import exec_describe_program, llm_chat

PROSE_PROMPT = (
    "Write ONE paragraph (90 words max) describing what the {name} "
    "module does, for the opening of a requirements document. Use only "
    "these mined facts, invent nothing:\n{facts}\nOutput only the "
    "paragraph."
)

SUMMARY_PROMPT = (
    "Write the 'Requirements summary' for a requirements document about "
    "the {name} module: one or two paragraphs, 130 words max, no "
    "heading. Below is the COMPLETE digest of its mined rules "
    "(condition -> code, grouped by paragraph). Summarize what the "
    "module enforces — the major groups of checks, the fields they "
    "guard, the most consequential rejections. Invent nothing:\n"
    "{digest}\nOutput only the text."
)


def rules_digest(prof: dict, budget_chars: int = 9000) -> str:
    """Every mined rule, compressed to 'condition -> code' lines grouped
    by paragraph — small enough for the model to see the WHOLE module
    while writing the summary. Over budget, groups keep their honest
    counts and drop tail entries with '+N more'."""
    groups: dict[str, list] = {}
    for r in prof.get("business_rules", []):
        groups.setdefault(r.get("paragraph") or "(main)", []).append(r)

    def render(per_group: int | None) -> str:
        lines = [f"{len(prof.get('business_rules', []))} rules across "
                 f"{len(groups)} paragraphs"]
        for para, rs in groups.items():
            shown = rs if per_group is None else rs[:per_group]
            entries = []
            for r in shown:
                e = r.get("when") or "(untranslated)"
                if r.get("code"):
                    e += f" -> {r['code']}"
                entries.append(e)
            more = ("" if len(shown) == len(rs)
                    else f" (+{len(rs) - len(shown)} more)")
            lines.append(f"{para} ({len(rs)}): "
                         + "; ".join(entries) + more)
        return "\n".join(lines)

    text = render(None)
    if len(text) > budget_chars:
        text = render(4)
    if len(text) > budget_chars:
        text = text[:budget_chars] + "\n[digest truncated]"
    return text


def _ask(cfg: dict, prompt: str) -> str | None:
    try:
        msg = llm_chat(cfg, [{"role": "user", "content": prompt}], [])
        return (msg.get("content") or "").strip() or None
    except Exception:
        return None


def build_prose(cfg: dict | None, prof: dict) -> str | None:
    """The one model-written paragraph. Bounded, fail-soft: any error
    returns None and the assembled draft says the description is
    pending — a missing paragraph must never block a complete draft."""
    if not cfg:
        return None
    facts = {
        "application": prof.get("application"),
        "copies": prof.get("copies"), "calls": prof.get("calls"),
        "sql_tables": prof.get("sql_tables"),
        "batch_jobs": prof.get("batch_jobs"),
        "codes": [c["code"] for c in prof.get("codes_raised_or_set", [])][:10],
        "sample_rules": [r["when"] for r in prof.get("business_rules", [])[:6]],
    }
    return _ask(cfg, PROSE_PROMPT.format(name=prof["program"],
                                         facts=facts))


def build_summary(cfg: dict | None, prof: dict) -> str | None:
    """The requirements-summary section — model-written from the full
    compressed rule digest. Bounded and fail-soft like the
    description."""
    if not cfg or not prof.get("business_rules"):
        return None
    return _ask(cfg, SUMMARY_PROMPT.format(
        name=prof["program"], digest=rules_digest(prof)))


def _fmt(items: dict, var: str) -> str:
    """`WS-SSN` (X(9), 9 bytes) — the field with its declared format,
    when the data dictionary knows it; bare name otherwise."""
    it = items.get(var.upper())
    if not it:
        return f"`{var}`"
    bits = []
    if it["pic"]:
        bits.append(it["pic"])
    elif it["item_type"]:
        bits.append(it["item_type"])
    if it["length"]:
        bits.append(f"{it['length']} bytes")
    return f"`{var}`" + (f" ({', '.join(bits)})" if bits else "")


def _vars_in(span: str) -> list[str]:
    seen, out = set(), []
    for v in re.findall(r":([A-Za-z0-9-]+)", span):
        if v.upper() not in seen:
            seen.add(v.upper())
            out.append(v)
    return out


def _io_sections(conn, prog_id: int) -> tuple[list, list, list]:
    """(inputs, outputs, messages) — every data source the program
    reads, every destination it writes, straight from the source
    facets, with field formats from the data dictionary."""
    items = {row["name"].upper(): row for row in conn.execute(
        "SELECT name, pic, item_type, length FROM data_item"
        " WHERE program_id = ?", (prog_id,))}
    inputs: list[str] = []
    outputs: list[str] = []
    messages: list[str] = []
    for f in conn.execute(
            "SELECT kind, ref, detail FROM program_facet"
            " WHERE program_id = ? AND kind IN"
            " ('sql','file','cics','idms','message') ORDER BY id",
            (prog_id,)):
        d = json.loads(f["detail"] or "{}")
        kind, ref = f["kind"], f["ref"]
        if kind == "sql":
            t = " ".join((d.get("text") or "").split())
            m = re.search(r"EXEC SQL\s+(\w+)", t, re.I)
            verb = (m.group(1).upper() if m else "")
            if verb in ("SELECT", "FETCH"):
                cols = ""
                mc = re.search(r"SELECT\s+(.*?)\s+INTO\s", t, re.I)
                if mc:
                    cols = mc.group(1)
                mi = re.search(r"\sINTO\s+(.*?)(?:\s+FROM\s|$)", t, re.I)
                recv = _vars_in(mi.group(1)) if mi else []
                line = f"- **DB2 `{ref}`** — reads {cols or 'row'}"
                if recv:
                    line += " into " + ", ".join(
                        _fmt(items, v) for v in recv)
                inputs.append(line)
            elif verb in ("INSERT", "UPDATE", "DELETE"):
                cols: list[str] = []
                if verb == "INSERT":
                    mc = re.search(r"INTO\s+[\w.]+\s*\(([^)]*)\)", t, re.I)
                    if mc:
                        cols = [c.strip() for c in mc.group(1).split(",")]
                elif verb == "UPDATE":
                    cols = re.findall(r"([\w_]+)\s*=\s*:", t)
                srcs = _vars_in(t)
                line = f"- **DB2 `{ref}`** — {verb}"
                if cols:
                    line += " of " + ", ".join(cols)
                if srcs:
                    line += " from " + ", ".join(
                        _fmt(items, v) for v in srcs)
                outputs.append(line)
        elif kind == "file":
            ops = [o.get("op", "") for o in d.get("ops", [])]
            rec = next((o.get("target") for o in d.get("ops", [])
                        if o.get("target")), None)
            tag = f"- **File `{ref}`**"
            if d.get("logical"):
                tag += f" (`{d['logical']}`" + (
                    f", {d['org'].lower()})" if d.get("org") else ")")
            if any(o in ("read", "open-input", "start") for o in ops):
                inputs.append(tag + " — read"
                              + (f", record {_fmt(items, rec)}" if rec
                                 else ""))
            if any(o in ("write", "rewrite", "open-output",
                         "open-extend") for o in ops):
                outputs.append(tag + " — writes record "
                               + (_fmt(items, rec) if rec else "(see source)"))
        elif kind == "cics":
            op = (d.get("op") or "").lower()
            ms = f" (mapset `{d['mapset']}`)" if d.get("mapset") else ""
            if op == "receive-map":
                inputs.append(f"- **Screen `{ref}`** — CICS RECEIVE MAP{ms}")
            elif op == "send-map":
                outputs.append(f"- **Screen `{ref}`** — CICS SEND MAP{ms}")
        elif kind == "idms":
            op = (d.get("op") or "").lower()
            q = f" {d['qualifier']}" if d.get("qualifier") else ""
            if op in ("obtain", "find"):
                inputs.append(f"- **IDMS `{ref}`** — {op.upper()}{q}")
            elif op in ("modify", "store", "erase", "connect"):
                outputs.append(f"- **IDMS `{ref}`** — {op.upper()}")
        elif kind == "message":
            where = (f" _(paragraph `{d['paragraph']}`)_"
                     if d.get("paragraph") else "")
            messages.append(f"- \"{d.get('text', '')}\" — {ref}{where}")
    return inputs, outputs, messages


def assemble_dfr(conn, name: str, cfg: dict | None = None,
                 with_prose: bool = True) -> tuple[str | None, str | None]:
    """(markdown, error). Every rule becomes a numbered business rule —
    no cap, no window; the sections that must be complete are built
    without the model in the loop."""
    prof = exec_describe_program(conn, name, rule_limit=None)
    if "error" in prof:
        return None, prof["error"]
    prog_id = conn.execute(
        "SELECT id FROM program WHERE UPPER(name) = UPPER(?)",
        (name,)).fetchone()["id"]
    inputs, outputs, messages = _io_sections(conn, prog_id)
    prose = build_prose(cfg, prof) if with_prose else None
    summary = build_summary(cfg, prof) if with_prose else None

    L: list[str] = []
    w = L.append
    w(f"# DFR — {prof['program']} (DRAFT)")
    w("")
    w("> **DRAFT — for SME review.** Sections 3–7 are derived directly "
      "from the program source.")
    w("")
    meta = [f"**Program:** {prof['program']}"]
    if prof.get("application"):
        meta.append(f"**Application:** {prof['application']}")
    if prof.get("file"):
        meta.append(f"**Source member:** {prof['file']}")
    w(" · ".join(meta))
    w("")
    w("## 1. Description")
    w("")
    w(prose if prose else
      "_Description pending — fill in during review, or reassemble "
      "with the model online._")
    w("")
    w("## 2. Summary")
    w("")
    w(summary if summary else
      "_Summary pending — fill in during review, or reassemble with "
      "the model online._")
    w("")
    w("## 3. Input data")
    w("")
    if inputs:
        L.extend(inputs)
    else:
        w("_None identified in the program source._")
    w("")
    w("## 4. Output data and format")
    w("")
    if outputs:
        L.extend(outputs)
    else:
        w("_None identified in the program source._")
    if messages:
        w("")
        w("**Messages issued:**")
        w("")
        L.extend(messages)
    w("")
    w("## 5. Business rules")
    w("")
    rules = prof.get("business_rules", [])
    if rules:
        w(f"_{len(rules)} rules — complete set._")
        w("")
    else:
        w("_None identified in the program source._")
    meanings = {c["code"]: c["meaning"]
                for c in prof.get("codes_raised_or_set", [])}
    for i, r in enumerate(rules, 1):
        w(f"### R-{i:03d}")
        w(f"- **When:** {r.get('when') or '(see program source)'}")
        acts = r.get("actions") or []
        if acts:
            w(f"- **Then:** {'; '.join(acts)}")
        if r.get("code"):
            mean = meanings.get(r["code"])
            w(f"- **Raises:** `{r['code']}`"
              + (f" — {mean}" if mean else ""))
        if r.get("paragraph"):
            w(f"- **Where:** paragraph `{r['paragraph']}`")
        w("")
    w("## 6. Interfaces and dependencies")
    w("")

    def inv(label, deps):
        w(f"- **{label}:** " + (", ".join(
            f"`{x}`" for x in deps) if deps else "none"))
    inv("Copybooks", prof.get("copies"))
    inv("Called programs", prof.get("calls"))
    inv("SQL tables", prof.get("sql_tables"))
    inv("CICS", prof.get("cics"))
    jobs = [f"`{j['job']}` step `{j['step']}`"
            for j in prof.get("batch_jobs", [])]
    w("- **Batch schedule:** " + (", ".join(jobs) if jobs else "none"))
    w("")
    w("## 7. Exception codes")
    w("")
    codes = prof.get("codes_raised_or_set", [])
    if codes:
        w("| Code | Meaning |")
        w("|------|---------|")
        for c in codes:
            w(f"| `{c['code']}` | {c['meaning'] or '—'} |")
    else:
        w("_None raised or set by this module._")
    w("")
    w("---\n_Assembled by ChatBIS — draft for SME review._")
    return "\n".join(L), None
