"""ChatBIS — BMS mapset miner.

A BMS mapset is the screen as source: DFHMSD names the mapset, DFHMDI each
map (one screen), DFHMDF each field — position, length, initial value. A
LABELED field generates symbolic-map names (label + I/O/L/A suffixes) that
the COBOL program MOVEs from, which is the joint between the analyst's
keystroke and the flow graph.

Assembler macro format: label in column 1, continuation by trailing comma
with the next line indented. Pattern-based; unlabeled constants (screen
literals) are kept as labels of the screen, not fields.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

RE_POS = re.compile(r"\bPOS=\((\d+),(\d+)\)", re.I)
RE_LEN = re.compile(r"\bLENGTH=(\d+)", re.I)
RE_INITIAL = re.compile(r"\bINITIAL='([^']*)'", re.I)
RE_ATTRB = re.compile(r"\bATTRB=\(?([A-Z,]+)\)?", re.I)
RE_COLOR = re.compile(r"\bCOLOR=([A-Z]+)", re.I)
RE_HILIGHT = re.compile(r"\bHILIGHT=([A-Z]+)", re.I)
RE_OCCURS = re.compile(r"\bOCCURS=(\d+)", re.I)
RE_LINE = re.compile(r"\bLINE=(\d+)", re.I)
RE_COLUMN = re.compile(r"\bCOLUMN=(\d+)", re.I)
RE_SIZE = re.compile(r"\bSIZE=\((\d+),(\d+)\)", re.I)


@dataclass
class BmsField:
    name: str                # the DFHMDF label ('' for constants)
    row: int | None
    col: int | None
    length: int | None
    initial: str | None      # screen literal, when present
    lineno: int
    attrb: str | None = None # ASKIP,BRT / UNPROT,NUM,IC — verbatim
    color: str | None = None # COLOR= extended attribute
    hilight: str | None = None   # HILIGHT= REVERSE | UNDERLINE | BLINK
    occurs: int | None = None    # OCCURS= repeated fields


@dataclass
class BmsMap:
    name: str
    line: int = 1            # DFHMDI LINE= — where the map sits on screen
    column: int = 1
    rows: int | None = None  # DFHMDI SIZE=(rows,cols)
    cols: int | None = None
    fields: list[BmsField] = field(default_factory=list)


@dataclass
class BmsMapset:
    name: str | None = None
    maps: list[BmsMap] = field(default_factory=list)


def looks_like_bms(text: str) -> bool:
    u = text.upper()
    return "DFHMSD" in u and "DFHMDF" in u


def _statements(lines: list[str]) -> list[tuple[int, str]]:
    """Assembler statements. The REAL continuation rule: any non-blank in
    column 72 continues the statement, and the continuation text resumes at
    column 16 — which is how a quoted INITIAL='...' can span lines. The
    trailing-comma heuristic is kept as a fallback for members whose column
    72 didn't survive an editor."""
    out: list[tuple[int, str]] = []
    i = 0
    while i < len(lines):
        raw = lines[i]
        i += 1
        if not raw.strip() or raw.lstrip().startswith("*"):
            continue
        body = raw[:71]
        cont = bool(raw[71:72].strip())
        lineno = i
        while (cont or body.rstrip().endswith(",")) and i < len(lines):
            nxt = lines[i]
            if not nxt.strip() or nxt.lstrip().startswith("*"):
                break
            i += 1
            if cont:
                # Column-72 continuation: literal splice from column 16 —
                # no separator, so quoted strings survive intact.
                body = body + nxt[15:71].rstrip()
            else:
                body = body.rstrip() + nxt[:71].strip()
            cont = bool(nxt[71:72].strip())
        out.append((lineno, body.rstrip()))
    return out


def parse_bms(text: str) -> BmsMapset:
    ms = BmsMapset()
    cur: BmsMap | None = None
    for lineno, body in _statements(text.split("\n")):
        has_label = not body[:1].isspace()
        stripped = body.strip()
        parts = stripped.split(None, 2)
        if not parts:
            continue
        # rest must be the WHOLE remainder — splitting on whitespace would
        # cut a quoted INITIAL='BENE DOB:' at its embedded space.
        if has_label and len(parts) >= 2:
            label, op = parts[0].upper(), parts[1].upper()
            after = stripped.find(parts[1]) + len(parts[1])
            rest = stripped[after:].strip()
        else:
            label, op = "", parts[0].upper()
            rest = stripped[len(parts[0]):].strip()
        if op == "DFHMSD":
            if ms.name is None:
                ms.name = label or None
        elif op == "DFHMDI":
            ln = RE_LINE.search(rest)
            cl = RE_COLUMN.search(rest)
            sz = RE_SIZE.search(rest)
            cur = BmsMap(label or f"MAP{len(ms.maps) + 1}",
                         line=int(ln.group(1)) if ln else 1,
                         column=int(cl.group(1)) if cl else 1,
                         rows=int(sz.group(1)) if sz else None,
                         cols=int(sz.group(2)) if sz else None)
            ms.maps.append(cur)
        elif op == "DFHMDF" and cur is not None:
            pos = RE_POS.search(rest)
            ln = RE_LEN.search(rest)
            init = RE_INITIAL.search(rest)
            at = RE_ATTRB.search(rest)
            co = RE_COLOR.search(rest)
            hi = RE_HILIGHT.search(rest)
            oc = RE_OCCURS.search(rest)
            cur.fields.append(BmsField(
                label, int(pos.group(1)) if pos else None,
                int(pos.group(2)) if pos else None,
                int(ln.group(1)) if ln else None,
                init.group(1) if init else None, lineno,
                at.group(1).upper() if at else None,
                co.group(1).upper() if co else None,
                hi.group(1).upper() if hi else None,
                int(oc.group(1)) if oc else None))
    return ms
