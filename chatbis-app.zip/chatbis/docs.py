"""ChatBIS prototype — DFR / document ingestion.

Splits documents into sections and finds explicit exception-code mentions
for rule-level linking (spec §5.3: the governing DFR links at RULE level,
explicit mentions are highest confidence).

.docx needs no third-party library: it is a ZIP containing
word/document.xml — stdlib zipfile + ElementTree read it fine. PDFs are
out of prototype scope (convert to text first).
"""
from __future__ import annotations

import io
import re
import xml.etree.ElementTree as ET
import zipfile

from .mine import RE_CODE_IN_TEXT

RE_MD_HEADING = re.compile(r"^(#{1,4})\s+(.+?)\s*$")
# "3.1 Beneficiary validation" style headings in plain-text DFRs.
RE_NUM_HEADING = re.compile(r"^(\d+(?:\.\d+)*)\s+(.{3,80})$")

_W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def extract_docx(raw: bytes) -> str:
    """Flatten a .docx to text; Heading-styled paragraphs become '# ' lines
    so the same section splitter serves every doc type."""
    out: list[str] = []
    with zipfile.ZipFile(io.BytesIO(raw)) as zf:
        root = ET.fromstring(zf.read("word/document.xml"))
    for para in root.iter(f"{_W}p"):
        text = "".join(t.text or "" for t in para.iter(f"{_W}t")).strip()
        if not text:
            continue
        style = para.find(f"{_W}pPr/{_W}pStyle")
        if style is not None and (style.get(f"{_W}val") or "").startswith("Heading"):
            out.append(f"# {text}")
        else:
            out.append(text)
    return "\n".join(out)


def split_sections(text: str) -> list[tuple[str, str]]:
    """[(heading, body)]. Headings: markdown #s, '3.1 Title' numbering, or
    short ALL-CAPS lines. Preamble before any heading becomes one section."""
    sections: list[tuple[str, list[str]]] = []
    current = ("(preamble)", [])
    for line in text.split("\n"):
        stripped = line.strip()
        m = RE_MD_HEADING.match(stripped)
        heading = None
        if m:
            heading = m.group(2)
        elif RE_NUM_HEADING.match(stripped):
            nm = RE_NUM_HEADING.match(stripped)
            heading = f"{nm.group(1)} {nm.group(2)}"
        elif (stripped and stripped == stripped.upper() and 3 < len(stripped) < 70
              and stripped[0].isalpha() and not stripped.endswith(".")):
            heading = stripped.title()
        if heading is not None:
            if current[1] or current[0] != "(preamble)":
                sections.append(current)
            current = (heading, [])
        else:
            current[1].append(line)
    sections.append(current)
    return [(h, "\n".join(body).strip()) for h, body in sections
            if "\n".join(body).strip() or h != "(preamble)"]


def find_code_mentions(text: str, known: dict[str, str]) -> set[str]:
    """Normalized codes explicitly mentioned in a section. `known` maps
    normalized -> display code for everything already in the catalog; the
    generic pattern also catches codes the DFR names before the code does.

    Two hard rules, learned from a real policy render where every letter
    I/E/A in the prose lit up as a "mention" of a one-letter RFA code:
    - a code shorter than 3 characters is NOT prose-detectable — every
      sentence contains it. Short codes stay in the catalog and can be
      linked by an SME's hand; scanning for them is refused.
    - matches are whole-token, never substring: REC must not fire inside
      RECORD, nor E4417 inside XE4417Y."""
    from .db import normalize_code
    found: set[str] = set()
    upper = text.upper()
    for m in RE_CODE_IN_TEXT.finditer(upper):
        found.add(normalize_code(m.group(1)))
    for norm, code in known.items():
        c = code.upper().strip()
        if len(c) < 3:
            continue
        if re.search(r"(?<![A-Z0-9-])" + re.escape(c) + r"(?![A-Z0-9-])",
                     upper):
            found.add(norm)
    return found
