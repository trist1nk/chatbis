"""ChatBIS prototype — the web UI, on stdlib http.server (nothing to install).

Screens (spec §11): triage entry, resolution page, log-resolution form,
curation form (the analyst's investigation lands in the catalog), search,
source viewer, program detail (analyze path), applications, dashboard.
Every lookup is auto-logged as an event — frequency data starts accruing
before anyone logs a single resolution.
"""
from __future__ import annotations

import base64
import csv
import email.parser
import email.policy
import hashlib
import subprocess
import html
subprocess
hashlib
import io
import json
import os
import re
import secrets
import sqlite3
import threading
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from . import db
from .docs import find_code_mentions
from .draft import draft_checks, walk_paths
from .ingest import ingest_paths
from .jcl import gdg_base as jcl_gdg_base
from .dbsource import run_query as run_db_query
from . import investigate
from .dfr_draft import assemble_dfr
from .mbr import project_case
from .mine import query_tokens
from .recipe import (OPS, SCOPES, _MISSING, check_fires, get_path,
                     occurrences, pick_latest, run_recipe)
from .xlsx import (coerce_period, guess_field_columns, guess_mapping,
                   read_field_map, read_table)

MAX_UPLOAD = 100 * 1024 * 1024  # 100 MB per request

RE_PLACEHOLDER = re.compile(r"\{([a-zA-Z0-9_]+)\}")
SENSITIVE_PARAM = re.compile(r"ssn|tax|tin", re.I)


def mask_value(name: str, value: str) -> str:
    if SENSITIVE_PARAM.search(name) and len(value) > 4:
        return "•••" + value[-4:]
    return value


def parse_multipart(content_type: str, body: bytes) -> list[tuple[str, bytes]]:
    """(filename, payload) pairs from a multipart/form-data body. Stdlib
    email parser — the cgi module is gone in Python 3.13, and this stays
    3.9-compatible."""
    if "multipart/form-data" not in (content_type or ""):
        return []
    raw = (b"Content-Type: " + content_type.encode() + b"\r\nMIME-Version: 1.0\r\n\r\n"
           + body)
    msg = email.parser.BytesParser(policy=email.policy.default).parsebytes(raw)
    out: list[tuple[str, bytes]] = []
    for part in msg.iter_parts():
        name = part.get_filename()
        if not name:
            continue
        # Basename only, and nothing that could walk the artifact dir.
        safe = re.sub(r"[^A-Za-z0-9._@ -]", "_", Path(name).name).strip()
        payload = part.get_payload(decode=True) or b""
        if safe and payload:
            out.append((safe, payload))
    return out

PAGE = """<!doctype html><html><head><meta charset="utf-8">
<title>{title} · ChatBIS</title>
<link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'><rect width='32' height='32' rx='7' fill='%23122a43'/><text x='16' y='23' font-size='20' font-weight='700' text-anchor='middle' fill='%23e8b64c' font-family='Arial'>C</text></svg>">
<style>
 :root {{ --ink:#1a2433; --muted:#6b7789; --line:#e7eaef; --navy:#13273f;
         --navy-2:#0d1d31; --link:#2e5488; --gold:#c9971c; --gold-soft:#e8b64c;
         --green:#2e9e5b; --red:#cf4545; --amber:#cf8a12; --violet:#7a5cd6; }}
 * {{ box-sizing:border-box; }}
 body {{ font-family: -apple-system, 'Segoe UI', ui-sans-serif, sans-serif;
        margin:0; background:#f4f5f7; color:var(--ink); font-size:15px;
        -webkit-font-smoothing:antialiased; }}
 header {{ background:linear-gradient(180deg, var(--navy) 0%, var(--navy-2) 100%);
          color:#fff; border-bottom:1px solid rgba(232,182,76,.25); }}
 .nav {{ max-width:1060px; margin:0 auto; padding:0 20px; height:60px;
        display:flex; align-items:center; gap:2px; }}
 .nav .brand {{ font-weight:800; font-size:18px; color:#fff; margin-right:22px;
               letter-spacing:.2px; }}
 .nav .brand span {{ color:var(--gold-soft); }}
 .nav a {{ color:#a9bdd6; text-decoration:none; font-weight:600; font-size:13.5px;
          padding:7px 11px; border-radius:8px; letter-spacing:.01em;
          white-space:nowrap; }}
 .nav a:hover {{ background:rgba(255,255,255,.08); color:#fff; }}
 .nav a.active {{ background:rgba(232,182,76,.14); color:var(--gold-soft); }}
 .nav form {{ margin-left:auto; }}
 .nav input {{ padding:8px 14px; border-radius:9px; width:210px; font-size:13px;
              background:rgba(255,255,255,.1); color:#fff;
              border:1px solid rgba(255,255,255,.12); }}
 .nav input::placeholder {{ color:#8ba1bd; }}
 .nav input:focus {{ background:#fff; color:var(--ink); outline:none;
                    border-color:var(--gold-soft); }}
 main {{ max-width:1060px; margin:28px auto 64px; padding:0 20px; }}
 a {{ color:var(--link); text-decoration:none; }}
 a:hover {{ text-decoration:underline; }}
 a:visited {{ color:var(--link); }}
 .card {{ background:#fff; border:1px solid var(--line); border-radius:14px;
         padding:20px 24px; margin-bottom:18px;
         box-shadow:0 1px 2px rgba(15,23,42,.04), 0 1px 1px rgba(15,23,42,.03); overflow-x:auto; }}
 h1 {{ font-size:23px; margin:0 0 6px; letter-spacing:-.3px; }}
 h2 {{ font-size:11.5px; text-transform:uppercase; letter-spacing:.11em;
      color:var(--muted); margin:2px 0 14px; font-weight:700; }}
 .badge {{ display:inline-block; border-radius:999px; padding:2px 10px; font-size:11px;
          font-weight:700; margin-left:8px; vertical-align:2px; letter-spacing:.03em; }}
 .curated {{ background:#e3f2e8; color:#1e6b3d; }}
 .imported {{ background:#e3ecf8; color:#2c5687; }}
 .inferred {{ background:#f7ecd4; color:#8a6410; }}
 .exception {{ background:#f9e5e5; color:#a63838; }}
 .alert {{ background:#f8efd4; color:#8a6410; }}
 .limitation {{ background:#ece6fa; color:#5b3fb8; }}
 .resolved {{ background:#e3f2e8; color:#1e6b3d; }}
 .escalated {{ background:#f8efd4; color:#8a6410; }}
 .reprocessed {{ background:#e3ecf8; color:#2c5687; }}
 .failed {{ background:#f9e5e5; color:#a63838; }}
 pre {{ background:#101f31; color:#cde0f5; padding:14px 16px; border-radius:10px;
       overflow-x:auto; font-size:13px; line-height:1.55;
       border:1px solid #1d3450; }}
 .cond {{ color:#f0c568; }}
 table {{ border-collapse:collapse; width:100%; }}
 th {{ padding:8px 12px; text-align:left; font-size:11px; text-transform:uppercase;
      letter-spacing:.09em; color:var(--muted); border-bottom:1px solid var(--line); }}
 td {{ padding:9.5px 12px; border-bottom:1px solid #f1f3f6; font-size:14px; }}
 tr:last-child td {{ border-bottom:none; }}
 tr:hover td {{ background:#f8f9fb; }}
 td.num, th.num {{ text-align:right; font-variant-numeric:tabular-nums; }}
 .stat {{ display:inline-block; margin-right:24px; }}
 .stat b {{ font-size:21px; display:block; letter-spacing:-.5px; }}
 .muted {{ color:var(--muted); font-size:13px; }}
 .quote {{ border-left:3px solid var(--gold); padding:8px 14px; background:#faf7ef;
          font-size:14px; margin:6px 0; border-radius:0 8px 8px 0; }}
 .kpis {{ display:grid; grid-template-columns:repeat(4,1fr); gap:16px; margin-bottom:18px; }}
 .kpi {{ background:#fff; border:1px solid var(--line); border-radius:14px;
        padding:18px 20px 16px;
        box-shadow:0 1px 2px rgba(15,23,42,.04), 0 1px 1px rgba(15,23,42,.03); }}
 .kpi .big {{ font-size:33px; font-weight:800; letter-spacing:-1.2px;
             font-variant-numeric:tabular-nums; line-height:1.1; }}
 .kpi .lbl {{ font-size:11px; text-transform:uppercase; letter-spacing:.1em;
             color:var(--muted); font-weight:700; margin-bottom:8px; }}
 .kpi .sub {{ font-size:12.5px; color:var(--muted); margin-top:8px; line-height:1.7; }}
 .dot {{ display:inline-block; width:8px; height:8px; border-radius:50%;
        margin-right:6px; vertical-align:1px; }}
 .d-exception {{ background:var(--red); }} .d-alert {{ background:var(--amber); }}
 .d-status {{ background:#3c7edb; }} .d-reason {{ background:#2ea08a; }}
 .d-suspension {{ background:#3c7edb; }} .d-termination {{ background:#7a5cd6; }}
 .d-indicator {{ background:#2ea08a; }}
 .d-limitation {{ background:var(--violet); }}
 .track {{ background:#edeff3; border-radius:999px; height:7px; overflow:hidden;
          margin:7px 0 3px; }}
 .fill {{ height:100%; border-radius:999px; background:#3d5f8f; }}
 .fill.green {{ background:var(--green); }} .fill.gold {{ background:var(--gold); }}
 .abar {{ display:flex; align-items:center; gap:10px; justify-content:flex-end; }}
 .abar .track {{ width:110px; margin:0; flex:none; }}
 .abar b {{ font-variant-numeric:tabular-nums; font-weight:600; min-width:2ch;
           text-align:right; }}
 input[type=text], select, textarea {{ padding:9px 12px; border:1px solid #ccd4de;
   border-radius:9px; width:100%; margin:4px 0 10px; font-size:14px; background:#fff; }}
 input[type=text]:focus, select:focus {{ outline:2px solid #dbc99a; border-color:var(--gold); }}
 button {{ background:var(--navy); color:#fff; border:none; border-radius:9px;
   padding:10px 20px; font-weight:600; cursor:pointer; font-size:14px; }}
 button:hover {{ background:#1c3c60; }}
 details summary {{ cursor:pointer; font-weight:600; color:#33506e; }}
 mark {{ background:#ffe9a8; }}
 code {{ background:#f1f4f8; border-radius:5px; padding:1px 5px; font-size:13px; }}
 .btnlink {{ display:inline-block; background:var(--navy); color:#fff; border-radius:9px;
            padding:9px 18px; font-weight:600; font-size:14px; }}
 .btnlink:hover {{ background:#1c3c60; text-decoration:none; color:#fff; }}
 .btnlink:visited {{ color:#fff; }}
 .banner {{ background:#d9f2e0; color:#116633; border:1px solid #b7e4c7;
           border-radius:12px; padding:12px 18px; margin-bottom:14px; font-weight:600; }}
 .cardhead {{ display:flex; align-items:center; justify-content:space-between;
             margin-bottom:10px; }}
 .cardhead h1 {{ margin:0; }}
 .crumbs {{ display:flex; align-items:center; gap:12px; margin-bottom:14px;
           font-size:13.5px; color:var(--muted); }}
 .backbtn {{ background:#fff; border:1px solid var(--line); border-radius:9px;
            padding:6px 14px; font-weight:600; color:#33506e;
            box-shadow:0 1px 1px rgba(16,24,40,.04); }}
 .backbtn:hover {{ text-decoration:none; background:#f3f7fc; }}
 .sep {{ color:#a9b6c2; }}
 .herowrap {{ border:1px solid var(--line); border-radius:14px; overflow:hidden;
             background:#fff; box-shadow:0 1px 2px rgba(15,32,54,.04),
             0 8px 24px rgba(15,32,54,.05); margin-bottom:18px; }}
 .apphero {{ background:linear-gradient(132deg,#0c1d30 0%,#123152 58%,#17436b 100%);
            padding:24px 28px 22px; position:relative; }}
 .apphero::after {{ content:''; position:absolute; left:0; right:0; bottom:0;
            height:2px; background:linear-gradient(90deg,#c9a44b,#e6cd8a 40%,
            rgba(201,164,75,.12)); }}
 .apphero h1 {{ color:#fff; margin:10px 0 4px; font-size:27px;
            letter-spacing:.015em; }}
 .herosub {{ color:#9db4cd; font-size:13px; }}
 .herostage {{ display:flex; align-items:center; gap:12px; flex-wrap:wrap; }}
 .heropill {{ display:inline-block; background:rgba(217,180,92,.13);
            border:1px solid rgba(217,180,92,.42); color:#e6cd8a;
            border-radius:999px; padding:3.5px 13px; font-size:11px;
            font-weight:800; letter-spacing:.09em; }}
 .heropill-role {{ color:#cfdcea; font-size:12.5px; font-weight:700;
            letter-spacing:.03em; text-transform:lowercase; }}
 .stagedots {{ display:inline-flex; gap:6px; align-items:center;
            margin-left:2px; }}
 .sdot {{ width:8px; height:8px; border-radius:50%;
          background:rgba(255,255,255,.24); transition:all .15s; }}
 .sdot:hover {{ background:rgba(255,255,255,.55); transform:scale(1.25); }}
 .sdot.cur {{ width:22px; border-radius:5px; background:#d9b45c;
          box-shadow:0 0 0 3px rgba(217,180,92,.18); }}
 .heroseam {{ color:#8fa9c4; font-size:12.5px; margin-top:9px; }}
 .miprefix {{ display:flex; gap:8px; align-items:center; margin:10px 0 0; }}
 .miprefix input {{ width:64px; margin:0; padding:4px 9px; font-size:12.5px;
            background:rgba(255,255,255,.08); color:#fff;
            border:1px solid rgba(255,255,255,.25); border-radius:7px;
            text-transform:uppercase; }}
 .miprefix .btnsm2 {{ padding:4px 11px; background:rgba(255,255,255,.1);
            color:#d9c48a; border-color:rgba(217,180,92,.4); }}
 .heroseam b {{ color:#d3e0ee; font-weight:650; }}
 .herobase {{ display:flex; gap:16px; padding:16px 18px;
            background:linear-gradient(180deg,#fdfcfa,#f7f4ee);
            align-items:stretch; }}
 .statiles {{ display:grid; grid-template-columns:repeat(4,1fr); gap:12px;
            flex:1; min-width:0; }}
 .statile {{ position:relative; display:flex; flex-direction:column;
            background:#fff;
            border:1px solid #e9e2d4; border-radius:12px; padding:13px 16px 12px;
            text-decoration:none; color:inherit;
            transition:border-color .15s, box-shadow .15s, transform .15s; }}
 .statile:hover {{ text-decoration:none; border-color:#cfae59;
            transform:translateY(-1px);
            box-shadow:0 8px 20px rgba(26,50,80,.09); }}
 .statile b {{ display:block; font-size:27px; font-weight:750; color:#16324e;
            line-height:1.05; letter-spacing:-.5px; }}
 .st-label {{ display:block; margin-top:3px; font-size:10.5px; font-weight:800;
            letter-spacing:.11em; text-transform:uppercase; color:#a3906a; }}
 .st-sub {{ display:block; margin-top:auto; padding-top:7px;
            font-size:11.5px; color:#8a97a8; white-space:nowrap;
            overflow:hidden; text-overflow:ellipsis; }}
 .st-ico {{ position:absolute; top:12px; right:12px; width:20px; height:20px;
            color:#d3bc80; }}
 .st-ico svg {{ width:20px; height:20px; }}
 .herobase .drop {{ width:230px; margin:0; padding:18px 14px;
            display:flex; flex-direction:column; justify-content:center; }}
 @media (max-width: 980px) {{
   .herobase {{ flex-direction:column; }}
   .statiles {{ grid-template-columns:repeat(2,1fr); }}
   .herobase .drop {{ width:auto; }}
 }}
 .apphead {{ display:flex; gap:26px; align-items:flex-start; }}
 .apphead .info {{ flex:1; min-width:0; }}
 .drop {{ display:block; width:300px; flex:none; border:2px dashed #c3cfdd;
         border-radius:12px; padding:22px 18px; text-align:center; color:var(--muted);
         cursor:pointer; font-size:13.5px; line-height:1.6; }}
 .drop:hover, .drop.over {{ border-color:#2563eb; background:#f0f5ff; color:#1d4ed8; }}
 .drop b {{ display:block; font-size:14.5px; color:inherit; }}
 .codechip {{ display:inline-flex; align-items:center; gap:7px; border:1px solid var(--line);
   border-radius:999px; padding:5px 14px; margin:0 8px 8px 0; background:#fff;
   font-weight:600; font-size:13.5px; box-shadow:0 1px 1px rgba(16,24,40,.04); }}
 td.filegroup {{ background:#f6f8fb; font-weight:700; font-size:12px;
   text-transform:uppercase; letter-spacing:.06em; color:#4a5b6d; }}
 .reader {{ font-family: Georgia, 'Times New Roman', serif; font-size:16.5px;
           line-height:1.8; color:#243342; max-width:760px; }}
 .reader h3 {{ font-size:20px; margin:30px 0 10px; letter-spacing:-.2px; }}
 .reader div:target {{ background:#fdf8ea; border-left:3px solid var(--gold);
                      padding:6px 16px; margin:24px -16px 10px;
                      border-radius:0 10px 10px 0; }}
 .reader div:target h3 {{ margin-top:4px; }}
 .reader h3:first-child {{ margin-top:4px; }}
 .reader p {{ margin:0 0 13px; }}
 .toc {{ display:flex; flex-wrap:wrap; gap:8px 18px; font-size:13.5px; }}
 .doctype {{ display:inline-block; background:#eef1f5; color:#4a5b6d; border-radius:6px;
            padding:2px 8px; font-size:11.5px; font-weight:700;
            text-transform:uppercase; letter-spacing:.05em; }}
 .reqres {{ display:grid; grid-template-columns:1fr 1fr; gap:18px; }}
 @media (max-width:900px) {{ .reqres {{ grid-template-columns:1fr; }} }}
 .panehead {{ font-size:11px; text-transform:uppercase; letter-spacing:.1em;
             color:var(--muted); font-weight:700; margin:0 0 8px; }}
 .tabbar {{ display:flex; gap:8px; margin-bottom:16px; }}
 .tabbar a {{ padding:7px 16px; border-radius:9px; font-weight:600; font-size:13.5px;
             color:#33506e; background:#fff; border:1px solid var(--line); }}
 .tabbar a:hover {{ text-decoration:none; background:#f3f7fc; }}
 .tabbar a.on {{ background:var(--navy); color:#fff; border-color:var(--navy); }}
 .flabel {{ display:block; font-size:12.5px; font-weight:600; color:#41546b;
           margin-bottom:4px; }}
 .fhint {{ display:block; font-size:12px; color:var(--muted); margin-top:-6px;
          margin-bottom:10px; line-height:1.5; }}
 .frow {{ display:grid; grid-template-columns:1fr 1fr; gap:0 16px; }}
 @media (max-width:760px) {{ .frow {{ grid-template-columns:1fr; }} }}
 .addbox {{ border:1px dashed #c3cfdd; border-radius:12px; padding:16px 18px;
           background:#fbfcfe; }}
 .addbox h3 {{ margin:0 0 14px; font-size:14px; letter-spacing:0; }}
 .delbtn {{ background:none; border:none; color:#a63838; cursor:pointer;
           font-size:12.5px; font-weight:600; padding:2px 6px; }}
 .delbtn:hover {{ text-decoration:underline; }}
 .setwrap {{ display:grid; grid-template-columns:190px 1fr; gap:20px;
            align-items:start; }}
 .setwrap > div {{ min-width:0; }}
 @media (max-width:820px) {{ .setwrap {{ grid-template-columns:1fr; }} }}
 .sidenav {{ background:#fff; border:1px solid var(--line); border-radius:14px;
            padding:10px; position:sticky; top:18px;
            box-shadow:0 1px 2px rgba(15,23,42,.04); }}
 .sidenav a {{ display:block; padding:9px 13px; border-radius:9px;
              font-weight:600; font-size:14px; color:#33506e; margin-bottom:2px; }}
 .sidenav a:hover {{ background:#f3f7fc; text-decoration:none; }}
 .sidenav a.on {{ background:var(--navy); color:#fff; }}
 .sidenav .grp {{ font-size:10.5px; text-transform:uppercase; letter-spacing:.1em;
                 color:var(--muted); font-weight:700; padding:10px 13px 5px; }}
 /* Lab: verdict bar — the one sentence the workbench exists to produce. */
 .verdict {{ display:flex; align-items:center; gap:14px; padding:14px 18px;
            border-radius:14px; margin-bottom:18px; border:1px solid; }}
 .verdict .vlabel {{ font-size:10.5px; font-weight:800; letter-spacing:.1em;
                    padding:5px 11px; border-radius:999px; white-space:nowrap;
                    color:#fff; }}
 .verdict b {{ font-size:15px; letter-spacing:-.1px; }}
 .vsub {{ font-size:12.5px; color:var(--muted); margin-top:3px;
         font-family:ui-monospace,Menlo,monospace; }}
 .vgood {{ background:#eef7f1; border-color:#c9e4d3; }}
 .vgood .vlabel {{ background:#1e6b3d; }}
 .vwarn {{ background:#fdf8ea; border-color:#efe1a8; }}
 .vwarn .vlabel {{ background:#8a6410; }}
 .vbad {{ background:#fbeeee; border-color:#e7c3c3; }}
 .vbad .vlabel {{ background:#a63838; }}
 .vnone {{ background:#f4f6f9; border-color:var(--line); }}
 .vnone .vlabel {{ background:#64748b; }}
 /* Lab: the loaded case as a pickable field list — never type a path. */
 .tree {{ max-height:360px; overflow:auto; border:1px solid var(--line);
         border-radius:11px; padding:5px; background:#fcfdfe; }}
 .tgrp {{ font-size:10.5px; text-transform:uppercase; letter-spacing:.09em;
         color:var(--muted); font-weight:700; padding:9px 9px 4px; }}
 .fpick {{ display:flex; width:100%; text-align:left; gap:10px; align-items:baseline;
          background:none; border:none; border-radius:7px; padding:5px 9px;
          cursor:pointer; font:inherit; font-size:13px; color:var(--ink); }}
 .fpick:hover {{ background:#e9eff8; }}
 .fpick .fp {{ font-family:ui-monospace,Menlo,monospace; }}
 .fpick .fv {{ color:var(--muted); margin-left:auto; font-size:12px;
              white-space:nowrap; overflow:hidden; text-overflow:ellipsis;
              max-width:48%; font-family:ui-monospace,Menlo,monospace; }}
 .fpick .fv:empty::after {{ content:'—'; }}
 /* Lab: machine-drafted checks awaiting confirmation. */
 .draft {{ border:1px dashed #cbb887; background:#fffdf5; border-radius:12px;
          padding:13px 16px; margin-bottom:10px; }}
 .draft.dead {{ border-color:#d8dee7; background:#fafbfc; }}
 .readback {{ font-size:14px; line-height:1.5; }}
 .readback code {{ background:#eef2f7; padding:1px 6px; border-radius:5px;
                  font-size:12.5px; }}
 .prov {{ font-size:11.5px; color:var(--muted); margin-top:6px; }}
 .checkrow {{ border:1px solid var(--line); border-radius:11px;
             padding:12px 14px; margin-bottom:10px; }}
 .checkrow.hot {{ border-color:var(--gold); box-shadow:0 0 0 3px #fdf3d9; }}
 a.btn {{ display:inline-block; background:var(--navy); color:#fff; font-weight:600;
         font-size:13.5px; padding:9px 16px; border-radius:9px; }}
 a.btn:hover {{ text-decoration:none; background:#16304f; }}
 a.btnsm {{ display:inline-block; color:#33506e; font-weight:600; font-size:12.5px;
           padding:5px 11px; border-radius:7px; border:1px solid var(--line); }}
 a.btnsm:hover {{ text-decoration:none; background:#f3f7fc; }}
 ul.readback {{ margin:10px 0 0; padding-left:20px; }}
 ul.readback li {{ margin-bottom:6px; }}
 /* Pipelines: stages left to right, data areas as the seams. */
 .pipe {{ display:flex; align-items:center; flex-wrap:wrap; gap:6px 4px;
         padding:4px 0 2px; }}
 .pstage {{ display:inline-flex; align-items:center; gap:8px; background:#fff;
           border:1.5px solid #c8d2df; border-radius:10px; padding:8px 13px;
           color:var(--ink); font-size:13px; box-shadow:0 1px 1px rgba(16,24,40,.05); }}
 .pstage:hover {{ text-decoration:none; border-color:var(--gold); background:#fffdf6; }}
 .pstage b {{ font-size:13px; letter-spacing:.01em; }}
 .pstage .prole {{ font-size:10.5px; text-transform:uppercase; letter-spacing:.07em;
                  color:var(--muted); font-weight:700; }}
 .pstage .pvol {{ background:#f9e5e5; color:#a63838; border-radius:999px;
                 font-size:11px; font-weight:700; padding:1px 8px; }}
 .pstage.hit {{ border-color:var(--red); background:#fdf7f7;
               box-shadow:0 0 0 3px #f7e3e3; }}
 .pseam {{ color:#8a97a8; font-size:11.5px; font-weight:700; letter-spacing:.04em;
          font-family:ui-monospace,Menlo,monospace; white-space:nowrap; }}
 .punit {{ display:inline-flex; align-items:center; gap:6px; }}
 .pstage.lane {{ border-style:dashed; border-color:#b9a3e3; background:#faf8fe; }}
 .pstage.lane .prole {{ color:#5b3fb8; }}
 .pseam.lane {{ color:#7a5cd6; font-size:14px; }}
 /* Lab checks: sentence first, machinery behind Edit. */
 .checkrow {{ padding:0; overflow:hidden; }}
 .chead {{ display:flex; align-items:flex-start; gap:12px; padding:13px 16px; }}
 .cnum {{ flex:none; width:24px; height:24px; border-radius:50%; background:#eef2f7;
         color:#41546b; font-size:12.5px; font-weight:700; display:flex;
         align-items:center; justify-content:center; margin-top:1px; }}
 .cnum.plus {{ background:transparent; border:1.5px dashed #b6c2d1; color:#8a97a8; }}
 .csay {{ flex:1; min-width:0; line-height:1.55; }}
 .carrow {{ color:var(--muted); }}
 .cev {{ margin-top:6px; font-size:12.5px; }}
 .cedit {{ flex:none; background:none; border:1px solid var(--line); color:#33506e;
          border-radius:7px; padding:4px 12px; font-size:12.5px; font-weight:600;
          cursor:pointer; }}
 .cedit:hover {{ background:#f3f7fc; }}
 .checkrow.ok {{ border-left:4px solid var(--green); }}
 .checkrow.err {{ border-left:4px solid var(--red); }}
 .checkrow.new {{ border-style:dashed; background:#fbfcfe; }}
 .cbody {{ display:none; border-top:1px dashed var(--line); background:#fbfcfe;
          padding:12px 16px 14px; }}
 .cbody.open {{ display:block; }}
 .cflds {{ display:grid; grid-template-columns:2fr 1.4fr 1.4fr; gap:0 12px; }}
 @media (max-width:760px) {{ .cflds {{ grid-template-columns:1fr; }} }}
 .cflds input, .cflds select {{ margin-top:2px; }}
 .opt {{ font-weight:400; color:var(--muted); font-size:11.5px; }}
 .refuse {{ outline:2px solid var(--red) !important; border-color:var(--red) !important; }}
 /* Group config strip */
 .gcbox {{ border:1px solid var(--line); border-radius:11px; background:#fbfcfe;
          padding:10px 14px; margin-top:4px; }}
 .gcbox summary {{ font-size:13px; }}
 .gchead {{ display:grid; grid-template-columns:2fr 2fr 1.6fr; gap:0 10px;
           font-size:10.5px; text-transform:uppercase; letter-spacing:.08em;
           color:var(--muted); font-weight:700; margin:12px 0 2px; }}
 .gcrow {{ display:grid; grid-template-columns:2fr 2fr 1.6fr; gap:0 10px; }}
 .gcrow input, .gcrow select {{ margin:3px 0; font-size:13px; padding:7px 10px; }}
 /* Field Scan: the mined journey of one field. */
 .chain {{ display:flex; flex-direction:column; gap:8px; }}
 .hop {{ display:flex; align-items:baseline; gap:9px; flex-wrap:wrap; }}
 .hop code {{ font-size:13px; }}
 .harr {{ color:#8a97a8; font-weight:700; }}
 .hlbl {{ color:var(--muted); font-size:12px; }}
 .dbcol {{ background:#ece6fa; color:#5b3fb8; border-radius:5px; }}
 td.mono {{ font-family:ui-monospace,Menlo,monospace; font-size:12.5px; }}
 /* Pipeline detail: vertical flow, seams between stages. */
 .pd-flow {{ display:flex; flex-direction:column; }}
 .pd-stage {{ }}
 .pd-head {{ display:flex; align-items:center; gap:14px; border:1.5px solid #c8d2df;
            border-radius:13px; padding:14px 18px; background:#fff;
            box-shadow:0 1px 2px rgba(15,23,42,.05); }}
 .pd-num {{ flex:none; width:26px; height:26px; border-radius:50%;
           background:var(--navy); color:#fff; font-size:12.5px; font-weight:700;
           display:flex; align-items:center; justify-content:center; }}
 .pd-title {{ flex:1; min-width:0; }}
 .pd-title b {{ font-size:15px; }}
 .pd-stats {{ display:flex; gap:18px; flex:none; }}
 .pd-stats .stat b {{ font-size:17px; }}
 .pd-arrows {{ display:flex; flex-direction:column; gap:3px; flex:none; margin:0; }}
 .pd-arrows button {{ padding:1px 9px; font-size:12px; line-height:1.5;
                     background:#fff; color:#33506e; border:1px solid var(--line);
                     border-radius:6px; }}
 .pd-arrows button:hover {{ background:#f3f7fc; }}
 .pd-edit {{ margin:6px 0 0 40px; }}
 .pd-edit summary {{ font-size:12.5px; cursor:pointer; }}
 .pd-seam {{ display:flex; align-items:center; gap:10px; margin:2px 0 2px 30px;
            height:34px; }}
 .pd-line {{ width:2px; height:100%; background:#c8d2df; border-radius:2px; }}
 .pd-area {{ background:#eef2f7; color:#41546b; border-radius:999px;
            font-size:11px; font-weight:700; letter-spacing:.05em;
            padding:3px 12px; font-family:ui-monospace,Menlo,monospace; }}
 a.viewbtn {{ display:inline-block; background:#fdf3d9; color:#7a5605;
             border:1px solid #e3c988; border-radius:999px; padding:4px 14px;
             font-size:12.5px; font-weight:700; margin-left:10px;
             vertical-align:1px; white-space:nowrap; }}
 a.viewbtn:hover {{ background:var(--gold); border-color:var(--gold);
                   color:#fff; text-decoration:none; }}
 a.viewbtn:visited {{ color:#7a5605; }}
 code.missing {{ background:#f9e5e5; color:#a63838; }}
 .bfrow {{ display:flex; align-items:flex-start; gap:12px;
           padding:11px 0; border-bottom:1px solid #f1f3f6; }}
 .bfrow:last-child {{ border-bottom:none; }}
 .bfmark {{ font-weight:800; width:14px; text-align:center; }}
 .missrow {{ display:flex; flex-wrap:wrap; gap:6px; margin-top:5px; }}
 .miss {{ font-size:11.5px; border-radius:6px; padding:2px 9px; }}
 .miss.blk {{ background:#f9e5e5; color:#a63838; }}
 .miss.adv {{ background:#fdf6dd; color:#7a5d05; }}
 .plainlist {{ margin:0; padding-left:20px; }}
 .plainlist li {{ margin:7px 0; line-height:1.65; }}
 .tracebox {{ max-height:60vh; overflow:auto; border:1px solid var(--line);
              border-radius:11px; padding:8px 4px; background:#fcfdfe;
              font-size:13px; }}
 .tev {{ padding:3px 12px; line-height:1.6; }}
 .tev:hover {{ background:#eef2f8; }}
 .tev code {{ font-size:12.5px; }}
 .tloc {{ display:inline-block; min-width:118px; color:#8a97a8;
          font-family:ui-monospace,Menlo,monospace; font-size:11.5px; }}
 .texc {{ background:#fdf3f3; }}
 .tstep {{ margin:10px 0 4px; padding:6px 12px; background:#eef2f7;
           border-radius:7px; font-size:13px; }}
 .wb {{ background:#0b1220; border:1px solid #1d2b45; border-radius:14px;
       overflow:hidden; box-shadow:0 18px 44px rgba(8,15,30,.30); }}
 .wbtop {{ display:flex; gap:6px; align-items:center; padding:8px 12px;
       background:#0f1830; border-bottom:1px solid #1d2b45; flex-wrap:wrap; }}
 .wbins {{ font-size:10.5px; letter-spacing:.14em; color:#5c6f93;
       text-transform:uppercase; margin-right:4px; font-weight:700; }}
 .wbbtn {{ background:#16223a; color:#c6d4ec; border:1px solid #24365a;
       border-radius:7px; padding:5px 12px; font-size:12.5px;
       cursor:pointer; }}
 .wbbtn:hover {{ background:#1d2c4a; border-color:#31487a; }}
 .wbhint {{ color:#4d5f80; font-size:11.5px; display:flex; gap:4px;
       align-items:center; }}
 .wbhint kbd {{ background:#16223a; border:1px solid #24365a;
       border-radius:4px; padding:1px 5px; font-size:10.5px;
       color:#8aa0c8; font-family:inherit; }}
 .wbsplit {{ display:grid; grid-template-columns:1fr 1fr; }}
 .wbpane {{ min-width:0; display:flex; flex-direction:column;
       background:#0b1220; }}
 .wbpane + .wbpane {{ border-left:1px solid #1d2b45; }}
 .wbph {{ display:flex; gap:8px; align-items:center; padding:6px 12px;
       background:#0e1628; border-bottom:1px solid #1a2740; }}
 .wbpt {{ font-size:10.5px; letter-spacing:.14em; color:#5c6f93;
       text-transform:uppercase; font-weight:700; }}
 .wbpn {{ font-family:ui-monospace,Menlo,monospace; font-size:11.5px;
       color:#8aa0c8; }}
 .wbico {{ width:26px; height:26px; display:inline-flex; align-items:center;
       justify-content:center; background:transparent; color:#6d81a6;
       border:1px solid transparent; border-radius:6px; cursor:pointer;
       font-size:13px; padding:0; }}
 .wbico:hover {{ background:#16223a; color:#c6d4ec; border-color:#24365a; }}
 .wbed {{ display:grid; grid-template-columns:auto 1fr; height:500px; }}
 #gut {{ overflow:hidden; padding:10px 0; text-align:right;
       user-select:none; font:12px/1.5 ui-monospace,Menlo,monospace;
       color:#3f5170; min-width:46px; background:#0b1220;
       border-right:1px solid #17233a; }}
 #gut .gl {{ padding:0 10px 0 16px; }}
 #gut .gl.on {{ color:#9fb6dd; background:#121d33; }}
 .wbtxt {{ position:relative; overflow:hidden; background:#0d1526;
       font:12px/1.5 ui-monospace,Menlo,monospace; }}
 .wbtxt textarea {{ display:block; width:100%; height:100%; margin:0;
       border:0; resize:none; background:transparent; color:#dbe6f6;
       border-radius:0; outline:none; padding:10px 14px; font:inherit;
       white-space:pre; overflow:auto; }}
 #rule72 {{ position:absolute; top:0; bottom:0; left:calc(14px + 71ch);
       width:0; border-left:1px dashed rgba(140,160,200,.25);
       pointer-events:none; }}
 #rule72::after {{ content:'72'; position:absolute; top:3px; left:3px;
       font-size:9px; color:rgba(140,160,200,.5); }}
 .wbtermwrap {{ position:relative; height:500px; background:#071008;
       padding:12px; display:flex; align-items:center;
       justify-content:center; }}
 .wbtermwrap #bmsout {{ width:100%; max-height:100%; overflow:auto; }}
 .wbtermwrap .panehead {{ color:#5e7590; background:transparent; border:0;
       padding:0 0 6px; margin:0; }}
 .wbtermwrap .panehead:first-of-type {{ display:none; }}
 .wbtermwrap .muted {{ color:#5e7590; }}
 .wbprob {{ border-top:1px solid #1d2b45; }}
 .wbprobbody {{ max-height:132px; overflow:auto; padding:6px 8px; }}
 .lintrow {{ display:flex; gap:9px; align-items:baseline; padding:4px 8px;
       border-radius:6px; color:#aebdd6; cursor:pointer; font-size:12.5px;
       line-height:1.45; }}
 .lintrow:hover {{ background:#121d33; }}
 .lms {{ width:14px; text-align:center; font-weight:700; flex:none; }}
 .lint-error .lms {{ color:#ff7a7a; }}
 .lint-warn .lms {{ color:#f0b84f; }}
 .lint-info .lms {{ color:#6d84a8; }}
 .lml {{ font-family:ui-monospace,Menlo,monospace; font-size:11px;
       color:#5c6f93; min-width:42px; flex:none; }}
 .lintok {{ color:#45d07c; padding:6px 10px; font-size:12.5px; }}
 .wbcounts {{ display:flex; gap:6px; margin-left:8px; }}
 .wbcounts span {{ font-family:ui-monospace,Menlo,monospace; font-size:11px;
       padding:1px 9px; border-radius:99px; border:1px solid #24365a;
       color:#8aa0c8; }}
 .wbcounts .ce {{ color:#ff8585; border-color:#5c2833; }}
 .wbcounts .cw {{ color:#f0b84f; border-color:#544218; }}
 .wbcounts .cok {{ color:#45d07c; border-color:#1d4a30; }}
 .wbstatus {{ display:flex; gap:16px; align-items:center; padding:6px 14px;
       background:#0f1830; border-top:1px solid #1d2b45; font-size:11.5px;
       color:#748ab0; }}
 .wbstatus .wbst {{ font-family:ui-monospace,Menlo,monospace;
       font-size:11px; }}
 .bmstog {{ font-size:11.5px; color:#748ab0; display:flex; gap:5px;
       align-items:center; cursor:pointer; }}
 .bmstog input {{ width:auto; margin:0; accent-color:#31487a; }}
 .bmslncol {{ font-family:ui-monospace,Menlo,monospace; font-size:11.5px;
       color:#8aa0c8; }}
 .bmslncol.over {{ color:#ff7a7a; font-weight:700; }}
 .bmsx {{ display:none; }}
 .wbpane:fullscreen .bmsx {{ display:inline-flex; }}
 .wbpane:fullscreen {{ background:#0b1220; }}
 #bmsed:fullscreen .wbed {{ height:calc(100vh - 40px); }}
 #bmsed:fullscreen .wbtxt, #bmsed:fullscreen #gut {{ font-size:13.5px; }}
 #bmsprev:fullscreen .wbtermwrap {{ height:calc(100vh - 40px);
       padding:4vh 4vw; }}
 .wbrules {{ margin-top:12px; color:var(--muted); font-size:12.5px;
       line-height:1.6; }}
 .wbrules summary {{ cursor:pointer; font-weight:600; font-size:12px;
       letter-spacing:.05em; }}
 .g3grid {{ position:absolute; inset:0; pointer-events:none; }}
 .g3grid .g3v {{ position:absolute; top:0; bottom:0; width:1px;
          background:rgba(120,255,160,.13); }}
 .g3grid .g3v::after {{ content:attr(data-c); position:absolute; top:1px;
          left:2px; font-size:.65em; color:rgba(120,255,160,.45); }}
 .g3grid .g3h {{ position:absolute; left:0; right:0; height:1px;
          background:rgba(120,255,160,.13); }}
 .g3grid .g3h::after {{ content:attr(data-r); position:absolute; left:2px;
          top:1px; font-size:.65em; color:rgba(120,255,160,.45); }}
 @media (max-width: 1000px) {{ .wbsplit {{ grid-template-columns:1fr; }}
          .wbpane + .wbpane {{ border-left:0;
          border-top:1px solid #1d2b45; }} }}
 .srcbar {{ display:flex; gap:8px; align-items:center;
          margin:0 0 10px; }}
 .srcbar input {{ margin:0; width:380px; max-width:60%; font-size:13px;
          padding:8px 13px; }}
 .srcbar .muted {{ font-family:ui-monospace,Menlo,monospace;
          font-size:12px; min-width:80px; }}
 #srcpane mark.fmatch {{ background:#f0d478; color:#122036;
          border-radius:3px; padding:0 1px; }}
 #srcpane mark.fmatch.cur {{ background:#e8963c; color:#0d1d31;
          font-weight:700; }}
 .mbrscroll {{ max-height:min(60vh, 680px); overflow-y:auto;
          scrollbar-width:thin; padding-right:2px; }}
 .mbrtab {{ border:1px solid var(--line); border-radius:10px;
          margin:0 0 8px; background:#fff; }}
 .mbrhead {{ display:flex; align-items:baseline; gap:2px; padding:6px 13px;
          background:#f4f7fa; border-bottom:1px solid var(--line);
          border-radius:9px 9px 0 0; position:sticky; top:0; z-index:2;
          font-family:ui-monospace,Menlo,monospace; font-size:12.5px; }}
 .mbrtab > :last-child {{ border-radius:0 0 9px 9px; overflow:hidden; }}
 .mbrschema {{ color:#8a97a8; }}
 .mbrtag {{ font-family:inherit; font-size:10.5px; color:#647289;
          margin-left:auto; letter-spacing:.04em; padding-left:12px; }}
 .mbrflex {{ display:grid; background:#fff; column-gap:6px;
          grid-template-columns:repeat(auto-fill, minmax(164px, 1fr)); }}
 .mbrfield {{ padding:7px 13px 8px; min-width:0; }}
 .mbrfield .mbrcol {{ display:block; }}
 .mbrval {{ display:block; font-size:13.5px; margin:1px 0;
          overflow-wrap:anywhere; }}
 .mbrgrid {{ margin:0; }}
 .mbrgrid th {{ text-align:left; text-transform:none; letter-spacing:0;
          padding:5px 13px; background:#fff;
          border-bottom:1px solid var(--line); font-weight:400; }}
 .mbrgrid td {{ font-size:13px; padding:5px 13px; }}
 .mbrcol {{ font-family:ui-monospace,Menlo,monospace; font-size:11.5px;
          color:#33506e; font-weight:600; }}
 .mbrlbl {{ display:block; font-family:-apple-system,BlinkMacSystemFont,
          'Segoe UI',sans-serif; font-size:10.5px; color:var(--muted);
          font-weight:400; margin-top:1px; line-height:1.3; }}
 .mbrocc {{ width:26px; color:#8a97a8;
          font-family:ui-monospace,Menlo,monospace; font-size:11px; }}
 .mbrnull {{ color:#c4cdd8; }}
 .mbrmf {{ font-family:ui-monospace,Menlo,monospace; font-size:11px;
          color:#647289; background:#eef2f7; border-radius:5px;
          padding:0 6px; margin-left:5px; }}
 .mbrempty {{ font-size:12px; margin:2px 0 0; }}
 .mbrempty span {{ font-family:ui-monospace,Menlo,monospace;
          font-size:11.5px; }}
 .mbrmore {{ margin:8px 0 0; font-size:12.5px; }}
 .mbrmore summary {{ cursor:pointer; color:var(--muted); }}
 .mbrmore ul {{ margin:6px 0 0; columns:2; column-gap:28px;
          padding-left:18px; }}
 .mbrmore li {{ break-inside:avoid; margin-bottom:2px; }}
 .mbrmore code {{ font-size:11.5px; }}
 .cwb {{ display:flex; flex-direction:column;
        height:calc(100vh - 190px); min-height:480px; }}
 .clog {{ flex:1; overflow-y:auto; padding:18px 18px 8px;
        display:flex; flex-direction:column; gap:10px;
        scrollbar-width:thin; }}
 .cnotice {{ background:#231c0e; color:#f0b84f; border:1px solid #54421d;
        border-radius:10px; padding:10px 14px; font-size:13px; }}
 .cnotice a {{ color:#f0d08a; }}
 .cmsg-user {{ display:flex; justify-content:flex-end; }}
 .cmsg-bot {{ display:flex; justify-content:flex-start; }}
 .cmsg-user .cbubble {{ background:#1d2c4a; border:1px solid #31487a;
        color:#dbe6f6; }}
 .cmsg-bot .cbubble {{ background:#0d1526; border:1px solid #1d2b45;
        color:#c6d4ec; }}
 .cbubble {{ max-width:76%; border-radius:12px; padding:10px 15px;
        font-size:13.5px; line-height:1.6; overflow-wrap:anywhere; }}
 .cbubble code {{ background:#16223a; color:#9fb6dd; border-radius:5px;
        padding:1px 6px; font-size:12px; }}
 .cbubble b {{ color:#e8eef8; }}
 .chr {{ display:block; border-top:1px solid #1d2b45; margin:4px 0; }}
 .ctrail {{ display:flex; flex-wrap:wrap; gap:6px; padding:0 4px; }}
 .cstep {{ font-family:ui-monospace,Menlo,monospace; font-size:11px;
        color:#5c6f93; background:#0e1628; border:1px solid #1a2740;
        border-radius:99px; padding:3px 11px; }}
 .cstep.ctool {{ color:#9fb6dd; border-color:#24365a; }}
 .cstep.on {{ color:#e8b64c; border-color:#54421d; }}
 .cdots {{ display:inline-flex; gap:2px; margin-left:6px; }}
 .cdots i {{ width:3px; height:3px; border-radius:50%;
        background:currentColor; animation:cpulse 1.2s infinite; }}
 .cdots i:nth-child(2) {{ animation-delay:.2s; }}
 .cdots i:nth-child(3) {{ animation-delay:.4s; }}
 @keyframes cpulse {{ 0%,60%,100% {{ opacity:.25; }}
        30% {{ opacity:1; }} }}
 .cbar {{ display:flex; gap:10px; padding:12px 14px;
        border-top:1px solid #1d2b45; background:#0f1830; margin:0; }}
 .cbar input {{ flex:1; margin:0; background:#0d1526; color:#dbe6f6;
        border:1px solid #24365a; border-radius:9px; padding:10px 14px;
        font-size:13.5px; outline:none; }}
 .cbar input:focus {{ border-color:#31487a; }}
 .cbar input:disabled {{ opacity:.5; }}
 .tokrow {{ display:flex; gap:12px; align-items:baseline;
          margin:8px 0 2px; }}
 .tokchip {{ font-family:ui-monospace,Menlo,monospace; font-size:11.5px;
          color:#647289; background:#eef2f7; border-radius:99px;
          padding:2px 11px; }}
 .tokchip.tokwarn {{ color:#8a5f07; background:#fdf3d8; }}
 .tokchip.tokdead {{ color:#a63838; background:#f9e5e5; }}
 .tokform summary {{ font-size:12.5px; color:var(--link); cursor:pointer;
          list-style:none; }}
 .tokform {{ flex:1; }}
 .mbrwb {{ background:#0b1220; border:1px solid #1d2b45;
          border-radius:13px; overflow:hidden;
          box-shadow:0 12px 32px rgba(8,15,30,.25); }}
 .mbrwbtop {{ display:flex; align-items:baseline; gap:10px;
          padding:8px 14px; background:#0f1830;
          border-bottom:1px solid #1d2b45; }}
 .mbrwbmark {{ font-size:11px; font-weight:800; letter-spacing:.18em;
          color:var(--gold-soft); }}
 .mbrwbsub {{ font-size:11.5px; color:#5c6f93; }}
 .mbrwbcov {{ font-family:ui-monospace,Menlo,monospace; font-size:11px;
          color:#8aa0c8; }}
 .mbrwbbody {{ padding:10px 12px; }}
 .mbrwb .mbrtab {{ border-color:#1d2b45; background:#0d1526; }}
 .mbrwb .mbrhead {{ background:#0e1628; border-color:#1a2740;
          color:#c6d4ec; }}
 .mbrwb .mbrschema, .mbrwb .mbrtag, .mbrwb .mbrlbl {{ color:#5c6f93; }}
 .mbrwb .mbrflex, .mbrwb .mbrfield {{ background:transparent; }}
 .mbrwb .mbrcol {{ color:#9fb6dd; }}
 .mbrwb .mbrval {{ color:#e8eef8; }}
 .mbrwb .mbrgrid th {{ background:#0d1526; border-color:#1a2740; }}
 .mbrwb .mbrgrid td {{ color:#dbe6f6; border-color:#152238; }}
 .mbrwb tr:hover td {{ background:#121d33; }}
 .mbrwb .mbrocc {{ color:#4d5f80; }}
 .mbrwb .mbrnull {{ color:#33415c; }}
 .mbrwb .mbrmf {{ background:#16223a; color:#8aa0c8; }}
 .mbrwb .mbrempty, .mbrwb .mbrempty span,
 .mbrwb .muted {{ color:#5c6f93; }}
 .mbrwb .mbrmore {{ color:#aebdd6; }}
 .mbrwb .mbrmore summary {{ color:#8aa0c8; }}
 .mbrwb .mbrmore code {{ background:#16223a; color:#9fb6dd; }}
 .rulecard {{ border:1px solid var(--line); border-left:3px solid var(--line);
             border-radius:11px; padding:15px 18px; margin-bottom:12px;
             background:#fff; }}
 .rulewhen {{ font-size:15.5px; line-height:1.5; }}
 .rulewhen b {{ font-weight:700; }}
 .rulegiven {{ margin-top:4px; font-size:12.5px; color:var(--muted); }}
 .rulegiven b {{ font-weight:600; color:var(--ink); }}
 .rulethen {{ margin-top:8px; font-size:14px; color:#3d4a5c; }}
 .rulemsg {{ font-style:italic; color:var(--muted); }}
 .rulesrc {{ margin-top:10px; padding-top:9px; border-top:1px dashed var(--line);
            display:flex; justify-content:space-between; align-items:baseline;
            gap:12px; flex-wrap:wrap; }}
 .rulesrc code {{ font-size:12.5px; background:#f2f5f9; padding:3px 9px;
            border-radius:6px; }}
 .btnsm2 {{ display:inline-block; background:#fff; color:#33506e;
           border:1px solid var(--line); border-radius:7px; padding:4px 11px;
           font-size:12px; font-weight:600; cursor:pointer; }}
 .btnsm2:hover {{ background:#f3f7fc; text-decoration:none; }}
 ul.readiness {{ margin:8px 0 0; padding-left:22px; }}
 ul.readiness li {{ margin-bottom:5px; font-size:13.5px; }}
 ul.readiness li.blk {{ color:#a63838; font-weight:600; }}
 ul.readiness li.adv {{ color:#8a6410; }}
 /* The 3270: green phosphor, 24 rows, 80 columns. */
 .screenwrap {{ container-type:inline-size; overflow-x:auto; }}
 .g3270 {{ position:relative; width:82ch; height:calc(24 * 1.45em);
          background:#071207; color:#33e673; border-radius:10px;
          font-family:ui-monospace,Menlo,monospace; font-size:13px;
          /* every offset is in ch/em, so scaling the font scales the whole
             terminal — sized to fill the card, capped for sanity */
          font-size:clamp(8px, 1.98cqw, 19px); margin-inline:auto;
          line-height:1.45; border:1px solid #123a1f;
          box-shadow:inset 0 0 60px rgba(20,80,30,.25); }}
 .g3f {{ position:absolute; white-space:pre; }}
 .g3f.bright {{ color:#c9ffd6; font-weight:700;
               text-shadow:0 0 6px rgba(120,255,160,.45); }}
 .g3f.inp {{ color:#2adf7a; border-bottom:1px solid rgba(42,223,122,.55); }}
 .g3f.blink {{ animation:g3blink 1.1s steps(1) infinite; }}
 @keyframes g3blink {{ 50% {{ opacity:0; }} }}
 .g3f.cursor {{ color:#c9ffd6; animation:g3blink .8s steps(1) infinite; }}
 /* Architecture diagram: fullscreen affordance. */
 .archwrap {{ position:relative; }}
 .archbtn {{ position:absolute; bottom:2px; right:2px; z-index:5; background:#fff;
            color:#33506e; border:1px solid var(--line); border-radius:8px;
            padding:4px 10px; font-size:15px; line-height:1.2; cursor:pointer;
            opacity:.55; }}
 .archbtn:hover {{ opacity:1; background:#f3f7fc; }}
 .archwrap:fullscreen {{ background:#fff; display:flex; align-items:center;
                        justify-content:center; padding:4vh 3vw; }}
 .archwrap:fullscreen > div {{ width:100%; }}
 .archwrap:fullscreen svg {{ width:100% !important; height:auto !important;
                            max-height:88vh; }}
 .archwrap:fullscreen .archbtn {{ top:14px; right:18px; bottom:auto;
                                 opacity:1; font-size:18px; padding:6px 14px; }}
 .archwrap:-webkit-full-screen {{ background:#fff; }}
</style></head><body>
<header><div class=nav><a class=brand href="/">Chat<span>BIS</span></a>
<a href="/" data-nav="/">Dashboard</a><a href="/apps" data-nav="/apps">Applications</a>
<a href="/catalog" data-nav="/catalog">Catalog</a>
<a href="/policy" data-nav="/policy">Policy</a>
<a href="/scan" data-nav="/scan">Scan</a>
<a href="/cases" data-nav="/cases">Case Lookup</a>
<a href="/lab" data-nav="/lab">Lab</a>
<a href="/cobrun" data-nav="/cobrun">cobrun</a>
<a href="/settings" data-nav="/settings">Settings</a>
<form action="/search"><input name="q" placeholder="Search codes, fields, programs, DFRs…"
 value="{q}"></form></div></header><main>{body}</main>
<script>
(function(){{
  var p = location.pathname;
  document.querySelectorAll('.nav a[data-nav]').forEach(function(a){{
    var n = a.getAttribute('data-nav');
    var hit = n === '/'
      ? (p === '/' || p === '/dash')
      : (n === '/catalog'
         ? (p.indexOf('/catalog') === 0 || p.indexOf('/x/') === 0)
         : p.indexOf(n) === 0);
    if (hit) a.classList.add('active');
  }});
}})();
// Lab: click a field in the loaded case to fill the first empty check.
// Typed paths are the worst bug class here — a typo looks authored and
// silently never fires — so the case data itself is the picker.
(function(){{
  // Remember the last check input the analyst was in, so a tree click can
  // land there: click into "Compared to", click a field -> field-to-field
  // reference written with the right $./$$. prefix. No syntax to memorise.
  var lastField = null;
  document.addEventListener('focusin', function(e){{
    if (e.target.name && /^(value|path)_/.test(e.target.name)) lastField = e.target;
  }});
  document.addEventListener('click', function(e){{
    var b = e.target.closest ? e.target.closest('.fpick') : null;
    if (!b) return;
    if (lastField && /^value_/.test(lastField.name) && lastField.closest('.cbody.open')) {{
      var row = lastField.closest('.checkrow');
      var rowGroup = (row.querySelector('input[name^=group_]') || {{}}).value || '';
      var ref = null;
      if (b.dataset.g && b.dataset.g === rowGroup.trim()) ref = '$.' + b.dataset.p;
      else if (!b.dataset.g) ref = '$$.' + b.dataset.p;
      if (ref) {{
        lastField.value = ref;
        var vm = row.querySelector('select[name^=vmode_]');
        if (vm) vm.value = 'field';
        lastField.focus();
      }} else {{
        // Cross-group compare: the engine can't do it, so refuse visibly
        // rather than write a reference that would never resolve.
        lastField.classList.add('refuse');
        setTimeout(function(){{ lastField.classList.remove('refuse'); }}, 900);
      }}
      return;
    }}
    var rows = document.querySelectorAll('.checkrow');
    var target = null;
    if (lastField && /^path_/.test(lastField.name) && lastField.closest('.cbody.open')) {{
      target = lastField.closest('.checkrow');   // fill where the analyst is
    }}
    for (var i = 0; !target && i < rows.length; i++) {{
      var pi = rows[i].querySelector('input[name^=path_]');
      if (pi && !pi.value.trim()) {{ target = rows[i]; break; }}
    }}
    if (!target) target = rows[rows.length - 1];
    if (!target) return;
    var path = target.querySelector('input[name^=path_]');
    var grp  = target.querySelector('input[name^=group_]');
    if (path) path.value = b.dataset.p || '';
    if (grp)  grp.value  = b.dataset.g || '';
    // Seed the group's "latest" config so it is never guessed from array order.
    if (b.dataset.g) {{
      var gcs = document.querySelectorAll('input[name^=gc_group_]');
      var known = false, blank = null;
      gcs.forEach(function(i){{
        if (i.value.trim() === b.dataset.g) known = true;
        else if (!i.value.trim() && !blank) blank = i;
      }});
      if (!known && blank) blank.value = b.dataset.g;
    }}
    var body = target.querySelector('.cbody');
    if (body) body.classList.add('open');
    rows.forEach(function(r){{ r.classList.remove('hot'); }});
    target.classList.add('hot');
    target.scrollIntoView({{block:'center', behavior:'smooth'}});
    var op = target.querySelector('select[name^=op_]');
    if (op) op.focus();
  }});
  document.addEventListener('change', function(e){{
    if (!e.target.classList || !e.target.classList.contains('vmode')) return;
    var inp = e.target.parentElement.querySelector('input[name^=value_]');
    inp.placeholder = e.target.value === 'field'
      ? 'click a field in the case above'
      : 'e.g. SUSPENDED · 2016-01-01';
    inp.focus();
  }});
  // ⛶ toggles the architecture diagram into native fullscreen.
  document.addEventListener('click', function(e){{
    if (!e.target.classList || !e.target.classList.contains('archbtn')) return;
    var wrap = e.target.closest('.archwrap');
    if (document.fullscreenElement) {{
      (document.exitFullscreen || document.webkitExitFullscreen).call(document);
      e.target.textContent = '⛶';
    }} else {{
      (wrap.requestFullscreen || wrap.webkitRequestFullscreen).call(wrap);
      e.target.textContent = '✕';
    }}
  }});
  document.addEventListener('fullscreenchange', function(){{
    if (!document.fullscreenElement)
      document.querySelectorAll('.archbtn').forEach(function(b){{
        b.textContent = '⛶'; }});
  }});
  // Edit toggles a check's form open/closed.
  document.addEventListener('click', function(e){{
    if (!e.target.classList || !e.target.classList.contains('cedit')) return;
    var body = e.target.closest('.checkrow').querySelector('.cbody');
    var open = body.classList.toggle('open');
    e.target.textContent = open ? 'Done' : 'Edit';
  }});
}})();
</script></body></html>"""


def esc(s) -> str:
    return html.escape(str(s if s is not None else ""))


# How a case-JSON value becomes the COBOL field's bytes. Deliberately a
# short, closed list: an unknown format is a halt at run time, not a guess.
FORMATS = [
    ("", "— not declared (treated as text) —"),
    ("text", "text · alphanumeric as-is"),
    ("iso-date", "date · ISO in JSON (1958-04-02)"),
    ("yyyymmdd", "date · CCYYMMDD digits (19580402)"),
    ("yymmdd", "date · YYMMDD, windowed"),
    ("julian-ccyyddd", "date · Julian CCYYDDD (2026032)"),
    ("julian-yyddd", "date · Julian YYDDD, windowed"),
    ("decimal", "number · decimal amount (1842.50)"),
    ("integer", "number · whole"),
    ("flag", "flag · Y/N, single byte"),
]


def suggest_format(conn, cobol_field: str | None, json_path: str | None,
                   db2: str | None) -> str:
    """Propose a format from what is already mined: the COBOL field's
    PICTURE plus the naming. A suggestion the analyst confirms — never
    applied on its own, because a wrong date format is silent corruption."""
    name = " ".join(x or "" for x in (cobol_field, json_path, db2)).upper()
    datish = any(k in name for k in ("DATE", "-DT", "DOB", "DOD", "_DT"))
    item = None
    if cobol_field:
        item = conn.execute(
            "SELECT pic, item_type FROM data_item WHERE name = ?"
            " ORDER BY id LIMIT 1", (cobol_field.upper(),)).fetchone()
    pic = (item["pic"] or "") if item else ""
    digits = sum(int(m or 1) for m in
                 __import__("re").findall(r"9(?:\((\d+)\))?", pic)) if pic else 0
    if datish:
        if "X" in pic.upper() and digits == 0:
            return "iso-date"
        return {8: "yyyymmdd", 7: "julian-ccyyddd", 6: "yymmdd",
                5: "julian-yyddd"}.get(digits, "iso-date")
    if item and (item["item_type"] or "") == "numeric":
        return "decimal" if "V" in pic.upper() else "integer"
    if pic.upper() in ("X", "X(1)"):
        return "flag"
    return "text"


def run_summary(conn, r) -> str:
    """The run, told in sentences. The trace below is the evidence; this is
    the reading — what ran, what fired, what got skipped because of it, and
    what would have landed in the database. Every claim here is derived
    from the run structure, never invented."""
    steps = r.get("steps") or []
    ms = r.get("_ms", 0)
    trace = r.get("trace", [])
    excs = r.get("exceptions", [])
    writes = r.get("writes", [])
    datasets = r.get("datasets") or {}
    bullets = []

    def code_note(code):
        row = conn.execute(
            "SELECT normalized, meaning FROM exception_code"
            " WHERE normalized = ?", (db.normalize_code(code),)).fetchone()
        link = (f"<a href='/x/{esc(db.normalize_code(code))}'>"
                f"<b>{esc(code)}</b></a>")
        if row and (row["meaning"] or "").strip():
            m = row["meaning"].strip()
            return f"{link} — <i>{esc(m[:90])}{'…' if len(m) > 90 else ''}</i>"
        return (f"{link} <span class=muted>(not in the catalog yet)</span>")

    # ── the headline ──────────────────────────────────────────────────
    if steps:
        ran = [s for s in steps if s["status"] == "completed"]
        skipped = [s for s in steps if s["status"] == "skipped"]
        broken = [s for s in steps if s["status"] in ("halted", "abended")]
        if broken:
            b = broken[0]
            why = b.get("reason") or b.get("detail") or ""
            lead = (f"The run stopped at <b>{esc(b['step'])} "
                    f"({esc(b['pgm'])})</b>: {esc(why)} "
                    f"{len(ran)} step{'s' if len(ran) != 1 else ''} had "
                    f"already finished before it.")
        else:
            lead = (f"All {len(steps)} steps of the mined JCL were "
                    f"processed in {ms}&thinsp;ms — {len(ran)} ran"
                    + (f", {len(skipped)} "
                       f"{'was' if len(skipped) == 1 else 'were'} skipped "
                       f"by gates" if skipped else "")
                    + ". Nothing outside this process was touched.")
    else:
        state = r.get("status", "")
        lead = {"completed": f"The program ran to completion in {ms}&thinsp;ms."
                }.get(state, f"The run ended: {esc(state)}.")
        if r.get("halt"):
            lead = (f"The run stopped: "
                    f"{esc(r['halt'].get('reason', ''))}")
        skipped, ran = [], []

    # ── exceptions, in the order they fired ───────────────────────────
    by_pgm: dict = {}
    for e in excs:
        by_pgm.setdefault(e["pgm"], []).append(e)
    for s in steps:
        hits = by_pgm.get(s["pgm"])
        if not hits or s["status"] != "completed":
            continue
        codes = " and ".join(code_note(e["code"]) for e in hits)
        bullets.append(
            f"<b>{esc(s['pgm'])}</b> raised {codes} and still finished "
            f"(return code {s.get('rc', '?')}).")
    if not steps:
        for pgm, hits in by_pgm.items():
            codes = " and ".join(code_note(e["code"]) for e in hits)
            bullets.append(f"<b>{esc(pgm)}</b> raised {codes}.")

    # ── the gate chain: skipped steps traced to the RC that closed them ─
    import re as _re
    by_blocker: dict = {}
    for s in skipped:
        m = _re.search(r"(\w+)\.RC = (\d+)", s.get("why", ""))
        by_blocker.setdefault(m.groups() if m else ("?", "?"),
                              []).append(s)
    for (blk, rc), members in by_blocker.items():
        blk_pgm = next((s["pgm"] for s in steps if s["step"] == blk), blk)
        names = ", ".join(f"<b>{esc(s['pgm'])}</b>" for s in members)
        bullets.append(
            f"Because <b>{esc(blk)} ({esc(blk_pgm)})</b> finished with "
            f"return code {esc(rc)}, its gate closed and {names} never "
            f"ran — no business function processed this case.")

    # ── what would have landed in the database ────────────────────────
    if writes:
        by_table: dict = {}
        for w in writes:
            table = w["column"].rsplit(".", 1)[0]
            by_table.setdefault((w["stmt"], table), []).append(w)
        VERB = {"insert": "inserted", "update": "updated",
                "delete": "deleted"}
        frags = [f"{VERB.get(stmt, stmt)} <b>{esc(t)}</b> "
                 f"({len(ws)} column{'s' if len(ws) != 1 else ''})"
                 for (stmt, t), ws in by_table.items()]
        blank = [w for w in writes
                 if _re.fullmatch(r"|0+|0*\.0+", w["value"].strip())]
        note = ""
        if blank:
            note = (f" <b>{len(blank)} of {len(writes)}</b> posted values "
                    f"are blank or zero")
            wr_pgms = {e.get("pgm") for e in trace
                       if e.get("kind") == "sql"
                       and e.get("op") in ("insert", "update")}
            put_idx = max((i for i, s in enumerate(steps)
                           if s["pgm"] in wr_pgms), default=-1)
            if any(i < put_idx for i, s in enumerate(steps)
                   if s["status"] == "skipped"):
                note += (" — the skipped business functions sit between "
                         "the build and the PUT, so nothing computed "
                         "them in this run")
            note += "."
        bullets.append("The run would have " + " and ".join(frags) +
                       " — recorded, never performed." + note)

    # ── blank seeds: where a downstream blank-field exception begins ──
    blank_fields: dict = {}
    for e in trace:
        if e.get("kind") == "seed":
            for b in e.get("blank") or []:
                blank_fields.setdefault(b, e.get("area"))
    if blank_fields:
        names = ", ".join(f"<code>{esc(b)}</code>"
                          for b in sorted(blank_fields)[:6])
        more = (f" +{len(blank_fields) - 6}"
                if len(blank_fields) > 6 else "")
        bullets.append(
            f"Seeded <b>blank</b> — the case carries no value for: "
            f"{names}{more}. A downstream blank-field exception starts "
            f"here, not in the code.")

    # ── carried state: the TDAIO seam, made visible ───────────────────
    seen_carry: dict = {}
    for e in trace:
        if e.get("kind") == "carry":
            seen_carry.setdefault(e["area"], []).append(e.get("into"))
    for area, hops in seen_carry.items():
        bullets.append(
            f"<code>{esc(area)}</code> was carried across steps — into "
            + ", ".join(f"<b>{esc(h)}</b>" for h in hops)
            + " — the state the host passes between stages.")

    # ── datasets: what flowed through the files ───────────────────────
    written_dsn = {e.get("dsn") for e in trace
                   if e.get("kind") == "file" and e.get("op") == "write"}
    for dsn, recs in sorted(datasets.items()):
        if dsn in written_dsn:
            first = recs[0][:46] if recs else ""
            bullets.append(
                f"<b>{esc(dsn)}</b> was written: {len(recs)} record"
                f"{'s' if len(recs) != 1 else ''}"
                + (f" <span class=mono muted>({esc(first)}…)</span>"
                   if first else "") + ".")
        elif not recs:
            bullets.append(
                f"<b>{esc(dsn)}</b> ended the run empty — nothing fell "
                f"to it.")
        else:
            bullets.append(
                f"<b>{esc(dsn)}</b>: {len(recs)} record"
                f"{'s' if len(recs) != 1 else ''} (input).")

    items = "".join(f"<li>{b}</li>" for b in bullets)
    return (f"<div class=card><h2>What happened</h2>"
            f"<p style='margin:2px 0 10px'>{lead}</p>"
            f"<ul class=plainlist>{items}</ul></div>")


# The shop's code taxonomy — one list, used by the code-page selector,
# the miner-vocabulary options, and the application groupings.
# Investigate chats live here and ONLY here — server memory, gone on
# restart. Transcripts carry case data; case data never touches
# chatbis.db.
CHATS: dict = {}
CHATS_LOCK = threading.Lock()

# DFR drafting jobs — keyed by program id, server memory only. A draft
# outlives the page that requested it: navigate anywhere, come back,
# the file is waiting. Finished jobs are swept after an hour.
DFR_JOBS: dict = {}
DFR_JOBS_LOCK = threading.Lock()

DOCK_HTML = """
<style>
 #cdockbtn { position:fixed;
   right:max(20px, calc(50vw - 610px)); bottom:9%; width:64px;
   height:64px; border-radius:50%; border:1px solid #2a3b5c;
   background:linear-gradient(180deg,#13273f,#0d1d31); cursor:pointer;
   box-shadow:0 10px 28px rgba(8,15,30,.4); z-index:60;
   display:flex; align-items:center; justify-content:center;
   transition:transform .12s, border-color .12s; }
 #cdockbtn svg { width:38px; height:38px; stroke:#e8b64c; fill:none;
   stroke-width:1.6; stroke-linecap:round; stroke-linejoin:round; }
 #cdockbtn:hover { border-color:#e8b64c; transform:scale(1.06); }
 @media (max-width: 1320px) {
   #cdockbtn { right:22px; bottom:22px; }
   #cdockpanel { right:22px; bottom:98px; }
 }
 #cdockpanel { position:fixed;
   right:max(20px, calc(50vw - 610px)); bottom:9%; width:400px;
   max-width:calc(100vw - 30px); height:min(64vh, 640px); z-index:61;
   background:#0b1220; border:1px solid #1d2b45; border-radius:14px;
   box-shadow:0 18px 44px rgba(8,15,30,.45); display:flex;
   flex-direction:column; overflow:hidden; }
 #cdockpanel[hidden] { display:none; }
 .cdockhead { display:flex; gap:9px; align-items:center;
   padding:9px 14px; background:#0f1830; border-bottom:1px solid #1d2b45; }
 .cdocktitle { font-size:10.5px; letter-spacing:.16em; color:#e8b64c;
   font-weight:800; }
 .cdockhint { font-size:11px; color:#5c6f93; }
 .cdockx { background:transparent; border:0; color:#6d81a6;
   cursor:pointer; font-size:14px; padding:2px 6px; border-radius:6px; }
 .cdockx:hover { background:#16223a; color:#c6d4ec; }
 #cdlog { flex:1; overflow-y:auto; padding:14px 14px 6px; display:flex;
   flex-direction:column; gap:9px; scrollbar-width:thin; }
 #cdockpanel .cbar { padding:10px; }
 #cdockpanel .cbubble { max-width:88%; font-size:13px; }
</style>
<button id=cdockbtn title="Investigate chat" aria-label="Investigate chat">
<svg viewBox="0 0 24 24">
<path d="M12 5.6 V3.9"/><circle cx="12" cy="2.9" r="1.1"/>
<rect x="4.2" y="5.6" width="15.6" height="11.2" rx="3.2"/>
<path d="M2.2 10.4 v2.8 M21.8 10.4 v2.8"/>
<circle cx="9.2" cy="10.4" r="1.15" fill="#e8b64c" stroke="none"/>
<circle cx="14.8" cy="10.4" r="1.15" fill="#e8b64c" stroke="none"/>
<path d="M9.4 13.2 q2.6 2.2 5.2 0"/>
<path d="M8.6 16.8 6.9 20.4 12 16.8"/>
</svg>
</button>
<div id=cdockpanel hidden>
<div class=cdockhead><span class=cdocktitle>INVESTIGATE</span>
<span class=cdockhint>evidence-first · session only</span>
<span style="flex:1"></span>
<button class=cdockx id=cdockend title="Clear this chat">clear</button>
<button class=cdockx id=cdockbye title="End the session and close">end</button>
<button class=cdockx id=cdockmin title="Minimize">&#8213;</button></div>
<div id=cdlog></div>
<form id=cdform class=cbar>
<input id=cdq type=text placeholder="Ask — codes, cases, programs, policy" autocomplete=off>
<button class=wbbtn style="padding:9px 18px">Send</button>
</form>
</div>
<script>
(function() {
  var KEY = 'chatbis.chat', OPENKEY = 'chatbis.dock.open',
      btn = document.getElementById('cdockbtn'),
      panel = document.getElementById('cdockpanel'),
      log = document.getElementById('cdlog'),
      form = document.getElementById('cdform'),
      q = document.getElementById('cdq'),
      send = form.querySelector('button'),
      chatId = sessionStorage.getItem(KEY),
      timer = null, trail = null;
  function esc(t) { var d = document.createElement('div');
    d.textContent = t; return d.innerHTML; }
  function el(cls, html) { var d = document.createElement('div');
    d.className = cls; d.innerHTML = html; return d; }
  function scroll() { log.scrollTop = log.scrollHeight; }
  function bubble(who, html) {
    log.appendChild(el(who === 'user' ? 'cmsg-user' : 'cmsg-bot',
      '<div class=cbubble>' + html + '</div>'));
    scroll();
  }
  function greet() {
    if (!log.children.length)
      bubble('bot', 'Ask about a code, a case, a program or policy — '
        + 'I answer only from the workbench evidence.');
  }
  var running = false;
  function busy(on) {
    running = on; q.disabled = on;
    send.textContent = on ? 'Stop' : 'Send';
  }
  function renderTrail(events, done) {
    if (!trail) { trail = el('ctrail', ''); log.appendChild(trail); }
    trail.innerHTML = events.map(function(e, i) {
      var last = (i === events.length - 1) && !done;
      return '<span class="cstep' + (last ? ' on' : '')
        + (e.k === 'tool' ? ' ctool' : '') + '">' + esc(e.label)
        + (last ? '<span class=cdots><i></i><i></i><i></i></span>' : '')
        + '</span>';
    }).join('');
    scroll();
  }
  function poll() {
    fetch('/chat/status?chat=' + chatId)
      .then(function(r) { return r.json(); })
      .then(function(d) {
        if (d.error === 'unknown chat') {
          clearInterval(timer); sessionStorage.removeItem(KEY);
          chatId = null; busy(false); return;
        }
        renderTrail(d.events, d.done);
        if (d.done) {
          clearInterval(timer); trail = null;
          bubble('bot', d.answer_html || '<i>'
            + esc(d.error || 'no answer') + '</i>');
          busy(false); q.focus();
        }
      });
  }
  function ask(text) {
    if (!text || running) return;
    bubble('user', esc(text));
    busy(true);
    fetch('/chat/ask', { method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: 'q=' + encodeURIComponent(text)
        + (chatId ? '&chat=' + chatId : '') })
      .then(function(r) { return r.json(); })
      .then(function(d) {
        if (d.error && !d.chat) {
          bubble('bot', '<i>' + esc(d.error) + '</i>'); busy(false);
          return;
        }
        chatId = d.chat; sessionStorage.setItem(KEY, chatId);
        timer = setInterval(poll, 600);
      })
      .catch(function() {
        bubble('bot', '<i>the server did not accept the question</i>');
        busy(false);
      });
  }
  function loadHistory() {
    if (!chatId) { greet(); return; }
    fetch('/chat/history?chat=' + chatId)
      .then(function(r) { return r.json(); })
      .then(function(d) {
        if (d.error) { sessionStorage.removeItem(KEY); chatId = null;
          greet(); return; }
        log.innerHTML = '';
        d.messages.forEach(function(m) { bubble(m.who, m.html); });
        greet();
        if (!d.done) { busy(true); timer = setInterval(poll, 600); }
      });
  }
  function openPanel() {
    panel.hidden = false; sessionStorage.setItem(OPENKEY, '1');
    if (!log.children.length) loadHistory();
    q.focus();
  }
  function closePanel() {
    panel.hidden = true; sessionStorage.removeItem(OPENKEY);
  }
  btn.addEventListener('click', function() {
    panel.hidden ? openPanel() : closePanel();
  });
  document.getElementById('cdockmin')
    .addEventListener('click', closePanel);
  function endSession() {
    if (timer) { clearInterval(timer); timer = null; }
    if (chatId) fetch('/chat/end', { method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: 'chat=' + chatId });
    sessionStorage.removeItem(KEY); chatId = null; trail = null;
    log.innerHTML = ''; busy(false); greet();
  }
  document.getElementById('cdockend').addEventListener('click',
    endSession);
  document.getElementById('cdockbye').addEventListener('click',
    function() { endSession(); closePanel(); });
  form.addEventListener('submit', function(ev) {
    ev.preventDefault();
    if (running) {
      if (chatId) fetch('/chat/stop', { method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'chat=' + chatId });
      return;
    }
    var text = q.value.trim(); q.value = '';
    ask(text);
  });
  document.addEventListener('click', function(ev) {
    var d = ev.target.closest('[data-draftq]');
    if (!d) return;
    ev.preventDefault();
    openPanel();
    ask(d.getAttribute('data-draftq'));
  });
  if (sessionStorage.getItem(OPENKEY) === '1') openPanel();
})();
</script>
"""

CATEGORIES = [
    ("exception", "Exception"),
    ("limitation", "Processing limitation (Proclim)"),
    ("alert", "Alert"),
    ("suspension", "Suspension"),
    ("termination", "Termination"),
    ("indicator", "Indicator"),
]

def md_lite(text: str) -> str:
    """The chat answer, rendered: escape everything first, then allow
    exactly the markdown the models actually emit — **bold**, `code`,
    # headings, --- rules. Nothing else; no raw HTML ever survives."""
    out = []
    for line in (text or "").split("\n"):
        e = esc(line)
        e = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", e)
        e = re.sub(r"`([^`]+)`", r"<code>\1</code>", e)
        m = re.match(r"^(#{1,4})\s+(.*)$", e)
        if m:
            e = (f"<b style='font-size:14.5px;display:inline-block;"
                 f"margin-top:6px'>{m.group(2)}</b>")
        elif re.fullmatch(r"[-—_]{3,}", e.strip()):
            e = "<span class=chr></span>"
        out.append(e)
    return "<br>".join(out)


def jwt_exp(token: str | None):
    """The exp claim of a JWT, as a unix timestamp — decoded, never
    verified (display only). None for opaque/absent/undecodable tokens:
    a token we can't read is a token we say nothing about."""
    if not token or token.count(".") != 2:
        return None
    try:
        payload = token.split(".")[1]
        payload += "=" * (-len(payload) % 4)
        claims = json.loads(base64.urlsafe_b64decode(payload))
        exp = claims.get("exp")
        return int(exp) if isinstance(exp, (int, float)) else None
    except (ValueError, TypeError):
        return None


def token_state_chip(env) -> str:
    """The environment's token, told honestly: how long it has left —
    30-minute JWTs die mid-shift, so the countdown lives where the
    analyst works, not buried in Settings."""
    if not env["token"]:
        return "<span class=tokchip>no token</span>"
    exp = jwt_exp(env["token"])
    if exp is None:
        return "<span class=tokchip>token set</span>"
    left = exp - int(time.time())
    when = time.strftime("%H:%M", time.localtime(exp))
    if left <= 0:
        return (f"<span class='tokchip tokdead'>token EXPIRED "
                f"{when}</span>")
    if left < 300:
        return (f"<span class='tokchip tokwarn'>token dies {when} "
                f"({left // 60}m)</span>")
    return f"<span class=tokchip>token to {when} ({left // 60}m)</span>"


def fill_headers(spec: str | None, params: dict) -> dict:
    """Per-endpoint header templates: one 'Name: value' line each,
    {placeholders} filled from the analyst's inputs (region selectors
    and the like). Junk lines are skipped, never guessed at."""
    out: dict = {}
    for line in (spec or "").splitlines():
        line = line.strip()
        if not line or ":" not in line:
            continue
        name, _, val = line.partition(":")
        val = val.strip()
        for k, v in params.items():
            val = val.replace("{%s}" % k, v)
        if name.strip():
            out[name.strip()] = val
    return out


HERO_ICONS = {
    "file": ("<svg viewBox='0 0 24 24' fill='none' stroke='currentColor'"
             " stroke-width='1.6'><path d='M6 2h8l4 4v16H6z'/>"
             "<path d='M14 2v4h4'/></svg>"),
    "doc": ("<svg viewBox='0 0 24 24' fill='none' stroke='currentColor'"
            " stroke-width='1.6'><path d='M5 3h14v18H5z'/>"
            "<path d='M8 8h8M8 12h8M8 16h5'/></svg>"),
    "code": ("<svg viewBox='0 0 24 24' fill='none' stroke='currentColor'"
             " stroke-width='1.6'><circle cx='12' cy='12' r='9'/>"
             "<path d='M12 7v6M12 16.5v.5'/></svg>"),
    "data": ("<svg viewBox='0 0 24 24' fill='none' stroke='currentColor'"
             " stroke-width='1.6'><ellipse cx='12' cy='6' rx='7' ry='3'/>"
             "<path d='M5 6v12c0 1.7 3.1 3 7 3s7-1.3 7-3V6'/>"
             "<path d='M5 12c0 1.7 3.1 3 7 3s7-1.3 7-3'/></svg>"),
    "rule": ("<svg viewBox='0 0 24 24' fill='none' stroke='currentColor'"
             " stroke-width='1.6'><path d='M4 6h16M4 12h10M4 18h7'/>"
             "<path d='M17 15l2 2 3.5-3.5'/></svg>"),
    "stage": ("<svg viewBox='0 0 24 24' fill='none' stroke='currentColor'"
              " stroke-width='1.6'><rect x='4' y='3' width='16' height='5'"
              " rx='1.5'/><rect x='4' y='10' width='16' height='5'"
              " rx='1.5'/><rect x='4' y='17' width='16' height='4'"
              " rx='1.5'/></svg>"),
    "run": ("<svg viewBox='0 0 24 24' fill='none' stroke='currentColor'"
            " stroke-width='1.6'><path d='M8 5v14l11-7z'/></svg>"),
}


def hero_tile(n, label, sub, href, icon, accent="") -> str:
    """One evidence tile under a hero band. `accent` colours the figure
    (readiness verdicts); default is the house navy."""
    style = f" style='color:{accent}'" if accent else ""
    return (f"<a class=statile href='{href}'>"
            f"<span class=st-ico>{HERO_ICONS[icon]}</span>"
            f"<b{style}>{n}</b><span class=st-label>{label}</span>"
            f"<span class=st-sub>{esc(sub)}</span></a>")


def corpus_generation(conn) -> tuple:
    """A fingerprint of everything readiness depends on. The BIG mined
    tables move only through ingest, so MAX/COUNT suffices; the small
    config tables (mappings, stubs) can be edited in place — including by
    scripts outside our routes — so their rows are digested outright.
    They hold at most a few thousand tiny rows; the digest costs
    microseconds and buys correctness a MAX(updated_at) cannot (an UPDATE
    that leaves count, id, and length unchanged still changes the hash)."""
    big = tuple(conn.execute("""SELECT
        (SELECT COALESCE(MAX(id),0)    FROM source_file),
        (SELECT COUNT(*)               FROM source_file),
        (SELECT COALESCE(MAX(rowid),0) FROM line_fts),
        (SELECT COALESCE(MAX(id),0)    FROM program_facet),
        (SELECT COUNT(*)               FROM program_facet),
        (SELECT COUNT(*)               FROM bms_field)""").fetchone())
    h = hashlib.sha1()
    for table in ("field_map", "area_map", "runner_stub"):
        for row in conn.execute(f"SELECT * FROM {table} ORDER BY 1"):
            h.update(repr(tuple(row)).encode())
    return big + (h.hexdigest(),)


_MEMO: dict = {"gen": None}


def _gen_memo(conn) -> dict:
    """The per-generation cache. Stale the instant the corpus moves."""
    g = corpus_generation(conn)
    global _MEMO
    if _MEMO.get("gen") != g:
        _MEMO = {"gen": g, "copy": {}, "call": {}, "ready": {},
                 "worklist": {}, "movelit": None}
    return _MEMO


def _copy_graph(conn, memo) -> dict:
    """file_id → [COPY names] for the whole corpus, in ONE narrowed FTS
    query. line_fts declares file_id UNINDEXED, so per-file WHERE clauses
    scan every line of every member — the cold-pass minutes on a real
    ingest. MATCH uses the token index; COPY lines are rare."""
    if memo.get("copygraph") is None:
        g: dict = {}
        for r in conn.execute(
                "SELECT file_id, text FROM line_fts"
                " WHERE tokens MATCH 'copy'"):
            m = re.search(r"\bCOPY\s+([A-Z0-9-]+)", r["text"], re.I)
            if m:
                g.setdefault(r["file_id"], []).append(m.group(1).upper())
        memo["copygraph"] = g
    return memo["copygraph"]


def _move_literal_index(conn, memo) -> dict:
    """var-name → literal for every MOVE '<lit>' TO <var> in the corpus.
    Built in ONE pass; the old per-call LIKE scan re-read the whole corpus
    for every dynamic CALL on every page load — the difference between
    2 minutes and instant on a real 126-member ingest."""
    if memo["movelit"] is None:
        idx = {}
        for r in conn.execute(
                "SELECT text FROM line_fts WHERE tokens MATCH 'move'"):
            m = re.search(r"MOVE\s+'([A-Z0-9$#@]+)'\s+TO\s+([A-Z0-9-]+)",
                          r["text"], re.I)
            if m and m.group(2).upper() not in idx:
                idx[m.group(2).upper()] = m.group(1).upper()
        memo["movelit"] = idx
    return memo["movelit"]


PROG_SQL = """SELECT p.id, p.name, f.id AS file_id, a.name AS app_name,
                     a.id AS app_id, a.pipeline, a.stage_seq
              FROM program p
              JOIN source_file f ON f.id = p.source_file_id
              LEFT JOIN application a ON a.id = f.application_id"""


def program_modes(conn) -> dict:
    """{program_name: {'online','batch'}} — how each program actually runs.

    Direct evidence only, then propagation: EXEC CICS in the source makes a
    program online; a mined JCL step running it makes it batch; and a callee
    inherits every mode of its callers (a pure business-function module
    LINKed from a screen AND called by the nightly driver is BOTH — the
    dual-mode pattern this shop runs on)."""
    modes: dict = {}
    for r in conn.execute(
            """SELECT DISTINCT p.name FROM program_facet pf
               JOIN program p ON p.id = pf.program_id WHERE pf.kind='cics'"""):
        modes.setdefault(r["name"], set()).add("online")
    for r in conn.execute(
            "SELECT DISTINCT pgm FROM jcl_step WHERE pgm IS NOT NULL"):
        modes.setdefault(r["pgm"], set()).add("batch")
    edges = [(r["caller"], r["ref"]) for r in conn.execute(
        """SELECT p.name AS caller, pf.ref FROM program_facet pf
           JOIN program p ON p.id = pf.program_id WHERE pf.kind='call'""")]
    changed = True
    while changed:
        changed = False
        for caller, callee in edges:
            for m in modes.get(caller, set()):
                if m not in modes.setdefault(callee, set()):
                    modes[callee].add(m)
                    changed = True
    return modes


def mode_chips(modes: set | None) -> str:
    if not modes:
        return ""
    out = ""
    if "batch" in modes:
        out += " <span class='badge reprocessed'>batch</span>"
    if "online" in modes:
        out += " <span class='badge limitation'>online</span>"
    return out


BMS_COLORS = {"BLUE": "#6ab0ff", "RED": "#ff6b5e", "PINK": "#ff8ad8",
              "GREEN": "#33e673", "TURQUOISE": "#4fd8d8",
              "YELLOW": "#ffd75e", "NEUTRAL": "#e8e8e8"}


def bms_lint(text: str, screens) -> list:
    """The 3270's hard rules, checked deterministically — each finding
    cites its line. [(level, lineno, message)]"""
    finds = []
    for i, raw in enumerate(text.splitlines(), 1):
        line = raw.rstrip("\n")
        if len(line) > 72:
            finds.append(("warn", i,
                          f"{len(line)} chars — text beyond column 71 never "
                          f"reaches the assembler; column 72 marks "
                          f"continuation"))
        elif len(line) == 72 and line[71] not in (" ",):
            finds.append(("info", i,
                          f"column 72 holds '{line[71]}' — the NEXT line "
                          f"is treated as a continuation (spliced from "
                          f"column 16)"))
        if line[:1] not in (" ", "*", "") and len(line.split()) > 0:
            label = line.split()[0]
            if len(label) > 8:
                finds.append(("warn", i,
                              f"label '{label}' is {len(label)} chars — "
                              f"BMS labels cap at 8"))
    for _, _, flds in screens:
        cells: dict = {}
        for f_ in flds:
            row, col = f_["pos_row"], f_["pos_col"]
            length = f_["length"] or 0
            if row is None or col is None:
                continue
            if not (1 <= row <= 24) or not (1 <= col <= 80):
                finds.append(("error", f_["lineno"],
                              f"POS=({row},{col}) is off the 24×80 screen"))
                continue
            init = f_["initial"] or ""
            if init and length and len(init) > length:
                finds.append(("warn", f_["lineno"],
                              f"INITIAL is {len(init)} chars but LENGTH="
                              f"{length} — the terminal truncates it"))
            reps = f_["occurs"] or 1
            start = ((f_["map_line"] or 1) - 1 + row - 1) * 80 + col - 1
            for k in range(reps):
                first = start + k * (length + 1)
                for cell in range(first, first + length + 1):
                    if cell >= 24 * 80:
                        finds.append(("warn", f_["lineno"],
                                      "field runs past row 24 — clipped"))
                        break
                    if cell in cells and cells[cell] != f_["lineno"]:
                        finds.append(("error", f_["lineno"],
                                      f"overlaps the field defined at line "
                                      f"{cells[cell]} (attribute byte "
                                      f"included — POS names the byte "
                                      f"BEFORE the text)"))
                        break
                    cells[cell] = f_["lineno"]
                else:
                    continue
                break
            end_col = col + length
            if end_col > 80:
                finds.append(("info", f_["lineno"],
                              f"column {col}+{length} crosses column 80 — "
                              f"the field wraps to the next row (real BMS "
                              f"behaviour, rendered as such)"))
    # dedupe, keep order
    seen, out = set(), []
    for lv, ln, msg in finds:
        if (lv, ln, msg) not in seen:
            seen.add((lv, ln, msg))
            out.append((lv, ln, msg))
    return out


def bms_screens_from_text(text: str) -> list[tuple[str, str, list]]:
    """Raw BMS source → [(mapset, label, field-rows)] ready for
    render_bms_screen — the SAME parser and compositing rule the file
    view uses, so the preview is the truth, not an approximation."""
    from .bms import parse_bms
    ms = parse_bms(text)
    rows = []
    for mp in ms.maps:
        for f_ in mp.fields:
            rows.append({"mapset": ms.name, "map": mp.name,
                         "name": f_.name, "pos_row": f_.row,
                         "pos_col": f_.col, "length": f_.length,
                         "initial": f_.initial, "attrb": f_.attrb,
                         "color": f_.color, "hilight": f_.hilight,
                         "occurs": f_.occurs, "map_line": mp.line,
                         "map_col": mp.column, "lineno": f_.lineno})
    maps = list(dict.fromkeys((b["mapset"], b["map"]) for b in rows))
    placed = {m for _, m in maps if any(
        b["map"] == m and (b["map_line"] or 1) > 1 for b in rows)}
    if placed and len(maps) > 1:
        return [(maps[0][0], " + ".join(m for _, m in maps), rows)]
    return [(ms_, m, [b for b in rows if b["map"] == m])
            for ms_, m in maps]


def render_bms_screen(fields) -> str:
    """A 24×80 3270 rendering of BMS fields — emulator-accurate for what a
    mapset can actually say:

    - POS names the ATTRIBUTE byte; visible text starts one column later
    - map placement honoured: a field's absolute row is DFHMDI LINE-1 +
      its POS row, so header/body/footer maps composite correctly
    - COLOR= renders in the 3270 palette; HILIGHT= REVERSE / UNDERLINE /
      BLINK render as themselves
    - ATTRB=DRK is NON-DISPLAY: the field paints nothing, exactly like the
      terminal (that is what password fields rely on)
    - ATTRB=IC draws the cursor block at the field's first byte
    - OCCURS=n lays the occurrences out the way BMS does: attribute byte +
      LENGTH each, consecutive, wrapping at column 80
    """
    spans = []
    for raw in fields:
        f = dict(raw) if not isinstance(raw, dict) else raw
        g = f.get
        row, col = g("pos_row"), g("pos_col")
        if not row or not col:
            continue
        row += (g("map_line") or 1) - 1
        col += (g("map_col") or 1) - 1
        attrb = (g("attrb") or "").upper()
        length = g("length") or 1

        cls = ["g3f"]
        style = ""
        color = BMS_COLORS.get((g("color") or "").upper())
        if "BRT" in attrb and not color:
            cls.append("bright")
        elif color:
            style += f"color:{color};"
        hil = (g("hilight") or "").upper()
        if hil == "REVERSE":
            style += (f"background:{color or '#33e673'};color:#071207;"
                      "font-weight:700;")
        elif hil == "UNDERLINE":
            style += "text-decoration:underline;"
        elif hil == "BLINK":
            cls.append("blink")

        text = g("initial") or ""
        if g("name") and "UNPROT" in attrb and not text:
            text = "_" * length
            cls.append("inp")
        elif g("name") and "UNPROT" in attrb:
            cls.append("inp")
        if "DRK" in attrb:
            text = ""                        # non-display, like the terminal
        if not text and "IC" not in attrb:
            continue

        # OCCURS: attribute byte + data, occurrences consecutive, wrapping
        # at the 80-column edge — the documented BMS layout.
        reps = g("occurs") or 1
        start = (row - 1) * 80 + col         # 0-based cell of the attr byte
        for k in range(reps):
            cell = start + k * (length + 1)
            r_k, c_k = cell // 80 + 1, cell % 80
            if r_k > 24:
                break
            if text:
                spans.append(
                    f"<span class='{' '.join(cls)}' style='left:{c_k}ch;"
                    f"top:{(r_k - 1) * 1.45}em;{style}'>{esc(text)}</span>")
            if "IC" in attrb and k == 0:
                spans.append(
                    f"<span class='g3f cursor' style='left:{c_k}ch;"
                    f"top:{(r_k - 1) * 1.45}em'>▌</span>")
    return f"<div class=g3270>{''.join(spans)}</div>"


def readback(c: dict) -> str:
    """A check as an English sentence. Correctness should be checkable at a
    glance, not by parsing eight form fields."""
    path = esc(c.get("path") or "")
    op = OPS.get(c.get("op") or "eq", c.get("op") or "")
    lead = ""
    if c.get("group"):
        scope = c.get("scope") or "latest"
        lead = ("In the <b>latest</b> " if scope == "latest"
                else f"In <b>{esc(scope)}</b> ")
        lead += f"<code>{esc(c['group'])}</code>, "
    val = (c.get("value") or "").strip()
    tail = ""
    if val and c.get("op") not in ("blank", "not_blank", "missing"):
        if val.startswith("$$."):
            tail = f" the case's <code>{esc(val[3:])}</code>"
        elif val.startswith("$."):
            # `$.` only means "this occurrence" inside a repeating group;
            # at case level the engine resolves it against the case root.
            where = "the same row's" if c.get("group") else "the case's"
            tail = f" {where} <code>{esc(val[2:])}</code>"
        else:
            tail = f" <code>{esc(val)}</code>"
    return f"{lead}<code>{path}</code> {esc(op)}{tail}"


def badge(text: str) -> str:
    return f'<span class="badge {esc(text)}">{esc(text)}</span>'


MONTHS = ("Jan", "Feb", "Mar", "Apr", "May", "Jun",
          "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")


def nice_day(ts: str) -> str:
    """'2026-07-14T09:00:00' → 'Jul 14'."""
    try:
        return f"{MONTHS[int(ts[5:7]) - 1]} {int(ts[8:10])}"
    except (ValueError, IndexError):
        return ts[:10]


def bar(pct, color: str = "") -> str:
    p = max(0, min(100, int(pct or 0)))
    return (f'<div class=track><div class="fill {color}" '
            f'style="width:{p}%"></div></div>')


def crumbs(*links: tuple[str, str], here: str | None = None) -> str:
    """← Back (browser history) plus a contextual trail for drill-down
    screens: app › program › file."""
    parts = ["<a class=backbtn href='#' onclick='history.back();return false'>"
             "&larr; Back</a>"]
    trail = [f"<a href='{esc(href)}'>{esc(label)}</a>" for label, href in links]
    if here:
        trail.append(f"<b style='color:#33506e'>{esc(here)}</b>")
    if trail:
        parts.append(" <span class=sep>›</span> ".join(trail))
    return "<div class=crumbs>" + "".join(
        f"<span>{p}</span>" for p in parts) + "</div>"


class Handler(BaseHTTPRequestHandler):
    db_path = "chatbis.db"

    def _send(self, body: str, title: str = "ChatBIS", q: str = "", code: int = 200):
        if not self.path.startswith("/chat"):
            body = body + DOCK_HTML
        page = PAGE.format(title=esc(title), body=body, q=esc(q)).encode()
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(page)))
        self.end_headers()
        self.wfile.write(page)

    def _redirect(self, to: str):
        self.send_response(303)
        self.send_header("Location", to)
        self.end_headers()

    def log_message(self, *a):
        pass

    # ── routing ─────────────────────────────────────────────────────────
    def do_GET(self):
        conn = db.connect(self.db_path)
        try:
            url = urllib.parse.urlparse(self.path)
            qs = urllib.parse.parse_qs(url.query)
            if url.path in ("/", "/dash"):
                self._dashboard(conn, qs)
            elif url.path == "/bms/lab":
                self._bms_lab(conn, qs)
            elif url.path == "/policy":
                self._policy(conn, qs)
            elif url.path == "/catalog":
                self._home(conn, qs)
            elif url.path == "/apps":
                self._apps(conn)
            elif url.path == "/scan":
                self._scan(conn, qs)
            elif url.path == "/cobrun":
                self._cobrun(conn, qs)
            elif url.path == "/cobrun/trace":
                self._cobrun_trace(conn, qs)
            elif url.path == "/settings/areamap":
                self._areamap_screen(conn, qs)
            elif url.path == "/pipeline":
                self._pipeline(conn, qs)
            elif url.path.startswith("/job/"):
                self._job(conn, url.path[5:])
            elif url.path == "/cases":
                self._cases(conn, qs)
            elif url.path == "/chat":
                self._chat(conn, qs)
            elif url.path == "/chat/status":
                self._chat_status(qs)
            elif url.path == "/chat/history":
                self._chat_history(qs)
            elif url.path == "/mi":
                # Moved under Settings > Import; keep the old path working.
                q = ("&pending=" + urllib.parse.quote(qs["pending"][0])
                     if qs.get("pending") else "")
                self._redirect("/settings?tab=mi" + q)
            elif url.path == "/lab":
                self._lab_index(conn)
            elif url.path == "/lab/new":
                self._lab_new(conn, qs)
            elif url.path == "/lab/edit":
                if not qs.get("code"):
                    self._redirect("/lab")
                else:
                    self._lab_edit(conn, qs)
            elif url.path == "/settings":
                self._settings(conn, tab=qs.get("tab", ["api"])[0],
                               pending=qs.get("pending", [""])[0],
                               q=qs.get("q", [""])[0].strip(),
                               mp=max(1, int(qs.get("mp", ["1"])[0] or 1)))
            elif url.path == "/settings/fieldmap/edit":
                self._fieldmap_edit(conn, qs)
            elif url.path == "/settings/env/edit":
                self._env_edit(conn, qs)
            elif url.path == "/settings/endpoint/edit":
                self._endpoint_edit(conn, qs)
            elif url.path == "/settings/fieldmap/export":
                self._fieldmap_export(conn, qs.get("fmt", ["csv"])[0])
            elif url.path == "/apps/new":
                self._app_new(conn, qs)
            elif url.path.startswith("/app/"):
                self._app_detail(conn, url.path[5:], qs)
            elif url.path.startswith("/x/"):
                self._resolution(conn, urllib.parse.unquote(url.path[3:]))
            elif url.path.startswith("/prog/") and \
                    url.path.endswith("/dfr.md"):
                self._prog_dfr(conn, url.path[6:-7], qs)
            elif url.path.startswith("/prog/") and \
                    url.path.endswith("/dfr/status"):
                self._dfr_status(url.path[6:-11])
            elif url.path.startswith("/prog/") and \
                    url.path.endswith("/dfr/file"):
                self._dfr_file(url.path[6:-9])
            elif url.path.startswith("/prog/") and \
                    url.path.endswith("/dfr"):
                self._prog_dfr_page(conn, url.path[6:-4])
            elif url.path.startswith("/prog/"):
                self._program(conn, url.path[6:], qs)
            elif url.path.startswith("/doc/"):
                self._doc_reader(conn, url.path[5:])
            elif url.path == "/search":
                self._search(conn, qs.get("q", [""])[0])
            elif url.path.startswith("/file/"):
                self._file(conn, url.path[6:], qs)
            else:
                self._send("<div class=card>Not found.</div>", code=404)
        finally:
            conn.close()

    def do_POST(self):
        conn = db.connect(self.db_path)
        try:
            length = int(self.headers.get("Content-Length", 0))
            if length > MAX_UPLOAD:
                self._send("<div class=card>Upload exceeds the 100 MB cap.</div>", code=413)
                return
            body = self.rfile.read(length)
            url = urllib.parse.urlparse(self.path)
            if url.path.startswith("/app/") and url.path.endswith("/upload"):
                self._post_upload(conn, url.path[5:-7], body)
                return
            if url.path.startswith("/app/") and url.path.endswith("/remine"):
                self._post_remine(conn, url.path[5:-7])
                return
            if url.path.startswith("/prog/") and \
                    url.path.endswith("/dfr/start"):
                self._dfr_start(conn, url.path[6:-10])
                return
            if url.path.startswith("/prog/") and \
                    url.path.endswith("/dfr/cancel"):
                self._dfr_cancel(url.path[6:-11])
                return
            if url.path == "/bms/preview":
                self._bms_preview(body)
                return
            if url.path == "/policy/upload":
                files = parse_multipart(self.headers.get("Content-Type", ""),
                                        body)
                self._policy_upload(conn, files)
                return
            if url.path == "/mi/upload":
                self._mi_upload(body)
                return
            if url.path == "/settings/fieldmap/upload":
                self._fieldmap_upload(body)
                return
            # keep_blank_values: a blank field must still be PRESENT. The Lab
            # walks check rows until path_<i> is absent, so dropping empties
            # truncated the recipe at the first blank row (and lost `manual`
            # checks, which legitimately have no path).
            form = {k: v[0] for k, v in
                    urllib.parse.parse_qs(body.decode(),
                                          keep_blank_values=True).items()}
            if url.path == "/settings/llm":
                self._settings_llm(conn, form)
            elif url.path == "/cobrun/run":
                self._cobrun_launch(conn, form)
            elif url.path == "/cobrun/preflight":
                self._cobrun_preflight(conn, form)
            elif url.path == "/settings/areamap/set":
                self._areamap_set(conn, form)
            elif url.path == "/stub":
                name = form.get("name", "").strip().upper()
                if name:
                    conn.execute(
                        "INSERT OR IGNORE INTO runner_stub (name, note,"
                        " created_at) VALUES (?, ?, ?)",
                        (name, form.get("note", "").strip() or None, db.now()))
                    conn.commit()
                self._redirect(form.get("back", "/apps"))
            elif url.path == "/stub/delete":
                conn.execute("DELETE FROM runner_stub WHERE name = ?",
                             (form.get("name", "").strip().upper(),))
                conn.commit()
                self._redirect(form.get("back", "/apps"))
            elif url.path == "/pipeline/move":
                self._pipeline_move(conn, form)
            elif url.path == "/pipeline/stage":
                self._pipeline_stage_edit(conn, form)
            elif url.path == "/pipeline/add":
                self._pipeline_add(conn, form)
            elif url.path == "/pipeline/rename":
                self._pipeline_rename(conn, form)
            elif url.path == "/pipeline/dissolve":
                self._pipeline_dissolve(conn, form)
            elif url.path == "/settings/fieldmap/format":
                conn.execute("UPDATE field_map SET format = ? WHERE id = ?",
                             (form.get("format", "").strip() or None,
                              int(form.get("id", 0) or 0)))
                conn.commit()
                dest = form.get("back", "")
                self._redirect(dest if dest.startswith("/settings")
                               else "/settings?tab=fields")
            elif url.path.startswith("/x/") and url.path.endswith("/dismiss"):
                norm = urllib.parse.unquote(url.path[3:-8])
                conn.execute("UPDATE exception_code SET status='dismissed',"
                             " updated_at=? WHERE normalized=?",
                             (db.now(), norm))
                conn.commit()
                self._redirect("/catalog")
            elif url.path.startswith("/x/") and url.path.endswith("/restore"):
                norm = urllib.parse.unquote(url.path[3:-8])
                conn.execute("UPDATE exception_code SET status='mined',"
                             " updated_at=? WHERE normalized=?",
                             (db.now(), norm))
                conn.commit()
                self._redirect(f"/x/{urllib.parse.quote(norm)}")
            elif (url.path.startswith("/app/")
                  and url.path.endswith("/miprefix")):
                aid2 = int(url.path[5:-9])
                conn.execute(
                    "UPDATE application SET mi_prefix = ? WHERE id = ?",
                    (form.get("mi_prefix", "").strip().upper() or None,
                     aid2))
                conn.commit()
                self._redirect(f"/app/{aid2}")
            elif (url.path.startswith("/app/")
                  and url.path.endswith("/delete")):
                self._app_delete(conn, url.path[5:-7])
            elif url.path.startswith("/x/") and url.path.endswith("/merge"):
                self._code_merge(conn, urllib.parse.unquote(url.path[3:-6]),
                                 form)
            elif url.path.startswith("/x/") and url.path.endswith("/cite"):
                self._code_cite(conn, urllib.parse.unquote(url.path[3:-5]),
                                form)
            elif url.path.startswith("/x/") and "/link/" in url.path \
                    and url.path.endswith("/annotate"):
                self._link_annotate(conn, url.path, form)
            elif url.path.startswith("/x/") and "/link/" in url.path \
                    and url.path.endswith("/remove"):
                self._link_remove(conn, url.path)
            elif (url.path.startswith("/x/")
                  and url.path.endswith("/category")):
                norm = urllib.parse.unquote(url.path[3:-9])
                cat = form.get("category", "")
                if cat in {v for v, _ in CATEGORIES}:
                    conn.execute(
                        "UPDATE exception_code SET category=?, updated_at=?"
                        " WHERE normalized=?", (cat, db.now(), norm))
                    row = conn.execute("SELECT id FROM exception_code"
                                       " WHERE normalized=?",
                                       (norm,)).fetchone()
                    if row:
                        db.add_event(conn, row["id"], "curated",
                                     outcome="category-changed",
                                     payload={"category": cat},
                                     actor="analyst")
                    conn.commit()
                self._redirect(f"/x/{urllib.parse.quote(norm)}")
            elif url.path == "/settings/vocab":
                conn.execute(
                    """INSERT OR REPLACE INTO field_vocab
                       (pattern, category, note, created_at)
                       VALUES (?, ?, ?, ?)""",
                    (form.get("pattern", "").strip().upper(),
                     form.get("category", "status"),
                     form.get("note", "").strip(), db.now()))
                conn.commit()
                self._redirect("/settings?tab=fields")
            elif url.path == "/settings/vocab/delete":
                conn.execute("DELETE FROM field_vocab WHERE pattern = ?",
                             (form.get("pattern", "").strip().upper(),))
                conn.commit()
                self._redirect("/settings?tab=fields")
            elif url.path == "/doc/kind":
                self._doc_kind(conn, form)
            elif url.path == "/settings/fieldmap/update":
                self._fieldmap_update(conn, form)
            elif url.path == "/settings/env/update":
                self._env_update(conn, form)
            elif url.path == "/settings/endpoint/update":
                self._endpoint_update(conn, form)
            elif url.path == "/settings/fieldmap/mined":
                self._fieldmap_mined(conn, form)
            elif url.path == "/settings/delete":
                self._settings_delete(conn, form)
            elif url.path == "/settings/fieldmap/import":
                self._fieldmap_import(conn, form)
            elif url.path == "/settings/fieldmap" and form.get("label", "").strip():
                aid = form.get("application_id", "").strip()
                conn.execute(
                    """INSERT INTO field_map (application_id, label, cobol_field,
                       db2_column, json_path, format, notes, updated_by,
                       updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (int(aid) if aid.isdigit() else None,
                     form["label"].strip(),
                     form.get("cobol_field", "").strip() or None,
                     form.get("db2_column", "").strip() or None,
                     form.get("json_path", "").strip() or None,
                     form.get("format", "").strip() or None,
                     form.get("notes", "").strip() or None,
                     form.get("actor", "analyst"), db.now()))
                conn.commit()
                self._redirect("/settings?tab=fields")
            elif url.path == "/settings/bundle" and form.get("name", "").strip():
                conn.execute(
                    "INSERT INTO case_bundle (name, description, created_at)"
                    " VALUES (?, ?, ?) ON CONFLICT(name) DO UPDATE SET"
                    " description = excluded.description",
                    (form["name"].strip(), form.get("description", "").strip() or None,
                     db.now()))
                conn.commit()
                self._redirect("/settings?tab=api")
            elif url.path == "/settings/bundlestep":
                try:
                    seq = int(form.get("seq", 0) or 0)
                except ValueError:
                    seq = 0
                conn.execute(
                    """INSERT INTO bundle_step (bundle_id, endpoint_id, mount_key,
                       seq, required) VALUES (?, ?, ?, ?, ?)""",
                    (int(form.get("bundle_id", 0) or 0),
                     int(form.get("endpoint_id", 0) or 0),
                     form.get("mount_key", "").strip(), seq,
                     1 if form.get("required") else 0))
                conn.commit()
                self._redirect("/settings?tab=api")
            elif url.path == "/lab/pull":
                self._lab_pull(conn, form)
            elif url.path == "/lab/create":
                self._lab_create(conn, form)
            elif url.path == "/lab/delete":
                self._lab_delete(conn, form)
            elif url.path == "/lab/draft":
                self._lab_draft(conn, form)
            elif url.path == "/lab/save":
                self._lab_save(conn, form)
            elif url.path == "/mi/import":
                self._mi_import(conn, form)
            elif url.path == "/cases/run":
                self._cases_run(conn, form)
            elif url.path == "/chat/ask":
                self._chat_ask(conn, form)
            elif url.path == "/chat/stop":
                with CHATS_LOCK:
                    st = CHATS.get(form.get("chat", ""))
                    if st:
                        st["stop"] = True
                self._send_json({"ok": True})
                return
            elif url.path == "/chat/end":
                with CHATS_LOCK:
                    st = CHATS.get(form.get("chat", ""))
                    if st:
                        st["stop"] = True   # a running worker winds down
                    CHATS.pop(form.get("chat", ""), None)
                self._send_json({"ok": True})
            elif url.path == "/cases/token":
                self._cases_token(conn, form)
            elif url.path == "/cases/evaluate":
                self._cases_evaluate(conn, form)
            elif url.path == "/cases/sql":
                self._cases_sql(conn, form)
            elif url.path == "/settings/dbsource" and form.get("name", "").strip():
                conn.execute(
                    """INSERT INTO db_source (name, driver, dsn, created_at)
                       VALUES (?, ?, ?, ?)
                       ON CONFLICT(name) DO UPDATE SET driver = excluded.driver,
                         dsn = excluded.dsn""",
                    (form["name"].strip().upper(),
                     "odbc" if form.get("driver") == "odbc" else "sqlite",
                     form.get("dsn", "").strip(), db.now()))
                conn.commit()
                self._redirect("/settings?tab=db")
            elif url.path == "/settings/dbquery" and form.get("name", "").strip():
                conn.execute(
                    "INSERT INTO db_query (name, sql, created_at) VALUES (?, ?, ?)",
                    (form["name"].strip(), form.get("sql", "").strip(), db.now()))
                conn.commit()
                self._redirect("/settings?tab=db")
            elif url.path == "/settings/env" and form.get("name", "").strip():
                conn.execute(
                    """INSERT INTO api_env (name, base_url, token, insecure_tls, created_at)
                       VALUES (?, ?, ?, ?, ?)
                       ON CONFLICT(name) DO UPDATE SET base_url = excluded.base_url,
                         token = CASE WHEN excluded.token != '' THEN excluded.token
                                      ELSE api_env.token END,
                         insecure_tls = excluded.insecure_tls""",
                    (form["name"].strip().upper(), form.get("base_url", "").strip(),
                     form.get("token", "").strip(),
                     1 if form.get("insecure_tls") else 0, db.now()))
                conn.commit()
                self._redirect("/settings?tab=api")
            elif url.path == "/settings/endpoint" and form.get("name", "").strip():
                conn.execute(
                    "INSERT INTO api_endpoint (name, method, path, body,"
                    " headers, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                    (form["name"].strip(),
                     "POST" if form.get("method") == "POST" else "GET",
                     form.get("path", "").strip(),
                     form.get("body", "").strip() or None,
                     form.get("headers", "").strip() or None, db.now()))
                conn.commit()
                self._redirect("/settings?tab=api")
            elif url.path == "/apps/create" and form.get("name", "").strip():
                app_id = db.get_or_create_app(conn, form["name"].strip(),
                                              form.get("description", "").strip() or None)
                conn.commit()
                if form.get("pipeline", "").strip():
                    # Placement rides the same form; _app_set_pipeline
                    # redirects, so re-point it at the artifacts step.
                    self._app_set_pipeline(conn, app_id, form)
                    return
                # Straight into the flow's next step: the app page, whose
                # drop zone is waiting for artifacts.
                self._redirect(f"/app/{app_id}?new=1")
            elif (url.path.startswith("/app/")
                  and url.path.endswith("/pipeline")):
                try:
                    self._app_set_pipeline(conn, int(url.path[5:-9]), form)
                except ValueError:
                    self._send("<div class=card>Bad application id.</div>",
                               code=400)
            elif url.path.startswith("/x/") and url.path.endswith("/recipe"):
                self._post_recipe(conn, url.path[3:-7], form)
            elif url.path.startswith("/x/") and url.path.endswith("/triage"):
                self._post_triage(conn, url.path[3:-7], form)
            elif url.path.startswith("/x/") and url.path.endswith("/resolve"):
                self._post_resolve(conn, url.path[3:-8], form)
            elif url.path.startswith("/x/") and url.path.endswith("/curate"):
                self._post_curate(conn, url.path[3:-7], form)
            else:
                self._send("<div class=card>Not found.</div>", code=404)
        finally:
            conn.close()

    def _exc(self, conn, code: str):
        return conn.execute("SELECT * FROM exception_code WHERE normalized = ?",
                            (db.normalize_code(urllib.parse.unquote(code)),)).fetchone()

    def _post_resolve(self, conn, code, form):
        r = self._exc(conn, code)
        if r:
            db.add_event(conn, r["id"], "resolution",
                         outcome=form.get("outcome", "resolved"),
                         payload={k: form.get(k, "") for k in
                                  ("case_ref", "cause", "field", "action")},
                         actor=form.get("actor", "analyst"))
            conn.commit()
        self._redirect(f"/x/{urllib.parse.unquote(code)}")

    def _post_upload(self, conn, app_id: str, body: bytes):
        """Browser ingest: save uploaded artifacts under the app's artifact
        dir (stable paths → re-uploading a file replaces it) and run the
        exact same pipeline as the CLI."""
        try:
            aid = int(app_id)
        except ValueError:
            self._send("<div class=card>Bad application id.</div>", code=400)
            return
        app = conn.execute("SELECT * FROM application WHERE id = ?", (aid,)).fetchone()
        if not app:
            self._send("<div class=card>Application not found.</div>", code=404)
            return
        files = parse_multipart(self.headers.get("Content-Type", ""), body)
        if not files:
            self._send(f"<div class=card>No files received. "
                       f"<a href='/app/{aid}'>Back</a></div>", code=400)
            return
        artifact_dir = Path(self.db_path).resolve().parent / "artifacts" / app["name"]
        artifact_dir.mkdir(parents=True, exist_ok=True)
        paths: list[Path] = []
        for name, payload in files:
            p = artifact_dir / name
            p.write_bytes(payload)
            paths.append(p)
        summary = ingest_paths(conn, paths, aid)
        self._ingest_results(app, aid, summary,
                             f"Ingested into {app['name']}")

    def _post_remine(self, conn, app_id: str):
        """Re-run the miner over every artifact stored for the app —
        the one-click path after a miner upgrade. Uses the copies the
        upload handler keeps under artifacts/<app>/, so nothing needs
        re-uploading; force bypasses the unchanged-file skip."""
        try:
            aid = int(app_id)
        except ValueError:
            self._send("<div class=card>Bad application id.</div>", code=400)
            return
        app = conn.execute("SELECT * FROM application WHERE id = ?",
                           (aid,)).fetchone()
        if not app:
            self._send("<div class=card>Application not found.</div>",
                       code=404)
            return
        artifact_dir = (Path(self.db_path).resolve().parent / "artifacts"
                        / app["name"])
        paths = sorted(p for p in artifact_dir.glob("*") if p.is_file()) \
            if artifact_dir.is_dir() else []
        if not paths:
            self._send(
                f"<div class=card><h1>Nothing stored to re-mine</h1>"
                f"<p>No uploaded artifacts are stored for "
                f"{esc(app['name'])} — files ingested via the CLI stay "
                f"where they were on disk. Re-upload the members once "
                f"(or rerun <code>chatbis.py ingest &lt;dir&gt; "
                f"--force</code>) and future re-mines are one click.</p>"
                f"<p><a href='/app/{aid}'>← Back</a></p></div>",
                f"Re-mine · {app['name']}")
            return
        summary = ingest_paths(conn, paths, aid, force=True)
        self._ingest_results(app, aid, summary,
                             f"Re-mined {app['name']}")

    def _ingest_results(self, app, aid, summary, title):
        suggest = [x for x in summary if x.get("suggest_policy")]
        pdf_errs = [x for x in summary if x.get("error")]
        rows = ""
        for s in summary:
            # Every ingester returns its own shape (BMS has mapset/fields,
            # JCL has steps, documents have sections). Render what each
            # result actually carries — a missing key must never take the
            # whole results page down after a successful ingest.
            if "skipped" in s:
                what = f"<span class=muted>skipped — {esc(s['skipped'])}</span>"
            elif s.get("error"):
                what = (f"<span style='color:#a63838'>failed — "
                        f"{esc(s['error'])}</span>")
            elif s.get("kind") == "error-table":
                what = (f"error table · {s.get('codes_imported', 0)} codes "
                        f"imported")
            elif s.get("kind") == "document":
                what = (f"document · {s.get('sections', 0)} sections · "
                        f"{s.get('code_links', 0)} rule links")
            elif s.get("kind") == "bms":
                what = (f"BMS · mapset {esc(s.get('mapset') or '—')} · "
                        f"{s.get('maps', 0)} map(s) · "
                        f"{s.get('fields', 0)} fields")
            elif s.get("kind") == "jcl":
                what = (f"JCL · job {esc(s.get('job') or '—')} · "
                        f"{s.get('steps', 0)} steps")
            else:
                bits = [esc(s.get("kind", "ingested"))]
                if s.get("encoding"):
                    bits.append(esc(s["encoding"]))
                if s.get("fmt"):
                    bits.append(f"{esc(s['fmt'])} format")
                if s.get("lines"):
                    bits.append(f"{s['lines']} lines")
                codes = ", ".join(s.get("codes", []))
                if codes:
                    bits.append(f"codes: {esc(codes)}")
                what = " · ".join(bits)
            rows += f"<tr><td><b>{esc(s.get('file', '?'))}</b></td><td>{what}</td></tr>"
        extra = ""
        for e in pdf_errs:
            extra += (f"<div class=banner style='background:#f9e5e5;"
                      f"color:#a63838;border-color:#e7c3c3'>"
                      f"{esc(e['file'])}: {esc(e['error'])}</div>")
        for sg in suggest:
            extra += (
                f"<div class=banner style='background:#fdf6dd;color:#7a5d05;"
                f"border-color:#efe1a8'><b>{esc(sg['file'])}</b> reads like "
                f"POLICY, not a DFR — it names sections the way operating "
                f"manuals do. "
                f"<form method=post action='/doc/kind' style='display:inline'>"
                f"<input type=hidden name=id value={sg['doc_id']}>"
                f"<input type=hidden name=kind value=policy>"
                f"<button class=btnsm2>Move to the Policy library</button>"
                f"</form> <span class=muted>or leave it here as a DFR.</span>"
                f"</div>")
        self._send(
            extra
            + f"<div class=card><h1>{esc(title)}</h1>"
            f"<table><tr><th>File</th><th>Result</th></tr>{rows}</table>"
            f"<p style='margin-top:14px'><a href='/app/{aid}'>← Back to {esc(app['name'])}</a>"
            f" &nbsp;·&nbsp; <a href='/dash'>Dashboard</a></p></div>",
            f"Upload · {app['name']}")

    def fetch_bundle(self, conn, env, bundle_id: int, params: dict):
        """Run a bundle's steps in order and merge them into ONE case object.

        Each step mounts its response at `mount_key` (blank = merge at root,
        for the primary call). Steps may reference earlier responses with
        `{$mount.path}` — e.g. `/v1/periods?claim={$claim.claimNumber}` — so a
        follow-up call can use an id only the first response knows.

        Returns (data, notes, ms). A REQUIRED step that fails aborts and its
        note explains why; an optional failure is noted and the rest proceeds,
        so a missing source reads as 'unavailable' rather than silently
        producing 'no diagnostic matched'.
        """
        steps = conn.execute(
            """SELECT bs.*, e.name AS ep_name FROM bundle_step bs
               JOIN api_endpoint e ON e.id = bs.endpoint_id
               WHERE bs.bundle_id = ? ORDER BY bs.seq, bs.id""",
            (bundle_id,)).fetchall()
        data: dict = {}
        notes: list[str] = []
        total = 0
        for s in steps:
            ep = conn.execute("SELECT * FROM api_endpoint WHERE id = ?",
                              (s["endpoint_id"],)).fetchone()
            if not ep:
                notes.append(f"{s['ep_name']}: endpoint missing")
                continue
            # Resolve {$mount.path} against what previous steps returned.
            step_params = dict(params)
            merged_path = ep["path"] + (ep["body"] or "")
            unresolved = None
            for ref in re.findall(r"\{\$([a-zA-Z0-9_.]+)\}", merged_path):
                val = get_path(data, ref)
                if val is _MISSING or val is None:
                    unresolved = ref
                    break
                step_params["$" + ref] = str(val)
            if unresolved:
                msg = f"{s['ep_name']}: needs {{${unresolved}}}, not present yet"
                notes.append(msg)
                if s["required"]:
                    return data, notes + ["aborted: a required step could not run"], total
                continue
            status, text, ms, err = self._call_api(env, ep, step_params)
            total += ms
            if err or not (status and 200 <= status < 300):
                why = err or f"HTTP {status}"
                notes.append(f"{s['ep_name']}: {why}")
                if s["required"]:
                    return data, notes + ["aborted: a required step failed"], total
                continue
            try:
                payload = json.loads(text)
            except ValueError:
                notes.append(f"{s['ep_name']}: response was not JSON")
                if s["required"]:
                    return data, notes + ["aborted: a required step failed"], total
                continue
            key = (s["mount_key"] or "").strip()
            if key:
                data[key] = payload
            elif isinstance(payload, dict):
                data.update(payload)          # primary call merges at root
            else:
                data.setdefault("_root", payload)
        return data, notes, total

    def _call_api(self, env, ep, params: dict, body_override: str = None):
        """One JWT-authenticated call through an endpoint template.
        Returns (status, text, ms, err). body_override is the analyst's
        edited request body from the form — it wins over the stored
        template, placeholders filled either way."""
        path = ep["path"]
        for k, v in params.items():
            path = path.replace("{%s}" % k, urllib.parse.quote(v, safe=""))
        url = env["base_url"].rstrip("/") + path
        body = None
        # Body on ANY method that defines one — some enterprise APIs take a
        # body on GET, and refusing to send it just breaks those endpoints.
        template = (body_override if body_override and body_override.strip()
                    else ep["body"])
        if template:
            b = template
            for k, v in params.items():
                b = b.replace("{%s}" % k, json.dumps(v)[1:-1])
            body = b.encode()
        headers = {"Accept": "application/json"}
        if env["token"]:
            headers["Authorization"] = f"Bearer {env['token']}"
        if body:
            headers["Content-Type"] = "application/json"
        try:
            hspec = ep["headers"]
        except (KeyError, IndexError):
            hspec = None
        headers.update(fill_headers(hspec, params))
        ctx = ssl._create_unverified_context() if env["insecure_tls"] else None
        started = time.perf_counter()
        status, text, err = None, "", None
        try:
            req = urllib.request.Request(url, data=body, headers=headers,
                                         method=ep["method"])
            with urllib.request.urlopen(req, timeout=20, context=ctx) as resp:
                status = resp.status
                text = resp.read(1_000_000).decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            status = e.code
            text = e.read(1_000_000).decode("utf-8", "replace")
        except Exception as e:
            err = str(e)
        return status, text, int((time.perf_counter() - started) * 1000), err

    def _post_recipe(self, conn, code, form):
        """Save the code's triage recipe: endpoint + checks + fallback steps."""
        r = self._exc(conn, code)
        if not r:
            self._send("<div class=card>Unknown code.</div>", code=404)
            return
        checks = []
        for i in range(40):
            if f"path_{i}" not in form:
                break
            path = form.get(f"path_{i}", "").strip()
            if not path:
                continue
            checks.append({
                "path": path,
                "op": form.get(f"op_{i}", "eq"),
                "value": form.get(f"value_{i}", "").strip(),
                "cause": form.get(f"cause_{i}", "").strip(),
                "steps": form.get(f"steps_{i}", "").strip(),
            })
        try:
            endpoint_id = int(form.get("endpoint_id", "") or 0) or None
        except ValueError:
            endpoint_id = None
        conn.execute(
            """INSERT INTO playbook (exception_id, endpoint_id, general_steps,
               checks, updated_by, updated_at) VALUES (?, ?, ?, ?, ?, ?)
               ON CONFLICT(exception_id) DO UPDATE SET
                 endpoint_id = excluded.endpoint_id,
                 general_steps = excluded.general_steps,
                 checks = excluded.checks,
                 updated_by = excluded.updated_by,
                 updated_at = excluded.updated_at""",
            (r["id"], endpoint_id, form.get("general_steps", "").strip() or None,
             json.dumps(checks), form.get("actor", "analyst"), db.now()))
        db.add_event(conn, r["id"], "edit", payload={"via": "recipe-form"},
                     actor=form.get("actor", "analyst"))
        conn.commit()
        self._redirect(f"/x/{urllib.parse.unquote(code)}")

    def _post_triage(self, conn, code, form):
        """Run the recipe against a live case: pull, diagnose, answer."""
        r = self._exc(conn, code)
        pb = (conn.execute("SELECT * FROM playbook WHERE exception_id = ?",
                           (r["id"],)).fetchone() if r else None)
        if not r or not pb or not pb["endpoint_id"]:
            self._send("<div class=card>No triage recipe configured.</div>", code=400)
            return
        env = conn.execute("SELECT * FROM api_env WHERE id = ?",
                           (int(form.get("env", 0)),)).fetchone()
        ep = conn.execute("SELECT * FROM api_endpoint WHERE id = ?",
                          (pb["endpoint_id"],)).fetchone()
        if not env or not ep:
            self._send("<div class=card>Environment or endpoint missing.</div>", code=400)
            return
        params = {k[2:]: v.strip() for k, v in form.items() if k.startswith("p_")}
        status, text, ms, err = self._call_api(env, ep, params)
        masked = {k: mask_value(k, v) for k, v in params.items()}

        if err or not (status and 200 <= status < 300):
            card = (f"<div class=card><h2>Triage · case pull failed</h2>"
                    f"<p><span class='badge failed' style='margin-left:0'>"
                    f"{esc(err or f'HTTP {status}')}</span> "
                    f"<span class=muted>{esc(env['name'])} · {ms} ms</span></p></div>")
            db.add_event(conn, r["id"], "triage", outcome="pull_failed",
                         payload={"params": masked, "status": status}, actor="web")
            conn.commit()
            self._resolution(conn, code, extra_html=card)
            return
        try:
            data = json.loads(text)
        except ValueError:
            data = {}
        # Same engine + same group_config as the Lab, so the workbench can
        # never disagree with production triage.
        result = run_recipe(json.loads(pb["checks"]), data,
                            json.loads(pb["group_config"] or "{}"))

        blocks = []
        for m in result["matches"]:
            steps = "".join(f"<li>{esc(s.strip())}</li>"
                            for s in m["steps"].split("\n") if s.strip())
            evidence = (f"<code>{esc(m['path'])}</code> = <b>{esc(m['actual'])}</b>"
                        f" · {esc(m['op'])}"
                        + (f" · {esc(m['expected'])}" if m["expected"] else ""))
            blocks.append(
                f"<div style='margin:12px 0;padding:12px 16px;background:#f2f7f3;"
                f"border:1px solid #cfe5d6;border-radius:10px'>"
                f"<div style='font-size:15px'><b>Cause: {esc(m['cause'])}</b></div>"
                f"<div class=muted style='margin:4px 0 8px'>{evidence}</div>"
                f"{('<ol style=margin:0>' + steps + '</ol>') if steps else ''}</div>")
        if not result["matches"]:
            fallback = "".join(f"<li>{esc(s.strip())}</li>" for s in
                               (pb["general_steps"] or "").split("\n") if s.strip())
            blocks.append(
                f"<div class=banner style='background:#fdf6dd;color:#7a5d05;"
                f"border-color:#efe1a8'>No diagnostic matched this case — "
                f"general steps below; consider adding a check for what you find."
                f"</div>" + (f"<ol>{fallback}</ol>" if fallback else ""))
        errs = ("<p class=muted>" + " · ".join(esc(e) for e in result["errors"])
                + "</p>") if result["errors"] else ""
        pretty = json.dumps(data, indent=2) if data else text
        card = (f"<div class=card><h2>Triage result · "
                f"{esc(', '.join(f'{k} {v}' for k, v in masked.items()))}</h2>"
                f"<p class=muted style='margin-top:-4px'>{result['evaluated']} checks "
                f"evaluated · {len(result['matches'])} matched · {esc(env['name'])} "
                f"· {ms} ms</p>{''.join(blocks)}{errs}"
                f"<details><summary class=muted>Case data</summary>"
                f"<pre style='max-height:360px;overflow:auto'>{esc(pretty[:40000])}"
                f"</pre></details></div>")
        db.add_event(conn, r["id"], "triage",
                     outcome="matched" if result["matches"] else "no_match",
                     payload={"params": masked,
                              "causes": [m["cause"] for m in result["matches"]]},
                     actor="web")
        conn.commit()
        self._resolution(conn, code, extra_html=card)

    def _post_curate(self, conn, code, form):
        """The analyst's analysis, captured: investigation output becomes
        the curated catalog entry (slow path feeds fast path, spec §3)."""
        r = self._exc(conn, code)
        if r:
            conn.execute(
                """UPDATE exception_code SET meaning = ?, screen_id = ?,
                   data_element = ?, category = ?, status = 'curated',
                   curated_by = ?, updated_at = ? WHERE id = ?""",
                (form.get("meaning") or r["meaning"],
                 form.get("screen_id") or r["screen_id"],
                 form.get("data_element") or r["data_element"],
                 form.get("category") or r["category"],
                 form.get("actor", "analyst"), db.now(), r["id"]))
            db.add_event(conn, r["id"], "edit", payload={"via": "curate-form"},
                         actor=form.get("actor", "analyst"))
            conn.commit()
        self._redirect(f"/x/{urllib.parse.unquote(code)}")

    # ── screens ─────────────────────────────────────────────────────────
    def _home(self, conn, qs):
        cat = qs.get("cat", [""])[0]
        q = qs.get("q", [""])[0].strip()
        conds, args = [], []
        if cat:
            conds.append("e.category = ?")
            args.append(cat)
        if q:
            # Code, meaning, screen — the three things an analyst arrives
            # with. Matching is separator-blind so e4417 and E-4417 both hit.
            like = f"%{q}%"
            conds.append(
                "(e.code LIKE ? OR e.normalized LIKE ? OR e.meaning LIKE ?"
                " OR e.screen_id LIKE ? OR EXISTS("
                "SELECT 1 FROM exception_link el WHERE el.exception_id = e.id"
                " AND el.relation IN ('emitted_by','raised_by','set_by')"
                " AND el.target_ref LIKE ?))")
            args += [like, f"%{db.normalize_code(q)}%", like, like, like]
        conds.append("COALESCE(e.status,'') != 'dismissed'")
        where = ("WHERE " + " AND ".join(conds)) if conds else ""
        total = conn.execute("SELECT COUNT(*) FROM exception_code"
                             " WHERE COALESCE(status,'') != 'dismissed'"
                             ).fetchone()[0]
        rows = conn.execute(f"""
            SELECT e.*, COUNT(ev.id) AS activity
            FROM exception_code e
            LEFT JOIN exception_event ev ON ev.exception_id = e.id
            {where} GROUP BY e.id ORDER BY activity DESC, e.normalized LIMIT 300
        """, tuple(args)).fetchall()
        # Where each code is raised: the top-confidence emitting program,
        # marked "batch" only when a mined JCL step provably runs it. Many
        # codes live in batch and never see a screen — the catalog should
        # say so instead of implying everything is fixed on one.
        # emitted_by/raised_by = the failure path; set_by = vocabulary-
        # classified indicator/status fields, whose "where" is the modules
        # that SET them. Highest confidence leads; the rest are counted.
        raised: dict = {}
        for l in conn.execute(
                """SELECT exception_id, target_ref, relation, confidence
                   FROM exception_link
                   WHERE relation IN ('emitted_by','raised_by','set_by')
                   AND target_kind = 'program'
                   ORDER BY confidence DESC, id"""):
            refs = raised.setdefault(l["exception_id"], [])
            if l["target_ref"] not in [x[0] for x in refs]:
                refs.append((l["target_ref"], l["relation"]))
        modes = program_modes(conn)
        qparam = f"&q={urllib.parse.quote(q)}" if q else ""
        tabs = " ".join(
            f"<a{' style=font-weight:700' if c == cat else ''} "
            f"href='/catalog?cat={c}{qparam}'>{c + 's' if c else 'all'}</a>"
            for c in [""] + [k for k, _ in CATEGORIES])
        def where_cell(r) -> str:
            progs = raised.get(r["id"], [])
            bits = []
            if progs:
                pgm, rel = progs[0]
                lead = ("<span class=muted>set in</span> "
                        if rel == "set_by" else "")
                more = (f" <span class=muted>+{len(progs) - 1} more</span>"
                        if len(progs) > 1 else "")
                bits.append(f"{lead}<code>{esc(pgm)}</code>"
                            f"{mode_chips(modes.get(pgm))}{more}")
            if r["screen_id"]:
                bits.append(f"<span class=muted>fix on</span> "
                            f"{esc(r['screen_id'])}")
            return " · ".join(bits) or "<span class=muted>—</span>"

        items = "".join(
            f"<tr><td><a href='/x/{esc(r['normalized'])}'><b>{esc(r['code'])}</b></a></td>"
            f"<td>{badge(r['category'])}{badge(r['status'])}</td>"
            f"<td>{esc((r['meaning'] or '—')[:100])}</td>"
            f"<td style='white-space:nowrap'>{where_cell(r)}</td>"
            f"<td>{r['activity']}</td></tr>"
            for r in rows)
        count = (f"{len(rows)} of {total} match" if q else f"{len(rows)} entries")
        clear = (f" · <a href='/catalog{('?cat=' + cat) if cat else ''}'>clear</a>"
                 if q else "")
        empty = ""
        if q and not rows:
            empty = (f"<p class=muted style='margin:16px 0 0'>Nothing in the "
                     f"catalog matches <b>{esc(q)}</b> — try "
                     f"<a href='/search?q={urllib.parse.quote(q)}'>searching the "
                     f"whole corpus</a> (source, DFRs, data items).</p>")
        body = (f"<div class=card><div class=cardhead><h1>Catalog</h1>"
                f"<form method=get action='/catalog' style='display:flex;gap:8px'>"
                + (f"<input type=hidden name=cat value='{esc(cat)}'>" if cat else "")
                + f"<input type=text name=q value=\"{esc(q)}\" "
                f"placeholder='Filter by code, meaning, program, or screen' "
                f"style='max-width:300px;margin:0'>"
                f"<button>Filter</button></form></div>"
                f"<p class=muted>{count}{clear} · {tabs} · the catalog compounds "
                f"as each investigation is captured</p>"
                f"<table><tr><th>Code</th><th></th><th>Meaning</th><th>Raised in</th>"
                f"<th>Activity</th></tr>{items}</table>{empty}</div>")
        self._send(body, "Catalog", q="")

    def _dashboard(self, conn, qs=None):
        one = lambda sql, *p: conn.execute(sql, p).fetchone()[0]
        cats = dict(conn.execute(
            "SELECT category, COUNT(*) FROM exception_code GROUP BY category").fetchall())
        curated = one("SELECT COUNT(*) FROM exception_code WHERE status IN ('curated','imported')")
        total = one("SELECT COUNT(*) FROM exception_code") or 1
        with_emit = one("""SELECT COUNT(DISTINCT exception_id) FROM exception_link
                           WHERE relation IN ('emitted_by','raised_by')""")
        recipes = one("SELECT COUNT(*) FROM playbook")
        apps = one("SELECT COUNT(*) FROM application")
        progs = one("SELECT COUNT(*) FROM program")
        docs = one("SELECT COUNT(*) FROM document")
        pct_rec = round(100 * recipes / total)
        pct_expl = round(100 * curated / total)
        pct_trace = round(100 * with_emit / total)

        kpis = f"""<div class=kpis>
<div class=kpi><div class=lbl>Catalog entries</div><div class=big>{total}</div>
 <div class=sub><span class="dot d-exception"></span>{cats.get('exception', 0)} exceptions<br>
 <span class="dot d-alert"></span>{cats.get('alert', 0)} alerts &nbsp;
 <span class="dot d-limitation"></span>{cats.get('limitation', 0)} limitations</div></div>
<div class=kpi><div class=lbl>Corpus</div><div class=big>{progs}</div>
 <div class=sub>programs indexed<br>{apps} application{'s' if apps != 1 else ''} ·
 {docs} DFR{'s' if docs != 1 else ''}</div></div>
<div class=kpi><div class=lbl>Recipes</div><div class=big>{recipes}</div>
 {bar(pct_rec, 'green')}<div class=sub>of {total} codes have one ·
 <a href="/lab/new">author the next</a></div></div>
<div class=kpi><div class=lbl>Catalog coverage</div>
 <div class=sub style="margin-top:2px">Explained · {pct_expl}%</div>{bar(pct_expl, 'green')}
 <div class=sub>Traced to code · {pct_trace}%</div>{bar(pct_trace, 'gold')}</div>
</div>"""

        # Production volume from imported MI: who is failing, where, and when.
        mi_card = ""
        mi_total = one("""SELECT COALESCE(SUM(CAST(json_extract(payload,'$.count')
                          AS INTEGER)), 0) FROM exception_event WHERE kind='mi'""")
        if mi_total:
            mq = (qs or {}).get("mq", [""])[0].strip()
            ms = (qs or {}).get("ms", ["volume"])[0]
            ORDERS = {"volume": "n DESC",
                      "code": "e.code, n DESC",
                      "application": "app, n DESC",
                      "period": "period DESC, n DESC"}
            order = ORDERS.get(ms, ORDERS["volume"])
            where, args = "", []
            if mq:
                like = f"%{mq}%"
                where = ("""AND (e.code LIKE ? OR e.normalized LIKE ?
                            OR COALESCE(json_extract(ev.payload,
                                '$.application'),'') LIKE ?
                            OR COALESCE(json_extract(ev.payload,
                                '$.period'),'') LIKE ?)""")
                args = [like] * 4
            groups = conn.execute(f"""
                SELECT e.code, e.normalized, e.category,
                  COALESCE(json_extract(ev.payload,'$.application'), '—') AS app,
                  COALESCE(json_extract(ev.payload,'$.period'), '—') AS period,
                  SUM(CAST(json_extract(ev.payload,'$.count') AS INTEGER)) AS n
                FROM exception_event ev
                JOIN exception_code e ON e.id = ev.exception_id
                WHERE ev.kind='mi' {where}
                GROUP BY e.id, app, period ORDER BY {order}""",
                tuple(args)).fetchall()
            shown = groups[:30]
            mxc = max((r["n"] for r in shown), default=1) or 1
            vol_rows = "".join(
                f"<tr><td style='white-space:nowrap'>"
                f"<span class='dot d-{esc(r['category'])}'></span>"
                f"<a href='/x/{esc(r['normalized'])}'><b>{esc(r['code'])}</b></a></td>"
                f"<td>{esc(r['app'])}</td>"
                f"<td style='white-space:nowrap'>{esc(r['period'])}</td>"
                f"<td class=num><div class=abar>{bar(100 * r['n'] / mxc)}"
                f"<b>{r['n']}</b></div></td></tr>" for r in shown)
            if not vol_rows:
                vol_rows = ("<tr><td colspan=4 class=muted>Nothing matches "
                            f"“{esc(mq)}”.</td></tr>")
            sort_chips = " · ".join(
                (f"<b>{label}</b>" if ms == key else
                 f"<a href='/dash?ms={key}"
                 f"{'&mq=' + urllib.parse.quote(mq) if mq else ''}#mi'>"
                 f"{label}</a>")
                for key, label in (("volume", "volume"), ("code", "code"),
                                   ("application", "application"),
                                   ("period", "period")))
            more = (f" · showing 30 of {len(groups)} groups"
                    if len(groups) > 30 else "")
            last = conn.execute("SELECT filename, ts FROM mi_import"
                                " ORDER BY id DESC LIMIT 1").fetchone()
            src = (f" · latest extract <b>{esc(last['filename'])}</b> "
                   f"({esc(nice_day(last['ts']))})" if last else "")
            mi_card = (
                f"<div class=card id=mi><div class=cardhead>"
                f"<h2 style='margin:0'>Production volume · from MI extracts"
                f"</h2>"
                f"<form method=get action='/dash#mi' style='display:flex;"
                f"gap:7px;margin:0'>"
                f"<input type=hidden name=ms value='{esc(ms)}'>"
                f"<input name=mq value='{esc(mq)}' placeholder='filter code, "
                f"application, period…' style='margin:0;width:230px;"
                f"font-size:13px;padding:6px 11px'>"
                f"<button class=btnsm2 style='padding:6px 13px'>Filter"
                f"</button>"
                + (f"<a class=btnsm2 style='padding:6px 11px' "
                   f"href='/dash?ms={esc(ms)}#mi'>clear</a>" if mq else "")
                + f"</form></div>"
                f"<p class=muted style='margin-top:2px'>"
                f"<b style='color:var(--ink);font-size:16px'>{mi_total:,}</b> occurrences "
                f"imported{src} · <a href='/settings?tab=mi'>import another</a>"
                f" · sort: {sort_chips}{more}</p>"
                f"<table><tr><th>Code</th><th>Application</th><th>Period</th>"
                f"<th class=num>Occurrences</th></tr>{vol_rows}</table>"
                f"</div>")

        # Hottest codes: production volume (MI) and tool events kept apart —
        # a summed 'activity' number answers no one's question.
        top = conn.execute("""
            SELECT e.code, e.normalized, e.category, e.meaning,
              SUM(CASE WHEN ev.kind='mi' THEN COALESCE(CAST(
                json_extract(ev.payload,'$.count') AS INTEGER), 1) ELSE 0 END) AS prod,
              SUM(CASE WHEN ev.kind='mi' THEN 0 ELSE 1 END) AS tool,
              EXISTS(SELECT 1 FROM playbook pb WHERE pb.exception_id = e.id)
                AS has_recipe
            FROM exception_code e JOIN exception_event ev ON ev.exception_id = e.id
            WHERE e.category IN ('exception','alert','limitation')
            GROUP BY e.id ORDER BY prod DESC, tool DESC LIMIT 12""").fetchall()
        max_n = max((r["prod"] for r in top), default=1) or 1
        toprows = ""
        for r in top:
            prod_cell = (f"<div class=abar>{bar(100 * r['prod'] / max_n)}"
                         f"<b>{r['prod']}</b></div>" if r["prod"]
                         else "<span class=muted>—</span>")
            toprows += (
                f"<tr><td style='white-space:nowrap'>"
                f"<span class='dot d-{esc(r['category'])}'></span>"
                f"<a href='/x/{esc(r['normalized'])}'><b>{esc(r['code'])}</b></a></td>"
                f"<td>{esc((r['meaning'] or '—')[:70])}</td>"
                f"<td class=num>{prod_cell}</td>"
                f"<td class=num>{r['tool']}</td>"
                f"<td style='white-space:nowrap'>"
                + (f"<a href='/lab/edit?code={esc(r['normalized'])}'>"
                   f"<span class='badge resolved' style='margin-left:0'>✓ recipe"
                   f"</span></a>" if r["has_recipe"] else
                   f"<a class=muted href='/lab/new?q={esc(r['normalized'])}'>"
                   f"author →</a>")
                + "</td></tr>")

        body = (kpis + mi_card
                + f"<div class=card><h2>Hottest codes · candidates for a permanent fix</h2>"
                  f"<table><tr><th>Code</th><th>Meaning</th>"
                  f"<th class=num>Prod volume · MI</th><th class=num>Tool events</th>"
                  f"<th>Recipe</th></tr>"
                  f"{toprows}</table>"
                  f"<p class=muted style='margin:12px 0 0'>Hot code without a "
                  f"recipe = the next one worth authoring — volume comes from "
                  f"the imported MI, tool events from analyst lookups here.</p>"
                  f"</div>")
        self._send(body, "Dashboard")

    # ── Field Scan: the mainframe developer's scan, classified ────────
    RE_IDENT = re.compile(r"[A-Z][A-Z0-9_.-]{2,}")

    @classmethod
    def classify_hit(cls, text: str, q: str) -> tuple[str, str]:
        """(kind, matched_identifier) for one source line containing q.
        Kinds: definition · write · read · condition · sql · mention.
        COBOL hyphens and DB2 underscores are the same name in different
        dress, so matching treats them as one separator."""
        u = text.upper()
        qn = q.replace("_", "-")
        idents = [i for i in cls.RE_IDENT.findall(u)
                  if qn in i.replace("_", "-")]
        ident = max(idents, key=len) if idents else q
        stripped = u.strip()
        if re.match(r"^\d{2}\s", stripped) and ("PIC" in u or "OCCURS" in u
                                                or stripped.split()[1].startswith(ident)):
            return "definition", ident
        if re.match(r"^88\s", stripped):
            return "definition", ident
        if f":{ident}" in u or "EXEC SQL" in u:
            return "sql", ident
        if re.search(r"\b(IF|WHEN|UNTIL|EVALUATE)\b", u):
            return "condition", ident
        if "MOVE" in u or "GIVING" in u or "INITIALIZE" in u:
            to_at = u.find(" TO ")
            giv_at = u.find("GIVING")
            at = u.find(ident)
            if "INITIALIZE" in u:
                return "write", ident
            if giv_at >= 0:
                return ("write" if at > giv_at else "read"), ident
            if to_at >= 0:
                return ("write" if at > to_at else "read"), ident
        if "COPY" in u:
            return "mention", ident
        return "mention", ident

    def _scan_edges(self, conn):
        """Every mined flow edge and SQL pair, with program + stage context."""
        rows = conn.execute("""
            SELECT pf.kind, pf.detail, pf.line, p.name AS prog,
                   f.id AS file_id, a.name AS app, a.pipeline, a.stage_seq
            FROM program_facet pf
            JOIN program p ON p.id = pf.program_id
            JOIN source_file f ON f.id = p.source_file_id
            LEFT JOIN application a ON a.id = f.application_id
            WHERE pf.kind IN ('flow', 'sqlmap')""").fetchall()
        edges = []
        for r in rows:
            d = json.loads(r["detail"])
            if r["kind"] == "flow":
                src, tgt = d["source"], d["target"]
            else:
                src, tgt = d["host"], d["column"]
            edges.append({"source": src, "target": tgt, "kind": r["kind"],
                          "verb": d.get("verb") or d.get("stmt", ""),
                          "prog": r["prog"], "line": r["line"],
                          "file_id": r["file_id"], "app": r["app"],
                          "seq": r["stage_seq"] if r["stage_seq"] is not None
                                 else 10 ** 6})
        # The screen joint: a labeled BMS field generates symbolic-map names
        # (label+I on the way in, label+O on the way out) that programs MOVE
        # from — screen edges sort first, they are where the data enters.
        for b in conn.execute(
                "SELECT b.*, f.id AS file_id FROM bms_field b"
                " JOIN source_file f ON f.id = b.source_file_id"
                " WHERE b.name != ''"):
            screen = f"{b['map']}.{b['name']}"
            for suffix, verb, into in (("I", "screen input", True),
                                       ("O", "screen output", False)):
                sym = b["name"] + suffix
                edges.append({
                    "source": screen if into else sym,
                    "target": sym if into else screen,
                    "kind": "bms", "verb": verb, "prog": b["map"],
                    "line": b["lineno"], "file_id": b["file_id"],
                    "app": None, "seq": -1})
        return edges

    @staticmethod
    def _chain_for(edges: list, q: str) -> list:
        """The connected slice of the flow graph touching q, in stage order.
        Follows edges both directions so scanning a middle hop still shows
        the whole journey."""
        adj: dict = {}
        for e in edges:
            adj.setdefault(e["source"], []).append(e)
            adj.setdefault(e["target"], []).append(e)
        seed = [n for n in adj if q in n]
        seen_nodes, out, frontier = set(seed), [], list(seed)
        seen_edges = set()
        while frontier:
            node = frontier.pop()
            for e in adj.get(node, []):
                key = (e["source"], e["target"], e["prog"], e["line"])
                if key in seen_edges:
                    continue
                seen_edges.add(key)
                out.append(e)
                for n in (e["source"], e["target"]):
                    if n not in seen_nodes:
                        seen_nodes.add(n)
                        frontier.append(n)
        out.sort(key=lambda e: (e["seq"], e["prog"] or "", e["line"] or 0))
        return out

    def _scan(self, conn, qs):
        q = (qs or {}).get("q", [""])[0].strip().upper()
        parts = [f"""<div class=card><div class=cardhead><h1>Field Scan</h1></div>
<p class=muted style='margin-top:-2px'>Every touch of a field across every
ingested member — the scan you'd run on the mainframe, classified: where it's
defined, written, read, tested, and where it lands in the database.</p>
<form method=get action='/scan' style='margin-top:12px;display:flex;gap:10px'>
<input type=text name=q value="{esc(q)}" placeholder='e.g. BENE-DOB · TDA-ENT-DT · CLM_TYPE'
 style='max-width:340px;margin:0' autofocus>
<button>Scan</button></form></div>"""]
        if not q:
            recent = conn.execute(
                """SELECT name, COUNT(*) n FROM data_item
                   GROUP BY name ORDER BY n DESC LIMIT 12""").fetchall()
            chips = "".join(f"<a class=codechip href='/scan?q={esc(r['name'])}'>"
                            f"{esc(r['name'])}</a>" for r in recent)
            parts.append(f"<div class=card><h2>Fields defined in more than one "
                         f"place</h2>{chips or '<p class=muted>Ingest source to scan.</p>'}"
                         f"<p class=muted style='margin:10px 0 0'>A field defined in "
                         f"several members usually rides a shared copybook — the "
                         f"seam between pipeline stages.</p></div>")
            self._send("".join(parts), "Field Scan")
            return

        # ── called from: the utility's callers, stage-ordered ──────────
        qn = q.replace("_", "-")
        callers = [r for r in conn.execute(
            """SELECT pf.ref, pf.line, pf.detail, p.name AS caller,
                      f.id AS file_id, a.name AS app, a.pipeline, a.stage_seq
               FROM program_facet pf
               JOIN program p ON p.id = pf.program_id
               JOIN source_file f ON f.id = p.source_file_id
               LEFT JOIN application a ON a.id = f.application_id
               WHERE pf.kind = 'call'
               ORDER BY a.stage_seq IS NULL, a.stage_seq, p.name, pf.line""")
            if qn in r["ref"].replace("_", "-")]
        # Dynamic resolution: CALL WS-PGM sites whose variable is loaded with
        # this literal somewhere in the source.
        dyn_vars = {m.group(1) for r in conn.execute(
            "SELECT text FROM line_fts WHERE text LIKE ?", (f"%'{q}'%",))
            for m in [re.search(rf"MOVE\s+'{re.escape(q)}'\s+TO\s+([A-Z0-9-]+)",
                                r["text"].upper())] if m}
        if dyn_vars:
            callers += [r for r in conn.execute(
                """SELECT pf.ref, pf.line, pf.detail, p.name AS caller,
                          f.id AS file_id, a.name AS app, a.pipeline, a.stage_seq
                   FROM program_facet pf
                   JOIN program p ON p.id = pf.program_id
                   JOIN source_file f ON f.id = p.source_file_id
                   LEFT JOIN application a ON a.id = f.application_id
                   WHERE pf.kind = 'call'""")
                if r["ref"] in dyn_vars]
        run_by = [r for r in conn.execute(
            """SELECT js.step_name, js.pgm, js.lineno, js.gate, js.cond,
                      j.name AS job, j.id AS job_id, f.id AS file_id
               FROM jcl_step js JOIN jcl_job j ON j.id = js.job_id
               JOIN source_file f ON f.id = j.source_file_id
               ORDER BY j.name, js.seq""")
            if r["pgm"] and qn == r["pgm"].replace("_", "-")]
        home = conn.execute(
            """SELECT p.name, a.name AS app, f.id AS file_id FROM program p
               JOIN source_file f ON f.id = p.source_file_id
               LEFT JOIN application a ON a.id = f.application_id
               WHERE p.name = ?""", (q,)).fetchone()
        if callers or run_by:
            trs = ""
            for r in run_by:
                gate = ""
                if r["gate"] or r["cond"]:
                    what = r["gate"] or f"COND={r['cond']}"
                    gate = (f" <span class='badge alert'>gated · "
                            f"{esc(what)}</span>")
                trs += (f"<tr><td><a href='/job/{r['job_id']}'>"
                        f"<b>{esc(r['job'])}</b></a>"
                        f"<span class='badge reprocessed'>job · "
                        f"{esc(r['step_name'])}</span>{gate}</td>"
                        f"<td class=muted>batch runbook</td>"
                        f"<td><span class=muted>—</span></td>"
                        f"<td style='white-space:nowrap'>"
                        f"<a href='/file/{r['file_id']}?hl={r['lineno']}'>"
                        f"line {r['lineno']}</a></td></tr>")
            for r in callers:
                d = json.loads(r["detail"] or "{}")
                using = (f"<code>{esc(', '.join(d['using']))}</code>"
                         if d.get("using") else "<span class=muted>—</span>")
                # A caller that reaches this program through EXEC CICS LINK
                # shows as the online path.
                cics_link = conn.execute(
                    """SELECT 1 FROM program_facet pf JOIN program p
                       ON p.id = pf.program_id WHERE p.name = ?
                       AND pf.kind='cics' AND pf.ref = ?
                       AND json_extract(pf.detail,'$.op') IN ('link','xctl')""",
                    (r["caller"], r["ref"])).fetchone()
                dyn = ("<span class='badge alert'>dynamic · via "
                       f"{esc(r['ref'])}</span>" if d.get("dynamic") else "")
                if cics_link:
                    dyn += "<span class='badge limitation'>CICS LINK · online</span>"
                stage = (f"<div class=muted style='font-size:12px'>"
                         f"{esc(r['pipeline'])}</div>" if r["pipeline"] else "")
                trs += (f"<tr><td><b>{esc(r['caller'])}</b>{dyn}</td>"
                        f"<td>{esc(r['app'] or '—')}{stage}</td>"
                        f"<td>{using}</td>"
                        f"<td style='white-space:nowrap'>"
                        f"<a href='/file/{r['file_id']}?hl={r['line']}'>"
                        f"line {r['line']}</a></td></tr>")
            where = (f" — lives in <a href='/file/{home['file_id']}'>"
                     f"{esc(home['app'] or '')}</a>" if home else "")
            n_sites = len(callers) + len(run_by)
            parts.append(
                f"<div class=card><h2>Called from · {n_sites} site"
                f"{'s' if n_sites != 1 else ''}{where}</h2>"
                f"<table><tr><th>Caller</th><th>Application</th>"
                f"<th>Passes (USING)</th><th>Where</th></tr>{trs}</table>"
                f"<p class=muted style='margin:12px 0 0'>Static CALLs are read "
                f"directly; a <b>dynamic</b> row means the target is a variable "
                f"and this literal is MOVEd into it somewhere — the load site "
                f"appears in the touches below.</p></div>")

        # ── screen fields (BMS) ────────────────────────────────────────
        scr = [b for b in conn.execute(
            """SELECT b.*, f.id AS file_id, f.name AS fname FROM bms_field b
               JOIN source_file f ON f.id = b.source_file_id
               WHERE b.name != ''""")
            if qn in b["name"].replace("_", "-")
            or qn.replace("-", "") in b["name"]]
        if scr:
            trs = "".join(
                f"<tr><td><b>{esc(b['name'])}</b></td>"
                f"<td>{esc(b['map'])}"
                f"{' · ' + esc(b['mapset']) if b['mapset'] else ''}</td>"
                f"<td class=num>{b['pos_row']},{b['pos_col']}</td>"
                f"<td class=num>{b['length'] or '—'}</td>"
                f"<td style='white-space:nowrap'>"
                f"<a href='/file/{b['file_id']}?hl={b['lineno']}'>"
                f"{esc(b['fname'])}</a></td></tr>" for b in scr)
            parts.append(
                f"<div class=card><h2>On screen — from the BMS mapset</h2>"
                f"<table><tr><th>Field</th><th>Map</th><th class=num>Row,Col"
                f"</th><th class=num>Length</th><th>Member</th></tr>{trs}"
                f"</table><p class=muted style='margin:10px 0 0'>A labeled "
                f"field generates its symbolic names (name+I in, name+O out) "
                f"— those are the flow graph's first hop.</p></div>")

        # ── IDMS access ────────────────────────────────────────────────
        idms = [r for r in conn.execute(
            """SELECT pf.ref, pf.line, pf.detail, p.name AS prog,
                      f.id AS file_id, a.name AS app
               FROM program_facet pf
               JOIN program p ON p.id = pf.program_id
               JOIN source_file f ON f.id = p.source_file_id
               LEFT JOIN application a ON a.id = f.application_id
               WHERE pf.kind = 'idms' ORDER BY p.name, pf.line""")
            if qn in r["ref"].replace("_", "-")]
        if idms:
            WRITE_OPS = {"store", "modify", "erase"}
            trs = ""
            for r in idms:
                d = json.loads(r["detail"])
                cls = "resolved" if d["op"] in WRITE_OPS else "reprocessed"
                within = f" within {esc(d['set'])}" if d.get("set") else ""
                trs += (f"<tr><td><span class='badge {cls}' "
                        f"style='margin-left:0'>{esc(d['op'])}</span></td>"
                        f"<td><code>{esc(r['ref'])}</code>{within}</td>"
                        f"<td><b>{esc(r['prog'])}</b>"
                        f"{' · ' + esc(r['app']) if r['app'] else ''}</td>"
                        f"<td style='white-space:nowrap'>"
                        f"<a href='/file/{r['file_id']}?hl={r['line']}'>"
                        f"line {r['line']}</a></td></tr>")
            parts.append(
                f"<div class=card><h2>IDMS access · {len(idms)} sites</h2>"
                f"<table><tr><th>Op</th><th>Record</th><th>Program</th>"
                f"<th>Where</th></tr>{trs}</table>"
                f"<p class=muted style='margin:10px 0 0'>store / modify / "
                f"erase write the record; obtain / find read it. The record "
                f"layout is its copybook — scan a field name to see who "
                f"moves data into it before the store.</p></div>")

        # ── files: the analyst's window into what a function produced ──
        frows = [r for r in conn.execute(
            """SELECT pf.ref, pf.line, pf.detail, p.name AS prog,
                      f.id AS file_id, a.name AS app
               FROM program_facet pf
               JOIN program p ON p.id = pf.program_id
               JOIN source_file f ON f.id = p.source_file_id
               LEFT JOIN application a ON a.id = f.application_id
               WHERE pf.kind = 'file' ORDER BY p.name""")
            if qn in r["ref"].replace("_", "-")
            or qn in json.loads(r["detail"]).get("logical", "").replace("_", "-")]
        # A DSN query finds the DD through the JCL binding.
        if not frows and ("." in q or len(q) > 8):
            dd_hits = [(js["step_name"], dd["dd"], dd["dsn"], js["pgm"])
                       for js in conn.execute(
                           "SELECT step_name, pgm, dds FROM jcl_step")
                       for dd in json.loads(js["dds"])
                       if dd.get("dsn") and qn in dd["dsn"].replace("_", "-")]
            if dd_hits:
                pgms = {h[3] for h in dd_hits if h[3]}
                frows = [r for r in conn.execute(
                    """SELECT pf.ref, pf.line, pf.detail, p.name AS prog,
                              f.id AS file_id, a.name AS app
                       FROM program_facet pf
                       JOIN program p ON p.id = pf.program_id
                       JOIN source_file f ON f.id = p.source_file_id
                       LEFT JOIN application a ON a.id = f.application_id
                       WHERE pf.kind = 'file'""")
                    if r["prog"] in pgms]
        if frows:
            # DSN binding per (program, ddname) through the mined JCL.
            dsn_of = {}
            for js in conn.execute("SELECT pgm, dds FROM jcl_step"):
                for dd in json.loads(js["dds"]):
                    if js["pgm"] and dd.get("dsn"):
                        dsn_of[(js["pgm"], dd["dd"])] = dd["dsn"]
            trs = ""
            for r in frows:
                d = json.loads(r["detail"])
                ops = ", ".join(sorted({o["op"] for o in d.get("ops", [])}))
                dsn = dsn_of.get((r["prog"], r["ref"]))
                writer = any(o["op"] in ("write", "rewrite", "open-output",
                                         "open-extend")
                             for o in d.get("ops", []))
                trs += (f"<tr><td><code>{esc(r['ref'])}</code>"
                        f"{' · <span class=muted>' + esc(d['org']) + '</span>' if d.get('org') else ''}</td>"
                        f"<td class=mono>{esc(dsn) if dsn else '<span class=muted>no JCL binding mined</span>'}</td>"
                        f"<td><b>{esc(r['prog'])}</b>"
                        f"<span class='badge {'resolved' if writer else 'reprocessed'}'>"
                        f"{'writes' if writer else 'reads'}</span></td>"
                        f"<td>{esc(ops) or '—'}</td>"
                        f"<td style='white-space:nowrap'>"
                        f"<a href='/file/{r['file_id']}?hl={r['line']}'>"
                        f"line {r['line']}</a></td></tr>")
            parts.append(
                f"<div class=card><h2>Files — who writes, who reads</h2>"
                f"<table><tr><th>DD · org</th><th>Dataset (from JCL)</th>"
                f"<th>Program</th><th>Ops</th><th>Where</th></tr>{trs}</table>"
                f"<p class=muted style='margin:10px 0 0'>INDEXED = VSAM. The "
                f"dataset name comes from the mined JCL DD for that program's "
                f"step — the file the analyst actually browses.</p></div>")

        # ── the flow chain ─────────────────────────────────────────────
        chain = self._chain_for(self._scan_edges(conn), q)
        if chain:
            hops = []
            for e in chain:
                where = (f"<a href='/file/{e['file_id']}?hl={e['line']}'>"
                         f"{esc(e['prog'])} {e['line']}</a>")
                arrow_lbl = ("SQL " + esc(e["verb"]).upper()
                             if e["kind"] == "sqlmap" else esc(e["verb"]))
                hops.append(
                    f"<span class=hop><code>{esc(e['source'])}</code>"
                    f"<span class=harr>→</span><code"
                    f"{' class=dbcol' if e['kind'] == 'sqlmap' else ''}>"
                    f"{esc(e['target'])}</code>"
                    f"<span class=hlbl>{arrow_lbl} · {where}"
                    f"{' · ' + esc(e['app']) if e['app'] else ''}</span></span>")
            parts.append(
                f"<div class=card><h2>Flow — mined from MOVE statements and "
                f"embedded SQL</h2><div class=chain>{''.join(hops)}</div>"
                f"<p class=muted style='margin:10px 0 0'>Stage order, source on "
                f"the left. A <span class=dbcol style='padding:1px 6px'>column"
                f"</span> is the database landing. Group-level moves are not "
                f"expanded — a whole-record MOVE shows as the group, not its "
                f"children.</p></div>")

        # ── every touch, by stage ──────────────────────────────────────
        # Phrase-match the split parts (BENE-DOB → "bene dob"), so the scan
        # finds the whole family: TDA-BENE-DOB, PDA-BENE-DOB, BENE_DOB.
        pieces = [x for x in re.split(r"[-_.]", q.lower()) if x]
        fts_q = f'"{" ".join(pieces)}"' if len(pieces) > 1 else (pieces or [q.lower()])[0]
        qpat = re.compile(re.escape(q).replace(r"\-", "\x00")
                          .replace("_", "\x00").replace("\x00", "[-_]"))
        hits = conn.execute(
            """SELECT l.lineno, l.text, f.id AS file_id, f.name AS fname,
                      f.kind AS fkind, p.name AS prog,
                      a.name AS app, a.pipeline, a.stage_seq
               FROM line_fts l
               JOIN source_file f ON f.id = l.file_id
               LEFT JOIN program p ON p.source_file_id = f.id
               LEFT JOIN application a ON a.id = f.application_id
               WHERE l.tokens MATCH ?
               ORDER BY a.stage_seq IS NULL, a.stage_seq, f.name, l.lineno
               LIMIT 400""", (fts_q,)).fetchall()
        hits = [h for h in hits if qpat.search(h["text"].upper())]
        if not hits:
            parts.append(f"<div class=card><p class=muted style='margin:0'>No "
                         f"source line contains <b>{esc(q)}</b>. The scan is "
                         f"literal — check the spelling, or ingest the members "
                         f"that use it.</p></div>")
            self._send("".join(parts), f"Scan · {q}")
            return

        KINDCLS = {"definition": "imported", "write": "resolved",
                   "read": "reprocessed", "condition": "alert",
                   "sql": "limitation", "mention": ""}
        counts: dict = {}
        by_bucket: dict = {}
        for h in hits:
            kind, ident = self.classify_hit(h["text"], q)
            counts[kind] = counts.get(kind, 0) + 1
            bucket = (h["app"] or "(no application)",
                      h["pipeline"], h["stage_seq"])
            by_bucket.setdefault(bucket, []).append((h, kind, ident))
        summary = " ".join(
            f"<span class='badge {KINDCLS[k]}' style='margin-left:0'>"
            f"{counts[k]} {k}{'s' if counts[k] != 1 and k != 'sql' else ''}</span>"
            for k in ("definition", "write", "read", "condition", "sql", "mention")
            if counts.get(k))
        parts.append(f"<div class=card style='padding:14px 18px'>"
                     f"<b>{len(hits)}</b> touches of <code>{esc(q)}</code> "
                     f"&nbsp;{summary}</div>")

        for (app, pipeline, seq), rows_ in by_bucket.items():
            stage = ""
            if pipeline:
                stage = (f" <span class=muted style='font-weight:400'>· stage in "
                         f"{esc(pipeline)}</span>")
            trs = ""
            for h, kind, ident in rows_:
                line_html = esc(h["text"].strip()[:110])
                line_html = re.sub(f"({re.escape(esc(ident))})",
                                   r"<mark>\1</mark>", line_html, count=1)
                trs += (f"<tr><td style='white-space:nowrap'>"
                        f"<span class='badge {KINDCLS[kind]}' "
                        f"style='margin-left:0'>{kind}</span></td>"
                        f"<td class=mono>{line_html}</td>"
                        f"<td style='white-space:nowrap' class=muted>"
                        f"{esc(h['prog'] or h['fname'])} · "
                        f"<a href='/file/{h['file_id']}?hl={h['lineno']}'>"
                        f"line {h['lineno']}</a></td></tr>")
            parts.append(f"<div class=card><h2>{esc(app)}{stage}</h2>"
                         f"<table>{trs}</table></div>")
        self._send("".join(parts), f"Scan · {q}")

    # ── pipelines: the flow is data, the renderer is generic ──────────
    ROLES = ("builds", "analyzes", "validates", "processes", "writes")

    def _mi_volume_by_app(self, conn) -> dict:
        """{application_id: MI exception volume} via the mined emitted_by
        links. Computed per exception first so one code linked to two
        programs in the same app is not counted twice."""
        exc_vol = {r["exception_id"]: r["n"] or 0 for r in conn.execute(
            """SELECT exception_id, SUM(CAST(json_extract(payload,'$.count')
               AS INTEGER)) AS n FROM exception_event WHERE kind='mi'
               GROUP BY exception_id""")}
        if not exc_vol:
            return {}
        vol: dict = {}
        for r in conn.execute(
                """SELECT DISTINCT l.exception_id, f.application_id AS aid
                   FROM exception_link l
                   JOIN program p ON p.name = l.target_ref
                   JOIN source_file f ON f.id = p.source_file_id
                   WHERE l.relation IN ('emitted_by','raised_by')
                   AND f.application_id IS NOT NULL"""):
            vol[r["aid"]] = vol.get(r["aid"], 0) + exc_vol.get(r["exception_id"], 0)
        return vol

    def _stage_chip(self, r, vol: int, hit: bool = False) -> str:
        role = (f"<span class=prole>{esc(r['stage_role'])}</span>"
                if r["stage_role"] else "")
        v = (f"<span class=pvol>{vol}</span>" if vol else "")
        return (f"<a class='pstage{' hit' if hit else ''}' href='/app/{r['id']}'>"
                f"<b>{esc(r['name'])}</b>{role}{v}</a>")

    def _pipeline_flow(self, stages, vols, hit_id: int | None = None) -> str:
        """Stage chips in seq order, with the data areas each stage writes as
        the seams between them. Each chip travels WITH its outgoing seam as
        one unit, so a line wrap breaks between stages — never leaving an
        arrow stranded at a row edge."""
        units = []
        n = len(stages)
        for i, r in enumerate(stages):
            chip = self._stage_chip(r, vols.get(r["id"], 0),
                                    hit=r["id"] == hit_id)
            areas = json.loads(r["writes"] or "[]")
            if i < n - 1:
                seam = (f"<span class=pseam>→{esc(' · '.join(areas))}→</span>"
                        if areas else "<span class=pseam>→</span>")
            else:
                # The last stage's sink (PUT → DB2, NOTIFY → NOTICES).
                seam = (f"<span class=pseam>→ {esc(' · '.join(areas))}</span>"
                        if areas else "")
            units.append(f"<span class=punit>{chip}{seam}</span>")
        return f"<div class=pipe>{''.join(units)}</div>"

    # ── JCL job view: the runbook, as mined ───────────────────────────
    def _job_apps(self, conn, job_id: int) -> list:
        """Steps mapped to applications through their programs: [(seq,
        step_name, pgm, app_id, app_name)] — app fields None when the
        program isn't in the corpus."""
        return conn.execute(
            """SELECT js.seq, js.step_name, js.pgm,
                      f.application_id AS app_id, a.name AS app_name
               FROM jcl_step js
               LEFT JOIN program p ON p.name = js.pgm
               LEFT JOIN source_file f ON f.id = p.source_file_id
               LEFT JOIN application a ON a.id = f.application_id
               WHERE js.job_id = ? ORDER BY js.seq""", (job_id,)).fetchall()

    def _job(self, conn, job_id: str):
        try:
            jid = int(job_id)
        except ValueError:
            self._send("<div class=card>Bad job id.</div>", code=400)
            return
        job = conn.execute(
            """SELECT j.*, f.name AS fname, f.id AS file_id,
                      a.name AS app_name, a.id AS app_id
               FROM jcl_job j JOIN source_file f ON f.id = j.source_file_id
               LEFT JOIN application a ON a.id = f.application_id
               WHERE j.id = ?""", (jid,)).fetchone()
        if not job:
            self._send("<div class=card>Job not found.</div>", code=404)
            return
        steps = conn.execute(
            "SELECT * FROM jcl_step WHERE job_id = ? ORDER BY seq",
            (jid,)).fetchall()
        step_apps = {r["seq"]: r for r in self._job_apps(conn, jid)}
        prog_ids = {r["name"]: r["id"] for r in conn.execute(
            "SELECT id, name FROM program")}

        # Seams: DSN first seen (with its DISP) vs later references.
        first_ref: dict = {}
        for st in steps:
            for d in json.loads(st["dds"]):
                if d["dsn"] and not d["dsn"].startswith("&") \
                        and d["dsn"] not in first_ref:
                    first_ref[d["dsn"]] = (st["seq"], d["disp"])

        cards = []
        for i, st in enumerate(steps):
            dds = json.loads(st["dds"])
            named = [d for d in dds if d["dsn"]]
            sa = step_apps.get(st["seq"])
            pgm_html = "<span class=muted>—</span>"
            if st["pgm"]:
                pid = prog_ids.get(st["pgm"])
                pgm_html = (f"<a href='/prog/{pid}'><b>{esc(st['pgm'])}</b></a>"
                            if pid else f"<b>{esc(st['pgm'])}</b>"
                            " <span class=muted>· not in the corpus</span>")
            elif st["proc"]:
                pgm_html = (f"<b>{esc(st['proc'])}</b> "
                            f"<span class=muted>· cataloged proc</span>")
            appchip = (f" <span class=doctype>{esc(sa['app_name'])}</span>"
                       if sa and sa["app_name"] else "")
            gates = ""
            if st["gate"]:
                gates += (f"<span class='badge alert' style='margin-left:0'>"
                          f"runs only if {esc(st['gate'])}</span> ")
            if st["cond"]:
                gates += (f"<span class='badge alert' style='margin-left:0'>"
                          f"COND={esc(st['cond'])}</span>")
            ddrows = "".join(
                f"<tr><td><code>{esc(d['dd'])}</code></td>"
                f"<td class=mono>{esc(d['dsn'])}</td>"
                f"<td>{esc(d['disp'] or '—')}</td></tr>" for d in named)
            ddbox = (f"<details class=pd-edit><summary class=muted>"
                     f"{len(named)} dataset{'s' if len(named) != 1 else ''}"
                     f"</summary><table style='margin-top:8px'>"
                     f"<tr><th>DD</th><th>Dataset</th><th>DISP</th></tr>"
                     f"{ddrows}</table></details>" if named else "")
            # Seam to the next step: datasets this step touches that the
            # next step also names.
            seam = ""
            if i < len(steps) - 1:
                mine_ = {jcl_gdg_base(d["dsn"])[0]: jcl_gdg_base(d["dsn"])[1]
                         for d in named}
                theirs = {jcl_gdg_base(d["dsn"])[0]
                          for d in json.loads(steps[i + 1]["dds"]) if d["dsn"]}
                shared = sorted(set(mine_) & theirs)
                lbl = "".join(
                    f"<span class=pd-area>{esc(b)}"
                    f"{' · GDG' if mine_.get(b) else ''}</span>"
                    for b in shared)
                seam = f"<div class=pd-seam><span class=pd-line></span>{lbl}</div>"
            cards.append(
                f"<div class=pd-stage><div class=pd-head>"
                f"<span class=pd-num>{st['seq']}</span>"
                f"<div class=pd-title>{pgm_html}{appchip}"
                f"<div class=muted style='font-size:12.5px;margin-top:2px'>"
                f"{esc(st['step_name'])} · "
                f"<a href='/file/{job['file_id']}?hl={st['lineno']}'>"
                f"line {st['lineno']}</a></div>"
                f"{f'<div style=margin-top:6px>{gates}</div>' if gates else ''}"
                f"</div></div>{ddbox}{seam}</div>")

        gated = sum(1 for s in steps if s["gate"] or s["cond"])
        trail = ([(job["app_name"], f"/app/{job['app_id']}")]
                 if job["app_id"] else [])
        parts = [crumbs(*trail, here=f"Job · {job['name']}"),
                 f"<div class=card><div class=cardhead>"
                 f"<h1>{esc(job['name'])}</h1>"
                 f"<span class=muted>{len(steps)} steps"
                 f"{f' · {gated} conditionally gated' if gated else ''}</span></div>"
                 f"<p class=muted style='margin-top:-2px'>Mined from "
                 f"<a href='/file/{job['file_id']}'>{esc(job['fname'])}</a> — "
                 f"the runbook as it actually executes: step order, the "
                 f"program each step runs, and the datasets passed between "
                 f"them.</p></div>",
                 f"<div class=card><div class=pd-flow>{''.join(cards)}</div></div>"]
        self._send("".join(parts), f"Job · {job['name']}")

    def _pipeline_runbook(self, conn, name: str, stages) -> str:
        """Reconcile the configured pipeline against mined JCL. A job whose
        steps run ≥2 of this pipeline's applications is its runbook; the
        discovered order either confirms the configuration or names the
        first disagreement. Config is intent — JCL is what actually runs."""
        stage_order = [s["name"] for s in stages]
        stage_ids = {s["id"] for s in stages}
        out = []
        for job in conn.execute("SELECT id, name FROM jcl_job ORDER BY name"):
            rows = self._job_apps(conn, job["id"])
            hits = [r for r in rows if r["app_id"] in stage_ids]
            if len({r["app_id"] for r in hits}) < 2:
                continue
            discovered = []
            for r in hits:
                if not discovered or discovered[-1] != r["app_name"]:
                    discovered.append(r["app_name"])
            configured = [n for n in stage_order if n in set(discovered)]
            unmapped = [r for r in rows if r["pgm"] and not r["app_id"]]
            chips = " <span class=harr>→</span> ".join(
                f"<code>{esc(n)}</code>" for n in discovered)
            if discovered == configured:
                verdict = ("<span class='badge resolved' style='margin-left:0'>"
                           "matches the configured order</span>")
            else:
                diff = next((i for i, (a, b) in
                             enumerate(zip(discovered, configured)) if a != b),
                            min(len(discovered), len(configured)))
                verdict = (f"<span class='badge failed' style='margin-left:0'>"
                           f"disagrees at position {diff + 1}</span> "
                           f"<span class=muted>configured: "
                           f"{esc(' → '.join(configured))}</span>")
            notes = ""
            if unmapped:
                notes = (f"<div class=muted style='font-size:12px;margin-top:4px'>"
                         f"{len(unmapped)} step"
                         f"{'s' if len(unmapped) != 1 else ''} run programs "
                         f"not in the corpus: "
                         f"{esc(', '.join(r['pgm'] for r in unmapped))}</div>")
            out.append(
                f"<div style='margin-bottom:10px'>"
                f"<a href='/job/{job['id']}'><b>{esc(job['name'])}</b></a> "
                f"{verdict}<div style='margin-top:6px'>{chips}</div>{notes}</div>")
        if not out:
            return ""
        return (f"<div class=card><h2>Runbook — discovered from JCL</h2>"
                f"{''.join(out)}"
                f"<p class=muted style='margin:10px 0 0'>Step order mined from "
                f"the job member; the configuration above is intent, the JCL "
                f"is what actually runs. A disagreement is worth a look before "
                f"trusting either.</p></div>")

    # ── pipeline detail: the flow as a living diagram, edited in place ─
    def _pipeline_renumber(self, conn, name: str, order: list[int]):
        """Stage order IS the list order; seqs renumber 10, 20, 30 so a
        future insert-between never needs fractions."""
        for i, aid in enumerate(order):
            conn.execute("UPDATE application SET stage_seq = ? WHERE id = ?",
                         ((i + 1) * 10, aid))

    def _pipeline_stages(self, conn, name: str):
        return conn.execute(
            "SELECT * FROM application WHERE pipeline = ?"
            " AND COALESCE(lane,'') != 'online' ORDER BY stage_seq",
            (name,)).fetchall()

    def _online_lane(self, conn, name: str):
        return conn.execute(
            "SELECT * FROM application WHERE pipeline = ? AND lane = 'online'"
            " ORDER BY name", (name,)).fetchall()

    def _lane_attachments(self, conn, app_id: int, name: str) -> list:
        """Where an online-lane app re-enters the batch flow — derived from
        mined call/LINK edges, never asserted. [(stage_name, caller, callee)]"""
        stage_ids = {s["id"]: s["name"] for s in self._pipeline_stages(conn, name)}
        out = []
        for r in conn.execute(
                """SELECT DISTINCT p.name AS caller, pf.ref,
                          tf.application_id AS tgt_app
                   FROM program_facet pf
                   JOIN program p ON p.id = pf.program_id
                   JOIN source_file f ON f.id = p.source_file_id
                   JOIN program tp ON tp.name = pf.ref
                   JOIN source_file tf ON tf.id = tp.source_file_id
                   WHERE pf.kind = 'call' AND f.application_id = ?""",
                (app_id,)):
            if r["tgt_app"] in stage_ids:
                out.append((stage_ids[r["tgt_app"]], r["caller"], r["ref"]))
        return out

    def _pipeline(self, conn, qs, banner: str = ""):
        name = (qs or {}).get("name", [""])[0].strip()
        stages = self._pipeline_stages(conn, name) if name else []
        if not stages:
            self._redirect("/apps")
            return
        vols = self._mi_volume_by_app(conn)
        n = len(stages)

        # Per-stage inventory: modules, mined codes, top code by volume.
        cards = []
        for i, st in enumerate(stages):
            aid = st["id"]
            mods = conn.execute(
                "SELECT COUNT(*) FROM source_file WHERE application_id = ?"
                " AND kind = 'cobol'", (aid,)).fetchone()[0]
            codes = conn.execute(
                """SELECT COUNT(DISTINCT l.exception_id) FROM exception_link l
                   JOIN program p ON p.name = l.target_ref
                   JOIN source_file f ON f.id = p.source_file_id
                   WHERE f.application_id = ?
                   AND l.relation IN ('emitted_by','raised_by')""",
                (aid,)).fetchone()[0]
            rd = " · ".join(json.loads(st["reads"] or "[]"))
            wr = " · ".join(json.loads(st["writes"] or "[]"))
            vol = vols.get(aid, 0)
            role_opts = "<option value=''>—</option>" + "".join(
                f"<option{' selected' if st['stage_role'] == x else ''}>{x}</option>"
                for x in self.ROLES)

            up = ("<button name=dir value=up title='Move earlier'>↑</button>"
                  if i else "<button disabled style='opacity:.3'>↑</button>")
            dn = ("<button name=dir value=down title='Move later'>↓</button>"
                  if i < n - 1 else "<button disabled style='opacity:.3'>↓</button>")
            seam = ""
            if i < n - 1:
                areas = json.loads(st["writes"] or "[]")
                lbl = (f"<span class=pd-area>{esc(' · '.join(areas))}</span>"
                       if areas else "")
                seam = f"<div class=pd-seam><span class=pd-line></span>{lbl}</div>"

            cards.append(f"""<div class=pd-stage>
<div class=pd-head>
<span class=pd-num>{i + 1}</span>
<div class=pd-title><a href='/app/{aid}'><b>{esc(st['name'])}</b></a>
{f"<span class=prole>{esc(st['stage_role'])}</span>" if st['stage_role'] else ''}
{f"<span class=pvol>{vol}</span>" if vol else ''}
<div class=muted style='font-size:12.5px;margin-top:2px'>
{esc(st['description'] or '')}
{(' · ' if st['description'] else '') + 'reads ' + esc(rd) if rd else ''}
{(' → writes ' + esc(wr)) if wr else ''}</div></div>
<div class=pd-stats><span class=stat><b>{mods}</b><span class=muted>modules</span></span>
<span class=stat style='margin-right:0'><b>{codes}</b><span class=muted>codes</span></span></div>
<form method=post action='/pipeline/move' class=pd-arrows>
<input type=hidden name=name value="{esc(name)}">
<input type=hidden name=app_id value={aid}>{up}{dn}</form>
</div>
<details class=pd-edit><summary class=muted>Edit stage</summary>
<form method=post action='/pipeline/stage' style='margin-top:10px'>
<input type=hidden name=name value="{esc(name)}">
<input type=hidden name=app_id value={aid}>
<div style='display:flex;gap:8px;flex-wrap:wrap'>
<select name=stage_role style='max-width:150px'>{role_opts}</select>
<input type=text name=reads value="{esc(rd.replace(' · ', ', '))}"
 placeholder='reads (e.g. TDA)' style='max-width:170px'>
<input type=text name=writes value="{esc(wr.replace(' · ', ', '))}"
 placeholder='writes (e.g. PDA)' style='max-width:170px'>
<button>Save</button>
<button name=remove value=1 class=delbtn
 onclick="return confirm('Remove {esc(st['name'])} from {esc(name)}? The application and its source are kept.')"
>Remove from pipeline</button>
</div></form></details>{seam}""")

        # Add-a-stage: existing standalone apps, or hand off to create-new.
        avail = conn.execute(
            "SELECT id, name FROM application WHERE pipeline IS NULL"
            " ORDER BY name").fetchall()
        opts = "".join(f"<option value={a['id']}>{esc(a['name'])}</option>"
                       for a in avail)
        role_opts = "<option value=''>—</option>" + "".join(
            f"<option>{r}</option>" for r in self.ROLES)
        add_box = (f"""<div class=addbox style='margin-top:14px'><h3>Add a stage</h3>
<form method=post action='/pipeline/add' style='display:flex;gap:8px;flex-wrap:wrap'>
<input type=hidden name=name value="{esc(name)}">
<select name=app_id style='max-width:220px'>{opts}</select>
<select name=stage_role style='max-width:140px'>{role_opts}</select>
<select name=lane style='max-width:190px'>
<option value=''>batch stage — at the end</option>
<option value=online>online lane (CICS)</option></select>
<input type=text name=reads placeholder='reads' style='max-width:130px'>
<input type=text name=writes placeholder='writes' style='max-width:130px'>
<button>Add</button>
<a class=btnsm href='/apps/new?pipeline={urllib.parse.quote(name)}'
 style='align-self:center'>…or create a new application</a>
</form></div>""" if avail else
            f"<div class=addbox style='margin-top:14px'><h3>Add a stage</h3>"
            f"<p class=muted style='margin:0'>Every registered application is "
            f"already in a pipeline — <a href='/apps/new?pipeline="
            f"{urllib.parse.quote(name)}'>create a new one</a>.</p></div>")

        lane_apps = self._online_lane(conn, name)
        lane_card = ""
        if lane_apps:
            lrows = ""
            for la in lane_apps:
                att = self._lane_attachments(conn, la["id"], name)
                if att:
                    links = "; ".join(sorted({
                        f"<b>{esc(c)}</b> → {esc(t)} <span class=muted>"
                        f"({esc(st)})</span>" for st, c, t in att}))
                else:
                    links = ("<span class=muted>no mined link into the batch "
                             "flow yet — ingest its members</span>")
                lrows += (
                    f"<div class=pd-head style='border-style:dashed;"
                    f"border-color:#b9a3e3;margin-bottom:8px'>"
                    f"<span class=pd-num style='background:#7a5cd6'>⇄</span>"
                    f"<div class=pd-title><a href='/app/{la['id']}'>"
                    f"<b>{esc(la['name'])}</b></a> "
                    f"<span class='badge limitation'>online</span>"
                    f"<div class=muted style='font-size:12.5px;margin-top:2px'>"
                    f"{links}</div></div>"
                    f"<form method=post action='/pipeline/stage'>"
                    f"<input type=hidden name=name value=\"{esc(name)}\">"
                    f"<input type=hidden name=app_id value={la['id']}>"
                    f"<button name=remove value=1 class=delbtn>Remove</button>"
                    f"</form></div>")
            lane_card = (
                f"<div class=card><h2>Online lane — corrections feed back in"
                f"</h2>{lrows}"
                f"<p class=muted style='margin:6px 0 0'>These applications run "
                f"under CICS, not in the job stream. Their re-entry points are "
                f"mined from CALL/LINK edges into the batch stages.</p></div>")

        total = sum(vols.get(s["id"], 0) for s in stages)
        diagram = ("<div class=card>"
                   + self._arch_svg(conn, name, stages, lane_apps, vols)
                   + "</div>")
        # dry-run posture, folded into the hero rather than a strip below
        rprogs = conn.execute(PROG_SQL + " WHERE a.pipeline = ?",
                              (name,)).fetchall()
        wl = self._cobrun_worklist(conn, rprogs)
        rv = wl["verdicts"]
        ok = len(rv["ready"]) + len(rv["advisory"])
        todo = sum(len(d) for d in wl["need"].values())
        run_href = f"/cobrun?pipeline={urllib.parse.quote(name)}"
        run_accent = "#1e6b3d" if todo == 0 else "#8a6410"
        mods_total = sum(conn.execute(
            "SELECT COUNT(*) FROM source_file WHERE application_id = ?"
            " AND kind = 'cobol'", (st["id"],)).fetchone()[0]
            for st in stages)
        seam_areas = []
        for st in stages:
            for a in json.loads(st["writes"] or "[]"):
                if a not in seam_areas:
                    seam_areas.append(a)
        seam = (" &nbsp;→&nbsp; ".join(f"<b>{esc(a)}</b>"
                                       for a in seam_areas)
                if seam_areas else "")

        parts = [crumbs(("Applications", "/apps"), here=name), banner,
                 f"""<div class=herowrap>
<div class=apphero>
<div class=herostage><span class=heropill>PIPELINE</span>
<span class=herosub>{n} batch stages
{f" + online lane ({len(lane_apps)})" if lane_apps else ""}</span></div>
{f"<div class=heroseam>the data areas, in build order: {seam}</div>" if seam else ""}
<h1>{esc(name)}</h1>
<div class=herosub>The nightly flow, top to bottom — the seams between
stages are the data areas each stage builds.</div>
</div>
<div class=herobase>
<div class=statiles>
{hero_tile(n + len(lane_apps), "stages", ("batch + online" if lane_apps
    else "all batch"), "#flow", "stage")}
{hero_tile(mods_total, "modules", "COBOL members across the flow",
    "#flow", "file")}
{hero_tile(total, "MI exceptions", ("live volume by stage" if total
    else "no MI imported yet"), "#flow", "code")}
{hero_tile(f"{ok}<span style='font-size:15px;color:#8a97a8'>/{len(rprogs)}</span>",
    "DRY RUN", f"{ok} of {len(rprogs)} programs runnable"
    + (f" · {todo} to do" if todo else ""), run_href, "run", run_accent)}
</div>
</div>
</div>""",
                 diagram,
                 f"<div class=card id=flow><div class=pd-flow>{''.join(cards)}</div>"
                 f"{add_box}</div>",
                 lane_card,
                 self._pipeline_runbook(conn, name, stages),
                 f"""<div class=card><h2>Pipeline settings</h2>
<div style='display:flex;gap:26px;flex-wrap:wrap;align-items:flex-end'>
<form method=post action='/pipeline/rename'>
<input type=hidden name=name value="{esc(name)}">
<label class=flabel>Rename</label>
<div style='display:flex;gap:8px'>
<input type=text name=new_name value="{esc(name)}" style='max-width:220px;margin:0'>
<button>Rename</button></div></form>
<form method=post action='/pipeline/dissolve'
 onsubmit="return confirm('Dissolve {esc(name)}? Its {n} applications become standalone — nothing else is deleted.')">
<input type=hidden name=name value="{esc(name)}">
<button class=delbtn style='padding:10px 0'>Dissolve pipeline</button></form>
</div></div>"""]
        self._send("".join(parts), name)

    def _pipeline_move(self, conn, form):
        name = form.get("name", "")
        try:
            aid = int(form.get("app_id", 0))
        except ValueError:
            self._send("<div class=card>Bad id.</div>", code=400)
            return
        order = [r["id"] for r in self._pipeline_stages(conn, name)]
        if aid in order:
            i = order.index(aid)
            j = i - 1 if form.get("dir") == "up" else i + 1
            if 0 <= j < len(order):
                order[i], order[j] = order[j], order[i]
            self._pipeline_renumber(conn, name, order)
            conn.commit()
        self._redirect(f"/pipeline?name={urllib.parse.quote(name)}")

    def _pipeline_stage_edit(self, conn, form):
        name = form.get("name", "")
        try:
            aid = int(form.get("app_id", 0))
        except ValueError:
            self._send("<div class=card>Bad id.</div>", code=400)
            return
        if form.get("remove"):
            conn.execute(
                """UPDATE application SET pipeline = NULL, stage_seq = NULL,
                   stage_role = NULL, reads = NULL, writes = NULL, lane = NULL
                   WHERE id = ? AND pipeline = ?""", (aid, name))
        else:
            conn.execute(
                """UPDATE application SET stage_role = ?, reads = ?, writes = ?
                   WHERE id = ? AND pipeline = ?""",
                (form.get("stage_role", "").strip() or None,
                 self._csv_areas(form.get("reads", "")),
                 self._csv_areas(form.get("writes", "")), aid, name))
        conn.commit()
        self._redirect(f"/pipeline?name={urllib.parse.quote(name)}")

    def _pipeline_add(self, conn, form):
        name = form.get("name", "")
        try:
            aid = int(form.get("app_id", 0))
        except ValueError:
            self._send("<div class=card>Bad id.</div>", code=400)
            return
        lane = form.get("lane", "").strip() or None
        seq = None if lane == "online" else (conn.execute(
            "SELECT COALESCE(MAX(stage_seq), 0) FROM application"
            " WHERE pipeline = ?", (name,)).fetchone()[0] or 0) + 10
        conn.execute(
            """UPDATE application SET pipeline = ?, stage_seq = ?, lane = ?,
               stage_role = ?, reads = ?, writes = ?
               WHERE id = ? AND pipeline IS NULL""",
            (name, seq, lane, form.get("stage_role", "").strip() or None,
             self._csv_areas(form.get("reads", "")),
             self._csv_areas(form.get("writes", "")), aid))
        conn.commit()
        self._redirect(f"/pipeline?name={urllib.parse.quote(name)}")

    def _pipeline_rename(self, conn, form):
        old, new = form.get("name", "").strip(), form.get("new_name", "").strip()
        if old and new and old != new:
            conn.execute("UPDATE application SET pipeline = ? WHERE pipeline = ?",
                         (new, old))
            conn.commit()
        self._redirect(f"/pipeline?name={urllib.parse.quote(new or old)}")

    def _pipeline_dissolve(self, conn, form):
        name = form.get("name", "").strip()
        conn.execute(
            """UPDATE application SET pipeline = NULL, stage_seq = NULL,
               stage_role = NULL, reads = NULL, writes = NULL, lane = NULL
               WHERE pipeline = ?""", (name,))
        conn.commit()
        self._redirect("/apps")

    # ── the architecture diagram: real boxes, real shapes ─────────────
    DB_NAMES = {"DB2", "IDMS"}

    @staticmethod
    def _svg_cyl(x, y, w, h, label) -> str:
        """A database cylinder."""
        ry = 7
        return (f"<path d='M{x} {y + ry} a{w / 2} {ry} 0 0 1 {w} 0 "
                f"v{h - 2 * ry} a{w / 2} {ry} 0 0 1 -{w} 0 z' "
                f"fill='#ece6fa' stroke='#7a5cd6' stroke-width='1.4'/>"
                f"<ellipse cx='{x + w / 2}' cy='{y + ry}' rx='{w / 2}' ry='{ry}' "
                f"fill='#f6f2fd' stroke='#7a5cd6' stroke-width='1.4'/>"
                f"<text x='{x + w / 2}' y='{y + h / 2 + 9}' text-anchor='middle' "
                f"font-size='10.5' font-weight='700' fill='#5b3fb8' "
                f"font-family='ui-monospace,Menlo,monospace'>{esc(label)}</text>")

    @staticmethod
    def _svg_doc(x, y, w, h, label) -> str:
        """An output-file / document shape (wavy bottom)."""
        return (f"<path d='M{x} {y} h{w} v{h - 8} "
                f"q-{w / 4} 9 -{w / 2} 0 q-{w / 4} -9 -{w / 2} 0 z' "
                f"fill='#fdf6dd' stroke='#c9971c' stroke-width='1.4'/>"
                f"<text x='{x + w / 2}' y='{y + h / 2 + 2}' text-anchor='middle' "
                f"font-size='10.5' font-weight='700' fill='#8a6410' "
                f"font-family='ui-monospace,Menlo,monospace'>{esc(label)}</text>")

    @staticmethod
    def _svg_area(x, y, w, h, label) -> str:
        """An in-memory data area (TDA, PDA) — an open rectangle."""
        return (f"<rect x='{x}' y='{y}' width='{w}' height='{h}' rx='5' "
                f"fill='#eef2f7' stroke='#8a97a8' stroke-width='1.3'/>"
                f"<text x='{x + w / 2}' y='{y + h / 2 + 4}' text-anchor='middle' "
                f"font-size='10.5' font-weight='700' fill='#41546b' "
                f"font-family='ui-monospace,Menlo,monospace'>{esc(label)}</text>")

    def _arch_svg(self, conn, name: str, stages, lane_apps, vols) -> str:
        """The pipeline as an architecture diagram: stage boxes left to
        right, the data area / database / output file each stage writes
        drawn as its own shape on the arrow, and the online lane as a
        dashed box wired into its mined re-entry stage."""
        BOX_W, BOX_H, NODE_W, GAP = 148, 62, 74, 118
        n = len(stages)
        step = BOX_W + GAP
        top = 26
        width = n * step - GAP + 40
        lane_y = top + BOX_H + 74
        height = (lane_y + 78) if lane_apps else (top + BOX_H + 42)

        out = [f"<defs><marker id='arr' viewBox='0 0 10 10' refX='9' refY='5' "
               f"markerWidth='7' markerHeight='7' orient='auto-start-reverse'>"
               f"<path d='M0 0 L10 5 L0 10 z' fill='#64748b'/></marker>"
               f"<marker id='arrv' viewBox='0 0 10 10' refX='9' refY='5' "
               f"markerWidth='7' markerHeight='7' orient='auto-start-reverse'>"
               f"<path d='M0 0 L10 5 L0 10 z' fill='#7a5cd6'/></marker></defs>"]

        mid = top + BOX_H / 2
        xs = {}
        for i, st in enumerate(stages):
            x = 20 + i * step
            xs[st["id"]] = x
            vol = vols.get(st["id"], 0)
            fs = 13 if len(st["name"]) <= 12 else 11
            out.append(
                f"<a href='/app/{st['id']}'>"
                f"<rect x='{x}' y='{top}' width='{BOX_W}' height='{BOX_H}' "
                f"rx='10' fill='#fff' stroke='#33506e' stroke-width='1.6'/>"
                f"<text x='{x + BOX_W / 2}' y='{top + 27}' text-anchor='middle' "
                f"font-size='{fs}' font-weight='700' "
                f"fill='#13273f'>{esc(st['name'])}</text>"
                + (f"<text x='{x + BOX_W / 2}' y='{top + 45}' "
                   f"text-anchor='middle' font-size='9.5' letter-spacing='1' "
                   f"fill='#6b7789'>{esc((st['stage_role'] or '').upper())}</text>"
                   if st["stage_role"] else "") + "</a>")
            if vol:
                bw = 16 + 7 * len(str(vol))
                out.append(
                    f"<rect x='{x + BOX_W - bw + 8}' y='{top - 10}' rx='9' "
                    f"width='{bw}' height='19' fill='#f9e5e5' "
                    f"stroke='#e7c3c3'/>"
                    f"<text x='{x + BOX_W - bw / 2 + 8}' y='{top + 3}' "
                    f"text-anchor='middle' font-size='10.5' font-weight='700' "
                    f"fill='#a63838'>{vol}</text>")

            # The arrow to the next box, carrying the written shape.
            areas = json.loads(st["writes"] or "[]")
            gx = x + BOX_W
            if i < n - 1:
                if areas:
                    nx = gx + (GAP - NODE_W) / 2
                    out.append(f"<line x1='{gx}' y1='{mid}' x2='{nx}' "
                               f"y2='{mid}' stroke='#64748b' stroke-width='1.4'/>")
                    out.append(self._shape_for(areas[0], nx, mid, NODE_W))
                    out.append(f"<line x1='{nx + NODE_W}' y1='{mid}' "
                               f"x2='{gx + GAP - 3}' y2='{mid}' stroke='#64748b' "
                               f"stroke-width='1.4' marker-end='url(#arr)'/>")
                else:
                    out.append(f"<line x1='{gx}' y1='{mid}' x2='{gx + GAP - 3}' "
                               f"y2='{mid}' stroke='#64748b' stroke-width='1.4' "
                               f"marker-end='url(#arr)'/>")
            elif areas:
                # Terminal sink hangs off the last stage.
                nx = gx + 26
                out.append(f"<line x1='{gx}' y1='{mid}' x2='{nx - 3}' y2='{mid}' "
                           f"stroke='#64748b' stroke-width='1.4' "
                           f"marker-end='url(#arr)'/>")
                out.append(self._shape_for(areas[0], nx, mid, NODE_W))
                width = max(width, nx + NODE_W + 20)

        # ── the online lane ────────────────────────────────────────────
        for la in lane_apps:
            x = 20
            att = self._lane_attachments(conn, la["id"], name)
            out.append(
                f"<a href='/app/{la['id']}'>"
                f"<rect x='{x}' y='{lane_y}' width='{BOX_W}' height='54' rx='10' "
                f"fill='#faf8fe' stroke='#7a5cd6' stroke-width='1.6' "
                f"stroke-dasharray='6 4'/>"
                f"<text x='{x + BOX_W / 2}' y='{lane_y + 24}' text-anchor='middle' "
                f"font-size='13' font-weight='700' "
                f"fill='#5b3fb8'>{esc(la['name'])}</text>"
                f"<text x='{x + BOX_W / 2}' y='{lane_y + 40}' text-anchor='middle' "
                f"font-size='9.5' letter-spacing='1' fill='#7a5cd6'>ONLINE · CICS"
                f"</text></a>")
            if att:
                tgt_name = sorted({a[0] for a in att})[0]
                tgt = next((s for s in stages if s["name"] == tgt_name), None)
                if tgt is not None:
                    tx = xs[tgt["id"]] + BOX_W / 2
                    sx = x + BOX_W
                    sy = lane_y + 27
                    out.append(
                        f"<path d='M{sx} {sy} C {sx + 90} {sy}, {tx} "
                        f"{top + BOX_H + 46}, {tx} {top + BOX_H + 4}' "
                        f"fill='none' stroke='#7a5cd6' stroke-width='1.5' "
                        f"stroke-dasharray='6 4' marker-end='url(#arrv)' "
                        f"marker-start='url(#arrv)'/>")
                    lbl = "; ".join(sorted({f"{c} → {t}" for _, c, t in att}))
                    out.append(
                        f"<text x='{sx + 16}' y='{sy + 20}' font-size='10.5' "
                        f"fill='#5b3fb8' font-family='ui-monospace,Menlo,"
                        f"monospace'>⇄ {esc(lbl)}</text>")
            else:
                out.append(
                    f"<text x='{x + BOX_W + 14}' y='{lane_y + 30}' "
                    f"font-size='10.5' fill='#6b7789'>no mined link into the "
                    f"batch flow yet</text>")

        return (f"<div class=archwrap><button type=button class=archbtn "
                f"title='Fullscreen'>⛶</button>"
                f"<div style='overflow-x:auto'>"
                f"<svg viewBox='0 0 {width} {height}' width='{width}' "
                f"height='{height}' style='max-width:100%;height:auto;"
                f"font-family:-apple-system,sans-serif' role='img'>"
                f"{''.join(out)}</svg></div></div>")

    def _shape_for(self, area: str, x: float, mid: float, w: float) -> str:
        """Database → cylinder, dataset/output name → document, in-memory
        data area → open rectangle."""
        if area.upper() in self.DB_NAMES:
            return self._svg_cyl(x, mid - 24, w, 48, area)
        if "." in area or area.upper() in ("NOTICES", "REJECTS", "AUDIT"):
            return self._svg_doc(x, mid - 17, w, 36, area)
        return self._svg_area(x, mid - 14, w, 28, area)

    def _lane_strip(self, conn, name: str, lane_apps, vols) -> str:
        """The online correction path, drawn under the batch flow with its
        mined re-entry points — connected by evidence, not decoration."""
        if not lane_apps:
            return ""
        bits = []
        for la in lane_apps:
            att = self._lane_attachments(conn, la["id"], name)
            into = ""
            if att:
                tgt = sorted({a[0] for a in att})
                into = (f"<span class=hlbl>corrections re-enter at "
                        f"{esc(' · '.join(tgt))} — "
                        + ", ".join(sorted({f"{esc(c)} → {esc(t)}"
                                            for _, c, t in att})) + "</span>")
            else:
                into = ("<span class=hlbl>no mined link into the batch flow "
                        "yet</span>")
            vol = vols.get(la["id"], 0)
            bits.append(
                f"<span class=punit><a class='pstage lane' href='/app/{la['id']}'>"
                f"<b>{esc(la['name'])}</b><span class=prole>online</span>"
                f"{f'<span class=pvol>{vol}</span>' if vol else ''}</a>"
                f"<span class='pseam lane'>⇄</span></span>{into}")
        return (f"<div class=pipe style='margin-top:4px'>"
                f"{''.join(bits)}</div>")

    def _apps(self, conn):
        rows = conn.execute("""
            SELECT a.*,
              (SELECT COUNT(*) FROM source_file f WHERE f.application_id = a.id) AS files,
              (SELECT COUNT(*) FROM document d WHERE d.application_id = a.id) AS docs
            FROM application a
            ORDER BY a.pipeline, a.stage_seq, a.name""").fetchall()
        vols = self._mi_volume_by_app(conn)
        pipelines: dict = {}
        lanes: dict = {}
        standalone = []
        for r in rows:
            if r["pipeline"] and (r["lane"] or "") == "online":
                lanes.setdefault(r["pipeline"], []).append(r)
            elif r["pipeline"]:
                pipelines.setdefault(r["pipeline"], []).append(r)
            else:
                standalone.append(r)

        parts = [f"<div class=card><div class=cardhead><h1>Applications</h1>"
                 f"<a class=btnlink href='/apps/new'>＋ New application</a></div>"
                 f"<p class=muted style='margin-top:-2px'>Pipelines run left to "
                 f"right — each stage is an application, the arrows carry the "
                 f"data areas it builds. Click a stage for its source, DFRs and "
                 f"codes.</p></div>"]
        for name, stages in pipelines.items():
            total = sum(vols.get(s["id"], 0) for s in stages)
            vtxt = (f"<span class=muted>{total} exceptions in the MI</span>"
                    if total else "")
            parts.append(
                f"<div class=card><div class=cardhead>"
                f"<h2 style='margin:0;font-size:15px;text-transform:none;"
                f"letter-spacing:0;color:var(--ink)'>"
                f"<a href='/pipeline?name={urllib.parse.quote(name)}'>{esc(name)}</a>"
                f"<span class=muted style='font-weight:400;font-size:13px'> · "
                f"{len(stages)} stage{'s' if len(stages) != 1 else ''}</span></h2>"
                f"{vtxt}</div>"
                f"{self._arch_svg(conn, name, stages, lanes.get(name, []), vols)}"
                f"</div>")

        if standalone:
            items = "".join(
                f"<tr><td><a href='/app/{r['id']}'><b>{esc(r['name'])}</b></a></td>"
                f"<td>{esc(r['description'] or '')}</td>"
                f"<td class=num>{r['files']}</td><td class=num>{r['docs']}</td>"
                f"<td class=muted>{esc(r['created_at'][:10])}</td></tr>"
                for r in standalone)
            title = "Standalone applications" if pipelines else "Applications"
            parts.append(
                f"<div class=card><h2>{title}</h2>"
                f"<table><tr><th>Name</th><th>Description</th>"
                f"<th class=num>Source files</th><th class=num>DFRs</th>"
                f"<th>Created</th></tr>{items}</table></div>")
        self._send("".join(parts), "Applications")

    def _app_new(self, conn, qs=None):
        pre = (qs or {}).get("pipeline", [""])[0]
        pipes = [r["pipeline"] for r in conn.execute(
            "SELECT DISTINCT pipeline FROM application WHERE pipeline IS NOT NULL"
            " ORDER BY pipeline")]
        pipe_opts = "<option value=''>Standalone — no pipeline</option>" + "".join(
            f"<option value=\"{esc(p)}\"{' selected' if p == pre else ''}>"
            f"Add to {esc(p)}</option>" for p in pipes
        ) + "<option value='__new__'>Start a new pipeline…</option>"
        role_opts = "<option value=''>—</option>" + "".join(
            f"<option>{r}</option>" for r in self.ROLES)
        body = (crumbs(("Applications", "/apps"), here="New application")
                + f"""<div class=card><h1>New application</h1>
<p class=muted>Step 1 of 2 — name it and place it. Next you'll add its
artifacts (COBOL, copybooks, DFRs, error tables).</p>
<form method=post action="/apps/create" style="max-width:560px;margin-top:14px">
<input type=text name=name placeholder="Name (e.g. WEEDER)" autofocus required>
<input type=text name=description placeholder="Description (optional)">
<label class=flabel style="margin-top:6px">Pipeline</label>
<select name=pipeline id=pipesel>{pipe_opts}</select>
<input type=text name=new_pipeline id=pipenew placeholder="New pipeline name (e.g. T2 NIGHTLY)"
 style="display:none">
<div id=stagebox style="display:none">
<div class=frow>
<div><label class=flabel>Role in the flow</label>
<select name=stage_role>{role_opts}</select></div>
<div><label class=flabel>Position</label>
<input type=text name=stage_seq placeholder="auto — appended to the end"></div>
</div>
<div class=frow>
<div><label class=flabel>Reads (data areas)</label>
<input type=text name=reads placeholder="e.g. TDA"></div>
<div><label class=flabel>Builds / writes</label>
<input type=text name=writes placeholder="e.g. PDA"></div>
</div>
<span class=fhint>Comma-separate multiples. These become the arrows on the
pipeline view — and later let triage answer “who wrote this field last”.</span>
</div>
<button>Create &amp; add artifacts →</button>
</form>
<p class=muted style="margin-top:16px">Bulk trees ingest fastest from the CLI:
<code>python3 chatbis.py ingest &lt;dir&gt; --app NAME</code></p></div>
<script>
(function(){{
  var sel=document.getElementById('pipesel'),
      nw=document.getElementById('pipenew'),
      box=document.getElementById('stagebox');
  function sync(){{
    nw.style.display = sel.value==='__new__' ? '' : 'none';
    box.style.display = sel.value ? '' : 'none';
  }}
  sel.addEventListener('change', sync); sync();
}})();
</script>""")
        self._send(body, "New application")

    @staticmethod
    def _csv_areas(raw: str) -> str | None:
        areas = [a.strip().upper() for a in (raw or "").split(",") if a.strip()]
        return json.dumps(areas) if areas else None

    def _app_set_pipeline(self, conn, app_id: int, form):
        """Place (or move, or remove) an existing application in a pipeline —
        the 'add app to existing pipeline' path for apps registered earlier."""
        pipeline = form.get("pipeline", "").strip()
        if pipeline == "__new__":
            pipeline = form.get("new_pipeline", "").strip()
        seq = None
        if pipeline:
            raw = form.get("stage_seq", "").strip()
            if raw:
                try:
                    seq = int(raw)
                except ValueError:
                    seq = None
            if seq is None:
                seq = (conn.execute(
                    "SELECT COALESCE(MAX(stage_seq), 0) FROM application"
                    " WHERE pipeline = ?", (pipeline,)).fetchone()[0] or 0) + 10
        conn.execute(
            """UPDATE application SET pipeline = ?, stage_seq = ?, stage_role = ?,
               reads = ?, writes = ? WHERE id = ?""",
            (pipeline or None, seq,
             form.get("stage_role", "").strip() or None,
             self._csv_areas(form.get("reads", "")),
             self._csv_areas(form.get("writes", "")), app_id))
        conn.commit()
        self._redirect(f"/app/{app_id}")

    def _pipeline_strip(self, conn, exc_id: int) -> str:
        """Where in its pipeline this exception is raised. Empty string when
        the raising application isn't in one — the strip is earned by
        configuration, never faked."""
        app = conn.execute(
            """SELECT DISTINCT a.* FROM exception_link l
               JOIN program p ON p.name = l.target_ref
               JOIN source_file f ON f.id = p.source_file_id
               JOIN application a ON a.id = f.application_id
               WHERE l.exception_id = ? AND l.relation IN ('emitted_by','raised_by')
               AND a.pipeline IS NOT NULL
               ORDER BY l.confidence DESC LIMIT 1""", (exc_id,)).fetchone()
        if not app:
            return ""
        stages = self._pipeline_stages(conn, app["pipeline"])
        if (app["lane"] or "") == "online":
            return (f"<div class=card style='padding:14px 18px'>"
                    f"<div class=panehead>Raised in <b>{esc(app['name'])}</b> — "
                    f"the <span style='color:#5b3fb8'>online lane</span> of "
                    f"{esc(app['pipeline'])} · corrections path, not a batch "
                    f"step</div>"
                    f"{self._pipeline_flow(stages, {})}</div>")
        pos = next((i for i, s in enumerate(stages) if s["id"] == app["id"]), 0)
        return (f"<div class=card style='padding:14px 18px'>"
                f"<div class=panehead>Raised at <b>{esc(app['name'])}</b> — "
                f"stage {pos + 1} of {len(stages)} in {esc(app['pipeline'])}"
                f"{' · upstream stages already ran' if pos else ''}</div>"
                f"{self._pipeline_flow(stages, {}, hit_id=app['id'])}</div>")

    def _app_detail(self, conn, app_id: str, qs=None):
        try:
            aid = int(app_id)
        except ValueError:
            self._send("<div class=card>Bad application id.</div>", code=400)
            return
        app = conn.execute("SELECT * FROM application WHERE id = ?", (aid,)).fetchone()
        if not app:
            self._send("<div class=card>Application not found.</div>", code=404)
            return

        files = conn.execute(
            """SELECT f.*, p.id AS pid, p.name AS pname FROM source_file f
               LEFT JOIN program p ON p.source_file_id = f.id
               WHERE f.application_id = ? ORDER BY f.kind, f.name""", (aid,)).fetchall()
        docs = conn.execute(
            "SELECT * FROM document WHERE application_id = ?"
            " AND COALESCE(kind,'dfr') = 'dfr' ORDER BY title",
            (aid,)).fetchall()
        items = conn.execute(
            """SELECT d.*, f.name AS fname, f.id AS fid FROM data_item d
               JOIN source_file f ON f.id = d.source_file_id
               WHERE f.application_id = ? ORDER BY f.name, d.lineno LIMIT 300""",
            (aid,)).fetchall()
        # Codes this app raises/defines: match links against its program
        # names and file stems.
        refs = {f["pname"] for f in files if f["pname"]} | {
            f["name"].rsplit(".", 1)[0].upper() for f in files}
        codes = []
        if refs:
            marks = ",".join("?" * len(refs))
            codes = conn.execute(
                f"""SELECT DISTINCT e.code, e.normalized, e.category, e.status,
                    e.meaning FROM exception_link l
                    JOIN exception_code e ON e.id = l.exception_id
                    WHERE l.relation IN ('emitted_by','raised_by','defined_in')
                    AND COALESCE(e.status,'') != 'dismissed'
                    AND l.target_ref IN ({marks})
                    ORDER BY CASE e.category WHEN 'exception' THEN 0
                             WHEN 'alert' THEN 1 ELSE 2 END, e.code""",
                tuple(refs)).fetchall()

        upload_form = (
            f"<form id=upform method=post action='/app/{aid}/upload'"
            f" enctype='multipart/form-data'>"
            f"<input type=file id=fs name=files multiple style='display:none'>"
            f"<label class=drop id=drop for=fs><b>Drop artifacts here</b>"
            f"or click to browse<br>"
            f"<span id=droplbl>COBOL · copybooks · JCL · BMS · DFRs (.pdf .docx .rtf .html .txt) · error tables</span></label>"
            f"</form>"
            f"<form method=post action='/app/{aid}/remine'"
            f" style='margin-top:6px;text-align:right'"
            f" onsubmit=\"return confirm('Re-run the miner over every"
            f" stored artifact for this application?')\">"
            f"<button class=btnsm2 title='Re-derive rules, fields and"
            f" I/O from the stored uploads — use after a ChatBIS"
            f" upgrade'>↻ Re-mine stored sources</button></form>")
        upload_js = """<script>
(function(){
  var inp=document.getElementById('fs'),drop=document.getElementById('drop'),
      lbl=document.getElementById('droplbl'),form=document.getElementById('upform');
  inp.addEventListener('change',function(){
    if(inp.files.length){lbl.textContent=inp.files.length+' file(s) — ingesting\\u2026';form.submit();}});
  ['dragover','dragenter'].forEach(function(e){drop.addEventListener(e,function(ev){
    ev.preventDefault();drop.classList.add('over');});});
  ['dragleave','drop'].forEach(function(e){drop.addEventListener(e,function(ev){
    ev.preventDefault();drop.classList.remove('over');});});
  drop.addEventListener('drop',function(ev){
    inp.files=ev.dataTransfer.files;inp.dispatchEvent(new Event('change'));});
})();
</script>"""

        stage_line = ""
        if app["pipeline"]:
            sibs = conn.execute(
                "SELECT id, name FROM application WHERE pipeline = ?"
                " ORDER BY stage_seq", (app["pipeline"],)).fetchall()
            pos = next((i for i, x in enumerate(sibs) if x["id"] == aid), 0)
            rd = " · ".join(json.loads(app["reads"] or "[]"))
            wr = " · ".join(json.loads(app["writes"] or "[]"))
            io = ((f" · reads {esc(rd)}" if rd else "")
                  + (f" → writes {esc(wr)}" if wr else ""))
            nav = ""
            if pos > 0:
                nav += (f" · <a href='/app/{sibs[pos-1]['id']}'>&larr; "
                        f"{esc(sibs[pos-1]['name'])}</a>")
            if pos < len(sibs) - 1:
                nav += (f" · <a href='/app/{sibs[pos+1]['id']}'>"
                        f"{esc(sibs[pos+1]['name'])} &rarr;</a>")
            stage_line = (
                f"<p style='margin:6px 0 0;font-size:13.5px'>"
                f"<span class=doctype>{esc(app['pipeline'])}</span> "
                f"stage {pos + 1} of {len(sibs)}"
                f"{' · <b>' + esc(app['stage_role']) + '</b>' if app['stage_role'] else ''}"
                f"{io}{nav}</p>")

        just_created = bool(qs and qs.get("new"))
        banner = ""
        if just_created:
            banner = ("<div class=banner>Application created — step 2 of 2: drop its "
                      "artifacts into the upload zone to build the catalog.</div>")
        elif not files and not docs:
            banner = ("<div class=banner style='background:#fdf6dd;color:#7a5d05;"
                      "border-color:#efe1a8'>No artifacts yet — drop COBOL, copybooks, "
                      "DFRs, or an error-code table into the upload zone.</div>")

        # ── hero: identity on navy, evidence tiles below ──────────────
        n_cobol = sum(1 for f in files if f["kind"] == "cobol")
        n_copy = sum(1 for f in files if f["kind"] == "copybook")
        n_other = sum(1 for f in files
                      if f["kind"] not in ("cobol", "copybook", "csv"))
        src_sub = " · ".join(x for x in (
            f"{n_cobol} COBOL" if n_cobol else "",
            f"{n_copy} copybook{'s' if n_copy != 1 else ''}" if n_copy else "",
            f"{n_other} other" if n_other else "") if x) or "none yet"
        cats = {}
        for c in codes:
            cats[c["category"]] = cats.get(c["category"], 0) + 1
        code_sub = " · ".join(f"{n} {k}{'s' if n != 1 else ''}"
                              for k, n in cats.items()) or "none mined"
        item_files = len({i["fid"] for i in items})
        docs_sub = ("resolution evidence" if docs else "none yet")


        if app["pipeline"]:
            sibs2 = conn.execute(
                "SELECT id, name FROM application WHERE pipeline = ?"
                " ORDER BY stage_seq", (app["pipeline"],)).fetchall()
            pos2 = next((i for i, x in enumerate(sibs2) if x["id"] == aid), 0)
            dots = "".join(
                f"<a class='sdot{' cur' if i == pos2 else ''}' "
                f"href='/app/{x['id']}' title='{esc(x['name'])}'></a>"
                for i, x in enumerate(sibs2))
            rd = ", ".join(json.loads(app["reads"] or "[]"))
            wr = ", ".join(json.loads(app["writes"] or "[]"))
            seam = ((f"reads <b>{esc(rd)}</b>" if rd else "")
                    + (" &nbsp;→&nbsp; " if rd and wr else "")
                    + (f"writes <b>{esc(wr)}</b>" if wr else ""))
            role = (f"<span class=heropill-role>{esc(app['stage_role'])}"
                    f"</span>" if app["stage_role"] else "")
            hero_ctx = (
                f"<div class=herostage><span class=heropill>"
                f"{esc(app['pipeline'])}</span>{role}"
                f"<span class=herosub style='margin-left:2px'>stage "
                f"{pos2 + 1} of {len(sibs2)}</span>"
                f"<span class=stagedots>{dots}</span></div>"
                + (f"<div class=heroseam>{seam}</div>" if seam else ""))
        else:
            hero_ctx = ("<div class=herostage><span class=heropill>"
                        "STANDALONE</span></div>")

        parts = [crumbs(("Applications", "/apps"), here=app["name"]),
                 banner,
                 f"""<div class=herowrap>
<div class=apphero>
{hero_ctx}
<h1>{esc(app['name'])}</h1>
<div class=herosub>{esc(app['description'] or 'No description yet')}
 · registered {esc(app['created_at'][:10])}</div>
<form method=post action='/app/{aid}/miprefix' class=miprefix>
<span class=herosub>MI prefix</span>
<input name=mi_prefix value="{esc(app['mi_prefix'] or '')}"
 placeholder="A2" maxlength=4>
<button class=btnsm2>set</button>
<span class=herosub>codes this function reports carry it — A2U804 lands
on U804 automatically</span>
</form>
</div>
<div class=herobase>
<div class=statiles>
{hero_tile(sum(1 for f in files if f['kind'] != 'csv'), "source files",
      src_sub, "#files", "file")}
{hero_tile(len(docs), "DFRs", docs_sub, "#docs", "doc")}
{hero_tile(len(codes), "codes", code_sub, "#codes", "code")}
{hero_tile(len(items), "data objects",
      f"across {item_files} file{'s' if item_files != 1 else ''}"
      if item_files else "none mined", "#data", "data")}
</div>
{upload_form}
</div>
</div>{upload_js}"""]

        if codes:
            groups = {"exception": [], "alert": [], "limitation": [],
                      "suspension": [], "termination": [], "indicator": [],
                      "status": [], "reason": []}
            for c in codes:
                groups.setdefault(c["category"], []).append(c)
            group_html = ""
            for cat, label in (("exception", "Exceptions"), ("alert", "Alerts"),
                               ("limitation", "Processing limitations"),
                               ("suspension", "Suspensions"),
                               ("termination", "Terminations"),
                               ("indicator", "Indicators"),
                               ("status", "Status codes (legacy)"),
                               ("reason", "Reason indicators (legacy)")):
                if not groups.get(cat):
                    continue
                chips = "".join(
                    f"<a class=codechip href='/x/{esc(c['normalized'])}'>"
                    f"<span class='dot d-{esc(c['category'])}' style='margin-right:0'>"
                    f"</span>{esc(c['code'])}</a>" for c in groups[cat])
                group_html += (
                    f"<div style='display:flex;gap:14px;align-items:baseline;"
                    f"margin-bottom:6px'><span class=muted style='flex:0 0 90px;"
                    f"font-weight:700;font-size:11.5px;text-transform:uppercase;"
                    f"letter-spacing:.07em'>{label} · {len(groups[cat])}</span>"
                    f"<div style='flex:1'>{chips}</div></div>")
            parts.append(f"<div class=card id=codes><h2>Codes in this application · "
                         f"{len(codes)}</h2>{group_html}</div>")

        if files:
            rows = ""
            for f0 in files:
                if f0["kind"] == "csv":
                    continue
                if f0["pid"]:
                    counts = {
                        "rules": conn.execute(
                            "SELECT COUNT(*) FROM program_facet WHERE program_id = ?"
                            " AND kind = 'rule'", (f0["pid"],)).fetchone()[0],
                        "codes": conn.execute(
                            """SELECT COUNT(DISTINCT exception_id) FROM exception_link
                               WHERE target_ref = ? AND relation IN
                               ('emitted_by','raised_by')""",
                            (f0["pname"],)).fetchone()[0],
                    }
                else:
                    counts = None
                items_n = conn.execute(
                    "SELECT COUNT(*) FROM data_item WHERE source_file_id = ?",
                    (f0["id"],)).fetchone()[0]
                prog_cell = (f"<a href='/prog/{f0['pid']}'><b>{esc(f0['pname'])}</b></a>"
                             if f0["pid"] else
                             f"<a href='/file/{f0['id']}'><b>{esc(f0['name'].rsplit('.', 1)[0].upper())}</b></a>")
                kind_cell = (f"<span class=doctype>{esc(f0['kind'])}</span>")
                rules_cell = (f"<a href='/prog/{f0['pid']}?tab=rules'>{counts['rules']}</a>"
                              if counts else "—")
                data_cell = (f"<a href='/prog/{f0['pid']}?tab=data'>{items_n}</a>"
                             if f0["pid"] else (items_n or "—"))
                codes_cell = counts["codes"] if counts else "—"
                rows += (f"<tr><td>{prog_cell}</td>"
                         f"<td><a href='/file/{f0['id']}'>{esc(f0['name'])}</a>"
                         f" <span class=muted>· {esc(f0['fmt'])} · {esc(f0['encoding'])}"
                         f"</span></td>"
                         f"<td>{kind_cell}</td>"
                         f"<td class=num>{rules_cell}</td>"
                         f"<td class=num>{data_cell}</td>"
                         f"<td class=num>{codes_cell}</td>"
                         f"<td class=num>{f0['line_count']}</td></tr>")
            parts.append(f"<div class=card id=files><h2>COBOL source · "
                         f"{sum(1 for f0 in files if f0['kind'] != 'csv')}</h2><table>"
                         f"<tr><th>Program</th><th>File</th><th>Kind</th>"
                         f"<th class=num>Rules</th><th class=num>Data</th>"
                         f"<th class=num>Codes</th><th class=num>Lines</th></tr>"
                         f"{rows}</table></div>")

        if docs:
            rows = ""
            for d in docs:
                nsec = conn.execute("SELECT COUNT(*) FROM doc_section WHERE document_id = ?",
                                    (d["id"],)).fetchone()[0]
                nlinks = conn.execute(
                    "SELECT COUNT(*) FROM exception_link WHERE target_kind = 'document'"
                    " AND json_extract(detail, '$.doc_id') = ?", (d["id"],)).fetchone()[0]
                rows += (f"<tr><td><a href='/doc/{d['id']}'><b>{esc(d['title'])}</b></a></td>"
                         f"<td><span class=doctype>{esc(d['doc_type'])}</span></td>"
                         f"<td class=num>{nsec}</td><td class=num>{nlinks}</td>"
                         f"<td class=muted>{esc(nice_day(d['ingested_at']))}</td></tr>")
            parts.append(f"<div class=card id=docs><h2>DFRs · {len(docs)}</h2><table>"
                         f"<tr><th>Document</th><th>Type</th><th class=num>Sections</th>"
                         f"<th class=num>Rule links</th><th>Updated</th></tr>"
                         f"{rows}</table>"
                         f"<p class=muted style='margin-top:10px;margin-bottom:0'>"
                         f"Open a document to read it; re-upload a new version above "
                         f"to update it in place.</p></div>")

        parts.append(self._readiness_strip(
            conn,
            conn.execute(
                """SELECT p.id, p.name, f.id AS file_id, a.name AS app_name,
                          a.id AS app_id, a.pipeline, a.stage_seq
                   FROM program p
                   JOIN source_file f ON f.id = p.source_file_id
                   JOIN application a ON a.id = f.application_id
                   WHERE a.id = ?""", (aid,)).fetchall(),
            f"/cobrun?app={urllib.parse.quote(app['name'])}"))

        parts.append(
            f"<div class=card style='display:flex;align-items:center;"
            f"gap:14px'>"
            f"<form method=post action='/app/{aid}/delete' style='margin:0' "
            f"onsubmit=\"return confirm('Delete {esc(app['name'])}? Removes "
            f"the application, its {len(files)} ingested file(s), and all "
            f"mined evidence. The exception catalog keeps its codes. This "
            f"cannot be undone.')\">"
            f"<button class=delbtn>Delete this application</button></form>"
            f"<span class=muted style='font-size:12.5px'>Removes the "
            f"application and everything mined from its members. Catalog "
            f"codes and your mappings stay. Re-ingest the files any time "
            f"to rebuild it.</span></div>")

        # Pipeline placement — how an already-registered app joins a flow,
        # moves stage, or leaves. Pre-filled with its current membership.
        pipes = [r["pipeline"] for r in conn.execute(
            "SELECT DISTINCT pipeline FROM application WHERE pipeline IS NOT NULL"
            " ORDER BY pipeline")]
        pipe_opts = ("<option value=''>Standalone — no pipeline</option>" + "".join(
            f"<option value=\"{esc(x)}\""
            f"{' selected' if app['pipeline'] == x else ''}>{esc(x)}</option>"
            for x in pipes) + "<option value='__new__'>New pipeline…</option>")
        role_opts = "<option value=''>—</option>" + "".join(
            f"<option{' selected' if app['stage_role'] == x else ''}>{x}</option>"
            for x in self.ROLES)
        rd = ", ".join(json.loads(app["reads"] or "[]"))
        wr = ", ".join(json.loads(app["writes"] or "[]"))
        parts.append(f"""<div class=card><h2>Pipeline placement</h2>
<form method=post action='/app/{aid}/pipeline' style='max-width:560px'>
<div class=frow>
<div><label class=flabel>Pipeline</label>
<select name=pipeline id=ppsel>{pipe_opts}</select>
<input type=text name=new_pipeline id=ppnew placeholder='New pipeline name'
 style='display:none'></div>
<div><label class=flabel>Role</label><select name=stage_role>{role_opts}</select></div>
</div>
<div class=frow>
<div><label class=flabel>Position</label>
<input type=text name=stage_seq value="{app['stage_seq'] if app['stage_seq'] is not None else ''}"
 placeholder='auto — appended to the end'></div>
<div><label class=flabel>Reads → writes</label>
<div style='display:flex;gap:8px'>
<input type=text name=reads value="{esc(rd)}" placeholder='TDA'>
<input type=text name=writes value="{esc(wr)}" placeholder='PDA'></div></div>
</div>
<button>Save placement</button>
<span class=fhint style='margin-top:8px'>Position orders the stages (gaps like
10, 20, 30 make inserts easy). The data areas become the arrows on the
pipeline view.</span>
</form></div>
<script>
(function(){{
  var sel=document.getElementById('ppsel'), nw=document.getElementById('ppnew');
  function sync(){{ nw.style.display = sel.value==='__new__' ? '' : 'none'; }}
  sel.addEventListener('change', sync); sync();
}})();
</script>""")

        # Data objects live on each program's detail page (Data objects tab);
        # the header stat keeps the app-wide count.
        self._send("".join(parts), app["name"])

    # ── Case lookup (spec Phase 4 via the shop's REST API) ─────────────
    def _send_json(self, obj):
        raw = json.dumps(obj).encode()
        # Pollers vanish mid-response constantly (dock closed, page
        # navigated); on Windows the half-written reply raises
        # ConnectionAborted and BaseHTTPServer prints a full traceback.
        # A gone client is not an error — swallow the write failure.
        try:
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)
        except (ConnectionError, BrokenPipeError, TimeoutError, OSError):
            pass

    def _chat(self, conn, qs=None):
        prefill = (qs or {}).get("q", [""])[0]
        autosend = (qs or {}).get("send", [""])[0] == "1"
        cfg = investigate.get_llm(conn)
        if not cfg:
            model_chip = ("<span class=tokchip tokdead style='color:#a63838;"
                          "background:#f9e5e5'>no model configured</span>")
            notice = ("<div class=cnotice>No model endpoint is configured "
                      "— set the base URL in <a href='/settings?tab=llm'>"
                      "Settings → LLM</a> (an in-network llama-server "
                      "works: <code>llama-server -m model.gguf --jinja "
                      "--port 8877</code>, base URL "
                      "<code>http://127.0.0.1:8877/v1</code>). Until "
                      "then the chat refuses rather than guesses.</div>")
        else:
            model_chip = (f"<span class=tokchip>{esc(cfg['model'])}"
                          f"{' · redacting identifiers' if cfg['redact'] else ''}"
                          f"</span>")
            notice = ""
        body = f"""<div class="wb cwb">
<div class=wbtop><span class=wbins style='margin-right:2px'>Investigate
</span><span class=wbhint>evidence-first — every answer is built from
tool calls you can see · session memory only, nothing is stored</span>
<span style='flex:1'></span>{model_chip}
<button id=chatclear title='Clear the conversation — forgets everything said'
 style='background:transparent;border:0;color:#6d81a6;cursor:pointer;
 font-size:11px;padding:3px 8px'>clear</button>
<button id=chatbye title='End the session and return to the dashboard'
 style='background:transparent;border:0;color:#6d81a6;cursor:pointer;
 font-size:11px;padding:3px 8px'>end session</button></div>
<div id=chatlog class=clog>{notice}
<div class=cmsg-bot><div class=cbubble>Ask about an exception code, a
case, a field, a program — I investigate with the catalog, the source
corpus and the case API, and answer only from what they return.
</div></div>
</div>
<form id=chatform class=cbar>
<input id=chatq type=text placeholder="Why did case 900010001A hit E4417?"
 autocomplete=off>
<button id=chatsend class=wbbtn style='padding:9px 22px'>Send</button>
</form>
</div>
<script>
(function(){{
  var log = document.getElementById('chatlog'),
      form = document.getElementById('chatform'),
      q = document.getElementById('chatq'),
      btn = document.getElementById('chatsend'),
      chatId = sessionStorage.getItem('chatbis.chat'), timer = null;
  function scroll() {{ log.scrollTop = log.scrollHeight; }}
  function el(cls, html) {{
    var d = document.createElement('div');
    d.className = cls; d.innerHTML = html; return d;
  }}
  function esc(t) {{
    var d = document.createElement('div');
    d.textContent = t; return d.innerHTML;
  }}
  var running = false;
  function setBusy(on) {{
    running = on; q.disabled = on;
    btn.textContent = on ? 'Stop' : 'Send';
  }}
  function endSession(then) {{
    if (chatId) fetch('/chat/end', {{method: 'POST',
      headers: {{'Content-Type': 'application/x-www-form-urlencoded'}},
      body: 'chat=' + chatId}}).then(then, then);
    else then();
    sessionStorage.removeItem('chatbis.chat'); chatId = null;
  }}
  document.getElementById('chatclear').addEventListener('click',
    function() {{ endSession(function() {{ location.href = '/chat'; }}); }});
  document.getElementById('chatbye').addEventListener('click',
    function() {{ endSession(function() {{ location.href = '/dash'; }}); }});
  form.addEventListener('submit', function(ev) {{
    ev.preventDefault();
    if (running) {{
      if (chatId) fetch('/chat/stop', {{method: 'POST',
        headers: {{'Content-Type': 'application/x-www-form-urlencoded'}},
        body: 'chat=' + chatId}});
      return;
    }}
    var text = q.value.trim();
    if (!text) return;
    q.value = '';
    setBusy(true);
    log.appendChild(el('cmsg-user', '<div class=cbubble>'
      + esc(text) + '</div>'));
    var trail = el('ctrail', '');
    log.appendChild(trail); scroll();
    var fd = 'q=' + encodeURIComponent(text)
      + (chatId ? '&chat=' + chatId : '');
    fetch('/chat/ask', {{method: 'POST', body: fd,
      headers: {{'Content-Type': 'application/x-www-form-urlencoded'}}}})
      .then(function(r) {{ return r.json(); }})
      .then(function(d) {{
        chatId = d.chat;
        sessionStorage.setItem('chatbis.chat', chatId);
        timer = setInterval(function() {{ poll(trail); }}, 600);
      }})
      .catch(function() {{ finish(trail,
        '<i>the server did not accept the question</i>'); }});
  }});
  function poll(trail) {{
    fetch('/chat/status?chat=' + chatId)
      .then(function(r) {{ return r.json(); }})
      .then(function(d) {{
        trail.innerHTML = d.events.map(function(e, i) {{
          var last = (i === d.events.length - 1) && !d.done;
          return '<span class="cstep' + (last ? ' on' : '')
            + (e.k === 'tool' ? ' ctool' : '') + '">'
            + esc(e.label) + (last ? '<span class=cdots><i></i><i></i>'
            + '<i></i></span>' : '') + '</span>';
        }}).join('');
        scroll();
        if (d.done) {{
          clearInterval(timer);
          finish(trail, d.answer_html
            || '<i>' + esc(d.error || 'no answer') + '</i>');
        }}
      }});
  }}
  function finish(trail, html) {{
    log.appendChild(el('cmsg-bot', '<div class=cbubble>' + html
      + '</div>'));
    setBusy(false); q.focus(); scroll();
  }}
  var pre = {json.dumps(prefill).replace("<", "\\u003c")};
  if (chatId) {{
    fetch('/chat/history?chat=' + chatId)
      .then(function(r) {{ return r.json(); }})
      .then(function(d) {{
        if (d.error) {{ sessionStorage.removeItem('chatbis.chat');
          chatId = null; return; }}
        d.messages.forEach(function(m) {{
          log.appendChild(el(m.who === 'user' ? 'cmsg-user' : 'cmsg-bot',
            '<div class=cbubble>' + m.html + '</div>'));
        }});
        scroll();
      }});
  }}
  if (pre) {{
    q.value = pre;
    if ({str(autosend).lower()} && !document.querySelector('.cnotice'))
      form.requestSubmit();
  }}
  q.focus();
}})();
</script>"""
        self._send(body, "Investigate chat")

    def _chat_ask(self, conn, form):
        question = (form.get("q") or "").strip()
        if not question:
            self._send_json({"error": "empty question"})
            return
        cfg = investigate.get_llm(conn)
        if not cfg:
            self._send_json({"error": "no model configured"})
            return
        chat_id = form.get("chat") or secrets.token_hex(8)
        now = time.time()
        with CHATS_LOCK:
            # closed tabs beacon /chat/end; this sweep catches the
            # browsers that died without saying goodbye
            for stale in [k for k, v in CHATS.items()
                          if now - v.get("touched", now) > 7200]:
                CHATS.pop(stale, None)
        with CHATS_LOCK:
            state = CHATS.setdefault(chat_id, {
                "messages": [{"role": "system",
                              "content": investigate.SYSTEM_PROMPT}],
                "display": [], "events": [], "done": True,
                "error": None, "answer": None, "stop": False})
            if not state["done"]:
                self._send_json({"error": "still working", "chat": chat_id})
                return
            state["events"] = []
            state["done"] = False
            state["error"] = None
            state["answer"] = None
            state["stop"] = False
            state["messages"].append({"role": "user", "content": question})
            state["display"].append(("user", question))
            state["touched"] = now
        db_path = self.db_path
        handler = self

        def work():
            wconn = db.connect(db_path)
            try:
                def status(kind, label):
                    with CHATS_LOCK:
                        state["events"].append({"k": kind, "label": label})

                def call_api(env, ep, params):
                    return handler._call_api(env, ep, params)

                def should_stop():
                    with CHATS_LOCK:
                        return state.get("stop", False)
                answer = investigate.run_investigation(
                    wconn, call_api, cfg, state["messages"], status,
                    should_stop=should_stop)
                with CHATS_LOCK:
                    state["answer"] = answer
                    state["display"].append(("bot", answer))
                    state["done"] = True
            except investigate.InvestigationStopped:
                stopped = ("⏹ Stopped. The trail above shows how far I "
                           "got — ask a follow-up to continue.")
                with CHATS_LOCK:
                    # Rewind any half-finished hop (an assistant
                    # tool_calls entry whose tool replies never landed
                    # would poison the next request), then close the
                    # turn cleanly.
                    msgs = state["messages"]
                    while msgs and msgs[-1]["role"] != "user":
                        msgs.pop()
                    msgs.append({"role": "assistant", "content": stopped})
                    state["answer"] = stopped
                    state["display"].append(("bot", stopped))
                    state["done"] = True
            except Exception as e:
                with CHATS_LOCK:
                    state["error"] = f"model endpoint failed: {e}"
                    state["done"] = True
            finally:
                wconn.close()
        threading.Thread(target=work, daemon=True).start()
        self._send_json({"chat": chat_id})

    def _chat_history(self, qs):
        """The display transcript for a chat — what the dock re-renders
        after a page navigation. Display pairs only, never the raw
        model messages."""
        chat_id = (qs or {}).get("chat", [""])[0]
        with CHATS_LOCK:
            state = CHATS.get(chat_id)
            if not state:
                self._send_json({"error": "unknown chat", "messages": []})
                return
            msgs = [{"who": who,
                     "html": md_lite(text) if who == "bot" else esc(text)}
                    for who, text in state.get("display", [])]
            self._send_json({"messages": msgs, "done": state["done"]})

    def _chat_status(self, qs):
        chat_id = (qs or {}).get("chat", [""])[0]
        # Snapshot under the lock, send outside it — a slow or vanished
        # client must never hold up every other chat.
        with CHATS_LOCK:
            state = CHATS.get(chat_id)
            if not state:
                payload = {"error": "unknown chat", "done": True,
                           "events": []}
            else:
                payload = {"events": list(state["events"]),
                           "done": state["done"],
                           "error": state["error"],
                           "answer_html": (md_lite(state["answer"])
                                           if state["answer"] else None)}
        self._send_json(payload)

    def _cases(self, conn, qs, result_html: str = ""):
        envs = conn.execute("SELECT * FROM api_env ORDER BY name").fetchall()
        eps = conn.execute("SELECT * FROM api_endpoint ORDER BY name").fetchall()
        sel_env = int(qs.get("env", ["0"])[0] or 0)
        raw_ep = qs.get("ep", [""])[0] or ""
        sel_ep = raw_ep if raw_ep.startswith("b") else int(raw_ep or 0)
        if envs and not sel_env:
            sel_env = envs[0]["id"]
        if eps and not sel_ep:
            sel_ep = eps[0]["id"]
        bundles_l = conn.execute("SELECT * FROM case_bundle ORDER BY name").fetchall()
        # The selected source is an endpoint OR a bundle ("b<id>"). Resolve
        # whichever it is — gating the whole card on an endpoint row made the
        # form vanish the moment a bundle was picked.
        sel_bundle = None
        if str(sel_ep).startswith("b"):
            sel_bundle = next((b for b in bundles_l
                               if f"b{b['id']}" == str(sel_ep)), None)
        ep_row = None if sel_bundle else next(
            (e for e in eps if e["id"] == sel_ep), None)
        if not ep_row and not sel_bundle and eps:
            ep_row = eps[0]
            sel_ep = ep_row["id"]

        parts = [result_html]
        if envs and (ep_row or sel_bundle):
            env_opts = "".join(
                f"<option value={e['id']}{' selected' if e['id'] == sel_env else ''}>"
                f"{esc(e['name'])}</option>" for e in envs)
            ep_opts = "".join(
                f"<option value={e['id']}{' selected' if e['id'] == sel_ep else ''}>"
                f"{esc(e['name'])} ({esc(e['method'])})</option>" for e in eps)
            if bundles_l:
                ep_opts += "".join(
                    f"<option value='b{b['id']}'"
                    f"{' selected' if sel_bundle and sel_bundle['id'] == b['id'] else ''}>"
                    f"⛓ {esc(b['name'])} (bundle)</option>" for b in bundles_l)

            if sel_bundle:
                # A bundle's inputs are the UNION of its steps' placeholders,
                # minus {$chained.refs} which come from earlier responses.
                steps = conn.execute(
                    """SELECT e.path, e.body, e.headers, e.name,
                              bs.mount_key, bs.required
                       FROM bundle_step bs JOIN api_endpoint e ON e.id = bs.endpoint_id
                       WHERE bs.bundle_id = ? ORDER BY bs.seq, bs.id""",
                    (sel_bundle["id"],)).fetchall()
                phs = list(dict.fromkeys(
                    ph for st in steps
                    for ph in RE_PLACEHOLDER.findall(
                        st["path"] + (st["body"] or "") + (st["headers"] or ""))
                    if not ph.startswith("$")))
                chain = "".join(
                    f"<li>{esc(st['name'])} → "
                    f"<code>{esc(st['mount_key'] or '(root)')}</code>"
                    f"{'' if st['required'] else ' <span class=muted>optional</span>'}"
                    f"</li>" for st in steps)
                src_note = (f"<p class=muted style='margin:6px 0 12px'>"
                            f"<b>{len(steps)} calls</b> merged into one case:"
                            f"<ol style='margin:6px 0 0'>{chain}</ol></p>")
            else:
                phs = list(dict.fromkeys(
                    RE_PLACEHOLDER.findall(
                        ep_row["path"] + (ep_row["body"] or "")
                        + (ep_row["headers"] or ""))))
                src_note = (f"<p class=muted style='margin:6px 0 12px'><code>"
                            f"{esc(ep_row['method'])} {esc(ep_row['path'])}</code></p>")
            fields = "".join(
                f"<input type=text name='p_{esc(p)}' placeholder='{esc(p)}' required>"
                for p in phs) or "<p class=muted>This source takes no parameters.</p>"
            body_area = ""
            if ep_row and ep_row["method"] == "POST":
                body_area = (
                    f"<div class=panehead style='margin-top:12px'>Request body (JSON) — "
                    f"edit before sending; {{placeholders}} fill from the fields above</div>"
                    f"<textarea name=body rows=7 spellcheck=false style='font-family:monospace;"
                    f"font-size:13px'>{esc(ep_row['body'] or '{}')}</textarea>")
            # Exception-code suggestions: the analyst arrives KNOWING the code,
            # so this is a searchable fill, not a picker to browse. A native
            # <datalist> gives type-ahead with no JS and no dependency; the
            # label flags whether a recipe exists so "no recipe" is visible
            # before the request goes out rather than after.
            code_rows = conn.execute("""
                SELECT e.code, e.normalized, e.meaning, e.category,
                       (SELECT COUNT(*) FROM playbook p
                         WHERE p.exception_id = e.id) AS has_recipe
                FROM exception_code e ORDER BY has_recipe DESC, e.code""").fetchall()
            datalist = "".join(
                f"<option value='{esc(c['code'])}'>"
                f"{'✓ recipe · ' if c['has_recipe'] else 'no recipe · '}"
                f"{esc((c['meaning'] or c['category'])[:70])}</option>"
                for c in code_rows)
            n_recipes = sum(1 for c in code_rows if c["has_recipe"])
            cur_env = next((e for e in envs if e["id"] == sel_env), envs[0])
            parts.append(f"""<div class=card><h2>Evaluate a case</h2>
<form method=get action="/cases" style="display:flex;gap:12px">
<select name=env onchange="this.form.submit()" style="max-width:220px">{env_opts}</select>
<select name=ep onchange="this.form.submit()" style="max-width:340px">{ep_opts}</select>
</form>
<div class=tokrow>{token_state_chip(cur_env)}
<details class=tokform><summary>update token</summary>
<form method=post action="/cases/token" style="display:flex;gap:8px;
margin:8px 0 0">
<input type=hidden name=env value={sel_env}>
<input type=hidden name=ep value="{esc(sel_ep)}">
<input type=password name=token placeholder="paste the fresh JWT"
 style="margin:0;flex:1;font-size:13px" required autocomplete=off>
<button class=btnsm2 style="padding:7px 14px">Save</button>
</form></details></div>
{src_note}
<form method=post action="/cases/evaluate" style="max-width:640px">
<input type=hidden name=env value={sel_env}>
<input type=hidden name=ep value="{esc(sel_ep)}">
<div style="display:flex;gap:10px;flex-wrap:wrap">{fields}</div>
<datalist id=codelist>{datalist}</datalist>
<input type=text name=code list=codelist autocomplete=off
 placeholder="Exception code — type to search ({n_recipes} with recipes)"
 style="max-width:420px">
{body_area}
<div style="display:flex;gap:10px;align-items:center;margin-top:4px">
<button>Evaluate</button>
<button name=raw value=1 style="background:#fff;color:#33506e;
 border:1px solid var(--line)">Pull data only</button></div>
<p class=muted style="margin-top:10px;margin-bottom:0">Evaluate pulls the case
and runs that code's recipe against it. Leave the code blank to just see the
data.</p></form></div>""")
        else:
            parts.append(
                "<div class=banner style='background:#fdf6dd;color:#7a5d05;"
                "border-color:#efe1a8'>Set up an environment and an endpoint below, "
                "then analysts can pull case data from here.</div>")

        # ── Database research: the SQL rail beside the REST one ────────
        sources = conn.execute("SELECT * FROM db_source ORDER BY name").fetchall()
        queries = conn.execute("SELECT * FROM db_query ORDER BY name").fetchall()
        sel_src = int(qs.get("src", ["0"])[0] or 0) or (sources[0]["id"] if sources else 0)
        sel_dq = qs.get("dq", ["adhoc"])[0]
        dq_row = next((q for q in queries if str(q["id"]) == sel_dq), None)
        if sources:
            src_opts = "".join(
                f"<option value={s['id']}{' selected' if s['id'] == sel_src else ''}>"
                f"{esc(s['name'])} ({esc(s['driver'])})</option>" for s in sources)
            dq_opts = ("<option value=adhoc"
                       + (" selected" if not dq_row else "")
                       + ">Ad-hoc SQL</option>") + "".join(
                f"<option value={q['id']}{' selected' if dq_row and dq_row['id'] == q['id'] else ''}>"
                f"{esc(q['name'])}</option>" for q in queries)
            if dq_row:
                phs = list(dict.fromkeys(RE_PLACEHOLDER.findall(dq_row["sql"])))
                inner = ("".join(
                    f"<input type=text name='p_{esc(p)}' placeholder='{esc(p)}' required>"
                    for p in phs) or "<p class=muted>This query takes no parameters.</p>"
                ) + (f"<p class=muted style='margin:4px 0 10px'><code>"
                     f"{esc(dq_row['sql'][:180])}</code></p>"
                     f"<input type=hidden name=query_id value={dq_row['id']}>")
            else:
                inner = ("<textarea name=sql rows=4 spellcheck=false "
                         "style='font-family:monospace;font-size:13px' "
                         "placeholder='SELECT ... (read-only; {placeholders} allowed "
                         "for saved queries)'></textarea>")
            parts.append(f"""<div class=card><h2>Database research</h2>
<form method=get action="/cases" style="display:flex;gap:12px">
<input type=hidden name=env value={sel_env}><input type=hidden name=ep value={sel_ep}>
<select name=src onchange="this.form.submit()" style="max-width:220px">{src_opts}</select>
<select name=dq onchange="this.form.submit()" style="max-width:340px">{dq_opts}</select>
</form>
<form method=post action="/cases/sql" style="max-width:640px;margin-top:10px">
<input type=hidden name=src value={sel_src}>
{inner}
<button>Run query</button></form></div>""")

        log = conn.execute("SELECT * FROM api_call_log ORDER BY id DESC LIMIT 10").fetchall()
        if log:
            rows = "".join(
                f"<tr><td class=muted style='white-space:nowrap'>{esc(nice_day(l['ts']))}</td>"
                f"<td>{esc(l['env'])}</td><td>{esc(l['endpoint'])}</td>"
                f"<td><code>{esc(l['params'])}</code></td>"
                f"<td><span class='badge {'resolved' if l['ok'] else 'failed'}'"
                f" style='margin-left:0'>{l['status'] or 'ERR'}</span></td>"
                f"<td class=num>{l['ms']} ms</td></tr>" for l in log)
            parts.append(f"<div class=card><h2>Recent lookups</h2><table>"
                         f"<tr><th>When</th><th>Env</th><th>Endpoint</th><th>Params</th>"
                         f"<th>Status</th><th class=num>Time</th></tr>{rows}</table></div>")

        # Connector CONFIG lives in Settings — this screen is the analyst's
        # research surface, not a setup wizard.
        if not (envs or eps or sources or queries):
            parts.append("<div class=banner style='background:#fdf6dd;color:#7a5d05;"
                         "border-color:#efe1a8'>No connectors configured yet — add "
                         "them in <a href='/settings'>Settings</a>.</div>")
        else:
            parts.append("<p class=muted>Connectors are configured in "
                         "<a href='/settings'>Settings</a>.</p>")
        self._send("".join(parts), "Case lookup")

    # ── Settings: connectors ───────────────────────────────────────────
    # Left-hand sections; add to this list as new setting groups appear.
    SETTINGS_NAV = (
        ("Connections", (("api", "API"), ("db", "Database"), ("llm", "LLM"))),
        ("Mapping", (("fields", "Field mappings"),)),
        ("Import", (("mi", "Exception MI"),)),
    )

    def _mined_pairs_card(self, conn, maps) -> str:
        """COBOL↔DB2 pairs read straight out of embedded SQL — the crosswalk
        nobody should have to type. Proposals, not facts: each pair is
        accepted per-row, exactly like Lab drafts."""
        have = {(m["cobol_field"] or "").upper() for m in maps} | \
               {(m["db2_column"] or "").upper() for m in maps}
        pairs: dict = {}
        for r in conn.execute(
                """SELECT pf.detail, pf.line, p.name AS prog, f.id AS file_id
                   FROM program_facet pf
                   JOIN program p ON p.id = pf.program_id
                   JOIN source_file f ON f.id = p.source_file_id
                   WHERE pf.kind = 'sqlmap' ORDER BY p.name, pf.line"""):
            d = json.loads(r["detail"])
            key = (d["host"].upper(), d["column"].upper())
            if d["host"].upper() in have or d["column"].upper() in have:
                continue
            pairs.setdefault(key, {"host": d["host"], "column": d["column"],
                                   "stmts": set(), "prog": r["prog"],
                                   "line": r["line"], "file_id": r["file_id"]})
            pairs[key]["stmts"].add(d["stmt"])
        if not pairs:
            return ""
        rows = ""
        for pr in pairs.values():
            label = pr["column"].rsplit(".", 1)[-1].replace("_", " ").capitalize()
            rows += (
                f"<tr><td><code>{esc(pr['host'])}</code></td>"
                f"<td><code>{esc(pr['column'])}</code></td>"
                f"<td class=muted>{esc('/'.join(sorted(pr['stmts'])))} · "
                f"<a href='/file/{pr['file_id']}?hl={pr['line']}'>"
                f"{esc(pr['prog'])} {pr['line']}</a></td>"
                f"<td class=num><form method=post action='/settings/fieldmap/mined'>"
                f"<input type=hidden name=host value=\"{esc(pr['host'])}\">"
                f"<input type=hidden name=column value=\"{esc(pr['column'])}\">"
                f"<input type=hidden name=label value=\"{esc(label)}\">"
                f"<button style='padding:5px 14px;font-size:12.5px'>Accept"
                f"</button></form></td></tr>")
        return (f"<div class=card><h2>Mined from embedded SQL · "
                f"{len(pairs)} pairs</h2>"
                f"<p class=muted style='margin-top:-8px'>Host variables paired "
                f"with their DB2 columns, read positionally from the SQL your "
                f"programs already contain. Accepting creates the COBOL and "
                f"DB2 legs of a mapping — add the JSON path when the API "
                f"exposes the field.</p>"
                f"<table><tr><th>COBOL host variable</th><th>DB2 column</th>"
                f"<th>Where</th><th></th></tr>{rows}</table></div>")

    def _fieldmap_mined(self, conn, form):
        host = form.get("host", "").strip()
        column = form.get("column", "").strip()
        if not host or not column:
            self._send("<div class=card>Bad pair.</div>", code=400)
            return
        conn.execute(
            """INSERT INTO field_map (label, cobol_field, db2_column,
               format, notes, updated_by, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (form.get("label", "").strip() or host, host, column,
             suggest_format(conn, host, None, column),
             "mined from embedded SQL · format suggested, confirm it",
             "mined", db.now()))
        conn.commit()
        self._redirect("/settings?tab=fields")

    def _settings(self, conn, banner: str = "", tab: str = "api",
                  pending: str = "", banner_mi: str = "",
                  q: str = "", mp: int = 1):
        """Settings with left-hand navigation. Only the selected panel
        renders, so each page stays short enough to act on."""
        valid = {k for _, items in self.SETTINGS_NAV for k, _ in items}
        if tab not in valid:
            tab = "api"

        def field(label, control, hint=""):
            return (f"<label><span class=flabel>{label}</span>{control}</label>"
                    + (f"<span class=fhint>{hint}</span>" if hint else ""))

        nav = "<nav class=sidenav>"
        for group, items in self.SETTINGS_NAV:
            nav += f"<div class=grp>{group}</div>"
            for k, lbl in items:
                nav += (f"<a href='/settings?tab={k}' "
                        f"class='{'on' if tab == k else ''}'>{lbl}</a>")
        nav += "</nav>"

        parts = [banner,
                 "<div class=card><h1>Settings</h1><p class=muted>Connections and "
                 "mappings are configured once here, then used by Case Lookup, "
                 "the Lab and triage.</p></div>",
                 f"<div class=setwrap>{nav}<div>"]

        # ── API ────────────────────────────────────────────────────────
        if tab == "api":
            envs = conn.execute("SELECT * FROM api_env ORDER BY name").fetchall()
            eps = conn.execute("SELECT * FROM api_endpoint ORDER BY name").fetchall()
            rows = "".join(
                f"<tr><td><b>{esc(e['name'])}</b></td>"
                f"<td><code>{esc(e['base_url'])}</code></td>"
                f"<td>{'•••' + esc(e['token'][-6:]) if e['token'] else '<span class=muted>none</span>'}</td>"
                f"<td>{'skipped' if e['insecure_tls'] else 'on'}</td>"
                f"<td class=num><a class=btnsm "
                f"href='/settings/env/edit?id={e['id']}'>edit</a></td></tr>"
                for e in envs)
            parts.append(
                f"<div class=card><h2>Environments · {len(envs)}</h2>"
                f"<p class=muted style='margin-top:-8px'>Where to send requests. "
                f"An environment is a base URL plus the JWT used to reach it.</p>"
                f"<table style='margin-bottom:18px'><tr><th>Name</th><th>Base URL</th>"
                f"<th>JWT</th><th>TLS</th><th></th></tr>"
                f"{rows or '<tr><td colspan=6 class=muted>None yet.</td></tr>'}</table>"
                f"<div class=addbox><h3>Add or update an environment</h3>"
                f"<form method=post action='/settings/env'><div class=frow>"
                + field("Name", "<input type=text name=name placeholder='TEST1' required>",
                        "Re-using an existing name updates it.")
                + field("Base URL",
                        "<input type=text name=base_url "
                        "placeholder='https://test1.internal:8443' required>",
                        "Scheme and host only — paths live on endpoints.")
                + "</div>"
                + field("JWT token",
                        "<input type=text name=token placeholder='eyJhbGciOi…'>",
                        "Leave blank to keep the stored token. Stored in "
                        "chatbis.db on this machine — TEST tokens only.")
                + "<label class=muted style='display:block;margin:2px 0 14px'>"
                  "<input type=checkbox name=insecure_tls "
                  "style='width:auto;margin-right:6px'>Skip TLS verification "
                  "(self-signed test certificates)</label>"
                  "<button>Save environment</button></form></div></div>")

            ep_rows = "".join(
                f"<tr><td><b>{esc(e['name'])}</b></td><td>{esc(e['method'])}</td>"
                f"<td><code>{esc(e['path'])}</code></td>"
                f"<td class=num><a class=btnsm "
                f"href='/settings/endpoint/edit?id={e['id']}'>edit</a></td></tr>"
                for e in eps)
            parts.append(
                f"<div class=card><h2>Endpoints · {len(eps)}</h2>"
                f"<p class=muted style='margin-top:-8px'>What to request. Anything "
                f"in <code>{{braces}}</code> becomes a field the analyst fills in.</p>"
                f"<table style='margin-bottom:18px'><tr><th>Name</th><th>Method</th>"
                f"<th>Path</th><th></th></tr>"
                f"{ep_rows or '<tr><td colspan=4 class=muted>None yet.</td></tr>'}</table>"
                f"<div class=addbox><h3>Add an endpoint</h3>"
                f"<form method=post action='/settings/endpoint'><div class=frow>"
                + field("Name", "<input type=text name=name "
                        "placeholder='Claim by SSN+BIC' required>",
                        "Shown in the analyst's dropdown.")
                + field("Method", "<select name=method><option>GET</option>"
                        "<option>POST</option></select>")
                + "</div>"
                + field("Path",
                        "<input type=text name=path "
                        "placeholder='/v1/claims?ssn={ssn}&amp;bic={bic}' required>",
                        "Relative to the environment's base URL. "
                        "<code>{ssn}</code> and <code>{bic}</code> become inputs.")
                + field("POST body template",
                        "<textarea name=body rows=2 "
                        "placeholder='{\"ssn\": \"{ssn}\"}'></textarea>",
                        "Sent on any method that defines one — some APIs do "
                        "take a body on GET. <code>{ssn}</code> here becomes "
                        "an analyst input too.")
                + field("Headers",
                        "<textarea name=headers rows=2 placeholder='X-Region: "
                        "{region}'></textarea>",
                        "One per line, <code>Name: value</code>. "
                        "<code>{placeholders}</code> become analyst inputs — "
                        "for APIs that select a region by header.")
                + "<button>Save endpoint</button></form></div></div>")

            # ── bundles: several endpoints → one merged case ────────────
            bundles = conn.execute(
                "SELECT * FROM case_bundle ORDER BY name").fetchall()
            b_html = ""
            for b in bundles:
                steps = conn.execute(
                    """SELECT bs.*, e.name AS ep_name, e.method, e.path
                       FROM bundle_step bs JOIN api_endpoint e ON e.id = bs.endpoint_id
                       WHERE bs.bundle_id = ? ORDER BY bs.seq, bs.id""",
                    (b["id"],)).fetchall()
                srows = "".join(
                    f"<tr><td class=num>{st['seq']}</td>"
                    f"<td><code>{esc(st['mount_key'] or '(root)')}</code></td>"
                    f"<td><b>{esc(st['ep_name'])}</b> "
                    f"<span class=muted>{esc(st['path'][:52])}</span></td>"
                    f"<td>{'required' if st['required'] else 'optional'}</td>"
                    f"<td class=num><form method=post action='/settings/delete'>"
                    f"<input type=hidden name=kind value=bundlestep>"
                    f"<input type=hidden name=id value={st['id']}>"
                    f"<button class=delbtn>Remove</button></form></td></tr>"
                    for st in steps)
                ep_pick = "".join(f"<option value={e['id']}>{esc(e['name'])}</option>"
                                  for e in eps)
                b_html += (
                    f"<div style='border:1px solid var(--line);border-radius:12px;"
                    f"padding:14px 16px;margin-bottom:14px'>"
                    f"<div class=cardhead style='margin-bottom:8px'>"
                    f"<b style='font-size:15px'>{esc(b['name'])}</b>"
                    f"<form method=post action='/settings/delete' "
                    f"onsubmit=\"return confirm('Delete bundle {esc(b['name'])}?')\">"
                    f"<input type=hidden name=kind value=bundle>"
                    f"<input type=hidden name=id value={b['id']}>"
                    f"<button class=delbtn>Delete bundle</button></form></div>"
                    + (f"<p class=muted style='margin-top:-4px'>{esc(b['description'])}</p>"
                       if b["description"] else "")
                    + f"<table style='margin-bottom:10px'><tr><th class=num>#</th>"
                    f"<th>Mounts at</th><th>Endpoint</th><th></th><th></th></tr>"
                    f"{srows or '<tr><td colspan=5 class=muted>No steps yet.</td></tr>'}"
                    f"</table>"
                    f"<form method=post action='/settings/bundlestep' "
                    f"style='display:flex;gap:8px;flex-wrap:wrap;align-items:center'>"
                    f"<input type=hidden name=bundle_id value={b['id']}>"
                    f"<select name=endpoint_id style='max-width:200px'>{ep_pick}</select>"
                    f"<input type=text name=mount_key placeholder='mount key (blank = root)' "
                    f"style='max-width:190px'>"
                    f"<input type=number name=seq value='{len(steps)}' "
                    f"style='max-width:70px' title='order'>"
                    f"<label class=muted style='white-space:nowrap'>"
                    f"<input type=checkbox name=required checked "
                    f"style='width:auto;margin-right:5px'>required</label>"
                    f"<button>Add step</button></form></div>")
            parts.append(
                f"<div class=card><h2>Case bundles · {len(bundles)}</h2>"
                f"<p class=muted style='margin-top:-8px'>When one call doesn't "
                f"return a complete case, a bundle runs several in order and "
                f"merges them into a single object. Each step mounts under its "
                f"own key, so recipe paths look the same either way — "
                f"<code>claim.claimant.dob</code>, <code>periods[]</code>. A step "
                f"can use an earlier response with "
                f"<code>{{$mount.field}}</code>, e.g. "
                f"<code>/v1/periods?claim={{$claim.claimNumber}}</code>. Optional "
                f"steps that fail are reported, not silently dropped.</p>"
                f"{b_html}"
                f"<div class=addbox><h3>New bundle</h3>"
                f"<form method=post action='/settings/bundle'><div class=frow>"
                + field("Name", "<input type=text name=name placeholder='Full claim' "
                        "required>")
                + field("Description", "<input type=text name=description "
                        "placeholder='Claim + periods + addresses'>")
                + "</div><button>Create bundle</button></form></div></div>")

        # ── DATABASE ───────────────────────────────────────────────────
        if tab == "db":
            sources = conn.execute("SELECT * FROM db_source ORDER BY name").fetchall()
            queries = conn.execute("SELECT * FROM db_query ORDER BY name").fetchall()
            src_rows = "".join(
                f"<tr><td><b>{esc(s['name'])}</b></td>"
                f"<td><span class=doctype>{esc(s['driver'])}</span></td>"
                f"<td><code>{esc(s['dsn'][:60])}</code></td>"
                f"<td class=num><form method=post action='/settings/delete' "
                f"onsubmit=\"return confirm('Delete source {esc(s['name'])}?')\">"
                f"<input type=hidden name=kind value=dbsource>"
                f"<input type=hidden name=id value={s['id']}>"
                f"<button class=delbtn>Delete</button></form></td></tr>"
                for s in sources)
            parts.append(
                f"<div class=card><h2>Database sources · {len(sources)}</h2>"
                f"<p class=muted style='margin-top:-8px'>Read-only by construction: "
                f"SELECT/WITH only, one statement, bound parameters, 200-row cap.</p>"
                f"<table style='margin-bottom:18px'><tr><th>Name</th><th>Driver</th>"
                f"<th>Connection</th><th></th></tr>"
                f"{src_rows or '<tr><td colspan=4 class=muted>None yet.</td></tr>'}</table>"
                f"<div class=addbox><h3>Add a source</h3>"
                f"<form method=post action='/settings/dbsource'><div class=frow>"
                + field("Name", "<input type=text name=name placeholder='SUSPENSE-DB' "
                        "required>")
                + field("Driver", "<select name=driver>"
                        "<option value=sqlite>SQLite file</option>"
                        "<option value=odbc>ODBC DSN</option></select>",
                        "ODBC reaches DB2 / Oracle / SQL Server via the DSNs your "
                        "desktop team already configures (needs pyodbc).")
                + "</div>"
                + field("Connection",
                        "<input type=text name=dsn "
                        "placeholder='/path/to.db  —or—  DSN=DB2TEST;UID=user;PWD=secret' "
                        "required>")
                + "<button>Save source</button></form></div></div>")

            dq_rows = "".join(
                f"<tr><td><b>{esc(q['name'])}</b></td>"
                f"<td><code>{esc(q['sql'][:80])}</code></td>"
                f"<td class=num><form method=post action='/settings/delete' "
                f"onsubmit=\"return confirm('Delete query {esc(q['name'])}?')\">"
                f"<input type=hidden name=kind value=dbquery>"
                f"<input type=hidden name=id value={q['id']}>"
                f"<button class=delbtn>Delete</button></form></td></tr>"
                for q in queries)
            parts.append(
                f"<div class=card><h2>Saved queries · {len(queries)}</h2>"
                f"<p class=muted style='margin-top:-8px'>Parameterised SQL analysts "
                f"can run without writing any.</p>"
                f"<table style='margin-bottom:18px'><tr><th>Name</th><th>SQL</th>"
                f"<th></th></tr>"
                f"{dq_rows or '<tr><td colspan=3 class=muted>None yet.</td></tr>'}</table>"
                f"<div class=addbox><h3>Add a query</h3>"
                f"<form method=post action='/settings/dbquery'>"
                + field("Name", "<input type=text name=name "
                        "placeholder='Suspense by claim' required>")
                + field("SQL",
                        "<textarea name=sql rows=3 spellcheck=false "
                        "style='font-family:monospace;font-size:13px' "
                        "placeholder='SELECT * FROM SUSPENSE WHERE CLAIM_NO = {claim}' "
                        "required></textarea>",
                        "<code>{placeholders}</code> become the analyst's fields and "
                        "are bound as real SQL parameters — a value can never alter "
                        "the query.")
                + "<button>Save query</button></form></div></div>")

        # ── LLM ────────────────────────────────────────────────────────
        if tab == "llm":
            llm = conn.execute("SELECT * FROM llm_config WHERE id = 1").fetchone()
            prov = llm["provider"] if llm else "in-network"
            on = bool(llm and llm["enabled"])
            zr = bool(llm and llm["zero_retention_confirmed"])
            state = ("<span class='badge resolved' style='margin-left:0'>enabled</span>"
                     if on else "<span class='badge' style='margin-left:0;"
                     "background:#eef1f5;color:#4a5b6d'>disabled</span>")
            prov_opts = "".join(
                f"<option{' selected' if prov == v else ''}>{v}</option>"
                for v in ("in-network", "enterprise-zero-retention"))
            parts.append(
                f"<div class=card><h2>LLM connector {state}</h2>"
                f"<p class=muted style='margin-top:-8px'>Used <b>only</b> by the "
                f"Investigate path — when no recipe matches a code. Routine triage "
                f"is deterministic and never calls a model, so claim data stays "
                f"in-network.</p>"
                f"<div class=quote style='margin-bottom:16px'><b>Identifiers are "
                f"always stripped</b> before anything is sent — SSN, BIC, names, "
                f"dates of birth and addresses are redacted. This is not "
                f"configurable.</div>"
                f"<form method=post action='/settings/llm'><div class=frow>"
                + field("Provider", f"<select name=provider>{prov_opts}</select>")
                + field("Model", f"<input type=text name=model placeholder='llama-3.3-70b' "
                        f"value=\"{esc(llm['model'] if llm and llm['model'] else '')}\">")
                + "</div>"
                + field("Endpoint",
                        f"<input type=text name=base_url "
                        f"placeholder='http://llm.internal:8000/v1' "
                        f"value=\"{esc(llm['base_url'] if llm and llm['base_url'] else '')}\">")
                + field("API key", "<input type=text name=api_key placeholder='••••••'>",
                        "Leave blank to keep the stored key.")
                + f"<label class=muted style='display:block;margin:2px 0 6px'>"
                  f"<input type=checkbox name=enabled style='width:auto;margin-right:6px' "
                  f"{'checked' if on else ''}>Enable the Investigate path</label>"
                  f"<label class=muted style='display:block;margin:2px 0 16px'>"
                  f"<input type=checkbox name=zero_retention style='width:auto;"
                  f"margin-right:6px' {'checked' if zr else ''}>I confirm this "
                  f"endpoint is in-network or contractually zero-retention</label>"
                  f"<button>Save LLM connector</button>"
                  f"<p class=muted style='margin-top:12px;margin-bottom:0'>Not yet "
                  f"wired — the Investigate path is still to build.</p>"
                  f"</form></div>")

        # ── MAPPING ────────────────────────────────────────────────────
        if tab == "fields":
            apps = conn.execute("SELECT id, name FROM application ORDER BY name").fetchall()
            PAGE = 25
            where, args = "", []
            if q:
                like = f"%{q}%"
                where = ("""WHERE fm.label LIKE ? OR fm.cobol_field LIKE ?
                            OR fm.db2_column LIKE ? OR fm.json_path LIKE ?
                            OR fm.format LIKE ? OR a.name LIKE ?""")
                args = [like] * 6
            total = conn.execute(
                f"""SELECT COUNT(*) FROM field_map fm
                    LEFT JOIN application a ON a.id = fm.application_id
                    {where}""", tuple(args)).fetchone()[0]
            pages = max(1, -(-total // PAGE))
            mp = min(mp, pages)
            maps = conn.execute(
                f"""SELECT fm.*, a.name AS app FROM field_map fm
                    LEFT JOIN application a ON a.id = fm.application_id
                    {where} ORDER BY fm.label LIMIT ? OFFSET ?""",
                tuple(args) + (PAGE, (mp - 1) * PAGE)).fetchall()
            # actions return to this exact view
            back = ("/settings?tab=fields"
                    + (f"&q={urllib.parse.quote(q)}" if q else "")
                    + (f"&mp={mp}" if mp > 1 else ""))
            def fmt_cell(m):
                cur = m["format"] or ""
                sug = suggest_format(conn, m["cobol_field"], m["json_path"],
                                     m["db2_column"])
                opts = "".join(
                    f"<option value='{esc(v)}'"
                    f"{' selected' if v == cur else ''}>{esc(lbl)}</option>"
                    for v, lbl in FORMATS)
                hint = ("" if cur else
                        f"<div class=muted style='font-size:11.5px'>"
                        f"suggested: <b>{esc(sug)}</b></div>")
                return (f"<form method=post action='/settings/fieldmap/format'"
                        f" style='display:flex;gap:5px;align-items:center'>"
                        f"<input type=hidden name=id value={m['id']}>"
                        f"<input type=hidden name=back value='{esc(back)}'>"
                        f"<select name=format style='margin:0;font-size:12.5px;"
                        f"padding:5px 8px;max-width:190px'>{opts}</select>"
                        f"<button style='padding:5px 10px;font-size:12px'>"
                        f"Set</button></form>{hint}")

            rows = "".join(
                f"<tr><td><b>{esc(m['label'])}</b>"
                f"{'<br><span class=muted>' + esc(m['app']) + '</span>' if m['app'] else ''}</td>"
                f"<td><code>{esc(m['cobol_field'] or '—')}</code></td>"
                f"<td><code>{esc(m['db2_column'] or '—')}</code></td>"
                f"<td><code>{esc(m['json_path'] or '—')}</code></td>"
                f"<td>{fmt_cell(m)}</td>"
                f"<td class=num>"
                f"<a class=btnsm2 href='/settings/fieldmap/edit?id={m['id']}"
                f"&back={urllib.parse.quote(back)}'>Edit</a></td></tr>"
                for m in maps)
            if not rows:
                rows = ("<tr><td colspan=6 class=muted>"
                        + (f"Nothing matches “{esc(q)}”." if q
                           else "None yet.")
                        + "</td></tr>")
            app_opts = "<option value=''>— any application —</option>" + "".join(
                f"<option value={a['id']}>{esc(a['name'])}</option>" for a in apps)
            # Mined COBOL fields make useful suggestions for the left column.
            mined = conn.execute(
                "SELECT DISTINCT name FROM data_item WHERE item_type != 'group'"
                " ORDER BY name LIMIT 300").fetchall()
            dl = "".join(f"<option value='{esc(x['name'])}'></option>" for x in mined)
            if pending:
                parts.append(self._fieldmap_preview(conn, pending))
            parts.append(self._mined_pairs_card(conn, maps))
            parts.append(
                self._areas_card(conn)
                + self._vocab_card(conn)
                + f"<div class=card><div class=cardhead>"
                f"<h2 style='margin:0'>Field mappings · {total}"
                f"{' matching' if q else ''}</h2>"
                f"<form method=get action='/settings' style='display:flex;"
                f"gap:7px;margin:0'>"
                f"<input type=hidden name=tab value=fields>"
                f"<input name=q value='{esc(q)}' placeholder='search field, "
                f"COBOL, DB2, path…' style='margin:0;width:250px;"
                f"font-size:13px;padding:7px 12px'>"
                f"<button class=btnsm2 style='padding:7px 14px'>Search</button>"
                + (f"<a class=btnsm2 style='padding:7px 12px' "
                   f"href='/settings?tab=fields'>clear</a>" if q else "")
                + f"</form></div>"
                f"<p class=muted style='margin-top:-8px'>The same business field "
                f"wears three names: COBOL in the mined evidence, DB2 in the SQL "
                f"rail, JSON in the API response. Mapping them once means an "
                f"analyst writing a check doesn't have to translate in their "
                f"head — and it's what lets a mined gate like "
                f"<code>IF WS-BENE-DOB &gt; WS-EFF-DATE</code> line up with the "
                f"path a recipe actually evaluates.</p>"
                f"<div style='overflow-x:auto'>"
                f"<table style='margin-bottom:18px'><tr><th>Field</th>"
                f"<th>COBOL</th><th>DB2 column</th><th>JSON path</th>"
                f"<th>Format</th><th></th></tr>"
                f"{rows}</table></div>"
                + f"<div style='display:flex;align-items:center;gap:14px;"
                  f"margin:-4px 0 2px'>"
                + (f"<a class=btnsm2 href='/settings?tab=fields&mp={mp-1}"
                   f"{'&q=' + urllib.parse.quote(q) if q else ''}'>"
                   f"&larr; prev</a>" if mp > 1 else "")
                + f"<span class=muted style='font-size:12.5px'>"
                  f"{min((mp-1)*PAGE + 1, total)}–{min(mp*PAGE, total)} "
                  f"of {total} · page {mp} of {pages} · {PAGE} per page</span>"
                + (f"<a class=btnsm2 href='/settings?tab=fields&mp={mp+1}"
                   f"{'&q=' + urllib.parse.quote(q) if q else ''}'>"
                   f"next &rarr;</a>" if mp < pages else "")
                + "</div>"
                + "</div>"
                + f"<datalist id=mined>{dl}</datalist>"
                f"<div class=card><h2>Add a mapping</h2>"
                f"<form method=post action='/settings/fieldmap'><div class=frow>"
                + field("Field", "<input type=text name=label "
                        "placeholder='Beneficiary date of birth' required>",
                        "Plain language — what an analyst would call it.")
                + field("Application", f"<select name=application_id>{app_opts}</select>",
                        "Optional. Layouts differ between applications.")
                + "</div><div class=frow>"
                + field("COBOL field",
                        "<input type=text name=cobol_field list=mined "
                        "placeholder='WS-BENE-DOB' autocomplete=off>",
                        "Suggestions come from mined copybooks.")
                + field("DB2 column",
                        "<input type=text name=db2_column "
                        "placeholder='MCS.CLAIM.BENE_DOB'>",
                        "SCHEMA.TABLE.COLUMN, for the SQL rail.")
                + "</div>"
                + field("JSON path",
                        "<input type=text name=json_path "
                        "placeholder='claimant.dateOfBirth'>",
                        "Dot path into the case object — what a recipe check "
                        "actually evaluates.")
                + field("Format",
                        "<select name=format>" + "".join(
                            f"<option value='{v}'>{lbl}</option>"
                            for v, lbl in FORMATS) + "</select>",
                        "How the JSON value becomes the field's bytes. "
                        "Dates are the trap: 1958-04-02 into PIC 9(8) is "
                        "invalid decimal data unless it is converted.")
                + field("Notes", "<input type=text name=notes "
                        "placeholder='e.g. packed decimal, CCYYMMDD'>")
                + "<button>Save mapping</button></form></div>"
                + f"""<div class=card><h2>Import &amp; export</h2>
<div style="display:flex;gap:22px;
flex-wrap:wrap;align-items:flex-start">
<form id=fmup method=post action="/settings/fieldmap/upload"
 enctype="multipart/form-data">
<input type=file id=fmf name=file accept=".xlsx,.csv,.json" style="display:none">
<label class=drop id=fmdrop for=fmf style="width:340px;padding:16px">
<b>Import mappings</b>drop a file or click to browse<br>
<span id=fmlbl>.xlsx · .csv · .json</span></label></form>
<div style="flex:1;min-width:220px">
<div class=panehead>Export</div>
<p class=muted style="margin-top:0">Download what's here, edit in Excel, and
re-import — matching rows update rather than duplicate.</p>
<a class=btnlink href="/settings/fieldmap/export?fmt=csv">Export CSV</a>
<a class=btnlink style="margin-left:8px;background:#fff;color:#33506e;
 border:1px solid var(--line)" href="/settings/fieldmap/export?fmt=json">JSON</a>
</div></div>
<script>
(function(){{
  var i=document.getElementById('fmf'),d=document.getElementById('fmdrop'),
      l=document.getElementById('fmlbl'),f=document.getElementById('fmup');
  i.addEventListener('change',function(){{
    if(i.files.length){{l.textContent=i.files[0].name+' \\u2014 reading\\u2026';f.submit();}}}});
  ['dragover','dragenter'].forEach(function(e){{d.addEventListener(e,function(ev){{
    ev.preventDefault();d.classList.add('over');}});}});
  ['dragleave','drop'].forEach(function(e){{d.addEventListener(e,function(ev){{
    ev.preventDefault();d.classList.remove('over');}});}});
  d.addEventListener('drop',function(ev){{
    i.files=ev.dataTransfer.files;i.dispatchEvent(new Event('change'));}});
}})();
</script>""")

        if tab == "mi":
            parts.append(self._mi_panel(conn, {"pending": [pending]} if pending
                                        else {}, banner_mi))

        parts.append("</div></div>")
        self._send("".join(parts), "Settings")

    # ── editing one mapping in full ────────────────────────────────────
    def _fieldmap_edit(self, conn, qs):
        mid = int((qs or {}).get("id", ["0"])[0] or 0)
        back = (qs or {}).get("back", ["/settings?tab=fields"])[0]
        if not back.startswith("/settings"):
            back = "/settings?tab=fields"
        m = conn.execute(
            """SELECT fm.*, a.name AS app FROM field_map fm
               LEFT JOIN application a ON a.id = fm.application_id
               WHERE fm.id = ?""", (mid,)).fetchone()
        if not m:
            self._send("<div class=card>Mapping not found.</div>", code=404)
            return
        apps = conn.execute(
            "SELECT id, name FROM application ORDER BY name").fetchall()
        app_opts = "<option value=''>— any application —</option>" + "".join(
            f"<option value={a['id']}"
            f"{' selected' if a['id'] == m['application_id'] else ''}>"
            f"{esc(a['name'])}</option>" for a in apps)
        fmt_opts = "".join(
            f"<option value='{v}'"
            f"{' selected' if v == (m['format'] or '') else ''}>{lbl}"
            f"</option>" for v, lbl in FORMATS)
        sug = suggest_format(conn, m["cobol_field"], m["json_path"],
                             m["db2_column"])
        mined = conn.execute(
            "SELECT DISTINCT name FROM data_item WHERE item_type != 'group'"
            " ORDER BY name LIMIT 300").fetchall()
        dl = "".join(f"<option value='{esc(x['name'])}'></option>"
                     for x in mined)

        def fld(label, inner, hint=""):
            return (f"<div><label class=flabel>{label}</label>{inner}"
                    + (f"<span class=fhint>{hint}</span>" if hint else "")
                    + "</div>")

        self._send(
            crumbs(("Settings", back), here=f"Edit · {m['label']}")
            + f"""<div class=card><h1>Edit mapping</h1>
<p class=muted style='margin-top:-2px'>Every column of the row —
the per-row Set control only changes the format.</p>
<form method=post action='/settings/fieldmap/update'>
<input type=hidden name=id value={mid}>
<input type=hidden name=back value='{esc(back)}'>
<div class=frow>
{fld("Field", f"<input type=text name=label value='{esc(m['label'])}'"
     f" required>", "Plain language — what an analyst would call it.")}
{fld("Application", f"<select name=application_id>{app_opts}</select>")}
</div><div class=frow>
{fld("COBOL field", f"<input type=text name=cobol_field list=mined"
     f" value='{esc(m['cobol_field'] or '')}' autocomplete=off>")}
{fld("DB2 column", f"<input type=text name=db2_column"
     f" value='{esc(m['db2_column'] or '')}'>")}
</div>
{fld("JSON path", f"<input type=text name=json_path"
     f" value='{esc(m['json_path'] or '')}'>",
     "Dot path into the case object; [] marks a repeating group.")}
{fld("Format", f"<select name=format>{fmt_opts}</select>",
     f"suggested from the mined PIC: <b>{esc(sug)}</b>")}
{fld("Notes", f"<input type=text name=notes"
     f" value='{esc(m['notes'] or '')}'>")}
<datalist id=mined>{dl}</datalist>
<div style='margin-top:14px;display:flex;gap:10px'>
<button>Save changes</button>
<a class=btnsm href='{esc(back)}' style='align-self:center'>Cancel</a>
</div></form>
<div style='border-top:1px solid var(--line);margin-top:20px;
padding-top:14px;display:flex;align-items:center;gap:14px'>
<form method=post action='/settings/delete' style='margin:0'
 onsubmit="return confirm('Delete mapping {esc(m['label'])}?')">
<input type=hidden name=kind value=fieldmap>
<input type=hidden name=id value={mid}>
<input type=hidden name=back value='{esc(back)}'>
<button class=delbtn>Delete this mapping</button></form>
<span class=muted style='font-size:12.5px'>Removes the row for every
consumer — a run that needs it will halt naming the missing mapping.
</span></div></div>""",
            f"edit · {m['label']}")

    def _env_edit(self, conn, qs):
        eid = int((qs or {}).get("id", ["0"])[0] or 0)
        e = conn.execute("SELECT * FROM api_env WHERE id = ?",
                         (eid,)).fetchone()
        if not e:
            self._send("<div class=card>Environment not found.</div>",
                       code=404)
            return

        def fld(label, inner, hint=""):
            return (f"<div><label class=flabel>{label}</label>{inner}"
                    + (f"<span class=fhint>{hint}</span>" if hint else "")
                    + "</div>")

        self._send(
            crumbs(("Settings", "/settings?tab=api"),
                   here=f"Edit · {e['name']}")
            + f"""<div class=card><h1>Edit environment</h1>
<form method=post action='/settings/env/update'>
<input type=hidden name=id value={eid}>
<div class=frow>
{fld("Name", f"<input type=text name=name value='{esc(e['name'])}'"
     f" required>")}
{fld("Base URL", f"<input type=text name=base_url"
     f" value='{esc(e['base_url'])}' required>")}
</div><div class=frow>
{fld("JWT", "<input type=password name=token placeholder='"
     + ("unchanged — leave blank to keep" if e["token"]
        else "none set") + "'>",
     "Leave blank to keep the stored token.")}
{fld("TLS verification",
     f"<label style='display:flex;gap:7px;align-items:center;"
     f"margin-top:9px'><input type=checkbox name=insecure_tls"
     f"{' checked' if e['insecure_tls'] else ''} style='width:auto'>"
     f" skip certificate checks</label>",
     "Only for internal endpoints with self-signed certs.")}
</div>
<div style='margin-top:14px;display:flex;gap:10px'>
<button>Save changes</button>
<a class=btnsm href='/settings?tab=api' style='align-self:center'>Cancel
</a></div></form>
<div style='border-top:1px solid var(--line);margin-top:20px;
padding-top:14px;display:flex;align-items:center;gap:14px'>
<form method=post action='/settings/delete' style='margin:0'
 onsubmit="return confirm('Delete environment {esc(e['name'])}?')">
<input type=hidden name=kind value=env>
<input type=hidden name=id value={eid}>
<button class=delbtn>Delete this environment</button></form>
<span class=muted style='font-size:12.5px'>Case Lookup loses this
destination; saved recipes that point at it will refuse to run.</span>
</div></div>""",
            f"edit · {e['name']}")

    def _env_update(self, conn, form):
        eid = int(form.get("id", 0) or 0)
        e = conn.execute("SELECT * FROM api_env WHERE id = ?",
                         (eid,)).fetchone()
        if not e:
            self._redirect("/settings?tab=api")
            return
        token = form.get("token", "").strip() or e["token"]
        try:
            conn.execute(
                """UPDATE api_env SET name=?, base_url=?, token=?,
                   insecure_tls=? WHERE id=?""",
                (form.get("name", "").strip().upper() or e["name"],
                 form.get("base_url", "").strip() or e["base_url"],
                 token, 1 if form.get("insecure_tls") else 0, eid))
        except sqlite3.IntegrityError:
            self._send(f"<div class=card>An environment named "
                       f"<b>{esc(form.get('name', ''))}</b> already exists "
                       f"— pick another name. <a href='/settings/env/edit"
                       f"?id={eid}'>Back</a></div>", code=400)
            return
        conn.commit()
        self._redirect("/settings?tab=api")

    def _endpoint_edit(self, conn, qs):
        eid = int((qs or {}).get("id", ["0"])[0] or 0)
        e = conn.execute("SELECT * FROM api_endpoint WHERE id = ?",
                         (eid,)).fetchone()
        if not e:
            self._send("<div class=card>Endpoint not found.</div>",
                       code=404)
            return

        def fld(label, inner, hint=""):
            return (f"<div><label class=flabel>{label}</label>{inner}"
                    + (f"<span class=fhint>{hint}</span>" if hint else "")
                    + "</div>")

        try:
            hdrs = e["headers"] or ""
        except (KeyError, IndexError):
            hdrs = ""
        self._send(
            crumbs(("Settings", "/settings?tab=api"),
                   here=f"Edit · {e['name']}")
            + f"""<div class=card><h1>Edit endpoint</h1>
<p class=muted style='margin-top:-2px'>Anything in <code>{{braces}}</code>
— path, body or headers — becomes a field the analyst fills in.</p>
<form method=post action='/settings/endpoint/update'>
<input type=hidden name=id value={eid}>
<div class=frow>
{fld("Name", f"<input type=text name=name value='{esc(e['name'])}'"
     f" required>")}
{fld("Method", "<select name=method><option"
     + (" selected" if e["method"] == "GET" else "") + ">GET</option>"
     "<option" + (" selected" if e["method"] == "POST" else "")
     + ">POST</option></select>")}
</div>
{fld("Path", f"<input type=text name=path value='{esc(e['path'])}'"
     f" required>", "Relative to the environment's base URL.")}
{fld("Body template", f"<textarea name=body rows=3>"
     f"{esc(e['body'] or '')}</textarea>",
     "Sent on any method that defines one.")}
{fld("Headers", f"<textarea name=headers rows=2>{esc(hdrs)}"
     f"</textarea>",
     "One per line, <code>Name: value</code> — for APIs that select a "
     "region by header.")}
<div style='margin-top:14px;display:flex;gap:10px'>
<button>Save changes</button>
<a class=btnsm href='/settings?tab=api' style='align-self:center'>Cancel
</a></div></form>
<div style='border-top:1px solid var(--line);margin-top:20px;
padding-top:14px;display:flex;align-items:center;gap:14px'>
<form method=post action='/settings/delete' style='margin:0'
 onsubmit="return confirm('Delete endpoint {esc(e['name'])}?')">
<input type=hidden name=kind value=endpoint>
<input type=hidden name=id value={eid}>
<button class=delbtn>Delete this endpoint</button></form>
<span class=muted style='font-size:12.5px'>Bundles and recipes that
use it will refuse to run, naming the missing endpoint.</span>
</div></div>""",
            f"edit · {e['name']}")

    def _endpoint_update(self, conn, form):
        eid = int(form.get("id", 0) or 0)
        e = conn.execute("SELECT * FROM api_endpoint WHERE id = ?",
                         (eid,)).fetchone()
        if not e:
            self._redirect("/settings?tab=api")
            return
        conn.execute(
            """UPDATE api_endpoint SET name=?, method=?, path=?, body=?,
               headers=? WHERE id=?""",
            (form.get("name", "").strip() or e["name"],
             "POST" if form.get("method") == "POST" else "GET",
             form.get("path", "").strip() or e["path"],
             form.get("body", "").strip() or None,
             form.get("headers", "").strip() or None, eid))
        conn.commit()
        self._redirect("/settings?tab=api")

    def _fieldmap_update(self, conn, form):
        mid = int(form.get("id", 0) or 0)
        back = form.get("back", "/settings?tab=fields")
        if not back.startswith("/settings"):
            back = "/settings?tab=fields"
        conn.execute(
            """UPDATE field_map SET label=?, application_id=?, cobol_field=?,
               db2_column=?, json_path=?, format=?, notes=?,
               updated_by='analyst', updated_at=? WHERE id=?""",
            (form.get("label", "").strip() or "(unnamed)",
             int(form["application_id"]) if form.get("application_id")
             else None,
             form.get("cobol_field", "").strip() or None,
             form.get("db2_column", "").strip() or None,
             form.get("json_path", "").strip() or None,
             form.get("format", "").strip() or None,
             form.get("notes", "").strip() or None,
             db.now(), mid))
        conn.commit()
        self._redirect(back)

    # ── field-map import / export ──────────────────────────────────────
    def _fm_dir(self) -> Path:
        d = Path(self.db_path).resolve().parent / "artifacts" / "_fieldmap"
        d.mkdir(parents=True, exist_ok=True)
        return d

    def _fieldmap_upload(self, body: bytes):
        files = parse_multipart(self.headers.get("Content-Type", ""), body)
        if not files:
            self._send("<div class=card>No file received. "
                       "<a href='/settings?tab=fields'>Back</a></div>", code=400)
            return
        name, payload = files[0]
        (self._fm_dir() / name).write_bytes(payload)
        self._redirect(f"/settings?tab=fields&pending={urllib.parse.quote(name)}")

    def _fieldmap_preview(self, conn, filename: str) -> str:
        """Show the file's OWN columns and propose which is which — same
        dynamic contract as the MI import: nothing about the sheet's shape
        is assumed, the analyst confirms before anything is written."""
        fp = self._fm_dir() / Path(filename).name
        if not fp.exists():
            return ""
        try:
            headers, rows = read_field_map(fp.read_bytes(), fp.name)
        except Exception as e:
            return (f"<div class=banner style='background:#f9e5e5;color:#a63838;"
                    f"border-color:#e7c3c3'>Could not read {esc(fp.name)}: "
                    f"{esc(e)}</div>")
        if not headers:
            return (f"<div class=banner style='background:#fdf6dd;color:#7a5d05;"
                    f"border-color:#efe1a8'>{esc(fp.name)} has no readable "
                    f"rows.</div>")
        g = guess_field_columns(headers)
        head = "".join(f"<th>{esc(h) or '—'}</th>" for h in headers)
        body_rows = "".join(
            "<tr>" + "".join(f"<td>{esc(c)}</td>" for c in r) + "</tr>"
            for r in rows[:6])

        def sel(role, label, optional=True):
            opts = ("<option value='-1'>— none —</option>" if optional else "")
            for i, h in enumerate(headers):
                s_ = " selected" if g.get(role) == i else ""
                opts += f"<option value={i}{s_}>{esc(h) or f'col {i+1}'}</option>"
            return (f"<label><span class=flabel>{label}</span>"
                    f"<select name={role}_col>{opts}</select></label>")

        apps = conn.execute("SELECT id, name FROM application ORDER BY name").fetchall()
        app_opts = "<option value=''>— any application —</option>" + "".join(
            f"<option value={a['id']}>{esc(a['name'])}</option>" for a in apps)
        return (f"<div class=card><h2>{esc(fp.name)} · {len(rows)} rows · "
                f"{len(headers)} columns</h2>"
                f"<div style='overflow-x:auto'><table><tr>{head}</tr>{body_rows}"
                f"</table></div>"
                f"<p class=muted>Preview — first 6 rows, every column as-is. "
                f"Confirm which column is which, then import.</p>"
                f"<form method=post action='/settings/fieldmap/import' "
                f"style='max-width:640px'>"
                f"<input type=hidden name=file value='{esc(fp.name)}'>"
                f"<div class=frow>{sel('label', 'Field / description')}"
                f"{sel('cobol', 'COBOL field')}</div>"
                f"<div class=frow>{sel('db2', 'DB2 column')}"
                f"{sel('json', 'JSON path')}</div>"
                f"<div class=frow>{sel('notes', 'Notes')}"
                f"<label><span class=flabel>Application</span>"
                f"<select name=application_id>{app_opts}</select></label></div>"
                f"<button>Import mappings</button>"
                f"<a class=btnlink style='margin-left:10px;background:#fff;"
                f"color:#33506e;border:1px solid var(--line)' "
                f"href='/settings?tab=fields'>Cancel</a></form></div>")

    def _fieldmap_import(self, conn, form):
        fp = self._fm_dir() / Path(form.get("file", "")).name
        if not fp.exists():
            self._send("<div class=card>File not found.</div>", code=404)
            return
        headers, rows = read_field_map(fp.read_bytes(), fp.name)

        def col(role):
            try:
                v = int(form.get(f"{role}_col", "-1"))
            except ValueError:
                v = -1
            return v if 0 <= v < len(headers) else None

        cols = {r: col(r) for r in ("label", "cobol", "db2", "json", "notes")}
        aid = form.get("application_id", "").strip()
        aid = int(aid) if aid.isdigit() else None

        def cell(row, role):
            i = cols[role]
            return (row[i].strip() if i is not None and i < len(row) else "") or None

        added = updated = skipped = 0
        for row in rows:
            label = cell(row, "label")
            cobol = cell(row, "cobol")
            # A row needs SOME identity — label, or a COBOL field to name it by.
            if not label and not cobol:
                skipped += 1
                continue
            label = label or cobol
            # Re-import updates rather than duplicating: match on the same
            # application + label so an exported-edited-reimported sheet is
            # idempotent.
            existing = conn.execute(
                "SELECT id FROM field_map WHERE label = ? AND"
                " COALESCE(application_id, -1) = COALESCE(?, -1)",
                (label, aid)).fetchone()
            vals = (aid, label, cobol, cell(row, "db2"), cell(row, "json"),
                    cell(row, "notes"), form.get("actor", "import"), db.now())
            if existing:
                conn.execute(
                    """UPDATE field_map SET application_id=?, label=?,
                       cobol_field=?, db2_column=?, json_path=?, notes=?,
                       updated_by=?, updated_at=? WHERE id=?""",
                    vals + (existing["id"],))
                updated += 1
            else:
                conn.execute(
                    """INSERT INTO field_map (application_id, label, cobol_field,
                       db2_column, json_path, notes, updated_by, updated_at)
                       VALUES (?,?,?,?,?,?,?,?)""", vals)
                added += 1
        conn.commit()
        fp.unlink(missing_ok=True)
        self._settings(
            conn,
            f"<div class=banner>Imported {esc(fp.name)} — {added} added, "
            f"{updated} updated"
            f"{f', {skipped} skipped (no field name)' if skipped else ''}.</div>",
            "fields")

    def _fieldmap_export(self, conn, fmt: str):
        rows = conn.execute(
            """SELECT a.name AS application, fm.label, fm.cobol_field,
                      fm.db2_column, fm.json_path, fm.notes
               FROM field_map fm LEFT JOIN application a ON a.id = fm.application_id
               ORDER BY fm.label""").fetchall()
        if fmt == "json":
            payload = json.dumps([dict(r) for r in rows], indent=2).encode()
            ctype, fname = "application/json", "field-mappings.json"
        else:
            buf = io.StringIO()
            w = csv.writer(buf)
            w.writerow(["application", "label", "cobol_field", "db2_column",
                        "json_path", "notes"])
            for r in rows:
                w.writerow([r[k] or "" for k in
                            ("application", "label", "cobol_field", "db2_column",
                             "json_path", "notes")])
            payload = buf.getvalue().encode()
            ctype, fname = "text/csv", "field-mappings.csv"
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Disposition", f'attachment; filename="{fname}"')
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def _settings_delete(self, conn, form):
        """Remove a connector. Scoped by kind + id so nothing else is touched."""
        table = {"env": "api_env", "endpoint": "api_endpoint",
                 "dbsource": "db_source", "dbquery": "db_query",
                 "bundle": "case_bundle", "bundlestep": "bundle_step",
                 "fieldmap": "field_map"}.get(
                     form.get("kind", ""))
        tab = {"env": "api", "endpoint": "api", "bundle": "api",
               "bundlestep": "api", "fieldmap": "fields"}.get(
                   form.get("kind", ""), "db")
        if not table:
            self._send("<div class=card>Unknown connector type.</div>", code=400)
            return
        try:
            rid = int(form.get("id", 0))
        except ValueError:
            self._send("<div class=card>Bad id.</div>", code=400)
            return
        if table == "case_bundle":
            conn.execute("UPDATE playbook SET bundle_id = NULL WHERE bundle_id = ?",
                         (rid,))
            conn.execute("DELETE FROM bundle_step WHERE bundle_id = ?", (rid,))
        if table == "api_endpoint":
            conn.execute("DELETE FROM bundle_step WHERE endpoint_id = ?", (rid,))
            # Recipes point at endpoints; null the reference rather than
            # leaving a playbook aimed at something that no longer exists.
            conn.execute("UPDATE playbook SET endpoint_id = NULL WHERE endpoint_id = ?",
                         (rid,))
        conn.execute(f"DELETE FROM {table} WHERE id = ?", (rid,))
        conn.commit()
        dest = form.get("back", "")
        if dest.startswith("/settings"):
            self._redirect(dest)
            return
        self._settings(conn, "<div class=banner>Connector deleted.</div>", tab)

    def _settings_llm(self, conn, form):
        cur = conn.execute("SELECT api_key FROM llm_config WHERE id = 1").fetchone()
        key = form.get("api_key", "").strip() or (cur["api_key"] if cur else None)
        conn.execute(
            """INSERT INTO llm_config (id, provider, base_url, model, api_key,
               enabled, redact_identifiers, zero_retention_confirmed,
               updated_by, updated_at)
               VALUES (1, ?, ?, ?, ?, ?, 1, ?, ?, ?)
               ON CONFLICT(id) DO UPDATE SET
                 provider = excluded.provider, base_url = excluded.base_url,
                 model = excluded.model, api_key = excluded.api_key,
                 enabled = excluded.enabled,
                 zero_retention_confirmed = excluded.zero_retention_confirmed,
                 updated_by = excluded.updated_by, updated_at = excluded.updated_at""",
            (form.get("provider", "in-network"), form.get("base_url", "").strip(),
             form.get("model", "").strip(), key,
             1 if form.get("enabled") else 0,
             1 if form.get("zero_retention") else 0,
             form.get("actor", "admin"), db.now()))
        conn.commit()
        warn = ""
        if form.get("enabled") and not form.get("zero_retention"):
            warn = ("<div class=banner style='background:#f9e5e5;color:#a63838;"
                    "border-color:#e7c3c3'>Enabled without confirming the endpoint "
                    "is in-network or zero-retention — the Investigate path will "
                    "stay blocked until that is confirmed.</div>")
        self._settings(conn, warn or "<div class=banner>LLM connector saved.</div>", "llm")

    def _mbr_html(self, conn, data, raw_pretty: str) -> str:
        """The pulled case as the MBR — table sections with occurrence
        rows — with the raw JSON folded underneath as the evidence.
        Falls back to the raw <pre> alone when no MBR homes are declared
        yet, with a pointer to where they get declared."""
        proj = project_case(conn, data)
        raw_details = (f"<details style='margin-top:12px'>"
                       f"<summary class=muted>Raw JSON — as the rails "
                       f"returned it</summary>"
                       f"<pre style='max-height:360px;overflow:auto'>"
                       f"{esc(raw_pretty[:40000])}</pre></details>")
        if not proj["sections"]:
            return (f"<p class=muted>No MBR homes declared yet — map "
                    f"fields to SCHEMA.TABLE.COLUMN in "
                    f"<a href='/settings?tab=map'>Settings → Field "
                    f"mappings</a> and the case will present as the MBR "
                    f"here.</p><pre style='max-height:460px;"
                    f"overflow:auto'>{esc(raw_pretty[:60000])}</pre>")
        # One schema across every section? Say it once, not per header.
        schemas = {sec["schema"] for sec in proj["sections"] if sec["schema"]}
        lone = schemas.pop() if len(schemas) == 1 else None
        parts = [
            "<div class=mbrwb>",
            f"<div class=mbrwbtop><span class=mbrwbmark>MBR</span>"
            f"<span class=mbrwbsub>the record, through the declared "
            f"mappings{' · schema ' + esc(lone) if lone else ''}</span>"
            f"<span style='flex:1'></span>"
            f"<span class=mbrwbcov>{proj['covered']} of {proj['total']} "
            f"values homed</span></div>",
            "<div class=mbrwbbody>",
            "<div class=mbrscroll>"]
        empties = []
        for sec in proj["sections"]:
            qual = (f"<span class=mbrschema>{esc(sec['schema'])}.</span>"
                    if sec["schema"] and not lone else "")
            n = len(sec["rows"])
            if not n:
                empties.append(
                    (f"{sec['schema']}." if sec["schema"] and not lone
                     else "") + sec["table"])
                continue
            if sec["root"] is None:
                tag = "master row"
                cells = "".join(
                    f"<div class=mbrfield>"
                    f"<span class=mbrcol>{esc(c['column'])}</span>"
                    f"<span class=mbrval>"
                    f"{self._mbr_cell(c['column'], c['json_path'], cell)}"
                    f"</span>"
                    f"<span class=mbrlbl>{esc(c['label'])}</span></div>"
                    for c, cell in zip(sec["columns"], sec["rows"][0]))
                body = f"<div class=mbrflex>{cells}</div>"
            else:
                tag = f"{n} occurrence{'s' if n != 1 else ''}"
                ths = "".join(
                    f"<th><span class=mbrcol>{esc(c['column'])}</span>"
                    f"<div class=mbrlbl>{esc(c['label'])}</div></th>"
                    for c in sec["columns"])
                trs = ""
                for i, row in enumerate(sec["rows"], 1):
                    tds = "".join(
                        f"<td>{self._mbr_cell(c['column'], c['json_path'], cell)}</td>"
                        for c, cell in zip(sec["columns"], row))
                    trs += f"<tr><td class=mbrocc>{i}</td>{tds}</tr>"
                body = (f"<div style='overflow-x:auto'>"
                        f"<table class=mbrgrid><tr><th class=mbrocc>#</th>"
                        f"{ths}</tr>{trs}</table></div>")
            parts.append(
                f"<div class=mbrtab><div class=mbrhead>{qual}"
                f"<b>{esc(sec['table'])}</b>"
                f"<span class=mbrtag>{esc(tag)}</span></div>{body}</div>")
        parts.append("</div>")
        if empties:
            parts.append(
                f"<p class='muted mbrempty'>Not in this pull: "
                + " · ".join(f"<span>{esc(t)}</span>" for t in empties)
                + "</p>")
        if proj["no_home"]:
            items = "".join(
                f"<li><b>{esc(x['label'])}</b> · "
                f"<code>{esc(x['json_path'])}</code></li>"
                for x in proj["no_home"])
            parts.append(
                f"<details class=mbrmore><summary>Mapped, but no MBR home "
                f"declared yet ({len(proj['no_home'])})</summary>"
                f"<ul>{items}</ul></details>")
        if proj["unmapped"]:
            items = "".join(
                f"<li><code>{esc(pth)}</code> = "
                f"{esc(mask_value(pth, str(v)))}</li>"
                for pth, v in proj["unmapped"][:40])
            more = (f"<li class=muted>… {len(proj['unmapped']) - 40} more"
                    f"</li>" if len(proj["unmapped"]) > 40 else "")
            parts.append(
                f"<details class=mbrmore><summary>Not yet mapped "
                f"({len(proj['unmapped'])}) — the mapping backlog</summary>"
                f"<ul>{items}{more}</ul></details>")
        for label, reason in proj["refused"]:
            parts.append(f"<div class=banner style='background:#231c0e;"
                         f"color:#f0b84f;border-color:#54421d'>"
                         f"{esc(label)}: {esc(reason)}</div>")
        return "".join(parts) + raw_details + "</div></div>"

    def _mbr_cell(self, column: str, json_path: str, cell: dict) -> str:
        if cell["v"] is None:
            return "<span class=mbrnull>&mdash;</span>"
        shown = str(cell["v"])
        if SENSITIVE_PARAM.search(column) or SENSITIVE_PARAM.search(json_path):
            shown = mask_value("ssn", shown)
        out = esc(shown)
        if cell["mf"] and cell["mf"] != shown:
            out += f" <span class=mbrmf>{esc(cell['mf'])}</span>"
        return out

    def _cases_token(self, conn, form):
        """The 30-minute-JWT reality: paste the fresh token where the
        work happens, keep the env/endpoint selection."""
        eid = int(form.get("env", 0) or 0)
        token = form.get("token", "").strip()
        if eid and token:
            conn.execute("UPDATE api_env SET token = ? WHERE id = ?",
                         (token, eid))
            conn.commit()
        ep = urllib.parse.quote(str(form.get("ep", "")))
        self._redirect(f"/cases?env={eid}&ep={ep}")

    def _cases_evaluate(self, conn, form):
        """Pull the case, then run that exception's recipe against it.
        The analyst arrives knowing the code, so code + params are supplied
        together and a single action answers 'why did this except out'."""
        env = conn.execute("SELECT * FROM api_env WHERE id = ?",
                           (int(form.get("env", 0) or 0),)).fetchone()
        raw = str(form.get("ep", "") or "")
        bundle = None
        ep = None
        if raw.startswith("b"):
            bundle = conn.execute("SELECT * FROM case_bundle WHERE id = ?",
                                  (int(raw[1:] or 0),)).fetchone()
        else:
            ep = conn.execute("SELECT * FROM api_endpoint WHERE id = ?",
                              (int(raw or 0),)).fetchone()
        if not env or not (ep or bundle):
            self._send("<div class=card>Unknown environment or source.</div>",
                       code=400)
            return
        params = {k[2:]: v.strip() for k, v in form.items() if k.startswith("p_")}
        notes: list[str] = []
        if bundle:
            merged, notes, ms = self.fetch_bundle(conn, env, bundle["id"], params)
            status = 200 if merged else 502
            err = None if merged else "; ".join(notes)
            text = json.dumps(merged)
            src_name = f"{bundle['name']} (bundle)"
        else:
            status, text, ms, err = self._call_api(env, ep, params,
                                                    form.get("body"))
            src_name = ep["name"]
        masked = {k: mask_value(k, v) for k, v in params.items()}
        conn.execute(
            "INSERT INTO api_call_log (env, endpoint, params, status, ms, ok, ts)"
            " VALUES (?, ?, ?, ?, ?, ?, ?)",
            (env["name"], src_name, json.dumps(masked, ensure_ascii=False),
             status, ms, 0 if err or not status or status >= 300 else 1, db.now()))
        conn.commit()

        who = ", ".join(f"{k} {v}" for k, v in masked.items())
        if err or not (status and 200 <= status < 300):
            hint = ""
            if status in (401, 403):
                exp = jwt_exp(env["token"])
                stale = (" — it expired at "
                         + time.strftime("%H:%M", time.localtime(exp))
                         if exp and exp < time.time() else "")
                hint = (f"<p class=muted style='margin-top:6px'>The "
                        f"environment's JWT was refused{stale}. Paste a "
                        f"fresh one under <b>update token</b> below and "
                        f"re-run.</p>")
            self._cases(conn, {"env": [str(env["id"])], "ep": [raw]},
                        f"<div class=card><h2>Case pull failed</h2><p>"
                        f"<span class='badge failed' style='margin-left:0'>"
                        f"{esc(err or f'HTTP {status}')}</span> "
                        f"<span class=muted>{esc(env['name'])} · {esc(who)} · "
                        f"{ms} ms</span></p>{hint}</div>")
            return
        try:
            data = json.loads(text)
        except ValueError:
            data = {}

        code = (form.get("code") or "").strip()
        if form.get("raw") or not code:
            pretty = json.dumps(data, indent=2) if data else text
            self._cases(conn, {"env": [str(env["id"])], "ep": [raw]},
                        f"<div class=card><h2>Case · {esc(who)}</h2>"
                        f"<p class=muted>{esc(env['name'])} · {ms} ms — no code "
                        f"given, so nothing was evaluated.</p>"
                        f"{self._mbr_html(conn, data, pretty)}</div>")
            return

        r = self._exc(conn, code)
        if not r:
            self._cases(conn, {"env": [str(env["id"])], "ep": [raw]},
                        f"<div class=card><h2>{esc(code)} — not in the catalog</h2>"
                        f"<p class=muted>The case was pulled, but this code isn't "
                        f"catalogued yet, so there's nothing to evaluate against. "
                        f"Ingest the source that raises it, or add it in the "
                        f"<a href='/lab'>Lab</a>.</p></div>")
            return
        db.add_event(conn, r["id"], "lookup", actor="evaluate")
        pb = conn.execute("SELECT * FROM playbook WHERE exception_id = ?",
                          (r["id"],)).fetchone()
        checks = json.loads(pb["checks"]) if pb else []
        if not checks:
            conn.commit()
            self._cases(conn, {"env": [str(env["id"])], "ep": [raw]},
                        f"<div class=card><h2>{esc(r['code'])} — no recipe yet</h2>"
                        f"<p>{esc(r['meaning'] or 'No curated meaning yet.')}</p>"
                        f"<p class=muted>The case was pulled successfully, but no "
                        f"diagnostic checks exist for this code — so ChatBIS can't "
                        f"say why it excepted out.</p>"
                        f"<a class=btnlink href='/lab?code={esc(r['normalized'])}'>"
                        f"Build a recipe in the Lab →</a></div>")
            return

        result = run_recipe(checks, data,
                            json.loads(pb["group_config"] or "{}"))
        blocks = []
        for m in result["matches"]:
            steps = "".join(f"<li>{esc(s.strip())}</li>"
                            for s in (m.get("steps") or "").split("\n") if s.strip())
            evidence = (f"<code>{esc(m['path'])}</code> = <b>{esc(m['actual'])}</b>"
                        f" · {esc(m['op'])}"
                        + (f" · {esc(m['expected'])}" if m["expected"] else ""))
            where = ""
            if m.get("group"):
                where = (f" <span class=muted>· occurrence {m['occurrence']} of "
                         f"{m['occurrences_total']}"
                         f"{' · ' + str(m['matched_count']) + ' matched' if m.get('matched_count', 0) > 1 else ''}"
                         f"</span>")
            fix = ""
            if m.get("screen") or m.get("fix_field"):
                fix = (f"<div class=muted style='margin-top:4px'>Fix on "
                       f"<b>{esc(m.get('screen') or '—')}</b>"
                       f"{' · field ' + esc(m['fix_field']) if m.get('fix_field') else ''}"
                       f"</div>")
            conf = m.get("confidence", "definitive")
            blocks.append(
                f"<div style='margin:12px 0;padding:12px 16px;"
                f"background:{'#f2f7f3' if conf == 'definitive' else '#faf7ef'};"
                f"border:1px solid {'#cfe5d6' if conf == 'definitive' else '#efe1a8'};"
                f"border-radius:10px'>"
                f"<div style='font-size:15px'><b>Cause: {esc(m['cause'])}</b>"
                f"{'' if conf == 'definitive' else ' <span class=badge alert>likely</span>'}"
                f"{where}</div>"
                f"<div class=muted style='margin:4px 0 8px'>{evidence}</div>{fix}"
                f"{('<ol style=margin:6px_0_0>' + steps + '</ol>') if steps else ''}</div>")
        if not result["matches"]:
            fallback = "".join(f"<li>{esc(s.strip())}</li>" for s in
                               ((pb["general_steps"] or "").split("\n")) if s.strip())
            blocks.append(
                "<div class=banner style='background:#fdf6dd;color:#7a5d05;"
                "border-color:#efe1a8'>No diagnostic matched this case — the "
                "recipe ran but none of its checks fired. Either the cause is "
                "one not yet covered, or the case is healthy for this code."
                "</div>" + (f"<ol>{fallback}</ol>" if fallback else ""))
        errs = ("<p class=muted>" + " · ".join(esc(e) for e in result["errors"])
                + "</p>") if result["errors"] else ""
        db.add_event(conn, r["id"], "triage",
                     outcome="matched" if result["matches"] else "no_match",
                     payload={"params": masked,
                              "causes": [m["cause"] for m in result["matches"]]},
                     actor="evaluate")
        conn.commit()
        pretty = json.dumps(data, indent=2) if data else text
        self._cases(conn, {"env": [str(env["id"])], "ep": [raw]},
                    f"<div class=card><h2>{esc(r['code'])} · {esc(who)}</h2>"
                    f"<p style='font-size:15px;margin-top:-4px'>"
                    f"{esc(r['meaning'] or '')}</p>"
                    f"<p class=muted>{result['evaluated']} checks evaluated · "
                    f"{len(result['matches'])} matched · {esc(env['name'])} · "
                    f"{ms} ms</p>{''.join(blocks)}{errs}"
                    f"<details style='margin-top:8px'><summary class=muted>"
                    f"The case as the MBR</summary>"
                    f"<div style='margin-top:8px'>"
                    f"{self._mbr_html(conn, data, pretty)}</div></details>"
                    f"<p style='margin:12px 0 0'>"
                    f"<a href='/x/{esc(r['normalized'])}'>Open {esc(r['code'])} "
                    f"in the catalog</a> · "
                    f"<a href='/lab?code={esc(r['normalized'])}'>Refine in Lab</a>"
                    f"</p></div>")

    def _cases_sql(self, conn, form):
        src = conn.execute("SELECT * FROM db_source WHERE id = ?",
                           (int(form.get("src", 0) or 0),)).fetchone()
        if not src:
            self._send("<div class=card>Unknown database source.</div>", code=400)
            return
        qid = form.get("query_id", "")
        dq = (conn.execute("SELECT * FROM db_query WHERE id = ?",
                           (int(qid),)).fetchone() if qid.isdigit() else None)
        sql = dq["sql"] if dq else form.get("sql", "")
        params = {k[2:]: v.strip() for k, v in form.items() if k.startswith("p_")}
        result = run_db_query(src["driver"], src["dsn"], sql, params)
        masked = {k: mask_value(k, v) for k, v in params.items()}
        qname = dq["name"] if dq else "ad-hoc SQL"
        conn.execute(
            "INSERT INTO api_call_log (env, endpoint, params, status, ms, ok, ts)"
            " VALUES (?, ?, ?, ?, ?, ?, ?)",
            (f"DB:{src['name']}", qname, json.dumps(masked, ensure_ascii=False),
             None if result["error"] else 200, result["ms"],
             0 if result["error"] else 1, db.now()))
        conn.commit()

        if result["error"]:
            body_html = (f"<p><span class='badge failed' style='margin-left:0'>error"
                         f"</span> <span style='color:var(--red)'>"
                         f"{esc(result['error'])}</span></p>")
            chips = ""
        else:
            cols = result["columns"]
            sensitive = [bool(SENSITIVE_PARAM.search(c or "")) for c in cols]
            # The MBR speaks: if the query reads a table the field map
            # declares, name the section the way the analyst knows it and
            # caption columns with their plain-language labels.
            m_from = re.search(r"\bFROM\s+([A-Za-z0-9_.\$#@]+)", sql, re.I)
            from_ref = (m_from.group(1) if m_from else "").upper()
            labels = {}
            mbr_title = ""
            if from_ref:
                want_tbl = from_ref.split(".")[-1]
                for fm in conn.execute(
                        "SELECT label, db2_column FROM field_map"
                        " WHERE db2_column IS NOT NULL").fetchall():
                    parts = (fm["db2_column"] or "").upper().split(".")
                    if len(parts) >= 2 and parts[-2] == want_tbl:
                        labels[parts[-1]] = fm["label"]
                if labels:
                    n = len(result["rows"])
                    mbr_title = (f"<div class=mbrhead style='margin:2px 0 8px'>"
                                 f"<b>{esc(from_ref)}</b><span class=mbrtag>"
                                 f"MBR table · {n} occurrence"
                                 f"{'s' if n != 1 else ''}</span></div>")
            head = "".join(
                f"<th>{esc(c)}"
                + (f"<div class=mbrlbl>{esc(labels[c.upper()])}</div>"
                   if labels.get((c or '').upper()) else "")
                + "</th>" for c in cols)
            rows_html = ""
            for row in result["rows"]:
                cells = "".join(
                    f"<td>{esc(mask_value(cols[i], v) if sensitive[i] else v)}</td>"
                    for i, v in enumerate(row))
                rows_html += f"<tr>{cells}</tr>"
            trunc = (f" · first 200 rows shown" if result["truncated"] else "")
            body_html = (f"<p class=muted>{len(result['rows'])} rows · "
                         f"{result['ms']} ms{trunc}</p>{mbr_title}"
                         f"<div style='overflow-x:auto'><table><tr>{head}</tr>"
                         f"{rows_html}</table></div>")
            known = {r["normalized"]: r["code"] for r in
                     conn.execute("SELECT normalized, code FROM exception_code")}
            blob = " ".join(" ".join(row) for row in result["rows"])
            found = [n for n in find_code_mentions(blob, known) if n in known]
            chips = ""
            if found:
                marks = ",".join("?" * len(found))
                crows = conn.execute(
                    f"SELECT code, normalized, category FROM exception_code"
                    f" WHERE normalized IN ({marks}) ORDER BY code",
                    tuple(found)).fetchall()
                chip_html = "".join(
                    f"<a class=codechip href='/x/{esc(c['normalized'])}'>"
                    f"<span class='dot d-{esc(c['category'])}' style='margin-right:0'>"
                    f"</span>{esc(c['code'])}</a>" for c in crows)
                chips = (f"<div style='margin-top:12px'><h2>Exception codes in these "
                         f"results</h2>{chip_html}</div>")
        result_card = (f"<div class=card><h2>{esc(src['name'])} · {esc(qname)}</h2>"
                       f"{body_html}{chips}</div>")
        self._cases(conn, {"src": [str(src["id"])],
                           "dq": [qid or "adhoc"]}, result_card)

    def _cases_run(self, conn, form):
        env = conn.execute("SELECT * FROM api_env WHERE id = ?",
                           (int(form.get("env", 0)),)).fetchone()
        ep = conn.execute("SELECT * FROM api_endpoint WHERE id = ?",
                          (int(form.get("ep", 0)),)).fetchone()
        if not env or not ep:
            self._send("<div class=card>Unknown environment or endpoint.</div>", code=400)
            return
        params = {k[2:]: v.strip() for k, v in form.items() if k.startswith("p_")}
        path = ep["path"]
        for name, value in params.items():
            path = path.replace("{%s}" % name, urllib.parse.quote(value, safe=""))
        url = env["base_url"].rstrip("/") + path
        req_body = None
        req_body_text = ""
        # The analyst's edited body wins over the stored template.
        body_template = (form.get("body", "").strip() or ep["body"] or "") \
            if ep["method"] == "POST" else ""
        if body_template:
            btxt = body_template
            for name, value in params.items():
                btxt = btxt.replace("{%s}" % name, json.dumps(value)[1:-1])
            try:
                req_body_text = json.dumps(json.loads(btxt), indent=2)
            except ValueError as e:
                self._cases(conn, {"env": [str(env["id"])], "ep": [raw]},
                            f"<div class=card><h2>Request not sent</h2>"
                            f"<p><span class='badge failed' style='margin-left:0'>"
                            f"invalid JSON</span> <span class=muted>{esc(e)}</span></p>"
                            f"<pre>{esc(btxt[:4000])}</pre></div>")
                return
            req_body = req_body_text.encode()

        headers = {"Accept": "application/json"}
        if env["token"]:
            headers["Authorization"] = f"Bearer {env['token']}"
        if req_body:
            headers["Content-Type"] = "application/json"
        ctx = ssl._create_unverified_context() if env["insecure_tls"] else None

        started = time.perf_counter()
        status, resp_text, err = None, "", None
        try:
            req = urllib.request.Request(url, data=req_body, headers=headers,
                                         method=ep["method"])
            with urllib.request.urlopen(req, timeout=20, context=ctx) as resp:
                status = resp.status
                resp_text = resp.read(1_000_000).decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            status = e.code
            resp_text = e.read(1_000_000).decode("utf-8", "replace")
        except Exception as e:  # DNS, refused, TLS, timeout
            err = str(e)
        ms = int((time.perf_counter() - started) * 1000)

        masked = {k: mask_value(k, v) for k, v in params.items()}
        ok = 1 if (status and 200 <= status < 300) else 0
        conn.execute(
            "INSERT INTO api_call_log (env, endpoint, params, status, ms, ok, ts)"
            " VALUES (?, ?, ?, ?, ?, ?, ?)",
            (env["name"], ep["name"], json.dumps(masked, ensure_ascii=False),
             status, ms, ok, db.now()))
        conn.commit()

        # Masked views only: sensitive values and the token never render.
        shown_url = url
        shown_body = req_body_text
        for name, value in params.items():
            mv = mask_value(name, value)
            if mv != value:
                shown_url = shown_url.replace(urllib.parse.quote(value, safe=""), mv)
                if shown_body:
                    shown_body = shown_body.replace(json.dumps(value)[1:-1], mv)
        req_lines = [f"{ep['method']} {shown_url}", "Accept: application/json"]
        if env["token"]:
            req_lines.append("Authorization: Bearer •••")
        if req_body:
            req_lines.append("Content-Type: application/json")
        req_pane = (f"<pre style='max-height:480px;overflow:auto'>"
                    f"{esc(chr(10).join(req_lines))}"
                    f"{esc(chr(10) + chr(10) + shown_body) if shown_body else ''}</pre>")

        if err:
            verdict = f"<span class='badge failed' style='margin-left:0'>failed</span>"
            body_html = f"<p style='color:var(--red)'>{esc(err)}</p>"
        else:
            cls = "resolved" if ok else "failed"
            verdict = f"<span class='badge {cls}' style='margin-left:0'>HTTP {status}</span>"
            try:
                pretty = json.dumps(json.loads(resp_text), indent=2)
            except ValueError:
                pretty = resp_text
            body_html = f"<pre style='max-height:480px;overflow:auto'>{esc(pretty[:60000])}</pre>"

        # The triage hook: known catalog codes inside the case data become
        # entry points to their resolution pages.
        chips = ""
        if resp_text:
            known = {r["normalized"]: r["code"] for r in
                     conn.execute("SELECT normalized, code FROM exception_code")}
            found = [n for n in find_code_mentions(resp_text, known) if n in known]
            if found:
                rows = conn.execute(
                    f"SELECT code, normalized, category FROM exception_code"
                    f" WHERE normalized IN ({','.join('?' * len(found))})"
                    f" ORDER BY code", tuple(found)).fetchall()
                chip_html = "".join(
                    f"<a class=codechip href='/x/{esc(c['normalized'])}'>"
                    f"<span class='dot d-{esc(c['category'])}' style='margin-right:0'></span>"
                    f"{esc(c['code'])}</a>" for c in rows)
                chips = (f"<div style='margin-top:14px'><h2>Exception codes in this "
                         f"case</h2>{chip_html}</div>")

        result = (f"<div class=card><h2>{esc(env['name'])} · {esc(ep['name'])}</h2>"
                  f"<p>{verdict} <span class=muted>{ms} ms</span></p>"
                  f"<div class=reqres>"
                  f"<div><div class=panehead>Request</div>{req_pane}</div>"
                  f"<div><div class=panehead>Response</div>{body_html}</div>"
                  f"</div>{chips}</div>")
        self._cases(conn, {"env": [str(env["id"])], "ep": [raw]}, result)

    # ── The Lab: recipe workbench ──────────────────────────────────────
    # Author checks against a REAL failing case with live FIRES/quiet
    # feedback, evidence in the same view. Case data is SESSION-ONLY —
    # chatbis.db never holds it (docs/agent-architecture.md §3c).
    # ── Lab index: every recipe, ranked by how much it would matter ───
    def _lab_index(self, conn, banner: str = ""):
        rows = conn.execute("""
            SELECT e.id, e.code, e.normalized, e.category, e.meaning,
                   p.checks, p.group_config, p.general_steps,
                   p.updated_by, p.updated_at
            FROM playbook p JOIN exception_code e ON e.id = p.exception_id
            ORDER BY e.code""").fetchall()
        vol = {r["exception_id"]: r["n"] for r in conn.execute(
            """SELECT exception_id, SUM(CAST(json_extract(payload,'$.count')
               AS INTEGER)) AS n FROM exception_event WHERE kind='mi'
               GROUP BY exception_id""")}
        n_codes = conn.execute("SELECT COUNT(*) FROM exception_code").fetchone()[0]

        parts = [banner,
                 f"<div class=card><div class=cardhead><h1>Recipes</h1>"
                 f"<a class=btn href='/lab/new'>+ New recipe</a></div>"
                 f"<p class=muted style='margin-top:-2px'>A recipe turns an "
                 f"exception code into an answer: which fields to check, what "
                 f"each mismatch means, and how to fix it. "
                 f"{len(rows)} of {n_codes} catalogued codes have one.</p></div>"]

        if not rows:
            parts.append(
                "<div class=card style='text-align:center;padding:44px 24px'>"
                "<div style='font-size:34px;margin-bottom:8px'>&#9881;</div>"
                "<h3 style='margin:0 0 6px;font-size:17px'>No recipes yet</h3>"
                "<p class=muted style='max-width:430px;margin:0 auto 18px'>"
                "Start with the codes that fail most — the new-recipe screen "
                "ranks them by volume and tells you how much can be drafted "
                "straight from the mined source.</p>"
                "<a class=btn href='/lab/new'>+ New recipe</a></div>")
            self._send("".join(parts), "Recipes")
            return

        # Ranked by MI volume: the recipe that covers the most failures first.
        ranked = sorted(rows, key=lambda r: (-vol.get(r["id"], 0), r["code"]))
        mx = max((vol.get(r["id"], 0) for r in ranked), default=0)
        body = ""
        for r in ranked:
            checks = json.loads(r["checks"]) if r["checks"] else []
            groups = sorted({c["group"] for c in checks if c.get("group")})
            auto = sum(1 for c in checks if (c.get("path") or "").strip()
                       and c.get("kind") != "manual")
            n = vol.get(r["id"], 0)
            volcell = (f"<div class=abar>{bar(100 * n / mx)}<b>{n}</b></div>"
                       if mx and n else "<span class=muted>—</span>")
            gtxt = (" · ".join(esc(g) for g in groups[:2])
                    + (f" +{len(groups) - 2}" if len(groups) > 2 else "")
                    ) if groups else "<span class=muted>—</span>"
            when = esc((r["updated_at"] or "")[:10])
            who = esc(r["updated_by"] or "")
            body += (
                f"<tr><td style='white-space:nowrap'>"
                f"<span class='dot d-{esc(r['category'])}'></span>"
                f"<a href='/lab/edit?code={esc(r['normalized'])}'>"
                f"<b>{esc(r['code'])}</b></a></td>"
                f"<td>{esc((r['meaning'] or '')[:70]) or '<span class=muted>—</span>'}</td>"
                f"<td class=num>{auto}{'' if auto == len(checks) else f' <span class=muted>of {len(checks)}</span>'}</td>"
                f"<td>{gtxt}</td>"
                f"<td class=num>{volcell}</td>"
                f"<td style='white-space:nowrap'><span class=muted>{when}"
                f"{' · ' + who if who else ''}</span></td>"
                f"<td style='white-space:nowrap;text-align:right'>"
                f"<a class=btnsm href='/lab/edit?code={esc(r['normalized'])}'>Modify</a>"
                f"<form method=post action='/lab/delete' style='display:inline'>"
                f"<input type=hidden name=code value='{esc(r['normalized'])}'>"
                f"<button class=delbtn>Delete</button></form></td></tr>")
        parts.append(
            f"<div class=card><table><tr><th>Code</th><th>Meaning</th>"
            f"<th class=num>Checks</th><th>Repeating groups</th>"
            f"<th class=num>Volume</th><th>Updated</th><th></th></tr>"
            f"{body}</table>"
            f"<p class=muted style='margin:14px 0 0'>Ordered by exception volume "
            f"from the imported MI — the recipe at the top covers the most "
            f"failing cases. <b>Checks</b> counts the ones evaluated "
            f"automatically; manual steps are excluded.</p></div>")
        self._send("".join(parts), "Recipes")

    # ── New recipe: pick the code, see what can be drafted ────────────
    def _lab_new(self, conn, qs, banner: str = ""):
        q = (qs or {}).get("q", [""])[0].strip()
        sql = ("SELECT e.* FROM exception_code e WHERE e.id NOT IN"
               " (SELECT exception_id FROM playbook)")
        args: list = []
        if q:
            sql += " AND (e.code LIKE ? OR e.normalized LIKE ? OR e.meaning LIKE ?)"
            args += [f"%{q}%", f"%{q}%", f"%{q}%"]
        codes = conn.execute(sql + " ORDER BY e.code", args).fetchall()
        vol = {r["exception_id"]: r["n"] for r in conn.execute(
            """SELECT exception_id, SUM(CAST(json_extract(payload,'$.count')
               AS INTEGER)) AS n FROM exception_event WHERE kind='mi'
               GROUP BY exception_id""")}
        fmap = [dict(x) for x in conn.execute(
            "SELECT cobol_field, json_path, label FROM field_map"
            " WHERE cobol_field IS NOT NULL AND json_path IS NOT NULL")]

        parts = [crumbs(("Recipes", "/lab"), here="New recipe"), banner,
                 f"<div class=card><h1>New recipe</h1>"
                 f"<p class=muted style='margin-top:-2px'>Pick the exception "
                 f"code this recipe explains. Codes are ranked by volume, so "
                 f"the one that fails most is first.</p>"
                 f"<form method=get action='/lab/new' style='margin-top:14px'>"
                 f"<input type=text name=q value='{esc(q)}' style='max-width:300px'"
                 f" placeholder='Filter by code or meaning'>"
                 f"<button>Filter</button>"
                 f"{' <a href=/lab/new>clear</a>' if q else ''}</form></div>"]

        if not codes:
            parts.append(
                f"<div class=card><p class=muted style='margin:0'>"
                f"{'No catalogued code matches “' + esc(q) + '”.' if q else
                   'Every catalogued code already has a recipe.'} "
                f"<a href='/lab'>Back to recipes</a></p></div>")
            self._send("".join(parts), "New recipe")
            return

        counts = {r["id"]: self._draft_counts(conn, r["id"], fmap) for r in codes}
        # Volume first, then how much of the recipe writes itself — a code we
        # can pre-draft is cheaper to add than one starting from nothing.
        ranked = sorted(codes, key=lambda r: (-vol.get(r["id"], 0),
                                              -counts[r["id"]][0], r["code"]))
        body = ""
        for r in ranked[:100]:
            n_draft, n_blocked = counts[r["id"]]
            n = vol.get(r["id"], 0)
            if n_draft:
                btn = (f"<button>Start with {n_draft} drafted "
                       f"check{'s' if n_draft != 1 else ''}</button>")
                hint = (f"<span style='color:#1e6b3d;font-weight:600'>"
                        f"{n_draft} draftable</span>"
                        + (f" <span class=muted>· {n_blocked} can't be "
                           f"translated</span>" if n_blocked else ""))
            else:
                btn = "<button>Start recipe</button>"
                # Silence for codes with no mined conditions at all — saying
                # "nothing draftable" on every row is noise, not information.
                hint = (f"<span class=muted>{n_blocked} mined condition"
                        f"{'s' if n_blocked != 1 else ''}, none translatable"
                        f"</span>" if n_blocked else "")
            body += (
                f"<tr><td style='white-space:nowrap'>"
                f"<span class='dot d-{esc(r['category'])}'></span>"
                f"<a href='/x/{esc(r['normalized'])}'><b>{esc(r['code'])}</b></a></td>"
                f"<td>{esc((r['meaning'] or '')[:60]) or '<span class=muted>—</span>'}"
                f"{f'<div style=\'font-size:12px;margin-top:2px\'>{hint}</div>' if hint else ''}</td>"
                f"<td class=num>{n if n else '<span class=muted>—</span>'}</td>"
                f"<td style='text-align:right;white-space:nowrap'>"
                f"<form method=post action='/lab/create' style='display:inline'>"
                f"<input type=hidden name=code value='{esc(r['normalized'])}'>"
                f"<input type=hidden name=seed value='{n_draft}'>{btn}</form></td>"
                f"</tr>")
        more = (f"<p class=muted style='margin:14px 0 0'>Showing 100 of "
                f"{len(ranked)} — filter to narrow.</p>" if len(ranked) > 100 else "")
        parts.append(
            f"<div class=card><table><tr><th>Code</th><th>Meaning</th>"
            f"<th class=num>Volume</th><th></th></tr>{body}</table>{more}"
            f"<p class=muted style='margin:14px 0 0'>Drafted checks come from "
            f"mined COBOL conditions joined to your field mappings. They save "
            f"as <b>likely</b> — proposals you confirm, edit or remove in the "
            f"Lab.</p></div>")
        self._send("".join(parts), "New recipe")

    def _draft_counts(self, conn, exc_id: int, fmap: list) -> tuple:
        """(draftable, blocked) for a code — how much of the recipe writes
        itself. Cheap enough to run per row on the new-recipe screen."""
        conds = []
        for l in conn.execute(
                "SELECT target_ref, detail FROM exception_link WHERE exception_id = ?"
                " AND relation IN ('emitted_by','raised_by')", (exc_id,)):
            d = json.loads(l["detail"])
            if d.get("condition"):
                conds.append({"condition": d["condition"], "program": l["target_ref"],
                              "file": d.get("file", ""), "line": d.get("line")})
        if not conds:
            return 0, 0
        drafts = draft_checks(conds, fmap)
        return (sum(1 for d in drafts if d["check"]),
                sum(1 for d in drafts if not d["check"]))

    def _lab_create(self, conn, form):
        """Create the recipe row, optionally pre-filled with source drafts."""
        r = self._exc(conn, form.get("code", ""))
        if not r:
            self._send("<div class=card>Unknown code.</div>", code=404)
            return
        if conn.execute("SELECT 1 FROM playbook WHERE exception_id = ?",
                        (r["id"],)).fetchone():
            self._redirect(f"/lab/edit?code={urllib.parse.quote(r['normalized'])}")
            return
        checks = []
        if (form.get("seed") or "0") != "0":
            fmap = [dict(x) for x in conn.execute(
                "SELECT cobol_field, json_path, label FROM field_map"
                " WHERE cobol_field IS NOT NULL AND json_path IS NOT NULL")]
            conds = []
            for l in conn.execute(
                    "SELECT target_ref, detail FROM exception_link"
                    " WHERE exception_id = ? AND relation IN ('emitted_by','raised_by')",
                    (r["id"],)):
                d = json.loads(l["detail"])
                if d.get("condition"):
                    conds.append({"condition": d["condition"],
                                  "program": l["target_ref"],
                                  "file": d.get("file", ""), "line": d.get("line")})
            checks = [d["check"] for d in draft_checks(conds, fmap) if d["check"]]
        conn.execute(
            """INSERT INTO playbook (exception_id, general_steps, checks,
               group_config, updated_by, updated_at)
               VALUES (?, NULL, ?, '{}', ?, ?)""",
            (r["id"], json.dumps(checks), "new", db.now()))
        db.add_event(conn, r["id"], "edit",
                     payload={"via": "lab-create", "seeded": len(checks)},
                     actor="analyst")
        conn.commit()
        seeded = (f" — {len(checks)} check{'s' if len(checks) != 1 else ''} drafted "
                  f"from source, marked <b>likely</b>. Confirm each, add the "
                  f"cause and steps, then save." if checks else
                  " — pull a failing case, then click its fields to build checks.")
        self._lab_edit(conn, {"code": [r["normalized"]]},
                       f"<div class=banner>Recipe created for "
                       f"{esc(r['code'])}{seeded}</div>")

    def _lab_delete(self, conn, form):
        """Two-step delete: authored work is never one click from gone."""
        r = self._exc(conn, form.get("code", ""))
        if not r:
            self._send("<div class=card>Unknown code.</div>", code=404)
            return
        pb = conn.execute("SELECT * FROM playbook WHERE exception_id = ?",
                          (r["id"],)).fetchone()
        if not pb:
            self._lab_index(conn, "<div class=banner>That recipe no longer "
                                  "exists.</div>")
            return
        checks = json.loads(pb["checks"]) if pb["checks"] else []
        if form.get("confirm") != "1":
            listing = "".join(
                f"<li>{readback(c)}"
                f"{' &rarr; <b>' + esc(c['cause']) + '</b>' if c.get('cause') else ''}"
                f"</li>" for c in checks if c.get("path"))
            fixtures = conn.execute(
                "SELECT COUNT(*) FROM playbook_test_case WHERE exception_id = ?",
                (r["id"],)).fetchone()[0]
            self._send(
                f"{crumbs(('Recipes', '/lab'), here='Delete recipe')}"
                f"<div class=card><h1>Delete the recipe for {esc(r['code'])}?</h1>"
                f"<p class=muted style='margin-top:-2px'>This removes the "
                f"authored checks and resolution steps. The exception code, its "
                f"mined source links and its MI history are untouched.</p>"
                f"<div class='banner' style='background:#fbeeee;color:#a63838;"
                f"border-color:#e7c3c3'>You would lose "
                f"<b>{len(checks)} check{'s' if len(checks) != 1 else ''}</b>"
                f"{f' and {fixtures} pinned fixture' + ('s' if fixtures != 1 else '') if fixtures else ''}."
                f"</div>"
                f"{'<ul class=readback>' + listing + '</ul>' if listing else ''}"
                f"<form method=post action='/lab/delete' style='margin-top:8px'>"
                f"<input type=hidden name=code value='{esc(r['normalized'])}'>"
                f"<input type=hidden name=confirm value='1'>"
                f"<button style='background:#a63838;border-color:#a63838'>"
                f"Delete recipe</button> "
                f"<a href='/lab/edit?code={esc(r['normalized'])}'>Cancel</a>"
                f"</form></div>", f"Delete {r['code']}")
            return
        conn.execute("DELETE FROM playbook WHERE exception_id = ?", (r["id"],))
        conn.execute("DELETE FROM playbook_test_case WHERE exception_id = ?",
                     (r["id"],))
        db.add_event(conn, r["id"], "edit",
                     payload={"via": "lab-delete", "checks": len(checks)},
                     actor="analyst")
        conn.commit()
        self._lab_cases.pop(r["id"], None)     # drop the in-memory case too
        self._lab_index(conn, f"<div class=banner>Recipe for {esc(r['code'])} "
                              f"deleted — {len(checks)} check"
                              f"{'s' if len(checks) != 1 else ''} removed.</div>")

    def _lab_verdict(self, checks, case, gcfg) -> str:
        """The one sentence the Lab exists to produce, stated up front."""
        if case is None:
            return ("<div class='verdict vnone'><span class=vlabel>NO CASE</span>"
                    "<div><b>Pull a failing case to evaluate</b><div class=vsub>"
                    "Checks cannot be verified without data.</div></div></div>")
        if not checks:
            return ("<div class='verdict vnone'><span class=vlabel>NO CHECKS</span>"
                    "<div><b>No recipe yet</b><div class=vsub>Accept a draft or "
                    "click a field below to author the first check.</div></div></div>")
        out = run_recipe(checks, case, gcfg)
        if out["matches"]:
            m = out["matches"][0]
            more = (f" · +{len(out['matches']) - 1} more cause"
                    f"{'s' if len(out['matches']) > 2 else ''}"
                    if len(out["matches"]) > 1 else "")
            ev = f"{m['path']} = {m['actual']} · {m['op']}"
            if m["expected"]:
                ev += f" · {m['expected']}"
            fix = ""
            if m["fix_field"] or m["screen"]:
                fix = (f"<div style='margin-left:auto;text-align:right;font-size:13px;"
                       f"white-space:nowrap;padding-left:18px'>"
                       f"fix <b>{esc(m['fix_field'] or '—')}</b>"
                       f"{'<div class=vsub>screen ' + esc(m['screen']) + '</div>' if m['screen'] else ''}"
                       f"</div>")
            return (f"<div class='verdict vgood'><span class=vlabel>EXPLAINED</span>"
                    f"<div><b>{esc(m['cause'])}</b>"
                    f"<div class=vsub>{esc(ev)}{esc(more)}</div></div>{fix}</div>")
        if out["errors"]:
            return (f"<div class='verdict vbad'><span class=vlabel>CHECK ERROR</span>"
                    f"<div><b>A check could not be evaluated</b>"
                    f"<div class=vsub>{esc(out['errors'][0])}</div></div></div>")
        return (f"<div class='verdict vwarn'><span class=vlabel>NOT EXPLAINED</span>"
                f"<div><b>No check fires on this case</b><div class=vsub>"
                f"{out['evaluated']} check{'s' if out['evaluated'] != 1 else ''} "
                f"evaluated — the recipe does not yet cover this failure.</div>"
                f"</div></div>")

    def _lab_drafts(self, conn, exc_id, checks) -> str:
        """Pre-draft the recipe from mined COBOL conditions joined to the field
        map. The analyst confirms rather than composes — and anything we cannot
        translate faithfully is shown as blocked, never guessed."""
        conds = []
        for l in conn.execute(
                "SELECT target_ref, detail FROM exception_link WHERE exception_id = ?"
                " AND relation IN ('emitted_by','raised_by')", (exc_id,)):
            d = json.loads(l["detail"])
            if d.get("condition"):
                conds.append({"condition": d["condition"], "program": l["target_ref"],
                              "file": d.get("file", ""), "line": d.get("line")})
        if not conds:
            return ""
        fmap = [dict(x) for x in conn.execute(
            "SELECT cobol_field, json_path, label FROM field_map"
            " WHERE cobol_field IS NOT NULL AND json_path IS NOT NULL")]
        drafts = draft_checks(conds, fmap)
        def key(c):
            # `$.x` and `$$.x` are the same reference outside a group, so a
            # hand-authored check must suppress the equivalent draft.
            v = (c.get("value") or "").strip()
            if not c.get("group") and v.startswith("$.") and not v.startswith("$$."):
                v = "$$." + v[2:]
            return (c.get("path"), c.get("op"), v)

        have = {key(c) for c in checks}
        live = [d for d in drafts if d["check"] and key(d["check"]) not in have]
        blocked = [d for d in drafts if not d["check"]]
        if not live and not blocked:
            return ""

        html_ = []
        for d in live:
            c = d["check"]
            p = d["provenance"]
            where = esc(p.get("program") or "")
            if p.get("line"):
                where += f" line {p['line']}"
            html_.append(
                f"<div class=draft><div class=readback>{esc(d['why'])}</div>"
                f"<div class=prov>from <b>{where}</b> · "
                f"<code class=cond style='color:#8a6410'>{esc(p.get('condition',''))}</code>"
                f"</div>"
                f"<form method=post action='/lab/draft' style='margin-top:9px'>"
                f"<input type=hidden name=code value='{esc(self._lab_code)}'>"
                f"<input type=hidden name=payload value='{esc(json.dumps(c))}'>"
                f"<button>Accept as check</button></form></div>")
        for d in blocked:
            need = d.get("needs_mapping")
            fix = (f" — <a href='/settings?tab=fields'>add a mapping for "
                   f"{esc(need)}</a>" if need else "")
            html_.append(
                f"<div class='draft dead'><div class=readback style='color:var(--muted)'>"
                f"<code class=cond style='color:#64748b'>"
                f"{esc(d['provenance'].get('condition',''))}</code></div>"
                f"<div class=prov>can't draft: {esc(d['blocked'])}{fix}</div></div>")
        n = len(live)
        return (f"<div class=card><h2>Drafted from source — {n} ready to confirm</h2>"
                f"{''.join(html_)}<p class=muted style='margin-bottom:0'>Drafts are "
                f"proposals: they save as <b>likely</b>, and you add the cause and "
                f"resolution steps. Nothing is guessed — a condition we can't "
                f"translate is listed as blocked.</p></div>")

    _lab_cases: dict = {}          # {exception_id: case json} — in memory only
    _lab_code: str = ""            # normalized code being edited (for draft forms)

    def _lab_edit(self, conn, qs, banner: str = ""):
        codes = conn.execute(
            "SELECT e.id, e.code, e.normalized, e.category, e.meaning"
            " FROM exception_code e JOIN playbook p ON p.exception_id = e.id"
            " ORDER BY e.code").fetchall()
        sel = (qs or {}).get("code", [""])[0]
        if sel and not any(c["normalized"] == db.normalize_code(sel) for c in codes):
            # Deep link to a code with no recipe yet: let it be authored anyway.
            extra = self._exc(conn, sel)
            if extra:
                codes = list(codes) + [extra]
        r = (self._exc(conn, sel) if sel else None) or (codes[0] if codes else None)
        if not r:
            self._redirect("/lab")
            return
        exc_id = r["id"]
        self._lab_code = r["normalized"]
        pb = conn.execute("SELECT * FROM playbook WHERE exception_id = ?",
                          (exc_id,)).fetchone()
        checks = json.loads(pb["checks"]) if pb else []
        gcfg = json.loads(pb["group_config"]) if pb and pb["group_config"] else {}
        case = self._lab_cases.get(exc_id)
        envs = conn.execute("SELECT * FROM api_env ORDER BY name").fetchall()
        eps = conn.execute("SELECT * FROM api_endpoint ORDER BY name").fetchall()

        code_opts = "".join(
            f"<option value='{esc(c['normalized'])}'"
            f"{' selected' if c['id'] == exc_id else ''}>{esc(c['code'])}"
            f"{' — ' + esc((c['meaning'] or '')[:40]) if c['meaning'] else ''}"
            f"</option>" for c in codes)
        parts = [crumbs(("Recipes", "/lab"), here=f"Lab · {r['code']}"), banner,
                 f"<div class=card><div class=cardhead><h1>Lab</h1>"
                 f"<form method=get action='/lab/edit'>"
                 f"<select name=code onchange='this.form.submit()' "
                 f"style='max-width:420px'>{code_opts}</select></form></div>"
                 f"<p class=muted style='margin-top:-2px'>Author checks against a "
                 f"real failing case. Case data stays in memory — never written "
                 f"to disk.</p>"
                 f"<form method=post action='/lab/delete' style='margin-top:10px'>"
                 f"<input type=hidden name=code value='{esc(r['normalized'])}'>"
                 f"<button class=delbtn style='padding-left:0'>Delete this recipe"
                 f"</button></form></div>",
                 self._lab_verdict(checks, case, gcfg),
                 self._pipeline_strip(conn, exc_id)]

        # ── 1 · the case, and the case as the picker ───────────────────
        if envs and eps:
            ep_opts = "".join(
                f"<option value={e['id']}"
                f"{' selected' if pb and pb['endpoint_id'] == e['id'] else ''}>"
                f"{esc(e['name'])}</option>" for e in eps)
            env_opts = "".join(f"<option value={e['id']}>{esc(e['name'])}</option>"
                               for e in envs)
            ep_row = next((e for e in eps if pb and pb["endpoint_id"] == e["id"]),
                          eps[0])
            phs = list(dict.fromkeys(RE_PLACEHOLDER.findall(
                ep_row["path"] + (ep_row["body"] or ""))))
            fields = "".join(
                f"<input type=text name='p_{esc(p)}' placeholder='{esc(p)}'"
                f" style='max-width:150px' required>" for p in phs)
            pull = (f"<form method=post action='/lab/pull' style='display:flex;gap:10px;"
                    f"flex-wrap:wrap;align-items:flex-start'>"
                    f"<input type=hidden name=code value='{esc(r['normalized'])}'>"
                    f"<select name=env style='max-width:130px'>{env_opts}</select>"
                    f"<select name=endpoint_id style='max-width:200px'>{ep_opts}</select>"
                    f"{fields}<button>Pull</button></form>")
        else:
            pull = ("<div class=banner style='background:#fdf6dd;color:#7a5d05;"
                    "border-color:#efe1a8;margin:0'>Add an environment and endpoint "
                    "in <a href='/settings?tab=api'>Settings</a> to pull live cases."
                    "</div>")

        if case:
            entries = walk_paths(case)
            tree, seen_grp = [], None
            if entries and entries[0]["kind"] != "group":
                tree.append("<div class=tgrp>case level</div>")
            for e in entries:
                if e["kind"] == "group":
                    seen_grp = e["path"]
                    cfg = gcfg.get(e["path"], {})
                    idx, _ = pick_latest(occurrences(case, e["path"]),
                                         cfg.get("order_by", ""),
                                         cfg.get("latest_is", "max_start"))
                    warn = ("" if cfg.get("order_by") else
                            " · <span style='color:#8a6410'>⚠ order_by not set</span>")
                    tree.append(f"<div class=tgrp>↻ {esc(e['path'])} — "
                                f"{e['count']} occurrences · latest = #{idx}{warn}</div>")
                    continue
                if not e["group"] and seen_grp:
                    seen_grp = None
                    tree.append("<div class=tgrp>case level</div>")
                v = e["value"]
                tree.append(
                    f"<button type=button class=fpick data-g=\"{esc(e['group'])}\" "
                    f"data-p=\"{esc(e['field'])}\">"
                    f"<span class=fp>{esc(e['field'])}</span>"
                    f"<span class=fv>{esc(v[:60])}</span></button>")
            case_pane = (f"<div class=tree>{''.join(tree)}</div>"
                         f"<p class=muted style='margin:8px 0 0'>Click a field to fill "
                         f"the next empty check — no path typing, no typos.</p>"
                         f"<details style='margin-top:10px'><summary class=muted "
                         f"style='cursor:pointer'>Raw JSON</summary>"
                         f"<pre style='max-height:280px;overflow:auto'>"
                         f"{esc(json.dumps(case, indent=2)[:12000])}</pre></details>")
            head = (f"<h2>1 · Case loaded — {len(entries)} fields</h2>")
        else:
            case_pane = ("<p class=muted>No case loaded. Pull one above — the fields "
                         "become clickable and every check shows whether it fires.</p>")
            head = "<h2>1 · Pull a failing case</h2>"
        parts.append(f"<div class=card>{head}{pull}"
                     f"<div style='margin-top:14px'>{case_pane}</div></div>")

        # ── drafted from source ────────────────────────────────────────
        parts.append(self._lab_drafts(conn, exc_id, checks))

        # ── 2 · checks: sentences first, machinery on demand ───────────
        # An authored check IS its readback sentence — the form that built it
        # is machinery, hidden behind Edit. Only the add-a-check row opens
        # with its form showing, so the screen reads as a list of rules, not
        # a wall of inputs.
        STATE = {"fires": ("resolved", "FIRES", "ok"),
                 "quiet": ("", "quiet", ""),
                 "error": ("failed", "ERROR", "err"),
                 "manual": ("reprocessed", "MANUAL", "")}
        rows_html = ""
        edit = checks + [{}]
        for i, c in enumerate(edit):
            is_new = not c.get("path") and c.get("kind") != "manual"
            live, row_cls = "", ""
            if case and c.get("path"):
                res = check_fires(c, case, gcfg)
                cls, lbl, row_cls = STATE.get(res["state"],
                                              ("", res["state"], ""))
                live = (f"<div class=cev>"
                        f"<span class='badge {cls}' style='margin-left:0'>{lbl}</span> "
                        f"<span class=muted>{esc(res['detail'])}</span></div>")
            kind_opts = "".join(
                f"<option{' selected' if c.get('kind', 'compare') == k else ''}>{k}</option>"
                for k in ("compare", "presence", "set", "pattern", "manual"))
            scope_opts = "".join(
                f"<option{' selected' if c.get('scope', 'latest') == s else ''}>{s}</option>"
                for s in SCOPES)
            op_opts = "".join(
                f"<option value={k}{' selected' if c.get('op') == k else ''}>{v}</option>"
                for k, v in OPS.items())
            is_ref = (c.get("value") or "").startswith("$")
            body = f"""<div class='cbody{' open' if is_new else ''}'>
<div class=cflds>
<div><label class=flabel>Kind</label>
<select name=kind_{i}>{kind_opts}</select></div>
<div><label class=flabel>Repeating group <span class=opt>optional</span></label>
<input type=text name=group_{i} value="{esc(c.get('group',''))}"
 placeholder='e.g. entitlementPeriods'></div>
<div><label class=flabel>Scope</label>
<select name=scope_{i}>{scope_opts}</select></div>
</div>
<div class=cflds>
<div><label class=flabel>Field</label>
<input type=text name=path_{i} value="{esc(c.get('path',''))}"
 placeholder='click a field in the case above'></div>
<div><label class=flabel>Condition</label>
<select name=op_{i}>{op_opts}</select></div>
<div><label class=flabel>Compared to</label>
<div style='display:flex;gap:6px'>
<select name=vmode_{i} class=vmode style='max-width:150px'>
<option value=value{'' if is_ref else ' selected'}>a value</option>
<option value=field{' selected' if is_ref else ''}>another field</option></select>
<input type=text name=value_{i} value="{esc(c.get('value',''))}"
 placeholder="{'click a field in the case above' if is_ref else 'e.g. SUSPENDED · 2016-01-01'}">
</div></div>
</div>
<div class=cflds style='margin-top:2px'>
<div style='grid-column:1 / -1'><label class=flabel>Cause when this matches
 <span class=opt>shown to the analyst as the answer</span></label>
<input type=text name=cause_{i} value="{esc(c.get('cause',''))}"
 placeholder='e.g. Date of birth is later than the entitlement date'></div>
</div>
<div class=cflds>
<div><label class=flabel>Screen <span class=opt>optional</span></label>
<input type=text name=screen_{i} value="{esc(c.get('screen',''))}" placeholder='PS220'></div>
<div><label class=flabel>Field to fix <span class=opt>optional</span></label>
<input type=text name=fix_{i} value="{esc(c.get('fix_field',''))}" placeholder='BENE-DOB'></div>
<div><label class=flabel>Confidence</label>
<select name=conf_{i}>
<option{' selected' if c.get('confidence') == 'definitive' else ''}>definitive</option>
<option{' selected' if c.get('confidence') == 'likely' else ''}>likely</option></select></div>
</div>
<label class=flabel>Resolution steps <span class=opt>one per line</span></label>
<textarea name=steps_{i} rows=2 style='margin-bottom:0'
>{esc(c.get('steps',''))}</textarea>
</div>"""
            if is_new:
                rows_html += (
                    f"<div class='checkrow new'><div class=chead>"
                    f"<span class='cnum plus'>＋</span>"
                    f"<div class=csay><span class=muted>Add a check — click a "
                    f"field in the case above, or fill it in by hand.</span>"
                    f"</div></div>{body}</div>")
            else:
                cause = (f" <span class=carrow>&rarr;</span> "
                         f"<b>{esc(c['cause'])}</b>" if c.get("cause") else
                         " <span class=carrow>&rarr;</span> <span class=muted>"
                         "no cause written yet</span>")
                conf = ("<span class='badge alert'>likely</span>"
                        if c.get("confidence") == "likely" else "")
                rows_html += (
                    f"<div class='checkrow {row_cls}'><div class=chead>"
                    f"<span class=cnum>{i + 1}</span>"
                    f"<div class=csay><span class=readback>{readback(c)}</span>"
                    f"{cause}{conf}{live}</div>"
                    f"<button type=button class=cedit>Edit</button>"
                    f"</div>{body}</div>")

        # Group config: a compact labeled strip, only as loud as it needs to
        # be. Open when a check actually reads a repeating group.
        groups = list(dict.fromkeys(
            [c["group"] for c in checks if c.get("group")] + list(gcfg)))
        gc_rows = ""
        for n, g in enumerate(groups + [None]):
            cfg = gcfg.get(g, {}) if g else {}
            opts = "".join(
                f"<option{' selected' if cfg.get('latest_is') == v else ''}>{v}</option>"
                for v in ("max_start", "array_order", "open_period", "covers_today"))
            gc_rows += (
                f"<div class=gcrow>"
                f"<input type=text name=gc_group_{n} value='{esc(g or '')}' "
                f"placeholder='repeating group'>"
                f"<input type=text name=gc_order_{n} value='{esc(cfg.get('order_by',''))}' "
                f"placeholder='date field, e.g. startDate'>"
                f"<select name=gc_latest_{n}>{opts}</select></div>")
        missing_order = [g for g in groups if not gcfg.get(g, {}).get("order_by")]
        gc_note = (f"<span style='color:#8a6410;font-weight:600'>⚠ "
                   f"{' · '.join(esc(g) for g in missing_order)}: set the date "
                   f"field so “latest” isn't guessed from array order</span>"
                   if missing_order else
                   "<span class=muted>Which occurrence “latest” means, per group.</span>")
        gc_box = f"""<details class=gcbox{' open' if groups else ''}>
<summary>Repeating groups — what “latest” means &nbsp;{gc_note}</summary>
<div class=gchead><span>Group</span><span>Ordered by</span><span>Latest is</span></div>
{gc_rows}</details>"""

        parts.append(f"""<div class=card><h2>2 · Checks{' — live against the loaded case' if case else ''}</h2>
<form method=post action="/lab/save">
<input type=hidden name=code value="{esc(r['normalized'])}">
{rows_html}
{gc_box}
<label class=flabel style='margin-top:14px'>General steps
 <span class=opt>fallback when no check matches</span></label>
<textarea name=general_steps rows=2
>{esc(pb['general_steps'] if pb and pb['general_steps'] else '')}</textarea>
<div style='display:flex;gap:10px;align-items:center'>
<input type=text name=actor placeholder="Your initials" style="max-width:140px;margin:0">
<button>Save recipe</button>
<span class=muted>Blank rows are ignored.</span>
</div>
</form></div>""")
        self._send("".join(parts), f"Lab · {r['code']}")

    def _lab_draft(self, conn, form):
        """Accept a machine-drafted check into the playbook."""
        r = self._exc(conn, form.get("code", ""))
        if not r:
            self._send("<div class=card>Unknown code.</div>", code=404)
            return
        try:
            c = json.loads(form.get("payload", ""))
        except ValueError:
            self._send("<div class=card>Bad draft payload.</div>", code=400)
            return
        pb = conn.execute("SELECT * FROM playbook WHERE exception_id = ?",
                          (r["id"],)).fetchone()
        checks = json.loads(pb["checks"]) if pb else []
        checks.append(c)
        conn.execute(
            """INSERT INTO playbook (exception_id, endpoint_id, general_steps,
               checks, group_config, updated_by, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(exception_id) DO UPDATE SET
                 checks = excluded.checks,
                 updated_by = excluded.updated_by,
                 updated_at = excluded.updated_at""",
            (r["id"], pb["endpoint_id"] if pb else None,
             pb["general_steps"] if pb else None, json.dumps(checks),
             pb["group_config"] if pb else "{}", "draft", db.now()))
        db.add_event(conn, r["id"], "edit",
                     payload={"via": "lab-draft", "path": c.get("path")},
                     actor="analyst")
        conn.commit()
        self._lab_edit(conn, {"code": [form.get("code", "")]},
                  "<div class=banner>Draft accepted — add the cause and "
                  "resolution steps, then save.</div>")


    def _lab_pull(self, conn, form):
        r = self._exc(conn, form.get("code", ""))
        env = conn.execute("SELECT * FROM api_env WHERE id = ?",
                           (int(form.get("env", 0) or 0),)).fetchone()
        ep = conn.execute("SELECT * FROM api_endpoint WHERE id = ?",
                          (int(form.get("endpoint_id", 0) or 0),)).fetchone()
        if not r or not env or not ep:
            self._send("<div class=card>Pick a code, environment and endpoint.</div>",
                       code=400)
            return
        params = {k[2:]: v.strip() for k, v in form.items() if k.startswith("p_")}
        status, text, ms, err = self._call_api(env, ep, params)
        masked = {k: mask_value(k, v) for k, v in params.items()}
        conn.execute(
            "INSERT INTO api_call_log (env, endpoint, params, status, ms, ok, ts)"
            " VALUES (?, ?, ?, ?, ?, ?, ?)",
            (f"LAB:{env['name']}", ep["name"], json.dumps(masked, ensure_ascii=False),
             status, ms, 0 if err or not status or status >= 300 else 1, db.now()))
        conn.commit()
        if err or not (status and 200 <= status < 300):
            self._lab_edit(conn, {"code": [form.get("code", "")]},
                      f"<div class=banner style='background:#f9e5e5;color:#a63838;"
                      f"border-color:#e7c3c3'>Pull failed — "
                      f"{esc(err or f'HTTP {status}')}</div>")
            return
        try:
            self._lab_cases[r["id"]] = json.loads(text)
        except ValueError:
            self._lab_cases[r["id"]] = {}
        self._lab_edit(conn, {"code": [form.get("code", "")]},
                  f"<div class=banner>Case loaded ({ms} ms) — session only, not "
                  f"written to disk.</div>")

    def _lab_save(self, conn, form):
        r = self._exc(conn, form.get("code", ""))
        if not r:
            self._send("<div class=card>Unknown code.</div>", code=404)
            return
        checks = []
        for i in range(60):
            if f"path_{i}" not in form:
                break
            path = form.get(f"path_{i}", "").strip()
            kind = form.get(f"kind_{i}", "compare")
            if not path and kind != "manual":
                continue
            c = {"kind": kind, "path": path,
                 "op": form.get(f"op_{i}", "eq"),
                 "value": form.get(f"value_{i}", "").strip(),
                 "cause": form.get(f"cause_{i}", "").strip(),
                 "steps": form.get(f"steps_{i}", "").strip(),
                 "screen": form.get(f"screen_{i}", "").strip(),
                 "fix_field": form.get(f"fix_{i}", "").strip(),
                 "confidence": form.get(f"conf_{i}", "definitive")}
            g = form.get(f"group_{i}", "").strip()
            if g:
                c["group"] = g
                c["scope"] = form.get(f"scope_{i}", "latest")
            if (form.get(f"vmode_{i}") == "field" and c["value"]
                    and not c["value"].startswith("$")):
                c["value"] = ("$." if g else "$$.") + c["value"]
            checks.append(c)
        gcfg = {}
        for n in range(40):
            if f"gc_group_{n}" not in form:
                break
            g = form.get(f"gc_group_{n}", "").strip()
            if g:
                gcfg[g] = {"order_by": form.get(f"gc_order_{n}", "").strip(),
                           "latest_is": form.get(f"gc_latest_{n}", "max_start")}
        pb = conn.execute("SELECT endpoint_id FROM playbook WHERE exception_id = ?",
                          (r["id"],)).fetchone()
        conn.execute(
            """INSERT INTO playbook (exception_id, endpoint_id, general_steps,
               checks, group_config, updated_by, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(exception_id) DO UPDATE SET
                 general_steps = excluded.general_steps,
                 checks = excluded.checks,
                 group_config = excluded.group_config,
                 updated_by = excluded.updated_by,
                 updated_at = excluded.updated_at""",
            (r["id"], pb["endpoint_id"] if pb else None,
             form.get("general_steps", "").strip() or None,
             json.dumps(checks), json.dumps(gcfg),
             form.get("actor", "analyst"), db.now()))
        db.add_event(conn, r["id"], "edit", payload={"via": "lab",
                                                     "checks": len(checks)},
                     actor=form.get("actor", "analyst"))
        conn.commit()
        self._lab_edit(conn, {"code": [form.get("code", "")]},
                  f"<div class=banner>Recipe saved — {len(checks)} check"
                  f"{'s' if len(checks) != 1 else ''}.</div>")

    # ── Exception MI (statistic-server extracts) ───────────────────────
    def _mi_dir(self) -> Path:
        d = Path(self.db_path).resolve().parent / "artifacts" / "_mi"
        d.mkdir(parents=True, exist_ok=True)
        return d

    def _mi_panel(self, conn, qs, result_html: str = "") -> str:
        parts = [result_html]
        parts.append("""<div class=card><h2>Import exception MI</h2>
<p class=muted style="margin-top:-4px">Drop the statistic-server extract
(.xlsx or .csv). You'll see the file's own columns, confirm which one is the
code / period / count, and the numbers land on each exception's page and the
dashboard.</p>
<form id=upform method=post action="/mi/upload" enctype="multipart/form-data">
<input type=file id=fs name=file accept=".xlsx,.csv" style="display:none">
<label class=drop id=drop for=fs style="width:100%;max-width:520px">
<b>Drop the MI extract here</b>or click to browse<br>
<span id=droplbl>.xlsx · .csv</span></label></form></div>
<script>
(function(){
  var inp=document.getElementById('fs'),drop=document.getElementById('drop'),
      lbl=document.getElementById('droplbl'),form=document.getElementById('upform');
  inp.addEventListener('change',function(){
    if(inp.files.length){lbl.textContent=inp.files[0].name+' \\u2014 reading\\u2026';form.submit();}});
  ['dragover','dragenter'].forEach(function(e){drop.addEventListener(e,function(ev){
    ev.preventDefault();drop.classList.add('over');});});
  ['dragleave','drop'].forEach(function(e){drop.addEventListener(e,function(ev){
    ev.preventDefault();drop.classList.remove('over');});});
  drop.addEventListener('drop',function(ev){
    inp.files=ev.dataTransfer.files;inp.dispatchEvent(new Event('change'));});
})();
</script>""")

        pending = (qs or {}).get("pending", [""])[0]
        if pending:
            fp = self._mi_dir() / Path(pending).name
            if fp.exists():
                table = read_table(fp.read_bytes(), fp.name)
                if table:
                    headers, data = table[0], table[1:]
                    guess = guess_mapping(headers)
                    head_html = "".join(f"<th>{esc(h) or '—'}</th>" for h in headers)
                    body_html = "".join(
                        "<tr>" + "".join(f"<td>{esc(c)}</td>" for c in r) + "</tr>"
                        for r in data[:8])

                    def sel(name, current, optional):
                        opts = ""
                        if optional:
                            opts += ("<option value='-1'"
                                     + (" selected" if current is None else "")
                                     + ">— none —</option>")
                        for i, h in enumerate(headers):
                            s = " selected" if current == i else ""
                            opts += f"<option value={i}{s}>{esc(h) or f'col {i + 1}'}</option>"
                        return (f"<label class=muted style='display:block'>{name}"
                                f"<select name={name.split()[0].lower()}_col>{opts}"
                                f"</select></label>")

                    parts.append(
                        f"<div class=card><h2>{esc(fp.name)} · {len(data)} rows · "
                        f"{len(headers)} columns</h2>"
                        f"<div style='overflow-x:auto'><table><tr>{head_html}</tr>"
                        f"{body_html}</table></div>"
                        f"<p class=muted>Preview — first 8 rows, every column as-is."
                        f" All columns are kept on import; the mapping below only "
                        f"tells the catalog which is which.</p>"
                        f"<form method=post action='/mi/import' "
                        f"style='max-width:420px'>"
                        f"<input type=hidden name=file value='{esc(fp.name)}'>"
                        f"{sel('Code column', guess['code'] or 0, False)}"
                        f"{sel('Period column', guess['period'], True)}"
                        f"{sel('Count column', guess['count'], True)}"
                        f"{sel('Application column', guess['application'], True)}"
                        f"<button style='margin-top:8px'>Import</button></form></div>")

        batches = conn.execute("SELECT * FROM mi_import ORDER BY id DESC LIMIT 12").fetchall()
        if batches:
            rows = "".join(
                f"<tr><td><b>{esc(b['filename'])}</b></td>"
                f"<td class=num>{b['rows_imported']}</td>"
                f"<td class=num>{b['codes']}</td>"
                f"<td>{esc(b['period_min'] or '—')} → {esc(b['period_max'] or '—')}</td>"
                f"<td class=muted>{esc(nice_day(b['ts']))}</td></tr>" for b in batches)
            parts.append(f"<div class=card><h2>Imported extracts</h2><table>"
                         f"<tr><th>File</th><th class=num>Rows</th><th class=num>Codes</th>"
                         f"<th>Period range</th><th>Imported</th></tr>{rows}</table>"
                         f"<p class=muted style='margin-top:10px;margin-bottom:0'>"
                         f"Re-importing a file replaces its previous numbers.</p></div>")
        return "".join(parts)

    def _mi_upload(self, body: bytes):
        files = parse_multipart(self.headers.get("Content-Type", ""), body)
        if not files:
            self._send("<div class=card>No file received. <a href='/settings?tab=mi'>Back</a></div>",
                       code=400)
            return
        name, payload = files[0]
        (self._mi_dir() / name).write_bytes(payload)
        self._redirect("/settings?tab=mi&pending="
                       + urllib.parse.quote(name))

    def _mi_import(self, conn, form):
        fp = self._mi_dir() / Path(form.get("file", "")).name
        if not fp.exists():
            self._send("<div class=card>File not found. <a href='/settings?tab=mi'>Back</a></div>",
                       code=404)
            return
        table = read_table(fp.read_bytes(), fp.name)
        headers, data = table[0], table[1:]

        def col(name):
            try:
                v = int(form.get(name, "-1"))
            except ValueError:
                v = -1
            return v if 0 <= v < len(headers) else None

        code_c, period_c = col("code_col"), col("period_col")
        count_c, app_c = col("count_col"), col("application_col")
        if code_c is None:
            self._send("<div class=card>A code column is required. "
                       "<a href='/settings?tab=mi'>Back</a></div>", code=400)
            return

        # Replace semantics: this file's previous numbers go away first.
        conn.execute("DELETE FROM exception_event WHERE kind = 'mi'"
                     " AND json_extract(payload, '$.src') = ?", (fp.name,))

        imported, skipped = 0, 0
        codes_seen, periods = set(), []
        for row in data:
            code = (row[code_c] if code_c < len(row) else "").strip()
            if not code:
                skipped += 1
                continue
            try:
                count = int(float(row[count_c])) if (count_c is not None
                                                     and row[count_c].strip()) else 1
            except (ValueError, IndexError):
                count = 1
            period = (coerce_period(row[period_c])
                      if period_c is not None and period_c < len(row) else None)
            exc_id = db.resolve_exception(conn, code)
            if exc_id is None:
                exc_id = db.upsert_exception(conn, code)
            row_app = (row[app_c].strip() if app_c is not None
                       and app_c < len(row) else None)
            if not row_app:
                # the code's own prefix names the business function
                row_app = db.app_for_code_prefix(conn, code)
            payload = {
                "src": fp.name, "count": count, "period": period,
                "application": row_app,
                # DYNAMIC: the whole source row rides along, keyed by the
                # file's own headers — unmapped columns are kept, not lost.
                "row": {h: (row[i] if i < len(row) else "")
                        for i, h in enumerate(headers) if h},
            }
            db.add_event(conn, exc_id, "mi", payload=payload)
            imported += 1
            codes_seen.add(db.normalize_code(code))
            if period:
                periods.append(period)
        conn.execute(
            """INSERT INTO mi_import (filename, columns, mapping, rows_imported,
               codes, period_min, period_max, ts) VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (fp.name, json.dumps(headers),
             json.dumps({"code": code_c, "period": period_c,
                         "count": count_c, "application": app_c}),
             imported, len(codes_seen),
             min(periods) if periods else None,
             max(periods) if periods else None, db.now()))
        conn.commit()
        result = (f"<div class=banner>Imported {imported} rows · "
                  f"{len(codes_seen)} exception codes"
                  f"{' · ' + str(skipped) + ' rows skipped (no code)' if skipped else ''}"
                  f" — see the <a href='/'>dashboard</a> or any code's page.</div>")
        self._settings(conn, tab="mi", banner_mi=result)

    def _doc_kind_bar(self, conn, d) -> str:
        kind = (d["kind"] or "dfr")
        if kind == "policy":
            apps = conn.execute(
                "SELECT id, name FROM application ORDER BY name").fetchall()
            opts = "".join(f"<option value={a['id']}>{esc(a['name'])}"
                           f"</option>" for a in apps)
            return (
                f"<div class=card style='padding:12px 18px;display:flex;"
                f"align-items:center;gap:12px;flex-wrap:wrap'>"
                f"<span class='badge limitation' style='margin-left:0'>"
                f"POLICY</span>"
                f"<span class=muted style='font-size:12.5px'>Global "
                f"reference — cited from codes and recipes, owned by no "
                f"application.</span>"
                f"<form method=post action='/doc/kind' style='display:flex;"
                f"gap:6px;margin:0 0 0 auto'>"
                f"<input type=hidden name=id value={d['id']}>"
                f"<input type=hidden name=kind value=dfr>"
                f"<select name=application_id style='margin:0;font-size:12px;"
                f"padding:5px 8px'>{opts}</select>"
                f"<button class=btnsm2>Reclassify as DFR</button></form>"
                f"</div>")
        return (
            f"<div class=card style='padding:12px 18px;display:flex;"
            f"align-items:center;gap:12px'>"
            f"<span class='badge imported' style='margin-left:0'>DFR</span>"
            f"<span class=muted style='font-size:12.5px'>Resolution "
            f"evidence, owned by its application.</span>"
            f"<form method=post action='/doc/kind' "
            f"style='margin:0 0 0 auto'>"
            f"<input type=hidden name=id value={d['id']}>"
            f"<input type=hidden name=kind value=policy>"
            f"<button class=btnsm2>This is policy — move to the "
            f"library</button></form></div>")

    def _doc_reader(self, conn, doc_id: str):
        """The DFR reader: sections with document typography, anchors, and
        the codes each section governs."""
        try:
            did = int(doc_id)
        except ValueError:
            self._send("<div class=card>Bad document id.</div>", code=400)
            return
        d = conn.execute(
            """SELECT d.*, a.name AS app_name, a.id AS app_id FROM document d
               LEFT JOIN application a ON a.id = d.application_id
               WHERE d.id = ?""", (did,)).fetchone()
        if not d:
            self._send("<div class=card>Document not found.</div>", code=404)
            return
        secs = conn.execute("SELECT * FROM doc_section WHERE document_id = ?"
                            " ORDER BY ord", (did,)).fetchall()
        gov_by_section: dict[str, list] = {}
        for g in conn.execute(
                """SELECT l.target_ref, e.code, e.normalized, e.category
                   FROM exception_link l JOIN exception_code e ON e.id = l.exception_id
                   WHERE l.target_kind = 'document'
                   AND json_extract(l.detail, '$.doc_id') = ?""", (did,)):
            gov_by_section.setdefault(g["target_ref"], []).append(g)

        trail = [(d["app_name"], f"/app/{d['app_id']}")] if d["app_id"] else []
        parts = [crumbs(*trail, here=d["title"]),
                 self._doc_kind_bar(conn, d)]
        parts.append(
            f"<div class=card><h1>{esc(d['title'])}</h1>"
            f"<p class=muted><span class=doctype>{esc(d['doc_type'])}</span> · "
            f"{len(secs)} sections · updated {esc(nice_day(d['ingested_at']))}</p></div>")

        real_secs = [s for s in secs if s["text"].strip() or s["heading"] != "(preamble)"]
        if len(real_secs) > 3:
            toc = "".join(f"<a href='#s{s['ord']}'>{esc(s['heading'])}</a>"
                          for s in real_secs)
            parts.append(f"<div class=card><h2>Contents</h2><div class=toc>{toc}</div></div>")

        body_html = []
        for s in real_secs:
            gov = gov_by_section.get(str(s["id"]), [])
            chips = "".join(
                f"<a class=codechip style='font-size:12.5px;padding:3px 11px;"
                f"vertical-align:3px;margin-left:10px' href='/x/{esc(g['normalized'])}'>"
                f"<span class='dot d-{esc(g['category'])}' style='margin-right:0'></span>"
                f"{esc(g['code'])}</a>" for g in gov)
            paras = "".join(f"<p>{esc(line)}</p>"
                            for line in s["text"].split("\n") if line.strip())
            body_html.append(f"<div id=s{s['ord']}><h3>{esc(s['heading'])}{chips}</h3>"
                             f"{paras}</div>")
        parts.append(f"<div class=card><div class=reader>{''.join(body_html)}</div></div>")
        self._send("".join(parts), d["title"])

    def _resolution(self, conn, code: str, extra_html: str = ""):
        r = self._exc(conn, code)
        norm = db.normalize_code(code)
        if not r:
            body = (f"<div class=card><h1>{esc(code)}</h1><p>Unknown code. "
                    f"<a href='/search?q={urllib.parse.quote(code)}'>Search the corpus</a> "
                    f"— if you resolve it, the entry you create becomes the next "
                    f"analyst's fast path.</p></div>")
            self._send(body, code, q=code)
            return
        db.add_event(conn, r["id"], "lookup", actor="web")
        conn.commit()

        stats = db.exception_stats(conn, r["id"])
        links = conn.execute(
            "SELECT * FROM exception_link WHERE exception_id = ?"
            " ORDER BY relation, confidence DESC", (r["id"],)).fetchall()
        events = conn.execute(
            "SELECT * FROM exception_event WHERE exception_id = ? AND kind = 'resolution'"
            " ORDER BY ts DESC LIMIT 8", (r["id"],)).fetchall()

        facets: dict[str, list] = {}
        for l in links:
            facets.setdefault(l["relation"], []).append(l)

        dismiss_ui = (
            f"<div class=banner style='background:#fdf6dd;color:#7a5d05;"
            f"border-color:#efe1a8'>This code is DISMISSED — hidden from "
            f"the catalog and application screens. "
            f"<form method=post style='display:inline' "
            f"action='/x/{urllib.parse.quote(r['normalized'])}/restore'>"
            f"<button class=btnsm2>Restore it</button></form></div>"
            if (r["status"] or "") == "dismissed" else "")
        aliases = [a["alias"] for a in conn.execute(
            "SELECT alias FROM code_alias WHERE exception_id = ?"
            " ORDER BY alias", (r["id"],))]

        shadow, pfx = self._prefix_shadow(conn, r)
        shadow_ui = ""
        if shadow is not None:
            shadow_ui = (
                f"<div class=banner style='background:#fdf6dd;color:#7a5d05;"
                f"border-color:#efe1a8'><b>{esc(r['code'])}</b> looks like "
                f"<a href='/x/{esc(shadow['normalized'])}'>"
                f"<b>{esc(shadow['code'])}</b></a> wearing the reporting "
                f"prefix <code>{esc(pfx)}</code> — the shop's MI prefixes "
                f"codes with the business function. "
                f"<form method=post style='display:inline' "
                f"action='/x/{urllib.parse.quote(r['normalized'])}/merge'>"
                f"<input type=hidden name=into value='{esc(shadow['code'])}'>"
                f"<button class=btnsm2>Merge into {esc(shadow['code'])}"
                f"</button></form> "
                f"<form method=post style='display:inline' "
                f"action='/x/{urllib.parse.quote(r['normalized'])}/merge'>"
                f"<input type=hidden name=into value='{esc(shadow['code'])}'>"
                f"<input type=hidden name=declare_prefix value='{esc(pfx)}'>"
                f"<select name=prefix_app style='margin:0;font-size:12px;"
                f"padding:4px 8px'>"
                f"<option value=''>— whose prefix? —</option>"
                + "".join(f"<option value={a['id']}>{esc(a['name'])}"
                          f"</option>" for a in conn.execute(
                              "SELECT id, name FROM application"
                              " ORDER BY name"))
                + f"</select> "
                f"<button class=btnsm2>Merge + declare {esc(pfx)}"
                f"</button></form>"
                f"<span class=muted style='font-size:12px'> — declaring "
                f"makes every future {esc(pfx)}-prefixed MI code resolve "
                f"automatically.</span></div>")
        cat_opts = "".join(
            f"<option value='{v}'"
            f"{' selected' if v == (r['category'] or 'exception') else ''}>"
            f"{label}</option>" for v, label in CATEGORIES)

        # ── hero: identity on navy, evidence tiles below — the category
        #    is edited HERE, where the identity lives ──────────────────
        cat_label = dict(CATEGORIES).get(r["category"] or "exception",
                                         r["category"] or "exception")
        ctx = ""
        if r["screen_id"] or r["data_element"]:
            ctx = (f"<div class=heroseam>screen <b>{esc(r['screen_id'] or '—')}"
                   f"</b> &nbsp;·&nbsp; field <b>"
                   f"{esc(r['data_element'] or '—')}</b></div>")
        alias_line = ""
        if aliases:
            alias_line = (
                f"<div class=herosub style='margin-top:6px'>Also reported as "
                + ", ".join(f"<code style='color:#d9c48a'>{esc(a)}</code>"
                            for a in aliases)
                + " — MI rows under these codes land here.</div>")
        succ = stats.get("success_rate")
        res_sub = (f"{succ}% success" if succ is not None else
                   ("none logged yet" if not stats.get("resolutions")
                    else ""))
        hero = f"""<div class=herowrap>
<div class=apphero>
<div class=herostage><span class=heropill>CODE</span>
<span class=heropill>{esc(cat_label).upper()}</span>
<span class=heropill-role>{esc(r['status'] or 'mined')}</span>
<form method=post class=miprefix style='margin:0 0 0 auto'
 action='/x/{urllib.parse.quote(r['normalized'])}/category'>
<select name=category style='margin:0;font-size:12px;padding:4px 8px;
background:rgba(255,255,255,.08);color:#fff;
border:1px solid rgba(255,255,255,.25);border-radius:7px'>{cat_opts}
</select>
<button class=btnsm2>Set category</button></form></div>
{ctx}
<h1>{esc(r['code'])}</h1>
<div class=herosub>{esc(r['meaning'] or
    'No curated meaning yet — mined facets below.')}</div>
{alias_line}
</div>
<div class=herobase>
<div class=statiles>
{hero_tile(stats['occurrences'] if stats['occurrences'] is not None
           else '—', "occurrences", "production volume from MI", "#mi-trend",
           "code")}
{hero_tile(stats['lookups'] if stats['lookups'] is not None else 0,
           "lookups", "analysts consulted this entry", "#recipe", "doc")}
{hero_tile(stats['resolutions'] if stats['resolutions'] is not None
           else 0, "resolutions", res_sub or "logged outcomes", "#log",
           "rule")}
{hero_tile(stats['runs'] if stats['runs'] is not None else 0,
           "dry runs", "cobrun hits on this code", "#recipe", "run")}
</div>
</div>
</div>"""
        parts = [crumbs(("Catalog", "/catalog"), here=r["code"]),
                 shadow_ui,
                 dismiss_ui,
                 hero]

        parts.append(extra_html)

        # ── Triage recipe: the automated "what do I do" ────────────────
        pb = conn.execute("SELECT * FROM playbook WHERE exception_id = ?",
                          (r["id"],)).fetchone()
        pb_checks = json.loads(pb["checks"]) if pb else []
        envs = conn.execute("SELECT * FROM api_env ORDER BY name").fetchall()
        eps = conn.execute("SELECT * FROM api_endpoint ORDER BY name").fetchall()
        pb_ep = next((e for e in eps if pb and pb["endpoint_id"] == e["id"]), None)

        if pb and (pb_checks or pb["general_steps"]):
            rows = ""
            for c in pb_checks:
                cond = (f"<code>{esc(c['path'])}</code> {esc(OPS.get(c['op'], c['op']))}"
                        + (f" <code>{esc(c['value'])}</code>" if c.get("value") else ""))
                steps = "".join(f"<li>{esc(s.strip())}</li>"
                                for s in (c.get("steps") or "").split("\n") if s.strip())
                rows += (f"<div style='padding:10px 0;border-bottom:1px solid #f1f3f6'>"
                         f"<b>If</b> {cond} → <b>{esc(c.get('cause') or '?')}</b>"
                         f"{('<ol style=margin:6px 0 0>' + steps + '</ol>') if steps else ''}"
                         f"</div>")
            gen = "".join(f"<li>{esc(s.strip())}</li>"
                          for s in (pb["general_steps"] or "").split("\n") if s.strip())
            triage_form = ""
            if pb_ep and envs:
                phs = list(dict.fromkeys(RE_PLACEHOLDER.findall(
                    pb_ep["path"] + (pb_ep["body"] or ""))))
                env_opts = "".join(f"<option value={e['id']}>{esc(e['name'])}</option>"
                                   for e in envs)
                fields = "".join(
                    f"<input type=text name='p_{esc(p)}' placeholder='{esc(p)}'"
                    f" required style='max-width:180px'>" for p in phs)
                triage_form = (
                    f"<form method=post action='/x/{esc(norm)}/triage' "
                    f"style='display:flex;gap:10px;align-items:flex-start;"
                    f"flex-wrap:wrap;margin-top:12px'>"
                    f"<select name=env style='max-width:140px'>{env_opts}</select>"
                    f"{fields}<button>Run triage</button></form>")
            parts.append(
                f"<div class=card><h2>Resolution recipe"
                f"{' · automated triage' if pb_ep else ''}</h2>"
                + (f"<ol style='margin:4px 0 10px'>{gen}</ol>" if gen else "")
                + rows + triage_form + "</div>")

        mi = conn.execute(
            """SELECT json_extract(payload,'$.period') AS period,
               SUM(COALESCE(CAST(json_extract(payload,'$.count') AS INTEGER),1)) AS n
               FROM exception_event WHERE exception_id = ? AND kind = 'mi'
               AND json_extract(payload,'$.period') IS NOT NULL
               GROUP BY period ORDER BY period DESC LIMIT 12""",
            (r["id"],)).fetchall()
        if mi:
            mi = list(reversed(mi))
            mx = max(row["n"] for row in mi) or 1
            bars_html = "".join(
                f"<tr><td style='white-space:nowrap'>{esc(row['period'])}</td>"
                f"<td class=num><div class=abar>{bar(100 * row['n'] / mx)}"
                f"<b>{row['n']}</b></div></td></tr>" for row in mi)
            parts.append(f"<div class=card><h2>Occurrences by period · from MI</h2>"
                         f"<table><tr><th>Period</th><th class=num>Count</th></tr>"
                         f"{bars_html}</table></div>")

        for rel, title in (("emitted_by", "Emitting code"),
                           ("raised_by", "Raised by (message)"),
                           ("defined_in", "Defined in"),
                           ("governed_by", "Requirements / DFR"),
                           ("uses_sql", "Related SQL"),
                           ("touches", "Data elements")):
            if rel not in facets:
                continue
            rows_html = []
            for l in facets[rel]:
                d = json.loads(l["detail"])
                prog_link = (f"<a href='/prog/{d['program_db_id']}'>{esc(l['target_ref'])}</a>"
                             if d.get("program_db_id") else f"<b>{esc(l['target_ref'])}</b>")
                if rel == "governed_by":
                    href = ""
                    if d.get("doc_id"):
                        href = f"/doc/{d['doc_id']}"
                        if d.get("section_id"):
                            ordr = conn.execute(
                                "SELECT ord FROM doc_section WHERE id = ?",
                                (d["section_id"],)).fetchone()
                            if ordr:
                                href += f"#s{ordr['ord']}"
                    dk = "dfr"
                    if d.get("doc_id"):
                        kr = conn.execute(
                            "SELECT kind FROM document WHERE id = ?",
                            (d["doc_id"],)).fetchone()
                        dk = (kr["kind"] if kr and kr["kind"] else "dfr")
                    kind_chip = ("<span class='badge limitation' "
                                 "style='margin-left:6px'>POLICY</span>"
                                 if dk == "policy" else "")
                    title_html = (f"<a href='{href}'><b>{esc(d.get('doc_title',''))}"
                                  f"</b></a>{kind_chip}" if href else
                                  f"<b>{esc(d.get('doc_title',''))}</b>")
                    read = (f"<a class=viewbtn href='{href}'>Read the "
                            f"{'policy' if dk == 'policy' else 'full DFR'}"
                            f" &rarr;</a>" if href else "")
                    sme_bits = ""
                    if d.get("citation"):
                        sme_bits += (f"<div style='margin-top:5px'>"
                                     f"<span class='badge reprocessed' "
                                     f"style='margin-left:0'>CITATION</span> "
                                     f"<b>{esc(d['citation'])}</b></div>")
                    if d.get("sme_note"):
                        sme_bits += (f"<div class=muted style='margin-top:4px;"
                                     f"font-size:13px'>{esc(d['sme_note'])}"
                                     f" <span style='font-size:11.5px'>— "
                                     f"{esc(d.get('sme_by','SME'))}</span>"
                                     f"</div>")
                    remove_btn = ""
                    if l["provenance"] == "sme":
                        remove_btn = (
                            f"<form method=post style='display:inline' "
                            f"action='/x/{urllib.parse.quote(r['normalized'])}"
                            f"/link/{l['id']}/remove' "
                            f"onsubmit=\"return confirm('Remove this "
                            f"citation?')\">"
                            f"<button class=delbtn style='font-size:11.5px;"
                            f"padding:2px 9px'>remove</button></form>")
                    annotate = (
                        f"<details style='margin-top:5px'><summary "
                        f"class=muted style='font-size:12px;cursor:pointer'>"
                        f"{'edit' if d.get('citation') or d.get('sme_note') else 'add'} "
                        f"citation / note</summary>"
                        f"<form method=post style='display:flex;gap:6px;"
                        f"flex-wrap:wrap;margin-top:7px' "
                        f"action='/x/{urllib.parse.quote(r['normalized'])}"
                        f"/link/{l['id']}/annotate'>"
                        f"<input name=citation value='{esc(d.get('citation',''))}'"
                        f" placeholder='RS 00605.362 C.1' "
                        f"style='margin:0;max-width:200px;font-size:12.5px'>"
                        f"<input name=sme_note value='{esc(d.get('sme_note',''))}'"
                        f" placeholder='what the SME wants the next analyst "
                        f"to know' style='margin:0;flex:1;min-width:220px;"
                        f"font-size:12.5px'>"
                        f"<button class=btnsm2>save</button></form></details>")
                    rows_html.append(
                        f"<div style='margin-bottom:14px'>{title_html} "
                        f"<span class=muted>§ {esc(d.get('heading',''))} · "
                        f"{esc(l['provenance'])}</span>{remove_btn}{read}"
                        f"<div class=quote>{esc(d.get('excerpt',''))}</div>"
                        f"{sme_bits}{annotate}</div>")
                    continue
                src = ""
                fid = d.get("file_id")
                if not fid and d.get("file"):
                    # Links mined before file_id landed in detail: resolve by
                    # member name (unique enough within a corpus to be useful).
                    row_ = conn.execute(
                        "SELECT id FROM source_file WHERE name = ?",
                        (d["file"],)).fetchone()
                    fid = row_["id"] if row_ else None
                if fid:
                    src = (f"<a class=viewbtn href='/file/{fid}"
                           f"?hl={d.get('line') or ''}'>View full source "
                           f"&rarr;</a>")
                head = (f"{prog_link} "
                        f"<span class=muted>{esc(d.get('file',''))}"
                        f"{' paragraph ' + esc(d['paragraph']) if d.get('paragraph') else ''}"
                        f"{' · line ' + esc(d['line']) if d.get('line') else ''}"
                        f" · confidence {l['confidence']:.0%} · "
                        f"{esc(l['provenance'])}</span>{src}")
                cond = (f"<div>Trigger (heuristic): "
                        f"<code class=cond>{esc(d['condition'])}</code></div>"
                        if d.get("condition") else "")
                msg = (f"<div>Message: <code>{esc(d['message'])}</code></div>"
                       if d.get("message") else "")
                snip = f"<pre>{esc(d['snippet'])}</pre>" if d.get("snippet") else ""
                sql = f"<pre>{esc(d['text'])}</pre>" if rel == "uses_sql" and d.get("text") else ""
                rows_html.append(f"<div style='margin-bottom:12px'>{head}{cond}{msg}{snip}{sql}</div>")
            parts.append(f"<div class=card><h2>{title}</h2>{''.join(rows_html)}</div>")

        # SMEs attach policy / DFR citations by hand — mined hits are the
        # floor, not the ceiling. Documents stay read-only (they are
        # evidence); the LINK carries the curation.
        doc_opts = "".join(
            f"<option value={dd['id']}>"
            f"{'[POLICY] ' if (dd['kind'] or 'dfr') == 'policy' else '[DFR] '}"
            f"{esc(dd['title'])}</option>"
            for dd in conn.execute(
                "SELECT id, title, kind FROM document ORDER BY "
                "COALESCE(kind,'dfr') DESC, title"))
        if doc_opts:
            parts.append(f"""<div class=card><h2>Add a citation</h2>
<p class=muted style='margin-top:-6px'>Link a policy or DFR section to
this code with the reference an SME would quote. If the citation matches
a section heading, the link lands on that exact section.</p>
<form method=post action="/x/{esc(norm)}/cite" style='display:flex;
gap:8px;flex-wrap:wrap'>
<select name=doc_id style='margin:0;max-width:260px'>{doc_opts}</select>
<input name=citation placeholder='RS 00605.362 C.1' required
 style='margin:0;max-width:190px'>
<input name=sme_note placeholder='why it applies — what the next analyst
 should know' style='margin:0;flex:1;min-width:220px'>
<input name=sme_by placeholder='initials' style='margin:0;width:80px'>
<button>Add citation</button></form></div>""")

        if events:
            ev_rows = "".join(
                f"<tr><td>{esc(e['ts'][:10])}</td><td>{esc(e['outcome'])}</td>"
                f"<td>{esc(json.loads(e['payload']).get('cause',''))}</td>"
                f"<td>{esc(json.loads(e['payload']).get('action',''))}</td>"
                f"<td class=muted>{esc(e['actor'])}</td></tr>" for e in events)
            parts.append(f"<div class=card><h2>Recent resolutions</h2><table>"
                         f"<tr><th>When</th><th>Outcome</th><th>Cause</th><th>Action</th>"
                         f"<th>By</th></tr>{ev_rows}</table></div>")

        parts.append(f"""<div class=card><h2>Log a resolution · ~20 seconds</h2>
<form method=post action="/x/{esc(norm)}/resolve">
<input type=text name=case_ref placeholder="Case / policy ref">
<input type=text name=cause placeholder="Cause (e.g. DOB after effective date)">
<input type=text name=field placeholder="Field corrected">
<input type=text name=action placeholder="Action taken">
<select name=outcome><option>resolved</option><option>escalated</option>
<option>reprocessed</option><option>failed</option></select>
<input type=text name=actor placeholder="Your initials">
<button>Save</button></form></div>""")

        # Recipe editor: existing checks + three blank rows; blank paths are
        # ignored on save, so "add more" is just save-and-reopen.
        ep_opts = "<option value=''>— endpoint (pulls the case) —</option>" + "".join(
            f"<option value={e['id']}{' selected' if pb and pb['endpoint_id'] == e['id'] else ''}>"
            f"{esc(e['name'])} ({esc(e['method'])})</option>" for e in eps)
        check_rows_html = ""
        edit_checks = pb_checks + [{} for _ in range(3)]
        for i, c in enumerate(edit_checks):
            op_opts = "".join(
                f"<option value={k}{' selected' if c.get('op') == k else ''}>{v}</option>"
                for k, v in OPS.items())
            check_rows_html += f"""<div style='border:1px solid var(--line);
border-radius:10px;padding:10px 12px;margin-bottom:10px'>
<div style='display:flex;gap:8px'>
<input type=text name=path_{i} placeholder='field path (e.g. beneficiary.dob)'
 value="{esc(c.get('path', ''))}">
<select name=op_{i} style='max-width:170px'>{op_opts}</select>
<input type=text name=value_{i} placeholder="value or $.other.field"
 value="{esc(c.get('value', ''))}">
</div>
<input type=text name=cause_{i} placeholder='Cause when this matches'
 value="{esc(c.get('cause', ''))}">
<textarea name=steps_{i} rows=2 placeholder='Resolution steps, one per line'
 style='margin-bottom:0'>{esc(c.get('steps', ''))}</textarea></div>"""
        parts.append(f"""<div class=card><details>
<summary>Analyst: edit triage recipe{'' if pb else ' — none yet'}</summary>
<form method=post action="/x/{esc(norm)}/recipe" style="margin-top:12px;max-width:680px">
<select name=endpoint_id>{ep_opts}</select>
<textarea name=general_steps rows=3 placeholder="General resolution steps (fallback when no check matches), one per line">{esc(pb['general_steps'] if pb and pb['general_steps'] else '')}</textarea>
<div class=panehead style="margin-top:8px">Diagnostic checks — evaluated against the pulled case</div>
{check_rows_html}
<input type=text name=actor placeholder="Your initials" style="max-width:180px">
<button>Save recipe</button>
<p class=muted style="margin-top:10px;margin-bottom:0">Compare a field to a fixed
value, or to another field with <code>$.path</code> (e.g. value
<code>$.policy.effectiveDate</code>). Save with blank rows to add more.</p>
</form></details></div>""")

        parts.append(f"""<div class=card><details><summary>Analyst: curate this entry</summary>
<form method=post action="/x/{esc(norm)}/curate" style="margin-top:10px">
<input type=text name=meaning placeholder="Plain-language meaning"
 value="{esc(r['meaning'] or '')}">
<input type=text name=screen_id placeholder="Screen ID" value="{esc(r['screen_id'] or '')}">
<input type=text name=data_element placeholder="Field / data element"
 value="{esc(r['data_element'] or '')}">
<select name=category>{''.join(f"<option{' selected' if r['category']==c else ''}>{c}</option>"
                               for c in ('exception', 'alert', 'limitation'))}</select>
<input type=text name=actor placeholder="Your initials">
<button>Save as curated</button></form></details></div>""")
        if (r["status"] or "") != "dismissed":
            parts.append(
                f"<div class=card style='display:flex;align-items:center;"
                f"gap:14px'>"
                f"<form method=post style='margin:0' "
                f"action='/x/{urllib.parse.quote(r['normalized'])}/dismiss' "
                f"onsubmit=\"return confirm('Dismiss {esc(r['code'])} — not "
                f"a real code? It disappears from the catalog and app "
                f"screens; restore any time from this page.')\">"
                f"<button class=delbtn>Not a code — dismiss</button></form>"
                f"<span class=muted style='font-size:12.5px'>For mined "
                f"false positives — a domain value or paragraph name the "
                f"miner mistook for a code. Re-ingest will not resurrect "
                f"it.</span></div>")
        self._send("".join(parts), r["code"], q=code)

    def _app_delete(self, conn, app_id: str):
        try:
            aid = int(app_id)
        except ValueError:
            self._send("<div class=card>Bad application id.</div>", code=400)
            return
        app = conn.execute("SELECT * FROM application WHERE id = ?",
                           (aid,)).fetchone()
        if not app:
            self._redirect("/apps")
            return
        file_ids = [r["id"] for r in conn.execute(
            "SELECT id FROM source_file WHERE application_id = ?", (aid,))]
        prog_names = [r["name"] for r in conn.execute(
            """SELECT p.name FROM program p
               JOIN source_file f ON f.id = p.source_file_id
               WHERE f.application_id = ?""", (aid,))]
        doc_ids = [r["id"] for r in conn.execute(
            "SELECT id FROM document WHERE application_id = ?", (aid,))]
        # Mined evidence goes with its files; the exception CATALOG stays —
        # codes may be curated or shared. Links into this app's members go.
        for fid in file_ids:
            conn.execute("DELETE FROM exception_link WHERE"
                         " json_extract(detail,'$.file_id') = ?", (fid,))
            for t in ("line_fts", ):
                conn.execute(f"DELETE FROM {t} WHERE file_id = ?", (fid,))
            for t in ("data_item", "bms_field"):
                conn.execute(f"DELETE FROM {t} WHERE source_file_id = ?",
                             (fid,))
            for j in conn.execute(
                    "SELECT id FROM jcl_job WHERE source_file_id = ?",
                    (fid,)):
                conn.execute("DELETE FROM jcl_step WHERE job_id = ?",
                             (j["id"],))
            conn.execute("DELETE FROM jcl_job WHERE source_file_id = ?",
                         (fid,))
            for pr in conn.execute(
                    "SELECT id FROM program WHERE source_file_id = ?", (fid,)):
                conn.execute("DELETE FROM paragraph WHERE program_id = ?",
                             (pr["id"],))
                conn.execute("DELETE FROM program_facet WHERE program_id = ?",
                             (pr["id"],))
            conn.execute("DELETE FROM program WHERE source_file_id = ?",
                         (fid,))
        if prog_names:
            marks = ",".join("?" * len(prog_names))
            conn.execute(
                f"""DELETE FROM exception_link WHERE target_kind = 'program'
                    AND target_ref IN ({marks})""", tuple(prog_names))
        for did in doc_ids:
            conn.execute("DELETE FROM doc_section WHERE document_id = ?",
                         (did,))
            conn.execute("DELETE FROM exception_link WHERE"
                         " target_kind = 'document' AND target_ref = ?",
                         (str(did),))
        conn.execute("DELETE FROM document WHERE application_id = ?", (aid,))
        conn.execute("DELETE FROM source_file WHERE application_id = ?",
                     (aid,))
        conn.execute("DELETE FROM application WHERE id = ?", (aid,))
        conn.commit()
        self._redirect("/apps")

    def _code_merge(self, conn, norm: str, form):
        """Fold a duplicate catalog entry into its real identity. Moves the
        evidence (events, links, recipes), records the alias so FUTURE MI
        imports land on the survivor, optionally registers the reporting
        prefix so every other code wearing it resolves too."""
        src = conn.execute("SELECT * FROM exception_code WHERE normalized=?",
                           (norm,)).fetchone()
        into_code = form.get("into", "").strip()
        dst_id = db.resolve_exception(conn, into_code) if into_code else None
        if not src or dst_id is None or dst_id == src["id"]:
            self._redirect(f"/x/{urllib.parse.quote(norm)}")
            return
        for table in ("exception_event", "exception_link", "playbook"):
            conn.execute(f"UPDATE {table} SET exception_id=? WHERE"
                         f" exception_id=?", (dst_id, src["id"]))
        conn.execute("UPDATE code_alias SET exception_id=? WHERE"
                     " exception_id=?", (dst_id, src["id"]))
        conn.execute(
            """INSERT OR IGNORE INTO code_alias
               (alias, exception_id, source, created_at)
               VALUES (?, ?, 'merge', ?)""", (norm, dst_id, db.now()))
        conn.execute("DELETE FROM exception_code WHERE id=?", (src["id"],))
        pfx = form.get("declare_prefix", "").strip().upper()
        if pfx:
            app_id = int(form.get("prefix_app", 0) or 0)
            if app_id:
                conn.execute("UPDATE application SET mi_prefix = ?"
                             " WHERE id = ?", (pfx, app_id))
            else:
                conn.execute(
                    """INSERT OR IGNORE INTO code_prefix (prefix, note,
                       created_at) VALUES (?, ?, ?)""",
                    (pfx, f"declared during merge of {src['code']}",
                     db.now()))
        conn.commit()
        dst = conn.execute("SELECT normalized FROM exception_code WHERE id=?",
                           (dst_id,)).fetchone()
        self._redirect(f"/x/{urllib.parse.quote(dst['normalized'])}")

    def _code_cite(self, conn, norm: str, form):
        """SME attaches a policy/DFR section to a code by citation. If the
        citation text matches a section heading, the link binds to that
        exact section — deterministic convenience, not a guess."""
        r = conn.execute("SELECT * FROM exception_code WHERE normalized=?",
                         (norm,)).fetchone()
        did = int(form.get("doc_id", 0) or 0)
        doc = conn.execute("SELECT * FROM document WHERE id=?",
                           (did,)).fetchone()
        citation = form.get("citation", "").strip()
        if not r or not doc or not citation:
            self._redirect(f"/x/{urllib.parse.quote(norm)}")
            return
        sec = conn.execute(
            """SELECT id, heading, text FROM doc_section
               WHERE document_id=? AND heading LIKE ? LIMIT 1""",
            (did, f"%{citation}%")).fetchone()
        detail = {"doc_id": did, "doc_title": doc["title"],
                  "citation": citation,
                  "sme_note": form.get("sme_note", "").strip(),
                  "sme_by": form.get("sme_by", "").strip() or "SME"}
        if sec:
            detail["section_id"] = sec["id"]
            detail["heading"] = sec["heading"]
            detail["excerpt"] = (sec["text"] or "")[:400]
        else:
            detail["heading"] = citation
        db.add_link(conn, r["id"], "document", str(did), "governed_by",
                    detail=detail, confidence=1.0, provenance="sme")
        db.add_event(conn, r["id"], "curated", outcome="citation-added",
                     payload={"citation": citation, "doc": doc["title"]},
                     actor=detail["sme_by"])
        conn.commit()
        self._redirect(f"/x/{urllib.parse.quote(norm)}")

    def _link_annotate(self, conn, path: str, form):
        seg = path.split("/")
        norm, link_id = urllib.parse.unquote(seg[2]), int(seg[4])
        l = conn.execute("SELECT * FROM exception_link WHERE id=?",
                         (link_id,)).fetchone()
        if l:
            d = json.loads(l["detail"] or "{}")
            d["citation"] = form.get("citation", "").strip()
            d["sme_note"] = form.get("sme_note", "").strip()
            d.setdefault("sme_by", "SME")
            conn.execute("UPDATE exception_link SET detail=? WHERE id=?",
                         (json.dumps(d), link_id))
            db.add_event(conn, l["exception_id"], "curated",
                         outcome="annotated",
                         payload={"citation": d["citation"]}, actor="SME")
            conn.commit()
        self._redirect(f"/x/{urllib.parse.quote(norm)}")

    def _link_remove(self, conn, path: str):
        seg = path.split("/")
        norm, link_id = urllib.parse.unquote(seg[2]), int(seg[4])
        # only SME-added citations are removable — mined evidence is
        # dismissed at the CODE level, never silently deleted row by row
        conn.execute("DELETE FROM exception_link WHERE id=?"
                     " AND provenance='sme'", (link_id,))
        conn.commit()
        self._redirect(f"/x/{urllib.parse.quote(norm)}")

    def _prefix_shadow(self, conn, r):
        """(base_row, prefix) when this code looks like another entry
        wearing a reporting prefix — A2U804 over U804. A SUGGESTION for
        the analyst; nothing merges without their click."""
        compact = "".join(ch for ch in r["code"].upper() if ch.isalnum())
        for plen in (1, 2, 3):
            if len(compact) <= plen + 2:
                continue
            rest = compact[plen:]
            rid = None
            row = conn.execute(
                "SELECT * FROM exception_code WHERE normalized = ?",
                (db.normalize_code(rest),)).fetchone()
            if row and row["id"] != r["id"]:
                return row, compact[:plen]
        return None, None

    # ── the screen lab: edit BMS, watch the 3270 repaint ─────────────
    def _bms_lab(self, conn, qs):
        fid = int((qs or {}).get("file", ["0"])[0] or 0)
        f = conn.execute("SELECT * FROM source_file WHERE id = ? AND"
                         " kind = 'bms'", (fid,)).fetchone()
        if not f:
            self._send("<div class=card>Not a BMS file.</div>", code=404)
            return
        try:
            src = Path(f["path"]).read_text(errors="replace")
        except OSError:
            self._send(f"<div class=card>{esc(f['name'])} is no longer at "
                       f"{esc(f['path'])} — re-ingest it.</div>", code=404)
            return
        body = f"""{crumbs((f['name'], f'/file/{fid}'), here='Screen lab')}
<div class=wb>
<div class="wbtop bmsbar">
<span class=wbins>Insert</span>
<button class=wbbtn data-snip="label">Label</button>
<button class=wbbtn data-snip="input">Input field</button>
<button class=wbbtn data-snip="output">Output field</button>
<button class=wbbtn data-snip="message">Message line</button>
<span style='flex:1'></span>
<span class=wbhint><kbd>Ctrl</kbd><kbd>&#9166;</kbd> repaint now ·
otherwise the terminal follows your typing</span>
</div>
<div class=wbsplit>
<section class=wbpane id=bmsed>
<header class=wbph><span class=wbpt>Source</span>
<span class=wbpn>{esc(f['name'])}</span>
<span style='flex:1'></span>
<button id=fsed class=wbico title='Fullscreen editor'>&#9974;</button>
<button class='wbico bmsx' title='Close fullscreen'>&#10005;</button>
</header>
<div class=wbed>
<div id=gut></div>
<div class=wbtxt>
<div id=rule72></div>
<textarea id=bmsrc spellcheck=false wrap=off>{esc(src)}</textarea>
</div>
</div>
</section>
<section class=wbpane id=bmsprev>
<header class=wbph><span class=wbpt>Terminal</span>
<span class=wbpn>24&times;80</span>
<span style='flex:1'></span>
<label class=bmstog><input type=checkbox id=gridtog> grid</label>
<button id=fsbtn class=wbico title='Fullscreen terminal'>&#9974;</button>
<button class='wbico bmsx' title='Close fullscreen'>&#10005;</button>
</header>
<div class=wbtermwrap>
<div id=bmsout><div class=muted style='padding:30px;text-align:center'>
rendering&hellip;</div></div>
</div>
</section>
</div>
<div class=wbprob>
<header class=wbph><span class=wbpt>Problems</span>
<span id=probsum class=wbcounts></span>
<span style='flex:1'></span>
<span class=wbhint>click a problem to jump to its line</span></header>
<div id=bmsissues class=wbprobbody></div>
</div>
<div class=wbstatus>
<span class=wbst>BMS map</span>
<span class=wbst id=stmap></span>
<span style='flex:1'></span>
<span class=wbst>preview only &mdash; the ingested member is untouched</span>
<span id=lncol class=bmslncol>Ln 1, Col 1</span>
</div>
</div>
<details class=wbrules><summary>Rules of the board</summary>
<p style='margin:8px 0 0'>24 rows &times; 80 columns. POS names the
ATTRIBUTE byte, so the text starts one column later and a field needs
LENGTH+1 cells. Source text lives in columns 1&ndash;71 (the dashed
ruler); a mark in column 72 splices the next line from column 16.
INITIAL longer than LENGTH truncates; crossing column 80 wraps. To keep
an edit, save the member in your source system and re-upload.</p>
</details>
<script>
(function(){{
  var src = document.getElementById('bmsrc'),
      out = document.getElementById('bmsout'),
      issues = document.getElementById('bmsissues'),
      lncol = document.getElementById('lncol'),
      grid = document.getElementById('gridtog'),
      prev = document.getElementById('bmsprev'),
      gut = document.getElementById('gut'),
      rule = document.getElementById('rule72'),
      probsum = document.getElementById('probsum'),
      stmap = document.getElementById('stmap'),
      t = null, gutN = 0;
  var SNIPS = {{
    label:   "         DFHMDF POS=(1,2),LENGTH=10,ATTRB=ASKIP,COLOR=BLUE,       X\\n               INITIAL='LABEL :'\\n",
    input:   "FLDNAME  DFHMDF POS=(1,14),LENGTH=8,ATTRB=(UNPROT,IC),            X\\n               COLOR=TURQUOISE,HILIGHT=UNDERLINE\\n",
    output:  "FLDOUT   DFHMDF POS=(1,14),LENGTH=10,ATTRB=(ASKIP,BRT),           X\\n               COLOR=YELLOW\\n",
    message: "MSGFLD   DFHMDF POS=(23,2),LENGTH=70,ATTRB=(ASKIP,BRT),COLOR=RED\\n"
  }};
  document.querySelectorAll('[data-snip]').forEach(function(b) {{
    b.addEventListener('click', function() {{
      var v = src.value, pos = src.selectionStart,
          lineEnd = v.indexOf('\\n', pos);
      if (lineEnd < 0) lineEnd = v.length;
      var insert = SNIPS[b.dataset.snip];
      src.value = v.slice(0, lineEnd + 1) + insert + v.slice(lineEnd + 1);
      src.focus();
      src.selectionStart = src.selectionEnd = lineEnd + 1 + insert.length;
      gutter(); cursor(); schedule();
    }});
  }});
  function curLine() {{
    var v = src.value.slice(0, src.selectionStart);
    return {{ ln: v.split('\\n').length,
              col: v.length - v.lastIndexOf('\\n') }};
  }}
  function gutter() {{
    var n = src.value.split('\\n').length;
    if (n !== gutN) {{
      gutN = n;
      var h = '';
      for (var i = 1; i <= n; i++)
        h += '<div class=gl id=gl' + i + '>' + i + '</div>';
      gut.innerHTML = h;
      gut.scrollTop = src.scrollTop;
    }}
  }}
  function cursor() {{
    var c = curLine();
    lncol.textContent = 'Ln ' + c.ln + ', Col ' + c.col;
    lncol.className = 'bmslncol' + (c.col > 71 ? ' over' : '');
    var on = gut.querySelector('.gl.on');
    if (on) on.classList.remove('on');
    var g = document.getElementById('gl' + c.ln);
    if (g) g.classList.add('on');
  }}
  function counts() {{
    var e = issues.querySelectorAll('.lint-error').length,
        w = issues.querySelectorAll('.lint-warn').length,
        i = issues.querySelectorAll('.lint-info').length, h = '';
    if (e) h += '<span class=ce>&#10007; ' + e + '</span>';
    if (w) h += '<span class=cw>&#9888; ' + w + '</span>';
    if (i) h += '<span>&#183; ' + i + '</span>';
    if (!h) h = '<span class=cok>&#10003; clean</span>';
    probsum.innerHTML = h;
    var ph = out.querySelector('.panehead');
    stmap.textContent = ph ? ph.textContent : '';
  }}
  function applyGrid() {{
    var scr = out.querySelector('.g3270');
    if (!scr) return;
    scr.classList.toggle('gridon', grid.checked);
    if (grid.checked && !scr.querySelector('.g3grid')) {{
      var g = document.createElement('div');
      g.className = 'g3grid';
      for (var c = 10; c <= 80; c += 10) {{
        var d = document.createElement('div');
        d.className = 'g3v'; d.style.left = c + 'ch';
        d.setAttribute('data-c', c);
        g.appendChild(d);
      }}
      for (var r = 6; r <= 24; r += 6) {{
        var h = document.createElement('div');
        h.className = 'g3h'; h.style.top = ((r - 1) * 1.45) + 'em';
        h.setAttribute('data-r', r);
        g.appendChild(h);
      }}
      scr.appendChild(g);
    }}
  }}
  function paint() {{
    fetch('/bms/preview', {{method: 'POST', body: src.value}})
      .then(function(r) {{ return r.text(); }})
      .then(function(h) {{
        var split = h.indexOf('<!--screen-->');
        issues.innerHTML = split >= 0 ? h.slice(0, split) : '';
        out.innerHTML = split >= 0 ? h.slice(split + 13) : h;
        counts(); applyGrid();
      }})
      .catch(function() {{
        out.innerHTML = '<div class=muted style="padding:20px">preview '
          + 'unreachable — is the server still running?</div>';
      }});
  }}
  function schedule() {{ clearTimeout(t); t = setTimeout(paint, 500); }}
  src.addEventListener('input', function() {{
    gutter(); cursor(); schedule();
  }});
  ['keyup', 'click'].forEach(function(e) {{
    src.addEventListener(e, cursor);
  }});
  src.addEventListener('scroll', function() {{
    gut.scrollTop = src.scrollTop;
    rule.style.transform = 'translateX(' + (-src.scrollLeft) + 'px)';
  }});
  src.addEventListener('keydown', function(e) {{
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {{
      clearTimeout(t); paint();
    }}
  }});
  issues.addEventListener('click', function(ev) {{
    var r = ev.target.closest('[data-ln]');
    if (!r) return;
    var ln = +r.getAttribute('data-ln'),
        lines = src.value.split('\\n'), idx = 0;
    for (var i = 0; i < ln - 1 && i < lines.length; i++)
      idx += lines[i].length + 1;
    src.focus();
    src.setSelectionRange(idx, idx + (lines[ln - 1] || '').length);
    src.scrollTop = Math.max(0, (ln - 4) * 18);
    gutter(); cursor();
  }});
  grid.addEventListener('change', applyGrid);
  var ed = document.getElementById('bmsed');
  [['fsbtn', prev], ['fsed', ed]].forEach(function(pair) {{
    document.getElementById(pair[0]).addEventListener('click', function() {{
      if (document.fullscreenElement) {{ document.exitFullscreen(); }}
      else {{ pair[1].requestFullscreen(); }}
    }});
  }});
  document.querySelectorAll('.bmsx').forEach(function(b) {{
    b.addEventListener('click', function() {{ document.exitFullscreen(); }});
  }});
  gutter(); cursor(); paint();
}})();
</script>"""
        self._send(body, f"screen lab · {f['name']}")

    def _bms_preview(self, body: bytes):
        """Raw BMS text in, rendered screens (or a named parse error)
        out. Stateless; nothing is stored."""
        text = body.decode("utf-8", errors="replace")
        try:
            screens = bms_screens_from_text(text)
        except Exception as e:
            self._send_fragment(
                f"<!--screen--><div class=banner style='background:#f9e5e5;"
                f"color:#a63838;border-color:#e7c3c3'>parse error — "
                f"{esc(str(e))}</div>")
            return
        if not screens or not any(flds for _, _, flds in screens):
            self._send_fragment(
                "<!--screen--><div class=muted style='padding:20px'>no "
                "DFHMDF fields yet — the screen is empty.</div>")
            return
        finds = bms_lint(text, screens)
        ICON = {"error": "✗", "warn": "⚠", "info": "·"}
        if finds:
            rows = "".join(
                f"<div class='lintrow lint-{lv}' data-ln={ln}>"
                f"<span class=lms>{ICON[lv]}</span>"
                f"<span class=lml>Ln {ln}</span>"
                f"<span>{esc(msg)}</span></div>"
                for lv, ln, msg in finds[:12])
            more = (f"<div class=lintrow><span class=lms></span>"
                    f"<span class=lml></span><span>… {len(finds) - 12} "
                    f"more</span></div>" if len(finds) > 12 else "")
            lint_html = rows + more
        else:
            lint_html = "<div class=lintok>✓ no layout issues</div>"
        out = ""
        for mapset, label, flds in screens:
            named = sum(1 for x in flds if x["name"])
            out += (f"<div class=panehead style='margin:8px 0 6px'>"
                    f"{esc(label)}{' · ' + esc(mapset) if mapset else ''}"
                    f" · 24×80 · {named} input/output fields</div>"
                    f"<div class=screenwrap>"
                    f"{render_bms_screen(flds)}</div>")
        self._send_fragment(lint_html + "<!--screen-->" + out)

    def _send_fragment(self, html: str):
        data = html.encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    # ── the policy library: global reference, cited everywhere ────────
    def _policy(self, conn, qs, banner: str = ""):
        q = (qs or {}).get("q", [""])[0].strip()
        docs = conn.execute(
            """SELECT d.*, (SELECT COUNT(*) FROM doc_section s
                            WHERE s.document_id = d.id) AS sections
               FROM document d WHERE COALESCE(d.kind,'dfr') = 'policy'
               ORDER BY d.title""").fetchall()
        hits = {}
        if q:
            like = f"%{q}%"
            hits = {r["document_id"]: r["n"] for r in conn.execute(
                """SELECT s.document_id, COUNT(*) AS n FROM doc_section s
                   JOIN document d ON d.id = s.document_id
                   WHERE COALESCE(d.kind,'dfr') = 'policy'
                   AND (s.heading LIKE ? OR s.text LIKE ?)
                   GROUP BY s.document_id""", (like, like))}
            docs = [d for d in docs if d["id"] in hits]
        cites = {r["doc_id"]: r["n"] for r in conn.execute(
            """SELECT json_extract(l.detail,'$.doc_id') AS doc_id,
                      COUNT(DISTINCT l.exception_id) AS n
               FROM exception_link l WHERE l.target_kind = 'document'
               GROUP BY 1""")}
        rows = "".join(
            f"<tr><td><a href='/doc/{d['id']}'><b>{esc(d['title'])}</b></a>"
            f"<div class=muted style='font-size:12px'>{esc(d['doc_type'])}"
            f" · ingested {esc(d['ingested_at'][:10])}</div></td>"
            f"<td class=num>{d['sections']}</td>"
            f"<td class=num>{cites.get(d['id'], 0) or '—'}</td>"
            + (f"<td class=num>{hits[d['id']]} match"
               f"{'es' if hits[d['id']] != 1 else ''}</td>" if q else "")
            + "</tr>"
            for d in docs)
        upload = (
            f"<form id=plform method=post action='/policy/upload'"
            f" enctype='multipart/form-data'>"
            f"<input type=file id=plf name=files multiple style='display:none'>"
            f"<label class=drop id=pldrop for=plf style='width:100%'>"
            f"<b>Drop policy documents here</b>or click to browse<br>"
            f"<span id=pllbl>.pdf · .docx · .md · .txt — text-layer PDFs; "
            f"scans need OCR first</span></label></form>"
            """<script>
(function(){
  var i=document.getElementById('plf'),d=document.getElementById('pldrop'),
      l=document.getElementById('pllbl'),f=document.getElementById('plform');
  i.addEventListener('change',function(){
    if(i.files.length){l.textContent=i.files.length+' file(s) — ingesting…';f.submit();}});
  ['dragover','dragenter'].forEach(function(e){d.addEventListener(e,function(ev){
    ev.preventDefault();d.classList.add('over');});});
  ['dragleave','drop'].forEach(function(e){d.addEventListener(e,function(ev){
    ev.preventDefault();d.classList.remove('over');});});
  d.addEventListener('drop',function(ev){
    i.files=ev.dataTransfer.files;i.dispatchEvent(new Event('change'));});
})();
</script>""")
        self._send(
            banner
            + f"<div class=card><div class=cardhead><h1>Policy</h1>"
            f"<form method=get action='/policy' style='display:flex;gap:7px;"
            f"margin:0'><input name=q value='{esc(q)}' placeholder='search "
            f"policy text…' style='margin:0;width:240px;font-size:13px;"
            f"padding:7px 12px'>"
            f"<button class=btnsm2 style='padding:7px 14px'>Search</button>"
            + (f"<a class=btnsm2 style='padding:7px 12px' href='/policy'>"
               f"clear</a>" if q else "") + "</form></div>"
            f"<p class=muted style='margin-top:-2px'>The shop's operating "
            f"policy, GLOBAL — one section, one truth, cited from catalog "
            f"codes and recipes across every application. A section that "
            f"names a known code links to it automatically at ingest.</p>"
            f"<table><tr><th>Document</th><th class=num>Sections</th>"
            f"<th class=num>Codes citing</th>"
            + ("<th class=num>Search</th>" if q else "") + f"</tr>"
            f"{rows or '<tr><td colspan=4 class=muted>No policy yet — drop the first document below.</td></tr>'}"
            f"</table></div>"
            f"<div class=card><h2>Add policy</h2>{upload}</div>",
            "Policy")

    def _policy_upload(self, conn, form_files):
        results = []
        for fname, data in form_files:
            dest = self._artifact_dir("policy") / fname
            dest.write_bytes(data)
            results.append(ingest_paths(conn, [dest], app_id=None,
                                        doc_kind="policy")[0])
        conn.commit()
        errs = [r for r in results if r.get("error")]
        ok = len(results) - len(errs)
        banner = (f"<div class=banner>{ok} policy document"
                  f"{'s' if ok != 1 else ''} ingested.</div>" if ok else "")
        for e in errs:
            banner += (f"<div class=banner style='background:#f9e5e5;"
                       f"color:#a63838;border-color:#e7c3c3'>"
                       f"{esc(e['file'])}: {esc(e['error'])}</div>")
        self._policy(conn, {}, banner)

    def _artifact_dir(self, sub: str):
        d = Path(self.db_path).resolve().parent / "artifacts" / sub
        d.mkdir(parents=True, exist_ok=True)
        return d

    def _doc_kind(self, conn, form):
        """Reclassify a document. → policy detaches it from its
        application (global); → dfr requires choosing the owner."""
        did = int(form.get("id", 0) or 0)
        kind = form.get("kind", "")
        d = conn.execute("SELECT * FROM document WHERE id = ?",
                         (did,)).fetchone()
        if not d or kind not in ("policy", "dfr"):
            self._redirect("/policy")
            return
        if kind == "policy":
            conn.execute("UPDATE document SET kind='policy',"
                         " application_id=NULL WHERE id=?", (did,))
        else:
            app_id = int(form.get("application_id", 0) or 0)
            if not app_id:
                self._redirect(f"/doc/{did}")
                return
            conn.execute("UPDATE document SET kind='dfr',"
                         " application_id=? WHERE id=?", (app_id, did))
        conn.commit()
        self._redirect(f"/doc/{did}")

    # ── area seed maps: how the case fills an interface area ──────────

    def _area_fields(self, conn, area: str):
        """The elementary fields belonging to a mined 01-level area:
        rows in the same source file between this 01 and the next."""
        head = conn.execute(
            """SELECT di.source_file_id, di.lineno FROM data_item di
               WHERE di.name = ? AND di.level = 1
               ORDER BY di.source_file_id LIMIT 1""",
            (area,)).fetchone()
        if not head:
            return []
        nxt = conn.execute(
            """SELECT MIN(lineno) AS ln FROM data_item
               WHERE source_file_id = ? AND level = 1 AND lineno > ?""",
            (head["source_file_id"], head["lineno"])).fetchone()
        stop = nxt["ln"] if nxt and nxt["ln"] else 10 ** 9
        return conn.execute(
            """SELECT name, pic, level, occurs FROM data_item
               WHERE source_file_id = ? AND lineno > ? AND lineno < ?
                 AND pic IS NOT NULL AND pic != ''
               ORDER BY lineno""",
            (head["source_file_id"], head["lineno"], stop)).fetchall()

    def _known_areas(self, conn):
        return [r["name"] for r in conn.execute(
            """SELECT DISTINCT di.name FROM data_item di
               WHERE di.level = 1 AND di.pic IS NULL
                 AND EXISTS (SELECT 1 FROM data_item c
                             WHERE c.source_file_id = di.source_file_id
                               AND c.lineno > di.lineno
                               AND c.pic IS NOT NULL AND c.level > 1)
               ORDER BY di.name""")]

    def _vocab_card(self, conn) -> str:
        rows = "".join(
            f"<tr><td><code>{esc(v['pattern'])}</code></td>"
            f"<td><span class='dot d-{esc(v['category'])}'></span>"
            f"{esc(v['category'])}</td>"
            f"<td class=muted>{esc(v['note'] or '')}</td>"
            f"<td class=num><form method=post action='/settings/vocab/delete'"
            f" style='margin:0'>"
            f"<input type=hidden name=pattern value='{esc(v['pattern'])}'>"
            f"<button class=delbtn>remove</button></form></td></tr>"
            for v in conn.execute(
                "SELECT * FROM field_vocab ORDER BY pattern"))
        return (
            f"<div class=card><h2>Miner vocabularies</h2>"
            f"<p class=muted style='margin-top:-2px'>The shop's field names "
            f"say what a literal means: a value set into a field matching "
            f"one of these patterns is catalogued as that CATEGORY — a "
            f"status code or reason indicator, never an exception. The "
            f"programs that set it are linked as <code>set_by</code>.</p>"
            f"<table><tr><th>Field pattern</th><th>Category</th><th>Note"
            f"</th><th></th></tr>{rows}</table>"
            f"<form method=post action='/settings/vocab' style='display:flex;"
            f"gap:8px;margin-top:10px;flex-wrap:wrap'>"
            f"<input name=pattern placeholder='RFD' required "
            f"style='margin:0;max-width:120px;text-transform:uppercase'>"
            f"<select name=category style='margin:0;max-width:170px'>"
            f"<option value=suspension>suspension</option>"
            f"<option value=termination>termination</option>"
            f"<option value=indicator>indicator</option></select>"
            f"<input name=note placeholder='what these codes mean' "
            f"style='margin:0;flex:1;min-width:200px'>"
            f"<button>Add pattern</button></form>"
            f"<p class=muted style='margin:8px 0 0;font-size:12px'>"
            f"Applies at ingest — re-upload affected members after a "
            f"change to reclassify their codes.</p></div>")

    def _areas_card(self, conn) -> str:
        rows = conn.execute(
            """SELECT area, COUNT(*) AS n FROM area_map
               GROUP BY area ORDER BY area""").fetchall()
        mapped = {r["area"]: r["n"] for r in rows}
        chips = "".join(
            f"<a class=btnsm href='/settings/areamap?area="
            f"{urllib.parse.quote(a)}' style='margin:0 6px 6px 0'>"
            f"{esc(a)} · {n}</a>" for a, n in mapped.items())
        opts = "".join(f"<option value='{esc(a)}'>"
                       for a in self._known_areas(conn)
                       if a not in mapped)
        return (f"<div class=card><h2>Interface areas — seed maps</h2>"
                f"<p class=muted style='margin-top:-2px'>How the case JSON "
                f"fills an area when a run starts there. Owned by the "
                f"copybook's 01-level — applies wherever it appears.</p>"
                f"<div>{chips or '<span class=muted>none yet</span>'}</div>"
                f"<form method=get action='/settings/areamap' "
                f"style='display:flex;gap:8px;margin-top:10px'>"
                f"<input name=area list=arealist placeholder='EE-RECORD' "
                f"style='max-width:260px'><datalist id=arealist>{opts}"
                f"</datalist><button class=btnsm2>open</button></form>"
                f"</div>")

    def _areamap_screen(self, conn, qs, banner: str = ""):
        area = (qs or {}).get("area", [""])[0].strip().upper()
        rows = {r["cobol_field"]: r for r in conn.execute(
            "SELECT * FROM area_map WHERE area = ?", (area,))}
        fields = self._area_fields(conn, area)
        if not fields:
            self._send(banner + crumbs(("Settings", "/settings?tab=fields"),
                                       here="Area map")
                       + "<div class=card><h2>Unknown area</h2><p class=muted>"
                       + f"No mined 01-level named {esc(area)}. Ingest the "
                       + "copybook or program that declares it.</p></div>",
                       "area map")
            return
        body = ""
        for f in fields:
            m = rows.get(f["name"])
            path = m["json_path"] if m else ""
            fmt = (m["format"] or "") if m else ""
            sugg = suggest_format(conn, f["name"], "", "") if not fmt else ""
            opts = "".join(
                f"<option value='{v}'{' selected' if v == fmt else ''}>"
                f"{label}</option>" for v, label in FORMATS)
            hint = (f"<span class=fhint>suggested: {sugg}</span>"
                    if sugg and not m else "")
            state = ("<span class='badge resolved' style='margin-left:0'>"
                     "mapped</span>" if m and path else
                     "<span class=muted>—</span>")
            occ = f" ×{f['occurs']}" if (f["occurs"] or 1) > 1 else ""
            body += (f"<tr><td style='white-space:nowrap'>"
                     f"<code>{esc(f['name'])}</code>"
                     f"<div class=muted style='font-size:11.5px'>"
                     f"PIC {esc(f['pic'])}{occ}</div></td>"
                     f"<td>{state}</td>"
                     f"<td><form method=post action='/settings/areamap/set'"
                     f" style='display:flex;gap:6px;margin:0'>"
                     f"<input type=hidden name=area value='{esc(area)}'>"
                     f"<input type=hidden name=field value='{esc(f['name'])}'>"
                     f"<input name=path value='{esc(path)}' "
                     f"placeholder='claimant.dateOfBirth"
                     f"{' or periods[].start' if (f['occurs'] or 1) > 1 else ''}'"
                     f" style='min-width:230px'>"
                     f"<select name=format style='margin:0'>{opts}</select>"
                     f"<button class=btnsm2>save</button></form>{hint}</td>"
                     f"</tr>")
        mapped = sum(1 for f in fields if f["name"] in rows
                     and rows[f["name"]]["json_path"])
        self._send(
            banner + crumbs(("Settings", "/settings?tab=fields"),
                            here=area)
            + f"<div class=card><div class=cardhead>"
            + f"<h1>{esc(area)}</h1><span class=muted>{mapped} of "
            + f"{len(fields)} fields mapped</span></div>"
            + "<p class=muted style='margin-top:-2px'>How the case JSON "
            + "fills this interface area when a run starts here. Owned by "
            + "the area, not any application — it applies wherever this "
            + "copybook appears. A repeating group maps with "
            + "<code>[]</code>: <code>entitlementPeriods[].startDate</code>."
            + "</p><table><tr><th>Field</th><th></th>"
            + f"<th>Case JSON path · format</th></tr>{body}</table></div>",
            f"area map · {area}")

    def _areamap_set(self, conn, form):
        area = form.get("area", "").strip().upper()
        field = form.get("field", "").strip().upper()
        path = form.get("path", "").strip()
        fmt = form.get("format", "").strip()
        if not area or not field:
            self._redirect("/settings?tab=fields")
            return
        if not path:
            conn.execute("DELETE FROM area_map WHERE area=? AND cobol_field=?",
                         (area, field))
        else:
            conn.execute(
                """INSERT INTO area_map (area, cobol_field, json_path,
                       format, updated_by, updated_at)
                   VALUES (?,?,?,?,?,?)
                   ON CONFLICT(area, cobol_field) DO UPDATE SET
                       json_path=excluded.json_path,
                       format=excluded.format,
                       updated_by=excluded.updated_by,
                       updated_at=excluded.updated_at""",
                (area, field, path, fmt, "analyst", db.now()))
        conn.commit()
        self._redirect(f"/settings/areamap?area={urllib.parse.quote(area)}")

    # ── pre-flight: what will this case actually fill? ────────────────

    def _dig_case(self, case, path):
        """Display-only resolver mirroring the runner's path semantics."""
        if "[]" in path:
            head, _, leaf = path.partition("[]")
            cur = self._dig_case(case, head.rstrip("."))
            if not isinstance(cur, list):
                return None
            leaf = leaf.lstrip(".")
            vals = [self._dig_case(r, leaf) if leaf else r for r in cur]
            vals = [v for v in vals if v not in (None, "")]
            return vals or None
        cur = case
        for part in path.split("."):
            if not part:
                continue
            if not isinstance(cur, dict) or part not in cur:
                return None
            cur = cur[part]
        return cur

    def _cobrun_preflight(self, conn, form):
        try:
            case = json.loads(form.get("case") or "{}")
        except ValueError as e:
            case, err = {}, str(e)
        else:
            err = ""
        maps = conn.execute(
            "SELECT * FROM area_map ORDER BY area, cobol_field").fetchall()
        by_area: dict = {}
        for m in maps:
            by_area.setdefault(m["area"], []).append(m)
        blanks = 0
        cards = ""
        for area, rows in by_area.items():
            body = ""
            area_blank = 0
            for m in rows:
                v = self._dig_case(case, m["json_path"])
                if v in (None, "", []):
                    area_blank += 1
                    blanks += 1
                    state = ("<span class='badge failed' "
                             "style='margin-left:0'>BLANK</span>")
                    val = f"the case does not carry {esc(m['json_path'])}"
                elif isinstance(v, list):
                    state = ("<span class='badge resolved' "
                             "style='margin-left:0'>✓</span>")
                    val = f"{len(v)} occurrence{'s' if len(v) != 1 else ''}"
                else:
                    state = ("<span class='badge resolved' "
                             "style='margin-left:0'>✓</span>")
                    sv = str(v)
                    val = esc(sv[:38] + ("…" if len(sv) > 38 else ""))
                body += (f"<tr><td><code>{esc(m['cobol_field'])}</code></td>"
                         f"<td>{state}</td>"
                         f"<td class=muted>{val}</td>"
                         f"<td class=muted>{esc(m['format'] or 'text')}"
                         f"</td></tr>")
            head_badge = ("<span class='badge resolved'>all fill</span>"
                          if not area_blank else
                          f"<span class='badge alert'>{area_blank} blank"
                          f"</span>")
            cards += (f"<div class=card><div class=cardhead>"
                      f"<h2 style='margin:0'>{esc(area)}</h2>{head_badge}"
                      f"</div><table><tr><th>Field</th><th></th>"
                      f"<th>This case</th><th>Format</th></tr>{body}"
                      f"</table></div>")
        if not by_area:
            cards = ("<div class=card><p class=muted>No area seed maps "
                     "declared yet — map an interface area from "
                     "<a href='/settings?tab=fields'>Settings</a>.</p></div>")
        lead = (f"<div class=banner style='background:#f9e5e5;color:#a63838;"
                f"border-color:#e7c3c3'>Case JSON did not parse: {esc(err)}"
                f"</div>" if err else "")
        verdict = ("every mapped field fills from this case" if not blanks
                   else f"{blanks} mapped field{'s' if blanks != 1 else ''} "
                        f"will seed BLANK — a downstream blank-field "
                        f"exception starts here, not in the code")
        pl = form.get("pipeline_scope", "")
        back = ("/cobrun?pipeline=" + urllib.parse.quote(pl)) if pl \
            else "/cobrun"
        self._send(
            lead + crumbs(("cobrun", back), here="Pre-flight")
            + f"<div class=card><h1>Pre-flight</h1>"
            + f"<p style='margin:2px 0 0'>{verdict}.</p></div>" + cards,
            "cobrun · pre-flight")

    # ── launching a dry run ───────────────────────────────────────────
    _runs: dict = {}       # {token: result} — session only, never on disk

    def _cobrun_binary(self) -> str | None:
        """The runner, wherever this platform put it. Windows builds are
        cobrun.exe — a bare-name check finds nothing there, which cost a
        real Windows install its dry runs. The platform's own name is
        tried first so a zip carrying both binaries picks the right one."""
        root = Path(self.db_path).resolve().parent / "cobrun" / "target"
        names = (("cobrun.exe", "cobrun") if os.name == "nt"
                 else ("cobrun", "cobrun.exe"))
        for build in ("release", "debug"):
            for name in names:
                p = root / build / name
                if p.exists():
                    return str(p)
        return None

    def _source_text(self, conn, file_id: int) -> tuple[str, str]:
        """(name, raw text) read from where it was ingested. The parser needs
        real column positions, and line_fts holds normalized text — so the
        member is read from disk, and a moved file is a named error."""
        r = conn.execute("SELECT path, name FROM source_file WHERE id = ?",
                         (file_id,)).fetchone()
        if not r:
            raise FileNotFoundError("unknown source file")
        p = Path(r["path"])
        if not p.exists():
            raise FileNotFoundError(
                f"{r['name']} is no longer at {r['path']} — re-ingest it")
        return r["name"], p.read_text(errors="replace")

    def _run_request(self, conn, qs_or_form) -> dict:
        """Assemble everything cobrun needs from what ChatBIS already holds."""
        f = qs_or_form
        pipeline = (f.get("pipeline_scope", "").strip()
                    if f.get("mode") == "flow" else "")
        entry = f.get("entry", "").strip().upper()

        sources, copybooks = {}, {}
        for r in conn.execute(
                "SELECT f.id, f.name, f.kind, p.name AS pgm FROM source_file f"
                " LEFT JOIN program p ON p.source_file_id = f.id"
                " WHERE f.kind IN ('cobol','copybook')"):
            try:
                _, text = self._source_text(conn, r["id"])
            except FileNotFoundError:
                continue
            if r["kind"] == "copybook":
                copybooks[Path(r["name"]).stem.upper()] = text
            else:
                sources[(r["pgm"] or Path(r["name"]).stem).upper()] = text

        field_map = [dict(x) for x in conn.execute(
            "SELECT db2_column, json_path, format FROM field_map"
            " WHERE db2_column IS NOT NULL AND json_path IS NOT NULL")]
        stubs = [r["name"] for r in conn.execute("SELECT name FROM runner_stub")]

        req = {"sources": sources, "copybooks": copybooks,
               "field_map": field_map, "stubs": stubs,
               "options": {"budget": 500000}}

        case_text = f.get("case", "").strip()
        if case_text:
            try:
                req["case"] = json.loads(case_text)
            except ValueError as e:
                raise ValueError(f"case JSON: {e}")

        carry = [c.strip().upper() for c in f.get("carry", "").split(",")
                 if c.strip()]
        if carry:
            req["carry"] = carry

        req["area_maps"] = [
            {"area": r["area"], "field": r["cobol_field"],
             "path": r["json_path"], "format": r["format"] or "text"}
            for r in conn.execute("SELECT * FROM area_map")]

        datasets = {}
        for line in f.get("datasets", "").splitlines():
            if "=" in line:
                dsn, rec = line.split("=", 1)
                datasets.setdefault(dsn.strip().upper(), []).append(rec)
        if datasets:
            req["datasets"] = datasets

        seeds = {}
        for line in f.get("seeds", "").splitlines():
            if "=" in line:
                k, v = line.split("=", 1)
                seeds[k.strip().upper()] = v.strip()
        if seeds:
            req["ws"] = seeds

        if pipeline:
            job = conn.execute(
                """SELECT j.id FROM jcl_job j
                   JOIN jcl_step s ON s.job_id = j.id
                   JOIN program p ON p.name = s.pgm
                   JOIN source_file sf ON sf.id = p.source_file_id
                   JOIN application a ON a.id = sf.application_id
                   WHERE a.pipeline = ? GROUP BY j.id
                   ORDER BY COUNT(*) DESC LIMIT 1""", (pipeline,)).fetchone()
            if not job:
                raise ValueError(
                    f"no mined JCL runs {pipeline}'s programs — ingest the "
                    f"job member, or run a single program instead")
            req["steps"] = [
                {"step": s["step_name"], "pgm": s["pgm"], "gate": s["gate"],
                 "cond": s["cond"],
                 "dds": [d for d in json.loads(s["dds"]) if d.get("dsn")]}
                for s in conn.execute(
                    "SELECT * FROM jcl_step WHERE job_id = ? ORDER BY seq",
                    (job["id"],))]
        else:
            req["entry"] = entry
        return req

    def _cobrun_launch(self, conn, form):
        binary = self._cobrun_binary()
        if not binary:
            self._cobrun(conn, {"pipeline": [form.get("pipeline_scope", "")]},
                         "<div class=banner style='background:#f9e5e5;"
                         "color:#a63838;border-color:#e7c3c3'>cobrun is not "
                         "built — run <code>cargo build --release</code> in "
                         "the cobrun directory.</div>")
            return
        try:
            req = self._run_request(conn, form)
        except (ValueError, FileNotFoundError) as e:
            self._cobrun(conn, {"pipeline": [form.get("pipeline_scope", "")]},
                         f"<div class=banner style='background:#f9e5e5;"
                         f"color:#a63838;border-color:#e7c3c3'>{esc(str(e))}"
                         f"</div>")
            return
        t0 = time.time()
        try:
            proc = subprocess.run([binary], input=json.dumps(req),
                                  capture_output=True, text=True, timeout=60)
            out = json.loads(proc.stdout.strip().split("\n")[-1])
        except subprocess.TimeoutExpired:
            out = {"status": "halted",
                   "halt": {"reason": "cobrun exceeded 60s — the run was "
                                      "stopped, nothing was written"}}
        except (ValueError, IndexError) as e:
            out = {"status": "halted",
                   "halt": {"reason": f"cobrun produced no usable output: {e}"}}
        out["_ms"] = int((time.time() - t0) * 1000)
        out["_label"] = (form.get("pipeline_scope") if form.get("mode") == "flow"
                         else req.get("entry")) or "run"
        token = hashlib.sha1(
            f"{out['_label']}{time.time()}".encode()).hexdigest()[:10]
        # Case data lives in memory for this session only — same rule as the
        # Lab's pulled cases. Nothing here is written to chatbis.db.
        Handler._runs[token] = out
        self._redirect(f"/cobrun/trace?run={token}")

    # ── the trace ─────────────────────────────────────────────────────
    def _cobrun_trace(self, conn, qs):
        token = (qs or {}).get("run", [""])[0]
        r = Handler._runs.get(token)
        if not r:
            self._cobrun(conn, {},
                         "<div class=banner style='background:#fdf6dd;"
                         "color:#7a5d05;border-color:#efe1a8'>That run is no "
                         "longer in memory — runs are session-only. Launch "
                         "it again.</div>")
            return
        field = (qs or {}).get("field", [""])[0].strip().upper()
        trace = r.get("trace", [])

        V = {"completed": ("resolved", "COMPLETED"),
             "halted": ("alert", "HALTED"),
             "abended": ("failed", "ABENDED")}
        cls, lbl = V.get(r.get("status", ""), ("", r.get("status", "")))
        detail = ""
        if r.get("halt"):
            detail = esc(r["halt"].get("reason") or json.dumps(r["halt"]))
        elif r.get("abend"):
            a = r["abend"]
            detail = (f"{esc(a.get('code'))} at line {a.get('line')} — "
                      f"{esc(a.get('detail', ''))}")

        parts = [crumbs(("cobrun", "/cobrun"), here="Trace"),
                 f"<div class='verdict {'vgood' if cls == 'resolved' else 'vwarn' if cls == 'alert' else 'vbad'}'>"
                 f"<span class=vlabel>{lbl}</span>"
                 f"<div><b>{esc(r.get('_label', 'run'))}</b>"
                 f"<div class=vsub>{len(trace)} trace events · "
                 f"{r.get('_ms', 0)} ms"
                 f"{' · ' + detail if detail else ''}</div></div></div>"]

        parts.append(run_summary(conn, r))

        # Steps, when the run was a pipeline.
        if r.get("steps"):
            rows = ""
            for s in r["steps"]:
                m = {"completed": ("✓", "#1e6b3d"), "skipped": ("–", "#6b7789"),
                     "halted": ("✗", "#a63838"), "abended": ("✗", "#a63838")}
                mark, col = m.get(s["status"], ("·", "#6b7789"))
                note = (f"rc={s.get('rc')}" if s["status"] == "completed"
                        else s.get("why") or s.get("reason")
                        or s.get("detail", ""))
                if s.get("exceptions"):
                    note += f" · {s['exceptions']} exception(s)"
                rows += (f"<tr><td style='color:{col};font-weight:800;"
                         f"width:20px'>{mark}</td>"
                         f"<td><b>{esc(s['step'])}</b></td>"
                         f"<td>{esc(s['pgm'])}</td>"
                         f"<td class=muted>{esc(note)}</td></tr>")
            parts.append(f"<div class=card><h2>Steps</h2><table>{rows}"
                         f"</table></div>")

        if r.get("exceptions"):
            rows = "".join(
                f"<tr><td><a href='/x/{esc(db.normalize_code(e['code']))}'>"
                f"<b>{esc(e['code'])}</b></a></td>"
                f"<td>{esc(e['pgm'])}</td>"
                f"<td class=muted>{esc(e.get('field',''))} · line "
                f"{e.get('line')}</td></tr>" for e in r["exceptions"])
            parts.append(f"<div class=card><h2>Exceptions raised · "
                         f"{len(r['exceptions'])}</h2><table>{rows}</table>"
                         f"<p class=muted style='margin:10px 0 0'>Each code "
                         f"links to its catalog entry — the recipe, the DFR, "
                         f"the resolution steps.</p></div>")

        if r.get("writes"):
            rows = "".join(
                f"<tr><td>{esc(w['stmt'])}</td>"
                f"<td class=mono>{esc(w['column'])}</td>"
                f"<td class=mono>{esc(w['value'])}</td></tr>"
                for w in r["writes"])
            parts.append(f"<div class=card><h2>Would write · "
                         f"{len(r['writes'])}</h2><table><tr><th>Statement</th>"
                         f"<th>Column</th><th>Value</th></tr>{rows}</table>"
                         f"<p class=muted style='margin:10px 0 0'>Recorded, "
                         f"never performed. Nothing outside this process was "
                         f"touched.</p></div>")

        # Field history: every write to one field, the "who changed it" view.
        moves = [e for e in trace if e.get("kind") == "move"]
        names = sorted({e["field"].split("(")[0] for e in moves})
        if field:
            hits = [e for e in moves
                    if e["field"].split("(")[0] == field]
            rows = "".join(
                f"<tr><td class=muted style='white-space:nowrap'>"
                f"{esc(e['pgm'])}:{e['line']}</td>"
                f"<td class=mono>{esc(e['before'] or '·')} → "
                f"<b>{esc(e['after'])}</b></td>"
                f"<td class=muted>{esc(e['cause'])}</td>"
                f"<td>{self._src_link(conn, e['pgm'], e['line'])}</td></tr>"
                for e in hits)
            parts.append(
                f"<div class=card><div class=cardhead>"
                f"<h2 style='margin:0'>History of {esc(field)} · "
                f"{len(hits)} write{'s' if len(hits) != 1 else ''}</h2>"
                f"<a class=btnsm href='/cobrun/trace?run={esc(token)}'>"
                f"whole trace</a></div><table>{rows}</table>"
                f"<p class=muted style='margin:10px 0 0'>Every program and "
                f"line that changed this field, in order. This is the answer "
                f"to “who set that value”.</p></div>")

        opts = "".join(f"<option value='{esc(n)}'"
                       f"{' selected' if n == field else ''}>{esc(n)}</option>"
                       for n in names)
        parts.append(
            f"<div class=card><div class=cardhead>"
            f"<h2 style='margin:0'>Trace · {len(trace)} events</h2>"
            f"<form method=get action='/cobrun/trace' style='display:flex;"
            f"gap:8px;margin:0'>"
            f"<input type=hidden name=run value='{esc(token)}'>"
            f"<select name=field style='margin:0;max-width:230px'>"
            f"<option value=''>— follow a field —</option>{opts}</select>"
            f"<button>Follow</button></form></div>"
            + self._trace_body(conn, trace) + "</div>")
        self._send("".join(parts), "cobrun · trace")

    def _src_link(self, conn, pgm: str, line) -> str:
        r = conn.execute(
            "SELECT source_file_id FROM program WHERE name = ?",
            (pgm,)).fetchone()
        if not r or not line:
            return ""
        return (f"<a class=btnsm href='/file/{r['source_file_id']}?hl={line}'>"
                f"source</a>")

    def _trace_body(self, conn, trace) -> str:
        out, depth = [], 0
        for e in trace:
            k = e.get("kind")
            pad = f"padding-left:{depth * 18}px"
            if k == "step":
                out.append(
                    f"<div class=tstep><b>{esc(e.get('step',''))}</b> · "
                    f"{esc(e.get('pgm',''))} <span class=muted>"
                    f"{esc(e.get('status',''))}"
                    f"{' · ' + esc(e.get('why','')) if e.get('why') else ''}"
                    f"</span></div>")
            elif k == "move":
                out.append(
                    f"<div class=tev style='{pad}'>"
                    f"<span class=tloc>{esc(e['pgm'])}:{e['line']}</span>"
                    f"<code>{esc(e['field'])}</code> "
                    f"<span class=muted>{esc(e['before'] or '·')} →</span> "
                    f"<b>{esc(e['after'])}</b> "
                    f"<span class=muted>({esc(e['cause'])})</span></div>")
            elif k == "branch":
                out.append(
                    f"<div class=tev style='{pad}'>"
                    f"<span class=tloc>{esc(e['pgm'])}:{e['line']}</span>"
                    f"<span class=muted>branch →</span> "
                    f"<b>{'true' if e['outcome'] else 'false'}</b></div>")
            elif k == "call":
                out.append(
                    f"<div class=tev style='{pad}'>"
                    f"<span class=tloc>{esc(e['pgm'])}:{e['line']}</span>"
                    f"<b>CALL {esc(e['target'])}</b> "
                    f"<span class='badge {'alert' if e.get('resolution') == 'stub' else 'reprocessed'}'>"
                    f"{esc(e.get('resolution',''))}</span> "
                    f"<span class=muted>{esc(e.get('via',''))}</span></div>")
                if e.get("resolution") != "stub":
                    depth += 1
            elif k == "return":
                depth = max(0, depth - 1)
                out.append(f"<div class=tev style='{pad}'><span class=muted>"
                           f"↩ returned from {esc(e.get('from',''))}</span></div>")
            elif k == "sql":
                extra = (e.get("columns") or e.get("would_write")
                         or e.get("cursor") or "")
                out.append(
                    f"<div class=tev style='{pad}'>"
                    f"<span class=tloc>{esc(e['pgm'])}:{e['line']}</span>"
                    f"<span class='badge limitation'>SQL "
                    f"{esc(e.get('op',''))}</span> "
                    f"<span class=mono>{esc(str(extra)[:120])}</span>"
                    f"{' <span class=muted>sqlcode=' + str(e['sqlcode']) + '</span>' if 'sqlcode' in e else ''}"
                    f"</div>")
            elif k == "file":
                out.append(
                    f"<div class=tev style='{pad}'>"
                    f"<span class=tloc>{esc(e['pgm'])}:{e['line']}</span>"
                    f"<span class='badge imported'>{esc(e.get('op',''))}</span> "
                    f"<code>{esc(e.get('file',''))}</code> "
                    f"<span class=muted>{esc(e.get('dsn',''))}"
                    f"{' · at end' if e.get('at_end') else ''}"
                    f"{' · ' + esc(e.get('preview','')) if e.get('preview') else ''}"
                    f"</span></div>")
            elif k == "seed":
                blank = e.get("blank") or []
                btxt = (" · <span style='color:#a63838'>blank: "
                        + ", ".join(esc(b) for b in blank) + "</span>"
                        if blank else "")
                out.append(
                    f"<div class=tev style='{pad}'>"
                    f"<span class=tloc>{esc(e.get('pgm',''))}</span>"
                    f"<span class='badge imported'>seed</span> "
                    f"<code>{esc(e.get('area',''))}</code> "
                    f"<span class=muted>{e.get('filled')} field(s) from "
                    f"the case{btxt}</span></div>")
            elif k == "carry":
                out.append(
                    f"<div class=tev style='{pad}'>"
                    f"<span class=tloc></span>"
                    f"<span class='badge reprocessed'>carry</span> "
                    f"<code>{esc(e.get('area',''))}</code> "
                    f"<span class=muted>→ {esc(e.get('into',''))} · "
                    f"{e.get('bytes')} bytes</span></div>")
            elif k == "exception":
                out.append(
                    f"<div class='tev texc' style='{pad}'>"
                    f"<span class=tloc>{esc(e['pgm'])}:{e['line']}</span>"
                    f"⚠ <b><a href='/x/{esc(db.normalize_code(e['code']))}'>"
                    f"{esc(e['code'])}</a></b> "
                    f"<span class=muted>into {esc(e.get('field',''))}</span>"
                    f"</div>")
            elif k == "display":
                out.append(
                    f"<div class=tev style='{pad}'>"
                    f"<span class=tloc>{esc(e['pgm'])}:{e['line']}</span>"
                    f"<span class=muted>DISPLAY</span> {esc(e.get('text',''))}"
                    f"</div>")
            elif k == "note":
                out.append(f"<div class='tev muted' style='{pad}'>"
                           f"note · {esc(e.get('text',''))}</div>")
        return f"<div class=tracebox>{''.join(out)}</div>"

    # ── cobrun: the run surface, and what still blocks a run ──────────
    def _cobrun_scope(self, conn, qs):
        """(programs, label) — everything, or one pipeline's / app's."""
        pipeline = (qs or {}).get("pipeline", [""])[0].strip()
        app = (qs or {}).get("app", [""])[0].strip()
        sql = """SELECT p.id, p.name, f.id AS file_id, a.name AS app_name,
                        a.id AS app_id, a.pipeline, a.stage_seq
                 FROM program p
                 JOIN source_file f ON f.id = p.source_file_id
                 LEFT JOIN application a ON a.id = f.application_id"""
        args: list = []
        label = "the whole corpus"
        if pipeline:
            sql += " WHERE a.pipeline = ?"
            args.append(pipeline)
            label = pipeline
        elif app:
            sql += " WHERE a.name = ?"
            args.append(app)
            label = app
        sql += " ORDER BY a.stage_seq IS NULL, a.stage_seq, p.name"
        return conn.execute(sql, tuple(args)).fetchall(), label

    def _cobrun_worklist(self, conn, progs) -> dict:
        """Readiness for many programs, DEDUPLICATED into acquisition
        items. Twelve programs calling EXCEPTRN is one errand, not twelve —
        that difference is the whole reason this view exists."""
        need: dict = {k: {} for k in
                      ("copybook", "program", "column", "format", "mapset",
                       "dynamic", "areamap")}
        mapped_areas = {r["area"] for r in conn.execute(
            "SELECT DISTINCT area FROM area_map")}
        area_cache: dict = {}
        verdicts = {"ready": [], "advisory": [], "blocked": []}
        memo = _gen_memo(conn)
        scope_key = tuple(sorted(p["id"] for p in progs))
        if scope_key in memo["worklist"]:
            return memo["worklist"][scope_key]
        fmt_of = {(x["db2_column"] or "").upper(): (x["format"] or "")
                  for x in conn.execute(
                      "SELECT db2_column, format FROM field_map"
                      " WHERE db2_column IS NOT NULL")}
        for p in progs:
            r = self._readiness(conn, p)
            verdicts[r["verdict"]].append(p)
            for name, fid in r["copies"]:
                if not fid:
                    need["copybook"].setdefault(name, set()).add(p["name"])
                    continue
                if fid not in area_cache:
                    area_cache[fid] = [x["name"] for x in conn.execute(
                        "SELECT name FROM data_item WHERE source_file_id=?"
                        " AND level=1 AND (pic IS NULL OR pic='')",
                        (fid,))]
                for area in area_cache[fid]:
                    if area not in mapped_areas:
                        need["areamap"].setdefault(area, set()).add(
                            p["name"])
            for t, st, _, caller in r["calls"]:
                if st == "missing":
                    need["program"].setdefault(t, set()).add(caller)
                elif st == "dynamic-unresolved":
                    need["dynamic"].setdefault(t, set()).add(caller)
            for col, pr, mapped in r["sql_reads"]:
                if not mapped:
                    need["column"].setdefault(col, set()).add(pr)
                elif not fmt_of.get(col.upper()):
                    need["format"].setdefault(col, set()).add(pr)
            for m, ok in r["maps"]:
                if not ok:
                    need["mapset"].setdefault(m, set()).add(p["name"])
        result = {"need": need, "verdicts": verdicts}
        memo["worklist"][scope_key] = result
        return result

    def _cobrun(self, conn, qs, banner: str = ""):
        """Pipelines first; drill into one to see its stages, their business
        functions, and exactly what each is missing. Green means runnable."""
        if (qs or {}).get("pipeline") or (qs or {}).get("app"):
            return self._cobrun_scoped(conn, qs, banner)

        rows = ""
        pipes = [r["pipeline"] for r in conn.execute(
            "SELECT DISTINCT pipeline FROM application"
            " WHERE pipeline IS NOT NULL ORDER BY pipeline")]
        for pl in pipes:
            progs = conn.execute(PROG_SQL + " WHERE a.pipeline = ?",
                                 (pl,)).fetchall()
            rows += self._cobrun_row(
                conn, pl, progs,
                f"/cobrun?pipeline={urllib.parse.quote(pl)}",
                sub=f"{len({p['app_name'] for p in progs})} applications")
        loose = conn.execute(
            PROG_SQL + " WHERE a.pipeline IS NULL ORDER BY a.name").fetchall()
        by_app: dict = {}
        for p in loose:
            by_app.setdefault(p["app_name"] or "(no application)", []).append(p)
        for app, progs in sorted(by_app.items()):
            rows += self._cobrun_row(
                conn, app, progs,
                f"/cobrun?app={urllib.parse.quote(app)}",
                sub="standalone")

        body = (f"{banner}<div class=card><h1>cobrun</h1>"
                f"<p class=muted style='margin-top:-2px'>A dry run needs a "
                f"program's whole closure in the corpus — its copybooks, "
                f"everything it calls, a mapping for every column it reads. "
                f"Pick a pipeline to see which of its business functions are "
                f"ready and what the rest are waiting on.</p></div>"
                f"<div class=card><table><tr><th>Flow</th>"
                f"<th class=num>Runnable</th><th>Readiness</th>"
                f"<th class=num>To do</th><th></th></tr>{rows}</table></div>")
        self._send(body, "cobrun")

    def _cobrun_row(self, conn, name, progs, href, sub="") -> str:
        wl = self._cobrun_worklist(conn, progs)
        v = wl["verdicts"]
        n = len(progs)
        ok = len(v["ready"]) + len(v["advisory"])
        items = sum(len(d) for d in wl["need"].values())
        pct = round(100 * ok / n) if n else 0
        cls = "green" if items == 0 else ("gold" if ok else "")
        chip = ("<span class='badge resolved'>all runnable</span>"
                if items == 0 else "")
        return (f"<tr><td><a href='{href}'><b>{esc(name)}</b></a>{chip}"
                f"{'<div class=muted style=font-size:12.5px>' + esc(sub) + '</div>' if sub else ''}</td>"
                f"<td class=num>{ok} of {n}</td>"
                f"<td style='width:200px'><div class=track style='margin:0'>"
                f"<div class='fill {cls}' style='width:{pct}%'></div></div></td>"
                f"<td class=num>{items if items else '—'}</td>"
                f"<td style='text-align:right'><a class=btnsm href='{href}'>"
                f"{'Open' if items == 0 else "What's missing"} →</a></td></tr>")

    def _cobrun_scoped(self, conn, qs, banner: str = ""):
        progs, label = self._cobrun_scope(conn, qs)
        wl = self._cobrun_worklist(conn, progs)
        v = wl["verdicts"]
        verdict_of = {}
        for k, lst in v.items():
            for p in lst:
                verdict_of[p["name"]] = k
        n = len(progs)
        ok = len(v["ready"]) + len(v["advisory"])
        items = sum(len(d) for d in wl["need"].values())

        # Group by application — a pipeline's stages, in order.
        stages: dict = {}
        for p in progs:
            stages.setdefault((p["stage_seq"] if p["stage_seq"] is not None
                               else 10 ** 6, p["app_name"] or "—"), []).append(p)

        cards = ""
        for (_, app), members in sorted(stages.items()):
            blocked = [m for m in members if verdict_of[m["name"]] == "blocked"]
            head_cls = "resolved" if not blocked else "failed"
            head_lbl = ("all runnable" if not blocked
                        else f"{len(blocked)} of {len(members)} blocked")
            body = ""
            for m in members:
                verdict = verdict_of[m["name"]]
                r = self._readiness(conn, m)
                mark = {"ready": ("✓", "#1e6b3d"), "advisory": ("!", "#8a6410"),
                        "blocked": ("✗", "#a63838")}[verdict]
                missing = ""
                if r["blockers"] or r["advisories"]:
                    missing = "".join(
                        f"<span class='miss {'blk' if b in r['blockers'] else 'adv'}'>"
                        f"{esc(b)}</span>"
                        for b in (r["blockers"] + r["advisories"])[:6])
                body += (f"<div class=bfrow>"
                         f"<span class=bfmark style='color:{mark[1]}'>{mark[0]}</span>"
                         f"<div style='flex:1;min-width:0'>"
                         f"<a href='/prog/{m['id']}'><b>{esc(m['name'])}</b></a>"
                         f"{'<div class=missrow>' + missing + '</div>' if missing else '<div class=muted style=font-size:12px>closure complete</div>'}"
                         f"</div></div>")
            cards += (f"<div class=card><div class=cardhead>"
                      f"<h2 style='margin:0'>{esc(app)}</h2>"
                      f"<span class='badge {head_cls}' style='margin-left:0'>"
                      f"{head_lbl}</span></div>{body}</div>")

        pct = round(100 * ok / n) if n else 0
        head = (f"{banner}{crumbs(('cobrun', '/cobrun'), here=label)}"
                f"<div class=card><div class=cardhead><h1>{esc(label)}</h1>"
                f"<span class=muted>{ok} of {n} business functions runnable"
                f"</span></div>"
                f"<div class=track style='margin:10px 0 0'>"
                f"<div class='fill {'green' if items == 0 else 'gold'}' "
                f"style='width:{pct}%'></div></div></div>")

        # ── launch ────────────────────────────────────────────────
        pl = (qs or {}).get("pipeline", [""])[0]
        entry_opts = "".join(
            f"<option value='{esc(p['name'])}'>{esc(p['name'])}"
            f"{' — ' + esc(p['app_name']) if p['app_name'] else ''}</option>"
            for p in progs if verdict_of[p["name"]] != "blocked")
        has_job = bool(pl and conn.execute(
            """SELECT 1 FROM jcl_step s JOIN program p ON p.name = s.pgm
               JOIN source_file f ON f.id = p.source_file_id
               JOIN application a ON a.id = f.application_id
               WHERE a.pipeline = ? LIMIT 1""", (pl,)).fetchone())
        whole = (f"<label class=flabel><input type=radio name=mode value=flow "
                 f"checked style='width:auto;margin-right:7px'>Run the whole "
                 f"flow — {esc(pl)}'s mined JCL, steps and gates</label>"
                 if has_job else "")
        am = conn.execute(
            "SELECT area, COUNT(*) AS n FROM area_map GROUP BY area"
            " ORDER BY area").fetchall()
        seed_note = (" · ".join(
            f"<a href='/settings/areamap?area={urllib.parse.quote(r['area'])}'>"
            f"{esc(r['area'])}</a> ({r['n']})" for r in am)
            + " — mapped areas fill from the case automatically"
            if am else
            "no area maps declared — <a href='/settings?tab=fields'>map an "
            "interface area</a> and runs seed themselves from the case")
        launch = (f"""<div class=card><h2>Launch a dry run</h2>
<form method=post action='/cobrun/run'>
<input type=hidden name=pipeline_scope value="{esc(pl)}">
{whole}
<label class=flabel style='margin-top:6px'>
<input type=radio name=mode value=one{'' if has_job else ' checked'}
 style='width:auto;margin-right:7px'>Run one business function</label>
<select name=entry style='max-width:340px'>{entry_opts}</select>
<div style='margin-top:10px'><label class=flabel>Auto-seed</label>
<div class=muted style='font-size:12.5px'>{seed_note}</div></div>
<div style='margin-top:10px'><label class=flabel>Carry areas
<span class=opt>01-level names, comma separated</span></label>
<input name=carry value="TDA-RECORD, PDA-RECORD" style='max-width:340px'>
<span class=fhint>State the host passes between steps (the TDAIO seam).
Each handoff is traced; an empty list means every step starts cold.</span>
</div>
<div class=frow>
<div><label class=flabel>Case data (JSON)</label>
<textarea name=case rows=6 placeholder='{{"claimant": {{"ssn": "…"}}}}'
></textarea>
<span class=fhint>The snapshot serves every SQL read, through the field
map. Held in memory for this session only — never written to disk.</span>
</div>
<div><label class=flabel>Seed fields <span class=opt>NAME=value per line</span></label>
<textarea name=seeds rows=6 placeholder='IN-SSN=900010002&#10;IN-DOB=1958-04-02'
></textarea>
<span class=fhint>Lands in whichever program declares the field — this is
how the transaction under test enters the flow.</span></div>
</div>
<div style='margin-top:10px'><label class=flabel>Input datasets
<span class=opt>DSN=record text, one per line</span></label>
<textarea name=datasets rows=2 placeholder='PROD.DAILY.TRANS=900010002A…'
></textarea></div>
<button>Run &rarr;</button>
<button formaction='/cobrun/preflight' formmethod=post
 class=btnsm2 style='margin-left:8px;padding:9px 16px'>Pre-flight — what
 will this case fill?</button>
<span class=muted style='margin-left:10px'>{'' if self._cobrun_binary() else 'cobrun is not built — cargo build --release'}</span>
</form></div>""")

        work = ""
        if items:
            GROUPS = [
                ("copybook", "Ingest copybooks",
                 "The layout IS the storage — a missing copybook cannot be "
                 "worked around.", True),
                ("program", "Ingest — or stub — called programs",
                 "Stub the ones the interpreter should never enter; stubbed "
                 "calls stay visible in the trace.", True),
                ("column", "Map DB2 columns",
                 "Each column a program reads needs a JSON path in the case "
                 "data.", False),
                ("format", "Declare formats",
                 "Mapped, but no shape: a date will not convert without one.",
                 False),
                ("mapset", "Ingest BMS mapsets",
                 "RECEIVE MAP needs the screen's fields.", False),
                ("dynamic", "Resolve dynamic calls",
                 "The target is a variable and no MOVE of a literal into it "
                 "was found.", False),
                ("areamap", "Declare area seed maps",
                 "How the case fills each interface area. Optional for "
                 "pipeline runs (carry covers them) — required to enter a "
                 "business function standalone.", False),
            ]
            work = (f"<div class=card><div class=cardhead>"
                    f"<h2 style='margin:0'>Everything this flow needs · "
                    f"{items} item{'s' if items != 1 else ''}</h2>"
                    f"<span class=muted>deduplicated · ordered by how many "
                    f"programs each unblocks</span></div>"
                    + "".join(self._need_group(k, t, w, st,
                                               wl["need"][k], qs)
                              for k, t, w, st in GROUPS if wl["need"][k])
                    + "</div>")
        self._send(head + launch + cards + work, f"cobrun · {label}")

    def _need_group(self, kind, title, why, stubbable, items, qs) -> str:
        back = "/cobrun"
        pl = (qs or {}).get("pipeline", [""])[0]
        if pl:
            back += "?pipeline=" + urllib.parse.quote(pl)
        rows = ""
        for name, users in sorted(items.items(),
                                  key=lambda kv: (-len(kv[1]), kv[0])):
            who = ", ".join(sorted(users)[:4])
            more = f" +{len(users) - 4}" if len(users) > 4 else ""
            act = ""
            if stubbable and kind == "program":
                act = (f"<form method=post action='/stub' style='display:inline'>"
                       f"<input type=hidden name=name value='{esc(name)}'>"
                       f"<input type=hidden name=back value='{esc(back)}'>"
                       f"<button class=btnsm2>mark stub</button></form>")
            elif kind in ("column", "format"):
                act = (f"<a class=btnsm2 href='/settings?tab=fields'>"
                       f"{'map it' if kind == 'column' else 'set format'}</a>")
            elif kind == "areamap":
                act = (f"<a class=btnsm2 href='/settings/areamap?area="
                       f"{urllib.parse.quote(name)}'>map the area</a>")
            rows += (f"<tr><td style='white-space:nowrap'>"
                     f"<code>{esc(name)}</code></td>"
                     f"<td class=num><b>{len(users)}</b></td>"
                     f"<td class=muted>{esc(who)}{more}</td>"
                     f"<td style='text-align:right'>{act}</td></tr>")
        return (f"<div style='margin-bottom:20px'>"
                f"<div class=panehead style='margin-bottom:2px'>{title} · "
                f"{len(items)}</div>"
                f"<p class=muted style='margin:0 0 6px'>{why}</p>"
                f"<table><tr><th>Item</th><th class=num>Programs</th>"
                f"<th>Needed by</th><th></th></tr>{rows}</table></div>")

    def _readiness_strip(self, conn, progs, href: str) -> str:
        """One line for the pipeline / application screens."""
        if not progs:
            return ""
        wl = self._cobrun_worklist(conn, progs)
        v = wl["verdicts"]
        n = len(progs)
        runnable = len(v["ready"]) + len(v["advisory"])
        items = sum(len(d) for d in wl["need"].values())
        cls = ("resolved" if items == 0 else
               "alert" if runnable > n / 2 else "failed")
        return (f"<div class=card style='padding:13px 18px;display:flex;"
                f"align-items:center;gap:14px'>"
                f"<span class='badge {cls}' style='margin-left:0'>DRY RUN</span>"
                f"<div><b>{runnable} of {n} programs runnable</b>"
                f"<div class=muted style='font-size:12.5px'>"
                f"{items} acquisition item{'s' if items != 1 else ''} "
                f"outstanding</div></div>"
                f"<a class=btnsm href='{href}' style='margin-left:auto'>"
                f"What's missing →</a></div>")

    # ── dry-run readiness: the closure, checked ───────────────────────
    def _copy_closure(self, conn, file_id: int) -> list:
        """Transitive copybook needs of one source file: [(name, resolved
        file_id | None)]. Copybooks have no program row, so nested COPYs
        are read from their indexed lines. Memoized per corpus generation —
        shared copybooks were being re-walked once per program."""
        memo = _gen_memo(conn)
        if file_id in memo["copy"]:
            return memo["copy"][file_id]
        graph = _copy_graph(conn, memo)
        if memo.get("bookfiles") is None:
            memo["bookfiles"] = {}
            for r in conn.execute(
                    "SELECT id, name FROM source_file"
                    " WHERE kind IN ('copybook','bms')"):
                stem = r["name"].rsplit(".", 1)[0].upper()
                memo["bookfiles"].setdefault(stem, r["id"])
                memo["bookfiles"].setdefault(r["name"].upper(), r["id"])
        books = memo["bookfiles"]
        out, seen, queue = [], set(), [file_id]
        while queue:
            fid = queue.pop()
            for name in graph.get(fid, ()):
                if name in seen:
                    continue
                seen.add(name)
                hit = books.get(name)
                out.append((name, hit))
                if hit:
                    queue.append(hit)
        memo["copy"][file_id] = out
        return out

    def _call_closure(self, conn, prog_name: str) -> list:
        """Transitive CALL/LINK targets from one entry program:
        [(target, status, via, caller)] where status ∈ resolved | stubbed |
        missing | dynamic-unresolved. Dynamic calls resolve through a
        MOVE-'literal' load site when one exists in the corpus."""
        memo = _gen_memo(conn)
        if prog_name in memo["call"]:
            return memo["call"][prog_name]
        movelit = _move_literal_index(conn, memo)
        stubs = {r["name"] for r in conn.execute("SELECT name FROM runner_stub")}
        progs = {r["name"]: r["id"] for r in conn.execute(
            "SELECT name, id FROM program")}
        out, seen, queue = [], set(), [prog_name]
        while queue:
            cur = queue.pop()
            pid = progs.get(cur)
            if pid is None:
                continue
            for c in conn.execute(
                    "SELECT ref, detail FROM program_facet WHERE program_id = ?"
                    " AND kind = 'call'", (pid,)):
                d = json.loads(c["detail"] or "{}")
                tgt, via = c["ref"], "static"
                if d.get("dynamic"):
                    lit = movelit.get(tgt.upper())
                    if lit:
                        tgt, via = lit, f"dynamic via {c['ref']}"
                    else:
                        if (c["ref"], cur) not in seen:
                            seen.add((c["ref"], cur))
                            out.append((c["ref"], "dynamic-unresolved",
                                        "dynamic", cur))
                        continue
                if (tgt, cur) in seen:
                    continue
                seen.add((tgt, cur))
                if tgt in progs:
                    out.append((tgt, "resolved", via, cur))
                    queue.append(tgt)
                elif tgt in stubs:
                    out.append((tgt, "stubbed", via, cur))
                else:
                    out.append((tgt, "missing", via, cur))
        memo["call"][prog_name] = out
        return out

    def _readiness(self, conn, p) -> dict:
        """Everything cobrun would need to run this program, checked against
        what the corpus actually holds. Every missing item is a concrete
        acquisition task, not a vibe. Memoized per corpus generation — this
        walks closures and was being recomputed for every program on every
        page view."""
        memo = _gen_memo(conn)
        if p["id"] in memo["ready"]:
            return memo["ready"][p["id"]]
        copies = self._copy_closure(conn, p["file_id"])
        calls = self._call_closure(conn, p["name"])
        closure_progs = [p["name"]] + [t for t, st, _, _ in calls
                                       if st == "resolved"]
        # Resolved callees' copybooks join the need list.
        for t, st, _, _ in calls:
            if st != "resolved":
                continue
            r = conn.execute(
                "SELECT source_file_id FROM program WHERE name = ?",
                (t,)).fetchone()
            if r:
                have = {n for n, _ in copies}
                copies += [(n, fid) for n, fid in
                           self._copy_closure(conn, r["source_file_id"])
                           if n not in have]

        marks = ",".join("?" * len(closure_progs))
        # SQL reads across the closure vs the field map.
        mapped_cols = {(r["db2_column"] or "").upper()
                       for r in conn.execute(
                           "SELECT db2_column FROM field_map"
                           " WHERE db2_column IS NOT NULL")}
        sql_reads = []
        for r in conn.execute(
                f"""SELECT pf.detail, p2.name AS prog FROM program_facet pf
                    JOIN program p2 ON p2.id = pf.program_id
                    WHERE pf.kind = 'sqlmap' AND p2.name IN ({marks})
                    AND json_extract(pf.detail,'$.stmt') IN ('select','fetch')""",
                tuple(closure_progs)):
            d = json.loads(r["detail"])
            sql_reads.append((d["column"], r["prog"],
                              d["column"].upper() in mapped_cols))
        # IDMS reads: mapping machinery is v1-pending — informational.
        idms_reads = [(r["ref"], r["prog"]) for r in conn.execute(
            f"""SELECT DISTINCT pf.ref, p2.name AS prog FROM program_facet pf
                JOIN program p2 ON p2.id = pf.program_id
                WHERE pf.kind = 'idms' AND p2.name IN ({marks})
                AND json_extract(pf.detail,'$.op') IN ('obtain','find','get')""",
            tuple(closure_progs))]
        # Screens: RECEIVE MAP needs the mapset mined.
        maps_needed = []
        for r in conn.execute(
                f"""SELECT DISTINCT pf.ref FROM program_facet pf
                    JOIN program p2 ON p2.id = pf.program_id
                    WHERE pf.kind = 'cics' AND p2.name IN ({marks})
                    AND json_extract(pf.detail,'$.op') = 'receive-map'""",
                tuple(closure_progs)):
            have = conn.execute("SELECT 1 FROM bms_field WHERE map = ?",
                                (r["ref"],)).fetchone()
            maps_needed.append((r["ref"], bool(have)))
        # Input files: contents needed at run time — informational.
        in_files = []
        dsn_of = {}
        for js in conn.execute("SELECT pgm, dds FROM jcl_step"):
            for dd in json.loads(js["dds"]):
                if js["pgm"] and dd.get("dsn"):
                    dsn_of[(js["pgm"], dd["dd"])] = dd["dsn"]
        for r in conn.execute(
                f"""SELECT pf.ref, pf.detail, p2.name AS prog
                    FROM program_facet pf
                    JOIN program p2 ON p2.id = pf.program_id
                    WHERE pf.kind = 'file' AND p2.name IN ({marks})""",
                tuple(closure_progs)):
            d = json.loads(r["detail"])
            reads = any(o["op"] in ("open-input", "open-i-o", "read")
                        for o in d.get("ops", []))
            if reads:
                in_files.append((r["ref"], dsn_of.get((r["prog"], r["ref"])),
                                 r["prog"]))
        # Run context — where it executes.
        run_at = [f"{js['job']} · {js['step_name']} (batch)"
                  for js in conn.execute(
                      """SELECT j.name AS job, s.step_name FROM jcl_step s
                         JOIN jcl_job j ON j.id = s.job_id WHERE s.pgm = ?""",
                      (p["name"],))]
        run_at += [f"{r['name']} · CICS LINK (online)" for r in conn.execute(
            """SELECT DISTINCT p2.name FROM program_facet pf
               JOIN program p2 ON p2.id = pf.program_id
               WHERE pf.kind='cics' AND pf.ref = ?
               AND json_extract(pf.detail,'$.op') IN ('link','xctl')""",
            (p["name"],))]

        blockers = ([f"ingest copybook {n}" for n, fid in copies if not fid]
                    + [f"ingest {t} (called by {c}) — or mark it a stub"
                       for t, st, _, c in calls if st == "missing"]
                    + [f"map DB2 column {col} (read by {pr})"
                       for col, pr, ok in sql_reads if not ok]
                    + [f"ingest mapset for map {m}"
                       for m, ok in maps_needed if not ok])
        fmt_of = {(r["db2_column"] or "").upper(): (r["format"] or "")
                  for r in conn.execute(
                      "SELECT db2_column, format FROM field_map"
                      " WHERE db2_column IS NOT NULL")}
        advisories = ([f"declare the format for {col} (read by {pr}) — "
                       f"dates need one or the value will not convert"
                       for col, pr, ok in sql_reads
                       if ok and not fmt_of.get(col.upper())]
                      + [f"resolve dynamic call via {t} in {c}"
                         for t, st, _, c in calls if st == "dynamic-unresolved"]
                      + [f"IDMS record {rec} (read by {pr}) — record mapping "
                         f"is a cobrun v1 open item" for rec, pr in idms_reads]
                      + [f"dataset contents for DD {dd}"
                         f"{' (' + dsn + ')' if dsn else ''} read by {pr}"
                         for dd, dsn, pr in in_files])
        result = {"copies": copies, "calls": calls, "sql_reads": sql_reads,
                "idms_reads": idms_reads, "maps": maps_needed,
                "in_files": in_files, "run_at": run_at,
                "blockers": blockers, "advisories": advisories,
                "verdict": ("ready" if not blockers and not advisories else
                            "advisory" if not blockers else "blocked")}
        memo["ready"][p["id"]] = result
        return result

    def _readiness_card(self, conn, p) -> str:
        r = self._readiness(conn, p)
        V = {"ready": ("resolved", "READY", "everything cobrun needs is in "
                       "the corpus"),
             "advisory": ("alert", "RUNNABLE", "runnable — with advisories"),
             "blocked": ("failed", "BLOCKED", "concrete items missing")}
        cls, lbl, sub = V[r["verdict"]]

        def li(items, cls_):
            return "".join(f"<li class={cls_}>{x}</li>" for x in items)

        rows = ""
        cp_ok = [n for n, fid in r["copies"] if fid]
        cp_no = [n for n, fid in r["copies"] if not fid]
        rows += (f"<tr><td>Copybooks</td><td>"
                 + (" ".join(f"<code>{esc(n)}</code> ✓" for n in cp_ok) or
                    "<span class=muted>none copied</span>")
                 + (" " + " ".join(f"<code class=missing>{esc(n)}</code> ✗"
                                   for n in cp_no)) + "</td></tr>")
        call_bits = []
        for t, st, via, c in r["calls"]:
            mark = {"resolved": "✓", "stubbed": "stub",
                    "missing": "✗", "dynamic-unresolved": "?"}[st]
            klass = " class=missing" if st in ("missing",
                                               "dynamic-unresolved") else ""
            act = ""
            if st == "missing":
                act = (f" <form method=post action='/stub' style='display:"
                       f"inline'><input type=hidden name=name value='{esc(t)}'>"
                       f"<input type=hidden name=back value='/prog/{p['id']}'>"
                       f"<button class=delbtn style='color:#33506e'>mark stub"
                       f"</button></form>")
            elif st == "stubbed":
                act = (f" <form method=post action='/stub/delete' style="
                       f"'display:inline'><input type=hidden name=name "
                       f"value='{esc(t)}'><input type=hidden name=back "
                       f"value='/prog/{p['id']}'>"
                       f"<button class=delbtn>unstub</button></form>")
            call_bits.append(f"<code{klass}>{esc(t)}</code> {mark}{act}")
        rows += (f"<tr><td>Calls (transitive)</td><td>"
                 + (" · ".join(call_bits) or "<span class=muted>none</span>")
                 + "</td></tr>")
        if r["sql_reads"]:
            rows += ("<tr><td>SQL reads</td><td>" + " · ".join(
                f"<code{'' if ok else ' class=missing'}>{esc(col)}</code> "
                f"{'✓' if ok else '✗ unmapped'}"
                for col, _, ok in r["sql_reads"]) + "</td></tr>")
        if r["maps"]:
            rows += ("<tr><td>Screens</td><td>" + " · ".join(
                f"<code{'' if ok else ' class=missing'}>{esc(m)}</code> "
                f"{'✓' if ok else '✗ mapset not ingested'}"
                for m, ok in r["maps"]) + "</td></tr>")
        if r["run_at"]:
            rows += ("<tr><td>Runs at</td><td>"
                     + " · ".join(esc(x) for x in r["run_at"]) + "</td></tr>")

        todo = ""
        if r["blockers"] or r["advisories"]:
            todo = ("<div class=panehead style='margin-top:14px'>To make it "
                    "runnable</div><ul class=readiness>"
                    + li([esc(b) for b in r["blockers"]], "blk")
                    + li([esc(a) for a in r["advisories"]], "adv") + "</ul>")
        return (f"<div class=card><div class=cardhead>"
                f"<h2 style='margin:0'>Dry-run readiness</h2>"
                f"<span><span class='badge {cls}' style='margin-left:0'>{lbl}"
                f"</span> <span class=muted>{sub}</span></span></div>"
                f"<table>{rows}</table>{todo}"
                f"<p class=muted style='margin:12px 0 0'>The closure cobrun "
                f"needs, checked against the corpus. Blockers (red) stop a "
                f"run; advisories are supplied at run time or pending in the "
                f"runner design. Stub a call the interpreter should never "
                f"enter — stub calls stay visible in the trace.</p></div>")

    def _dfr_start(self, conn, prog_id: str):
        """Kick off (or join) a background draft for the program. The
        job outlives the requesting page — navigating away costs
        nothing; the waiting room picks the result up whenever the
        analyst returns."""
        row = conn.execute(
            "SELECT id, name FROM program WHERE id = ?",
            (int(prog_id) if prog_id.isdigit() else 0,)).fetchone()
        if not row:
            self._send_json({"status": "error",
                             "error": "program not found"})
            return
        pid, name = row["id"], row["name"]
        cfg = investigate.get_llm(conn)
        now = time.time()
        with DFR_JOBS_LOCK:
            for k in [k for k, v in DFR_JOBS.items()
                      if v.get("finished") and now - v["finished"] > 3600]:
                DFR_JOBS.pop(k, None)
            job = DFR_JOBS.get(pid)
            if job and job["status"] in ("working", "done"):
                self._send_json({"status": job["status"]})
                return
            DFR_JOBS[pid] = {"status": "working", "md": None,
                             "error": None, "started": now,
                             "finished": None, "name": name,
                             "cancel": False}
        db_path = self.db_path

        def work():
            wconn = db.connect(db_path)
            try:
                md, err = assemble_dfr(wconn, name, cfg)
            except Exception as e:
                md, err = None, str(e)
            finally:
                wconn.close()
            with DFR_JOBS_LOCK:
                job = DFR_JOBS.get(pid)
                if not job or job.get("cancel"):
                    DFR_JOBS.pop(pid, None)   # canceled → discard
                    return
                job["md"], job["error"] = md, err
                job["status"] = "done" if md and not err else "error"
                job["finished"] = time.time()
        threading.Thread(target=work, daemon=True).start()
        self._send_json({"status": "working"})

    def _dfr_status(self, prog_id: str):
        pid = int(prog_id) if prog_id.isdigit() else 0
        with DFR_JOBS_LOCK:
            job = DFR_JOBS.get(pid)
            payload = ({"status": "none"} if not job else
                       {"status": job["status"],
                        "elapsed": int(time.time() - job["started"]),
                        "error": job["error"]})
        self._send_json(payload)

    def _dfr_cancel(self, prog_id: str):
        pid = int(prog_id) if prog_id.isdigit() else 0
        with DFR_JOBS_LOCK:
            job = DFR_JOBS.get(pid)
            if job and job["status"] == "working":
                job["cancel"] = True      # worker discards on finish
                DFR_JOBS.pop(pid, None)
            elif job:
                DFR_JOBS.pop(pid, None)   # done/error → just forget it
        self._send_json({"ok": True})

    def _dfr_file(self, prog_id: str):
        pid = int(prog_id) if prog_id.isdigit() else 0
        with DFR_JOBS_LOCK:
            job = DFR_JOBS.get(pid)
            md = job["md"] if job and job["status"] == "done" else None
            name = job["name"] if job else ""
        if not md:
            self._send("<div class=card>No finished draft — "
                       "start one from the program page.</div>", code=404)
            return
        raw = md.encode()
        try:
            self.send_response(200)
            self.send_header("Content-Type",
                             "text/markdown; charset=utf-8")
            self.send_header("Content-Disposition",
                             f'attachment; filename="DFR-{name}'
                             f'-draft.md"')
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)
        except (ConnectionError, BrokenPipeError, TimeoutError, OSError):
            pass

    def _prog_dfr_page(self, conn, prog_id: str):
        """The waiting room for a DFR draft. Drafting runs as a
        server-side job, so this page is just a window onto it:
        navigate away, come back, the draft is here. Auto-downloads
        the moment the job finishes."""
        row = conn.execute(
            "SELECT id, name FROM program WHERE id = ?",
            (int(prog_id) if prog_id.isdigit() else 0,)).fetchone()
        if not row:
            self._send("<div class=card>Program not found.</div>",
                       code=404)
            return
        pid, name = row["id"], row["name"]
        body = f"""<div class=card style='max-width:640px'>
<h1>Drafting the DFR — {esc(name)}</h1>
<p>The rules, inputs, outputs and formats assemble instantly from the
source; the model is writing the description and the summary. This
runs on the server — you can navigate anywhere and come back to this
page; the download starts by itself when the draft is ready.</p>
<p id=dfrstate><b>Starting…</b></p>
<p><button id=dfrcancel class=btnsm2 style='display:none'>Cancel</button></p>
<p><a href='/prog/{pid}/dfr.md?prose=0'>Skip the model — download the
draft without §1–§2 now</a> &nbsp;·&nbsp;
<a href='/prog/{pid}'>← Back to {esc(name)}</a></p>
</div>
<script>
(function() {{
  var state = document.getElementById('dfrstate'),
      cancel = document.getElementById('dfrcancel'),
      timer = null, downloaded = false;
  function show(html) {{ state.innerHTML = html; }}
  function deliver() {{
    if (downloaded) return;
    downloaded = true;
    location.href = '/prog/{pid}/dfr/file';
    show('<b>Done ✓</b> — DFR-{esc(name)}-draft.md is downloading. '
      + '<a href="/prog/{pid}/dfr/file">Download again</a> · '
      + '<a href="/prog/{pid}">Back to {esc(name)}</a>');
    cancel.style.display = 'none';
  }}
  function poll() {{
    fetch('/prog/{pid}/dfr/status')
      .then(function(r) {{ return r.json(); }})
      .then(function(d) {{
        if (d.status === 'working') {{
          show('<b>Working…</b> ' + (d.elapsed || 0) + 's');
          cancel.style.display = '';
        }} else if (d.status === 'done') {{
          clearInterval(timer); deliver();
        }} else if (d.status === 'error') {{
          clearInterval(timer); cancel.style.display = 'none';
          show('<b>Could not finish:</b> ' + (d.error || 'unknown')
            + '. The model may be offline — the no-model draft below '
            + 'still works.');
        }} else {{
          clearInterval(timer); cancel.style.display = 'none';
          show('Canceled. <a href="/prog/{pid}/dfr">Start again</a>');
        }}
      }});
  }}
  cancel.addEventListener('click', function() {{
    fetch('/prog/{pid}/dfr/cancel', {{method: 'POST'}});
  }});
  fetch('/prog/{pid}/dfr/start', {{method: 'POST'}})
    .then(function(r) {{ return r.json(); }})
    .then(function(d) {{
      if (d.status === 'done') {{ deliver(); return; }}
      if (d.status === 'error') {{
        show('<b>Could not start:</b> ' + (d.error || 'unknown'));
        return;
      }}
      poll();
      timer = setInterval(poll, 1000);
    }});
}})();
</script>"""
        self._send(body, f"Draft DFR · {name}")

    def _prog_dfr(self, conn, prog_id: str, qs=None):
        """The assembled DFR draft as a downloadable markdown file.
        Deterministic body; ?prose=0 skips the one model paragraph."""
        row = conn.execute(
            "SELECT name FROM program WHERE id = ?",
            (int(prog_id) if prog_id.isdigit() else 0,)).fetchone()
        if not row:
            self._send("<div class=card>Program not found.</div>",
                       code=404)
            return
        with_prose = (qs or {}).get("prose", ["1"])[0] != "0"
        cfg = investigate.get_llm(conn) if with_prose else None
        md, err = assemble_dfr(conn, row["name"], cfg,
                               with_prose=with_prose)
        if err:
            self._send(f"<div class=card>{esc(err)}</div>", code=404)
            return
        raw = md.encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/markdown; charset=utf-8")
        self.send_header("Content-Disposition",
                         f'attachment; filename="DFR-{row["name"]}'
                         f'-draft.md"')
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _program(self, conn, prog_id: str, qs=None):
        try:
            pid = int(prog_id)
        except ValueError:
            self._send("<div class=card>Bad program id.</div>", code=400)
            return
        p = conn.execute("""SELECT p.*, f.name AS file_name, f.id AS file_id, f.fmt,
                            f.encoding, a.name AS app_name, a.id AS app_id
                            FROM program p JOIN source_file f ON f.id = p.source_file_id
                            LEFT JOIN application a ON a.id = f.application_id
                            WHERE p.id = ?""", (pid,)).fetchone()
        if not p:
            self._send("<div class=card>Program not found.</div>", code=404)
            return
        paras = conn.execute("SELECT * FROM paragraph WHERE program_id = ? ORDER BY start_line",
                             (pid,)).fetchall()
        facets = conn.execute("SELECT * FROM program_facet WHERE program_id = ? ORDER BY kind, line",
                              (pid,)).fetchall()
        codes = conn.execute("""
            SELECT DISTINCT e.code, e.normalized, e.category FROM exception_link l
            JOIN exception_code e ON e.id = l.exception_id
            WHERE l.target_ref = ? AND l.relation IN ('emitted_by','raised_by')
            ORDER BY e.code""", (p["name"],)).fetchall()
        items = conn.execute(
            "SELECT * FROM data_item WHERE source_file_id = ? ORDER BY lineno",
            (p["file_id"],)).fetchall()

        by_kind: dict[str, list] = {}
        for f in facets:
            by_kind.setdefault(f["kind"], []).append(f)

        rules = by_kind.get("rule", [])
        tab = (qs or {}).get("tab", ["overview"])[0]
        trail = [(p["app_name"], f"/app/{p['app_id']}")] if p["app_id"] else []

        # readiness verdict, worn on the hero
        r = self._readiness(conn, p)
        V = {"ready": ("READY", "#7dd8a0", "runnable now"),
             "advisory": ("RUNNABLE", "#e6cd8a",
                          f"{len(r['advisories'])} advisor"
                          f"{'ies' if len(r['advisories']) != 1 else 'y'}"),
             "blocked": ("BLOCKED", "#f0a9a9",
                         f"{len(r['blockers'])} blocker"
                         f"{'s' if len(r['blockers']) != 1 else ''}")}
        vlbl, vcol, vsub = V[r["verdict"]]
        modes = program_modes(conn).get(p["name"]) or set()
        mode_txt = " · ".join(sorted(modes)) if modes else ""
        cats: dict = {}
        for c in codes:
            cats[c["category"]] = cats.get(c["category"], 0) + 1
        code_sub = " · ".join(f"{v} {k}{'s' if v != 1 else ''}"
                              for k, v in cats.items()) or "none mined"
        TV = {"ready": "#1e6b3d", "advisory": "#8a6410",
              "blocked": "#a63838"}

        # Draft-DFR handoff to the Investigate chat: the prompt names the
        # application's newest DFR as the format exemplar when one exists.
        exemplar = None
        if p["app_id"]:
            ex = conn.execute(
                "SELECT title FROM document WHERE application_id = ?"
                " AND COALESCE(kind,'dfr') = 'dfr'"
                " ORDER BY ingested_at DESC LIMIT 1",
                (p["app_id"],)).fetchone()
            exemplar = ex["title"] if ex else None
        draft_q = (
            f"Draft a DFR for the {p['name']} module. First profile it "
            f"with describe_program"
            + (f", and read the document '{exemplar}' to match its "
               f"section structure" if exemplar else "")
            + ". Then write: a module description; one numbered "
            "requirement per business rule (condition, action, exception "
            "code raised); and a section listing the exception codes "
            "with meanings. Mark it clearly as a draft derived from "
            "mined source, for SME review.")
        draft_btn = (f"<a class=viewbtn style='margin-left:10px' "
                     f"href='/prog/{pid}/dfr'>Draft DFR ↓</a>")

        parts = [crumbs(*trail, here=p["name"]),
                 f"""<div class=herowrap>
<div class=apphero>
<div class=herostage><span class=heropill>PROGRAM</span>
{f"<a class=heropill href='/app/{p['app_id']}' style='text-decoration:none'>{esc(p['app_name'])}</a>" if p['app_id'] else ""}
{f"<span class=heropill-role>{esc(mode_txt)}</span>" if mode_txt else ""}
<span class=herosub style='margin-left:auto;color:{vcol};font-weight:800;
letter-spacing:.08em;font-size:11.5px'>{vlbl}</span></div>
<h1>{esc(p['name'])}</h1>
<div class=herosub><a href='/file/{p['file_id']}'
 style='color:#b7c9dd'>{esc(p['file_name'])}</a> ·
 {esc(p['fmt'])} format · {esc(p['encoding'])}{draft_btn}</div>
</div>
<div class=herobase>
<div class=statiles>
{hero_tile(len(rules), "business rules", "mined decision gates",
           f"/prog/{pid}?tab=rules", "rule")}
{hero_tile(len(items), "data objects", "fields and layouts",
           f"/prog/{pid}?tab=data", "data")}
{hero_tile(len(codes), "codes", code_sub, "#codes", "code")}
{hero_tile(f"<span style='font-size:20px'>{vlbl}</span>", "dry run",
           vsub, "#readiness", "run", TV[r["verdict"]])}
</div>
</div>
</div>""",
                 f"<div class=tabbar>"
                 f"<a href='/prog/{pid}' class='{'on' if tab == 'overview' else ''}'>Overview</a>"
                 f"<a href='/prog/{pid}?tab=rules' class='{'on' if tab == 'rules' else ''}'>"
                 f"Business rules · {len(rules)}</a>"
                 f"<a href='/prog/{pid}?tab=data' class='{'on' if tab == 'data' else ''}'>"
                 f"Data objects · {len(items)}</a>"
                 f"<a href='/file/{p['file_id']}'>Source ↗</a></div>"]
        if tab == "overview":
            parts.append(f"<div id=readiness></div>")
            parts.append(self._readiness_card(conn, p))

        if tab == "rules":
            if rules:
                # Pure nested containers (actionless outer IFs whose
                # condition reappears as an inner rule's context) fold
                # into their leaves instead of rendering as
                # 'no action mined' cards.
                ctx_union = set()
                for f in rules:
                    d = json.loads(f["detail"]) if f["detail"] else {}
                    for c in (d.get("context") or []):
                        ctx_union.add((d.get("paragraph") or "", c))
                n_folded = 0
                rows_html = []
                for f in rules:
                    d = json.loads(f["detail"]) if f["detail"] else {}
                    code = d.get("code")
                    if (not d.get("actions") and not code
                            and (d.get("paragraph") or "",
                                 d.get("english") or d.get("condition")
                                 or "") in ctx_union):
                        n_folded += 1
                        continue
                    chip = ""
                    if code:
                        cr = conn.execute(
                            "SELECT normalized, category FROM exception_code"
                            " WHERE normalized = ?",
                            (db.normalize_code(code),)).fetchone()
                        if cr:
                            chip = (f" <a class=codechip style='font-size:12px;"
                                    f"padding:2px 10px;vertical-align:2px'"
                                    f" href='/x/{esc(cr['normalized'])}'>"
                                    f"<span class='dot d-{esc(cr['category'])}'"
                                    f" style='margin-right:0'></span>{esc(code)}</a>")
                    # severity rail: the linked code's category colours
                    # the card edge — what kind of consequence this gate
                    # has, visible before reading a word
                    rail = {"exception": "var(--red)", "alert": "var(--amber)",
                            "limitation": "var(--violet)",
                            "suspension": "#3c7edb",
                            "termination": "var(--violet)",
                            "indicator": "#2ea08a"}.get(
                        (cr["category"] if code and cr else ""),
                        "var(--line)")
                    ctx = d.get("context") or []
                    ctx_html = (
                        f"<div class=rulegiven>given "
                        + " and ".join(f"<b>{esc(c)}</b>" for c in ctx)
                        + "</div>" if ctx else "")
                    then_bits = []
                    for a in (d.get("actions") or []):
                        a = a.strip()
                        if a.lower().startswith("shows"):
                            then_bits.append(
                                f"<span class=rulemsg>{esc(a)}</span>")
                        else:
                            then_bits.append(esc(a))
                    then_html = (" &nbsp;·&nbsp; ".join(then_bits)
                                 or "<span class=muted>no action mined"
                                    "</span>")
                    rows_html.append(
                        f"<div class=rulecard style='border-left-color:{rail}'>"
                        f"<div class=rulewhen>When "
                        f"<b>{esc(d.get('english',''))}</b>{chip}</div>"
                        f"{ctx_html}"
                        f"<div class=rulethen>&rarr;&nbsp; {then_html}</div>"
                        f"<div class=rulesrc>"
                        f"<code>{esc(d.get('condition',''))}</code>"
                        f"<span class=muted style='white-space:nowrap'>"
                        f"{'paragraph <b>' + esc(d['paragraph']) + '</b> · ' if d.get('paragraph') else ''}"
                        f"<a href='/file/{p['file_id']}?hl={f['line']}'>line {f['line']}</a>"
                        f"</span></div></div>")
                parts.append(
                    f"<div class=card><h2>Business rules · mined from decision gates"
                    f"</h2><p class=muted style='margin-top:-6px'>Heuristic English "
                    f"reading of each IF / EVALUATE gate — the verbatim source below "
                    f"each rule is the truth."
                    + (f" {n_folded} nested container gate"
                       f"{'s' if n_folded != 1 else ''} folded into the "
                       f"leaf rules shown (their conditions appear as "
                       f"<i>given</i> lines)." if n_folded else "")
                    + f"</p>{''.join(rows_html)}</div>")
            else:
                parts.append("<div class=card><p class=muted>No decision gates mined "
                             "from this source.</p></div>")
            self._send("".join(parts), p["name"])
            return

        if tab == "data":
            if items:
                rows = "".join(
                    f"<tr><td style='padding-left:{12 + (i['level'] - 1) * 11}px'>"
                    f"{'<b>' if i['level'] == 1 else ''}{esc(i['name'])}"
                    f"{'</b>' if i['level'] == 1 else ''}</td>"
                    f"<td class=num>{i['level']:02d}</td>"
                    f"<td><code>{esc(i['pic'] or '—')}</code></td>"
                    f"<td>{esc(i['item_type'])}"
                    f"{' · ' + esc(i['usage']) if i['usage'] != 'DISPLAY' else ''}</td>"
                    f"<td class=num>{i['length'] if i['length'] is not None else '—'}</td>"
                    f"<td class=num>{i['occurs'] or ''}</td>"
                    f"<td class=muted><a href='/file/{p['file_id']}?hl={i['lineno']}'>"
                    f"line {i['lineno']}</a></td></tr>" for i in items)
                parts.append(
                    f"<div class=card><h2>Data objects · {esc(p['file_name'])}</h2>"
                    f"<table><tr><th>Name</th><th class=num>Lvl</th><th>PIC</th>"
                    f"<th>Type</th><th class=num>Bytes</th><th class=num>Occurs</th>"
                    f"<th>Where</th></tr>{rows}</table></div>")
            else:
                parts.append("<div class=card><p class=muted>No data items mined "
                             "from this source.</p></div>")
            self._send("".join(parts), p["name"])
            return

        if codes:
            chips = "".join(
                f"<a class=codechip href='/x/{esc(c['normalized'])}'>"
                f"<span class='dot d-{esc(c['category'])}' style='margin-right:0'></span>"
                f"{esc(c['code'])}</a>" for c in codes)
            parts.append(f"<div class=card id=codes><h2>Codes raised here · {len(codes)}</h2>"
                         f"<div>{chips}</div></div>")
        if paras:
            rows = "".join(f"<tr><td>{esc(x['name'])}</td>"
                           f"<td class=num><a href='/file/{p['file_id']}?hl={x['start_line']}'>"
                           f"{x['start_line']}–{x['end_line']}</a></td></tr>" for x in paras)
            parts.append(f"<div class=card><h2>Paragraphs · {len(paras)}</h2>"
                         f"<table><tr><th>Paragraph</th><th class=num>Lines</th></tr>"
                         f"{rows}</table></div>")
        for kind, title in (("copy", "Copybooks"), ("call", "Calls"),
                            ("sql", "SQL"), ("message", "Messages (alerts / limitations)")):
            if kind not in by_kind:
                continue
            rows = []
            for f in by_kind[kind]:
                d = json.loads(f["detail"]) if f["detail"] else {}
                extra = f" — <code>{esc(d['text'][:90])}</code>" if d.get("text") else ""
                extra = extra or (f" — <code>{esc(d['text2'])}</code>" if d.get("text2") else "")
                if kind == "message":
                    extra = f" {badge(f['ref'])} <code>{esc(d.get('text',''))}</code>"
                rows.append(f"<tr><td>{esc(f['ref']) if kind != 'message' else ''}"
                            f"{extra}</td><td>"
                            f"<a href='/file/{p['file_id']}?hl={f['line']}'>line {f['line']}</a>"
                            f"</td></tr>")
            parts.append(f"<div class=card><h2>{title}</h2><table>{''.join(rows)}</table></div>")
        self._send("".join(parts), p["name"])

    def _search(self, conn, q: str):
        parts = [f"<div class=card><h1>Search</h1><p class=muted>query: {esc(q)}</p></div>"]
        if q.strip():
            norm = db.normalize_code(q.strip())
            hit = conn.execute("SELECT * FROM exception_code WHERE normalized = ?",
                               (norm,)).fetchone()
            if hit:
                parts.append(f"<div class=card>Exception match: "
                             f"<a href='/x/{esc(norm)}'><b>{esc(hit['code'])}</b></a> "
                             f"{badge(hit['category'])}{badge(hit['status'])} "
                             f"{esc(hit['meaning'] or '')}</div>")
            tokens = query_tokens(q)
            if tokens:
                rows = conn.execute(
                    "SELECT file_id, lineno, text FROM line_fts WHERE tokens MATCH ?"
                    " LIMIT 60", (tokens,)).fetchall()
                files = {f["id"]: f for f in conn.execute("SELECT * FROM source_file")}
                res = "".join(
                    f"<tr><td><a href='/file/{r['file_id']}?hl={r['lineno']}'>"
                    f"{esc(files[r['file_id']]['name'])}</a></td>"
                    f"<td>{r['lineno']}</td><td><code>{esc(r['text'].strip()[:120])}</code></td></tr>"
                    for r in rows if r["file_id"] in files)
                parts.append(f"<div class=card><h2>Source hits ({len(rows)})</h2>"
                             f"<table><tr><th>File</th><th>Line</th><th>Text</th></tr>"
                             f"{res}</table></div>")
            secs = conn.execute(
                "SELECT s.*, d.title FROM doc_section s JOIN document d ON d.id = s.document_id"
                " WHERE s.text LIKE ? OR s.heading LIKE ? LIMIT 20",
                (f"%{q}%", f"%{q}%")).fetchall()
            if secs:
                res = "".join(
                    f"<div style='margin-bottom:10px'><b>{esc(s['title'])}</b> "
                    f"<span class=muted>§ {esc(s['heading'])}</span>"
                    f"<div class=quote>{esc(s['text'][:220])}</div></div>" for s in secs)
                parts.append(f"<div class=card><h2>Requirements / DFR hits</h2>{res}</div>")
        self._send("".join(parts), "Search", q=q)

    def _file(self, conn, file_id: str, qs):
        try:
            fid = int(file_id)
        except ValueError:
            self._send("<div class=card>Bad file id.</div>", code=400)
            return
        f = conn.execute("SELECT * FROM source_file WHERE id = ?", (fid,)).fetchone()
        if not f:
            self._send("<div class=card>File not found.</div>", code=404)
            return
        hl = int(qs.get("hl", ["0"])[0] or 0)
        rows = conn.execute(
            "SELECT lineno, text FROM line_fts WHERE file_id = ? ORDER BY lineno",
            (fid,)).fetchall()
        out = []
        for r in rows:
            line = f"{r['lineno']:>6}  {esc(r['text'])}"
            out.append(f"<mark id=hl>{line}</mark>" if r["lineno"] == hl else line)
        trail: list[tuple[str, str]] = []
        if f["application_id"]:
            app = conn.execute("SELECT id, name FROM application WHERE id = ?",
                               (f["application_id"],)).fetchone()
            if app:
                trail.append((app["name"], f"/app/{app['id']}"))
        prog = conn.execute("SELECT id, name FROM program WHERE source_file_id = ?",
                            (fid,)).fetchone()
        if prog:
            trail.append((prog["name"], f"/prog/{prog['id']}"))
        screens = ""
        if f["kind"] == "bms":
            allf = conn.execute(
                "SELECT * FROM bms_field WHERE source_file_id = ?"
                " ORDER BY lineno", (fid,)).fetchall()
            maps = list(dict.fromkeys((b["mapset"], b["map"]) for b in allf))
            placed = {m for _, m in maps if any(
                b["map"] == m and (b["map_line"] or 1) > 1 for b in allf)}
            # Header/body/footer maps (LINE > 1 anywhere) composite onto ONE
            # screen, as the terminal shows them; independent full-screen
            # maps render separately.
            if placed and len(maps) > 1:
                groups = [(maps[0][0], " + ".join(m for _, m in maps), allf)]
            else:
                groups = [(ms_, m, [b for b in allf if b["map"] == m])
                          for ms_, m in maps]
            for mapset, label, flds in groups:
                named = sum(1 for x in flds if x["name"])
                screens += (
                    f"<div class=card><h2>Screen — {esc(label)}"
                    f"{' · ' + esc(mapset) if mapset else ''} · 24×80 · "
                    f"{named} input/output fields</h2>"
                    f"<div class=screenwrap>{render_bms_screen(flds)}"
                    f"</div><p class=muted style='margin:10px 0 0'>Rendered "
                    f"from the mined mapset — attribute-byte offsets, COLOR "
                    f"and HILIGHT honoured, DRK fields non-display, ▌ marks "
                    f"the initial cursor. What the analyst actually sees. "
                    f"<a class=viewbtn href='/bms/lab?file={fid}' "
                    f"style='margin-left:8px'>Open in the Screen lab →</a>"
                    f"</p></div>")
        body = (crumbs(*trail, here=f["name"])
                + screens
                + f"<div class=card><h1>{esc(f['name'])}</h1>"
                f"<p class=muted>{esc(f['kind'])} · {esc(f['encoding'])} · "
                f"{esc(f['fmt'])} format · {f['line_count']} lines"
                f"{' · <a href=#hl>jump to line ' + str(hl) + '</a>' if hl else ''}</p>"
                # Production members run thousands of lines: the pane scrolls,
                # the page doesn't. The highlighted line anchors and centres
                # itself inside the pane on load.
                f"<div class=srcbar>"
                f"<input id=srcq placeholder='Search in this member — "
                f"Enter next · Shift+Enter previous · Esc clears' "
                f"autocomplete=off>"
                f"<span id=srccnt class=muted></span>"
                f"<button id=srcprev class=btnsm2 title='Previous match'>"
                f"&#8593;</button>"
                f"<button id=srcnext class=btnsm2 title='Next match'>"
                f"&#8595;</button></div>"
                f"<pre id=srcpane style='max-height:76vh;overflow:auto'>"
                f"{chr(10).join(out)}</pre></div>"
                + ("""<script>
(function(){
  // Centre the highlight INSIDE the pane without scrolling the page —
  // scrollIntoView would move every ancestor, including the window.
  var pane = document.getElementById('srcpane');
  var m = pane && pane.querySelector('mark');
  if (m) pane.scrollTop = m.getBoundingClientRect().top
      - pane.getBoundingClientRect().top + pane.scrollTop
      - pane.clientHeight / 2 + m.offsetHeight / 2;
})();
</script>""" if hl else "") + """<script>
(function(){
  var pane = document.getElementById('srcpane'),
      q = document.getElementById('srcq'),
      cnt = document.getElementById('srccnt'),
      prevb = document.getElementById('srcprev'),
      nextb = document.getElementById('srcnext');
  if (!pane || !q) return;
  var orig = pane.innerHTML, lines = pane.textContent.split('\\n'),
      cur = -1, total = 0, t = null;
  function h(x){ return x.replace(/&/g,'&amp;').replace(/</g,'&lt;')
      .replace(/>/g,'&gt;'); }
  function run(){
    var term = q.value;
    if (!term){ pane.innerHTML = orig; cnt.textContent = '';
      total = 0; cur = -1; return; }
    var low = term.toLowerCase(); total = 0;
    pane.innerHTML = lines.map(function(line){
      var ll = line.toLowerCase(), hit = ll.indexOf(low);
      if (hit < 0) return h(line);
      var out = '', i = 0;
      while (hit >= 0){
        out += h(line.slice(i, hit)) + '<mark class=fmatch data-m='
          + (total++) + '>' + h(line.slice(hit, hit + term.length))
          + '</mark>';
        i = hit + term.length;
        hit = ll.indexOf(low, i);
      }
      return out + h(line.slice(i));
    }).join('\\n');
    cur = total ? 0 : -1;
    show();
  }
  function show(){
    cnt.textContent = total ? (cur + 1) + ' of ' + total : 'no matches';
    var on = pane.querySelector('.fmatch.cur');
    if (on) on.classList.remove('cur');
    var el = pane.querySelector('[data-m="' + cur + '"]');
    if (el){ el.classList.add('cur');
      pane.scrollTop = el.getBoundingClientRect().top
        - pane.getBoundingClientRect().top + pane.scrollTop
        - pane.clientHeight / 2; }
  }
  function step(d){ if (total){ cur = (cur + d + total) % total;
      show(); } }
  q.addEventListener('input', function(){ clearTimeout(t);
    t = setTimeout(run, 220); });
  q.addEventListener('keydown', function(e){
    if (e.key === 'Enter'){ e.preventDefault();
      step(e.shiftKey ? -1 : 1); }
    if (e.key === 'Escape'){ q.value = ''; run(); }
  });
  nextb.addEventListener('click', function(){ step(1); });
  prevb.addEventListener('click', function(){ step(-1); });
})();
</script>""")
        self._send(body, f["name"])


def serve(db_path: str, port: int = 8765):
    Handler.db_path = db_path
    boot = db.connect(db_path)
    db.maintain(boot)
    boot.close()
    httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print(f"ChatBIS prototype → http://127.0.0.1:{port}")
    httpd.serve_forever()
