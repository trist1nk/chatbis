"""ChatBIS — minimal .xlsx reader for exception-MI extracts.

An .xlsx is a ZIP of XML (the .docx trick again): stdlib zipfile +
ElementTree read the first worksheet, resolving shared strings, inline
strings, and cached formula values. No third-party wheels — the corp-network
portability promise holds.

The DYNAMIC contract: nothing here knows what the statistic server's columns
are called. The caller gets the sheet exactly as-is (headers + rows);
guess_mapping() proposes which columns look like code / period / count /
application, and the analyst confirms in the UI. Every column of every row
is retained downstream, so a new column in next quarter's extract is data,
not a breakage.
"""
from __future__ import annotations

import csv
import io
import re
import zipfile
import xml.etree.ElementTree as ET
from datetime import date, timedelta

_NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"


def _col_index(ref: str) -> int:
    """'BC12' → 54 (0-based column)."""
    n = 0
    for ch in ref:
        if ch.isalpha():
            n = n * 26 + (ord(ch.upper()) - 64)
        else:
            break
    return n - 1


def read_xlsx(raw: bytes) -> list[list[str]]:
    """First worksheet as a rectangular list of string rows."""
    with zipfile.ZipFile(io.BytesIO(raw)) as zf:
        shared: list[str] = []
        if "xl/sharedStrings.xml" in zf.namelist():
            root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
            for si in root.findall(f"{_NS}si"):
                shared.append("".join(t.text or "" for t in si.iter(f"{_NS}t")))
        sheet = next((n for n in sorted(zf.namelist())
                      if re.match(r"xl/worksheets/sheet\d+\.xml$", n)), None)
        if not sheet:
            return []
        root = ET.fromstring(zf.read(sheet))
        rows: list[list[str]] = []
        for row in root.iter(f"{_NS}row"):
            cells: dict[int, str] = {}
            for c in row.findall(f"{_NS}c"):
                idx = _col_index(c.get("r") or "A")
                t = c.get("t")
                if t == "s":
                    v = c.find(f"{_NS}v")
                    val = shared[int(v.text)] if v is not None and v.text else ""
                elif t == "inlineStr":
                    val = "".join(x.text or "" for x in c.iter(f"{_NS}t"))
                else:
                    v = c.find(f"{_NS}v")
                    val = (v.text or "") if v is not None else ""
                cells[idx] = val
            if cells:
                rows.append([cells.get(i, "") for i in range(max(cells) + 1)])
        width = max((len(r) for r in rows), default=0)
        return [r + [""] * (width - len(r)) for r in rows]


def read_table(raw: bytes, filename: str) -> list[list[str]]:
    """Dispatch: .xlsx via the zip reader, anything else as CSV."""
    if filename.lower().endswith(".xlsx"):
        return read_xlsx(raw)
    text = raw.decode("utf-8-sig", "replace")
    return [row for row in csv.reader(io.StringIO(text)) if row]


def excel_serial_to_date(n: float) -> str:
    """Excel stores dates as day serials from 1899-12-30."""
    return (date(1899, 12, 30) + timedelta(days=int(n))).isoformat()


def coerce_period(value: str) -> str:
    """Periods stay opaque text (months, weeks, quarters all welcome) —
    except bare Excel date serials, which become ISO dates."""
    v = (value or "").strip()
    try:
        f = float(v)
        if 20000 <= f <= 80000:
            return excel_serial_to_date(f)
    except ValueError:
        pass
    return v


def guess_field_columns(headers: list[str]) -> dict:
    """Propose which columns hold the field-map roles. Same dynamic contract
    as guess_mapping(): read the file's own headers, propose, let the analyst
    confirm — nothing about the spreadsheet's shape is hardcoded."""
    hl = [(h or "").strip().lower() for h in headers]

    def find(words, exclude=()):
        for i, h in enumerate(hl):
            if any(w in h for w in words) and not any(x in h for x in exclude):
                return i
        return None

    return {
        "cobol": find(("cobol", "copybook", "wsfield", "ws field", "field name",
                       "elementary", "data name")),
        "db2": find(("db2", "column", "table", "sql")),
        "json": find(("json", "api", "path", "attribute", "response")),
        "label": find(("label", "description", "business", "meaning", "plain",
                       "title"), exclude=("column",)),
        "notes": find(("note", "comment", "remark", "usage", "format", "pic")),
    }


def read_field_map(raw: bytes, filename: str) -> tuple[list[str], list[list[str]]]:
    """(headers, rows) from .xlsx / .csv / .json.

    JSON accepts either an array of objects — keys become the columns — or a
    flat {"WS-BENE-DOB": "claimant.dateOfBirth"} dict, which is the shape
    people paste when they already have a COBOL→JSON crosswalk.
    """
    if filename.lower().endswith(".json"):
        import json as _json
        doc = _json.loads(raw.decode("utf-8-sig", "replace"))
        if isinstance(doc, dict):
            doc = [{"cobol_field": k, "json_path": v} for k, v in doc.items()]
        if not isinstance(doc, list) or not doc:
            return [], []
        headers: list[str] = []
        for item in doc:
            if isinstance(item, dict):
                for k in item:
                    if k not in headers:
                        headers.append(k)
        rows = [[str(it.get(h, "") if it.get(h) is not None else "")
                 for h in headers] for it in doc if isinstance(it, dict)]
        return headers, rows
    table = read_table(raw, filename)
    if not table:
        return [], []
    return table[0], table[1:]


def guess_mapping(headers: list[str]) -> dict:
    """Propose column roles from the file's own headers; the analyst
    confirms. None = not found (period/count/application are optional)."""
    hl = [(h or "").strip().lower() for h in headers]

    def find(words: tuple, exclude: tuple = ()) -> int | None:
        for i, h in enumerate(hl):
            if any(w in h for w in words) and not any(x in h for x in exclude):
                return i
        return None

    code = find(("code",), exclude=("sqlcode", "zip"))
    if code is None:
        code = find(("exception", "error", "abend"),
                    exclude=("count", "number", "total", "desc"))
    period = find(("period", "date", "month", "week", "cycle", "quarter"))
    count = find(("count", "volume", "occurrence", "qty", "number of", "total"))
    app = find(("application", "system", "app "), exclude=("code",))
    if app is None:
        app = find(("app",), exclude=("code",))
    return {"code": code, "period": period, "count": count, "application": app}
