#!/usr/bin/env python3
"""ChatBIS — exception triage workbench prototype. Stock Python only.

  python3 chatbis.py ingest <dir>     ingest a source tree (COBOL, copybooks,
                                    error-table CSVs; UTF-8 or EBCDIC)
  python3 chatbis.py serve [port]     run the web UI (default 8765)
  python3 chatbis.py lookup <code>    resolution summary on the console
  python3 chatbis.py seed-demo        add synthetic run/resolution history so
                                    the stats sections have something to show
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

from chatbis import db
from chatbis.ingest import ingest_tree
from chatbis.server import serve

DB_PATH = Path(__file__).parent / "chatbis.db"


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        return 1
    cmd = args[0]
    conn = db.connect(DB_PATH)

    if cmd == "ingest":
        if len(args) < 2:
            print("usage: chatbis.py ingest <dir> [--app NAME]")
            return 1
        app = None
        if "--app" in args:
            i = args.index("--app")
            app = args[i + 1] if i + 1 < len(args) else None
        summary = ingest_tree(conn, Path(args[1]), app_name=app)
        for row in summary:
            print(json.dumps(row))
        codes = conn.execute("SELECT COUNT(*) AS n FROM exception_code").fetchone()["n"]
        links = conn.execute("SELECT COUNT(*) AS n FROM exception_link").fetchone()["n"]
        by_cat = dict(conn.execute(
            "SELECT category, COUNT(*) FROM exception_code GROUP BY category").fetchall())
        print(f"\ncatalog: {codes} entries ({by_cat}), {links} links"
              + (f" · app={app}" if app else ""))
        return 0

    if cmd == "serve":
        port = int(args[1]) if len(args) > 1 else 8765
        serve(str(DB_PATH), port)
        return 0

    if cmd == "lookup":
        if len(args) < 2:
            print("usage: chatbis.py lookup <code>")
            return 1
        norm = db.normalize_code(args[1])
        r = conn.execute("SELECT * FROM exception_code WHERE normalized = ?", (norm,)).fetchone()
        if not r:
            print(f"unknown code: {args[1]}")
            return 1
        db.add_event(conn, r["id"], "lookup", actor="cli")
        conn.commit()
        print(f"{r['code']} [{r['status']}] {r['meaning'] or '(no curated meaning)'}")
        if r["screen_id"] or r["data_element"]:
            print(f"screen: {r['screen_id'] or '-'}  field: {r['data_element'] or '-'}")
        for l in conn.execute(
                "SELECT * FROM exception_link WHERE exception_id = ? ORDER BY relation",
                (r["id"],)):
            d = json.loads(l["detail"])
            loc = f"{d.get('file','')}:{d.get('line','')}"
            cond = f"  when {d['condition']}" if d.get("condition") else ""
            print(f"  {l['relation']:<12} {l['target_ref']:<20} {loc}{cond}")
        print(f"stats: {db.exception_stats(conn, r['id'])}")
        return 0

    if cmd == "seed-demo":
        # Deterministic synthetic history: heavier traffic on the first codes.
        rows = conn.execute(
            "SELECT id FROM exception_code WHERE scope = 'app' ORDER BY id LIMIT 6"
        ).fetchall()
        for i, row in enumerate(rows):
            for day in range(1, 15 - 2 * i):
                ts = f"2026-07-{day:02d}T09:00:00"
                db.add_event(conn, row["id"], "occurrence", payload={"batch": "NIGHTLY"}, ts=ts)
                if day % 2 == 0:
                    db.add_event(conn, row["id"], "resolution",
                                 outcome="resolved" if day % 6 else "escalated",
                                 payload={"cause": "demo seed", "action": "corrected field"},
                                 actor="seed", ts=ts)
        conn.commit()
        print("demo history seeded")
        return 0

    print(__doc__)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
